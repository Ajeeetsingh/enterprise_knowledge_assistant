# Apex National Bank — Master Company Profile

**Enterprise Reference Document | Single Source of Truth for Enterprise Knowledge Management**

---

## Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-REF-0001` |
| **Document Title** | Apex National Bank — Master Company Profile |
| **Version** | 4.0 |
| **Owner** | Enterprise Knowledge Management Office (EKMO), Administration Department (ADM) |
| **Document Custodian** | Nadine Okafor, Vice President, Enterprise Knowledge Management (G6) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer, Apex National Bank |
| **Secondary Approvers** | Margaret Sullivan, General Counsel; Samuel A. Okonkwo, Chief Compliance Officer |
| **Status** | Approved — Published |
| **Confidentiality** | Internal (C1) |
| **Created Date** | 2018-06-15 |
| **Last Updated** | 2026-06-30 |
| **Effective Date** | 2026-07-01 |
| **Review Cycle** | Annual (next scheduled review: 2027-06-30); event-driven review on material reorganization, acquisition, or regulatory change |
| **Supersedes** | `ANB-ADM-REF-0001-v3.4` (published 2025-06-28) |
| **Retention** | Permanent — corporate record; superseded versions retained 10 years in ApexVault |
| **Authoritative System of Record** | ApexDocs (Enterprise Document Management) |
| **Language / Locale** | English (US) — authoritative source text |
| **Related Documents (future references)** | `ANB-HRM-HBK-0001` Employee Handbook · `ANB-ADM-STD-0002` Document Retention Schedule · `ANB-ISC-STD-0004` Data Classification Standard · `ANB-RSK-POL-0001` Enterprise Risk Management Policy · `ANB-CMP-POL-0001` Anti-Money Laundering Policy · `ANB-CBK-POL-0001` Loan Approval Policy · `ANB-PRC-POL-0002` Third-Party Risk Management Policy · `ANB-ADM-STD-0005` Enterprise Metadata Standard |
| **Keywords** | Apex National Bank, company profile, master reference, organization structure, business units, departments, banking products, enterprise systems, document classification, naming standards, versioning, approval matrix, glossary, acronyms, knowledge taxonomy, metadata, governance |

> **Purpose of this document.** This profile is the canonical description of Apex National Bank's legal structure, organization, products, geography, systems, and documentation standards. All subsequently authored enterprise documents — policies, procedures, forms, contracts, customer records, audit reports, regulatory filings, meeting minutes, and correspondence — must align to the entity names, department names, department codes, job grades, system names, classification levels, and identifiers defined here. Where a downstream document conflicts with this profile, this profile prevails until formally amended.

---

## Table of Contents

1. [Company Overview](#1-company-overview)
2. [Organization Structure](#2-organization-structure)
3. [Banking Products](#3-banking-products)
4. [Geographic Presence](#4-geographic-presence)
5. [Employee Structure](#5-employee-structure)
6. [Corporate Policies Overview](#6-corporate-policies-overview)
7. [Departments](#7-departments)
8. [Enterprise Systems](#8-enterprise-systems)
9. [Document Classification](#9-document-classification)
10. [Document Naming Standards](#10-document-naming-standards)
11. [Versioning Standards](#11-versioning-standards)
12. [Approval Matrix](#12-approval-matrix)
13. [Business Terminology](#13-business-terminology)
14. [Acronyms](#14-acronyms)
15. [Future Document Dependency](#15-future-document-dependency)
16. [Appendix](#16-appendix)

---

## 1. Company Overview

### 1.1 Legal Identity

| Attribute | Detail |
|---|---|
| Legal Name (Bank) | Apex National Bank, National Association ("Apex National Bank", "ANB", "the Bank") |
| Parent Holding Company | Apex Financial Group, Inc. ("AFG", "the Group") — Delaware corporation |
| Listing | New York Stock Exchange — ticker `APXN` |
| Charter | National bank charter, Office of the Comptroller of the Currency (OCC), granted 1897 |
| Primary Federal Regulator | OCC; holding company supervised by the Federal Reserve Board (FRB) |
| Deposit Insurance | Federal Deposit Insurance Corporation (FDIC), Certificate No. 10428 |
| Other Supervisors | CFPB, FinCEN, SEC and FINRA (broker-dealer), FCA/PRA (UK), ECB and BaFin (EU), MAS (Singapore), HKMA (Hong Kong SAR), RBI (India), DFSA (UAE) |
| Headquarters | One Apex Plaza, 285 Greenwich Street, New York, NY 10007, United States |
| Legal Entity Identifier (LEI) | `5493001APEXNB0000C7` |
| SWIFT/BIC (Head Office) | `APXNUS33` |
| ABA Routing Number (US) | `021000418` |
| Fiscal Year | Calendar year: 1 January – 31 December |

**Principal subsidiaries and affiliates** (all referenced consistently in downstream documents):

- **Apex Securities LLC** — SEC-registered broker-dealer and FINRA member; underwriting, sales, trading.
- **Apex Asset Management, Inc.** — SEC-registered investment adviser; mutual funds and ETFs.
- **Apex Trust Company, N.A.** — fiduciary, trust, and estate administration.
- **Apex National Bank (UK) plc** — UK-authorised subsidiary, London.
- **Apex Bank Europe SE** — EU subsidiary, Frankfurt am Main.
- **Apex Global Services Private Limited** — captive service centre, Mumbai and Hyderabad ("Apex GSC").
- **Apex Insurance Agency, LLC** — licensed distribution agency (products underwritten by third parties).

### 1.2 Scale at a Glance (FY2025 audited, as at 31 December 2025)

| Metric | Value |
|---|---|
| Total assets | $1.34 trillion |
| Total deposits | $912 billion |
| Total loans, net | $684 billion |
| Assets under management (Wealth & Asset Management) | $1.10 trillion |
| Total revenue | $58.2 billion |
| Net income | $12.6 billion |
| Common Equity Tier 1 (CET1) ratio | 12.8% |
| Liquidity Coverage Ratio (LCR) | 128% |
| Employees (full-time equivalent) | 78,400 |
| Retail customers | 24.1 million |
| Business and commercial clients | 310,000 |
| Institutional clients | 3,400 |
| Branches (global) | 1,842 |
| ATMs | 4,600 |
| Countries of operation | 19 |

### 1.3 History

Apex National Bank traces its origin to **Apex Savings & Trust**, founded in **1873** in Hartford, Connecticut, to serve manufacturers and maritime traders in the Connecticut River Valley. The institution received a **national bank charter in 1897** and relocated its head office to New York City in **1911** to support correspondent banking for regional lenders.

| Period | Milestone |
|---|---|
| 1873 | Founded as Apex Savings & Trust, Hartford, Connecticut |
| 1897 | National bank charter granted; renamed Apex National Bank, N.A. |
| 1911 | Head office relocated to New York City |
| 1934 | Joined the FDIC following the Banking Act of 1933 |
| 1961 | Opened first overseas branch, London |
| 1978 | Launched proprietary card issuance; joined national ATM networks |
| 1986 | Formation of Apex Financial Group, Inc. as bank holding company |
| 1994 | Interstate expansion; acquisition of Lakeshore Federal (Chicago) — 240 branches |
| 2001 | Acquisition of Cordell Brothers & Co. — foundation of Corporate & Investment Banking |
| 2008–2010 | Acquisition of Meridian Trust Bancorp during market dislocation; conservative capital rebuild |
| 2014 | Launch of Apex Mobile; formal Digital Banking division established |
| 2017 | Establishment of Apex Global Services (Mumbai) captive operations centre |
| 2019 | Core banking modernization program ("Program Northstar") commenced |
| 2021 | Acquisition of Brightline Wealth Partners — $180 billion AUM added |
| 2023 | Apex Bank Europe SE established in Frankfurt following EU licensing |
| 2024 | Enterprise Data & AI Office created; Chief Data Officer appointed |
| 2025 | Program Northstar completed — ApexCore deployed across all US deposit and lending portfolios |
| 2026 | Enterprise Knowledge Management Office (EKMO) chartered to govern institutional knowledge |

### 1.4 Mission

> To steward our clients' financial lives with precision, integrity, and durability — providing dependable access to capital, safekeeping of deposits, and advice that improves long-term financial outcomes for households, businesses, and institutions.

### 1.5 Vision

> To be the most trusted and operationally resilient bank in every market we serve — where clients receive the same standard of judgment, transparency, and service whether they enter a branch in Charlotte, a corporate office in Singapore, or a mobile application at midnight.

### 1.6 Core Values

| Value | Definition | Observable Behaviour |
|---|---|---|
| **Integrity First** | The regulated obligation precedes the commercial opportunity. | Escalate concerns before deadlines; never suppress adverse information. |
| **Client Stewardship** | Client interest is assessed over the full life of the relationship. | Recommend the suitable product, not the profitable one. |
| **Disciplined Risk** | Risk is taken deliberately, priced correctly, and documented fully. | No undocumented exceptions; every limit has an owner. |
| **Operational Excellence** | Reliability is a product feature. | Root-cause every incident; measure against SLA, not intent. |
| **Respect and Inclusion** | Diverse judgment produces better decisions. | Challenge is invited; retaliation is a terminable offence. |
| **Accountability** | Every decision has a named owner and a written record. | Approvals are personal, evidenced, and auditable. |
| **Enduring Value** | Optimize for the next decade, not the next quarter. | Capital, liquidity, and talent decisions are cycle-tested. |

### 1.7 Corporate Culture

Apex National Bank operates a **documented-decision culture**. Material decisions are expected to exist in writing, with a named approver, a stated rationale, and a retained record. Informal approval — verbal, chat-based, or implied — is not recognised by Internal Audit or Compliance and does not constitute a control.

Cultural norms reinforced through performance management include:

- **Speak-up and escalation.** Employees at any grade may escalate directly to Compliance, Risk, or Internal Audit without line-manager consent. The Group operates a confidential Ethics Line administered by an independent third party.
- **Three Lines of Defence.** Business ownership (First Line), independent oversight by Risk and Compliance (Second Line), and independent assurance by Internal Audit (Third Line). Employees are expected to know which line they sit in.
- **Constructive challenge.** Committee minutes record dissent. A decision recorded without any challenge on a material matter is itself a governance finding.
- **Hybrid working.** Most non-branch, non-trading roles operate a hybrid model of three days on-site; branch, trading floor, cash operations, and certain supervised roles are fully on-site by regulatory necessity.
- **Learning obligation.** All employees complete mandatory annual training in AML/KYC, Information Security, Code of Conduct, Data Privacy, and role-specific regulatory modules.

### 1.8 Business Philosophy

1. **Balance sheet before earnings.** Capital adequacy, liquidity, and asset quality are protected ahead of short-term earnings targets.
2. **Through-the-cycle underwriting.** Credit standards are set for stress conditions, not benign conditions. Underwriting exceptions require formal, escalated approval and are reported to the Group Credit Committee monthly.
3. **Fee income diversification.** Wealth, treasury services, and advisory revenue reduce dependence on net interest margin.
4. **Regulatory relationships as an asset.** Supervisory engagement is proactive, factual, and consistent across jurisdictions.
5. **Build the utility, buy the commodity.** Client-differentiating capability is built in-house; commoditised capability is purchased from vetted vendors under the Third-Party Risk Management framework.
6. **Knowledge is an institutional asset.** Documented, classified, and retrievable knowledge is treated with the same governance discipline as financial capital — the founding rationale for this profile.

---

## 2. Organization Structure

### 2.1 Governance Framework

**Board of Directors** — 13 members (11 independent). Independent Chair: **Eleanor Whitcombe**.

| Board Committee | Chair | Mandate |
|---|---|---|
| Audit Committee | Priscilla Vance | Financial reporting integrity, external auditor, Internal Audit oversight |
| Risk Committee | Hugo Bertrand | Risk appetite, capital and liquidity adequacy, stress testing |
| Compensation & Human Capital Committee | Adaeze Nwosu | Executive pay, incentive risk alignment, succession |
| Nominating & Corporate Governance Committee | Eleanor Whitcombe | Board composition, governance policy |
| Technology & Operational Resilience Committee | Kenji Sato | Technology strategy, cyber resilience, third-party concentration |
| Public Responsibility & Compliance Committee | Marisol Reyes | Regulatory compliance, conduct, community reinvestment |

**Executive management committees** (referenced by name in all downstream governance documents):

- **Executive Committee (ExCo)** — chaired by the Group CEO; strategy, capital allocation, escalations.
- **Asset & Liability Committee (ALCO)** — chaired by the CFO; balance sheet, liquidity, interest rate risk, funds transfer pricing.
- **Group Credit Committee (GrCC)** — chaired by the CRO; large exposures, credit policy, exceptions.
- **Operational Risk Committee (ORC)** — chaired by the CRO; operational loss events, RCSA outcomes, resilience.
- **Financial Crime Committee (FCC)** — chaired by the Chief Compliance Officer; AML, sanctions, fraud typologies.
- **New Product Approval Committee (NPAC)** — chaired by the COO; product launches and material changes.
- **Change Advisory Board (CAB)** — chaired by the Head of IT Operations; production change authorisation.
- **Data Governance Council (DGC)** — chaired by the Chief Data Officer; data ownership, quality, lineage.
- **Enterprise Knowledge Council (EKC)** — chaired by the COO, secretariat EKMO; document standards, taxonomy, retention.
- **Disclosure Committee** — chaired by the CFO; external reporting accuracy.

### 2.2 Executive Leadership

| Role | Name | Grade | Reports To |
|---|---|---|---|
| Group Chief Executive Officer; President & CEO, Apex National Bank | Marcus D. Whitfield | G12 | Board of Directors |
| Chief Financial Officer | Priya Raghunathan | G11 | Group CEO |
| Chief Operating Officer | Daniel K. Ortega | G11 | Group CEO |
| Chief Risk Officer | Helena Brandt | G11 | Group CEO (with reporting line to Board Risk Committee) |
| Chief Compliance Officer | Samuel A. Okonkwo | G11 | Group CEO (with reporting line to Public Responsibility & Compliance Committee) |
| General Counsel & Corporate Secretary | Margaret Sullivan | G11 | Group CEO |
| Chief Information Officer | Arjun Patel | G11 | Chief Operating Officer |
| Chief Information Security Officer | Nadia Ferreira | G10 | Chief Information Officer (with reporting line to Technology & Operational Resilience Committee) |
| Chief Human Resources Officer | Yvonne Carter | G11 | Group CEO |
| Chief Data Officer | Elena Vasquez | G10 | Chief Operating Officer |
| Chief Audit Executive | Thomas Nakamura | G11 | Board Audit Committee (administratively, Group CEO) |
| Chief Marketing Officer | Rachel Osei | G10 | Group CEO |
| Chief Procurement Officer | Ian McAllister | G10 | Chief Operating Officer |
| Head of Consumer & Retail Banking | Gregory Lin | G10 | Group CEO |
| Head of Commercial Banking | Alicia Moreau | G10 | Group CEO |
| Head of Corporate & Investment Banking | Jonathan Reeves | G10 | Group CEO |
| Head of Wealth & Asset Management | Sofia Almeida | G10 | Group CEO |
| Group Treasurer; Head of Treasury & Markets | David Chen | G10 | Chief Financial Officer |

### 2.3 Business Units

| Code | Business Unit | Scope | FY2025 Revenue |
|---|---|---|---|
| **CRB** | Consumer & Retail Banking | Branches, deposits, consumer lending, mortgages, cards, digital banking | $21.4B |
| **CMB** | Commercial Banking | Middle-market and small-business lending, commercial real estate, equipment finance, business cash management | $9.8B |
| **CIB** | Corporate & Investment Banking | Large-corporate lending, syndications, debt and equity capital markets, M&A advisory, transaction banking, trade finance | $14.1B |
| **WAM** | Wealth & Asset Management | Private client, advisory, trust, retirement, asset management | $7.6B |
| **TM** | Treasury & Markets | Balance-sheet management, FX, rates, securities portfolio, liquidity and funding | $5.3B |
| **ETO** | Enterprise Technology & Operations | Technology, security, operations, payments processing, service centres | Cost centre |
| **CC** | Corporate Centre | Finance, Risk, Compliance, Legal, HR, Internal Audit, Marketing, Procurement, Administration | Cost centre |

### 2.4 Departments and Department Codes

The following **fifteen department names and three-letter codes are canonical**. No downstream document may introduce alternative names, abbreviations, or spellings for these functions.

| Code | Department | Business Unit | Department Head | Grade | Headcount |
|---|---|---|---|---|---|
| `HRM` | Human Resources | Corporate Centre | Yvonne Carter (CHRO) | G11 | 1,180 |
| `FIN` | Finance | Corporate Centre | Priya Raghunathan (CFO) | G11 | 2,340 |
| `RTL` | Retail Banking | CRB | Gregory Lin | G10 | 31,600 |
| `CBK` | Corporate Banking | CIB / CMB | Jonathan Reeves | G10 | 7,900 |
| `TRY` | Treasury | TM | David Chen | G10 | 640 |
| `LEG` | Legal | Corporate Centre | Margaret Sullivan (GC) | G11 | 720 |
| `CMP` | Compliance | Corporate Centre | Samuel A. Okonkwo (CCO) | G11 | 1,960 |
| `RSK` | Risk | Corporate Centre | Helena Brandt (CRO) | G11 | 2,850 |
| `ISC` | Information Security | ETO | Nadia Ferreira (CISO) | G10 | 910 |
| `ITO` | IT Operations | ETO | Arjun Patel (CIO) | G11 | 9,700 |
| `CST` | Customer Support | CRB | Marcus Adeyemi | G9 | 11,400 |
| `IAD` | Internal Audit | Independent (Board) | Thomas Nakamura (CAE) | G11 | 780 |
| `MKT` | Marketing | Corporate Centre | Rachel Osei (CMO) | G10 | 640 |
| `PRC` | Procurement | Corporate Centre | Ian McAllister (CPO) | G10 | 380 |
| `ADM` | Administration | Corporate Centre | Claire Bennett | G9 | 1,020 |

*Remaining headcount (4,380 FTE) sits within Wealth & Asset Management client-facing teams, Commercial Banking coverage, and Apex Securities LLC, which are reported as business-unit rather than departmental headcount.*

### 2.5 Reporting Hierarchy

```
Board of Directors
└── Group Chief Executive Officer (G12)
    ├── Chief Financial Officer (G11) ──────── Finance (FIN)
    │   └── Group Treasurer (G10) ─────────── Treasury (TRY)
    ├── Chief Operating Officer (G11)
    │   ├── Chief Information Officer (G11) ── IT Operations (ITO)
    │   │   └── Chief Information Security Officer (G10) ── Information Security (ISC)
    │   ├── Chief Data Officer (G10)
    │   ├── Chief Procurement Officer (G10) ── Procurement (PRC)
    │   └── Head of Administration (G9) ────── Administration (ADM) ── EKMO
    ├── Chief Risk Officer (G11) ───────────── Risk (RSK)
    ├── Chief Compliance Officer (G11) ─────── Compliance (CMP)
    ├── General Counsel (G11) ──────────────── Legal (LEG)
    ├── Chief Human Resources Officer (G11) ── Human Resources (HRM)
    ├── Chief Marketing Officer (G10) ──────── Marketing (MKT)
    ├── Head of Consumer & Retail Banking (G10)
    │   ├── Retail Banking (RTL)
    │   └── Customer Support (CST)
    ├── Head of Commercial Banking (G10)
    ├── Head of Corporate & Investment Banking (G10) ── Corporate Banking (CBK)
    └── Head of Wealth & Asset Management (G10)

Chief Audit Executive (G11) ── Internal Audit (IAD)
    └── Reports functionally to the Board Audit Committee (independent of management)
```

### 2.6 Department Responsibilities (Summary)

| Department | Primary Accountability | Line of Defence |
|---|---|---|
| Human Resources | Workforce lifecycle, conduct, compensation governance | First |
| Finance | Financial control, regulatory capital reporting, planning | First / Second (control) |
| Retail Banking | Consumer and small-business relationships and origination | First |
| Corporate Banking | Corporate and institutional coverage, credit origination | First |
| Treasury | Liquidity, funding, interest-rate and FX balance-sheet risk | First |
| Legal | Legal risk, contracts, litigation, corporate secretariat | Second |
| Compliance | Regulatory compliance, financial crime, conduct surveillance | Second |
| Risk | Credit, market, operational, and model risk oversight | Second |
| Information Security | Cyber defence, identity, data protection controls | Second (with First Line operational duties) |
| IT Operations | Availability, change, infrastructure, application support | First |
| Customer Support | Service delivery, complaints, dispute resolution | First |
| Internal Audit | Independent assurance over governance and controls | Third |
| Marketing | Brand, communications, regulated marketing review | First |
| Procurement | Sourcing, vendor contracts, third-party risk intake | First / Second (control) |
| Administration | Corporate services, records, facilities, knowledge management | First |

---

## 3. Banking Products

All product names below are canonical. Downstream product documentation, disclosures, and application forms must use these exact names.

### 3.1 Savings

| Product | Description | Notes |
|---|---|---|
| Apex Everyday Savings | Basic interest-bearing savings account | $25 minimum opening deposit; fee waived with linked checking |
| Apex High-Yield Savings | Tiered-rate digital savings account | Online origination only; $1,000 minimum balance for top tier |
| Apex Youth Saver | Custodial savings for account holders under 18 | Requires joint adult ownership; converts at age 18 |
| Apex Money Market Account | Higher-rate account with limited transactional access | Tiered rates; check-writing permitted |
| Apex Certificate of Deposit (CD) | Fixed-term deposits, 3 months to 60 months | Early withdrawal penalty schedule applies |
| Apex CD Ladder | Structured multi-maturity CD program | Advisory-supported product; sold through branches and Wealth |
| Apex Health Savings Account (HSA) | Tax-advantaged medical savings | Administered with third-party recordkeeper |

### 3.2 Checking

| Product | Target Segment | Key Features |
|---|---|---|
| Apex Essential Checking | Entry-level consumer | No minimum balance; standard debit card |
| Apex Advantage Checking | Mass-market consumer | Interest-bearing; ATM fee rebates |
| Apex Premier Checking | Affluent consumer | Relationship pricing; preferential FX; concierge servicing |
| Apex Student Checking | Ages 17–24 in full-time education | Fee-exempt; overdraft opt-in restricted |
| Apex Business Checking | Small business and professional firms | Transaction allowances; integrated merchant services |
| Apex Commercial Operating Account | Middle-market and corporate | Earnings credit rate; sweep and zero-balance structures |

### 3.3 Loans (Consumer)

- **Apex Personal Loan** — unsecured instalment loan, $2,000–$100,000, 12–84 months, fixed rate.
- **Apex Auto Loan** — secured vehicle financing, new and used, direct and dealer-indirect channels.
- **Apex Home Equity Line of Credit (HELOC)** — revolving line secured by residential property, up to 85% combined LTV.
- **Apex Home Equity Loan** — fixed-rate closed-end second lien.
- **Apex Student Refinance Loan** — refinancing of qualifying education debt.
- **Apex Overdraft Line of Credit** — linked revolving line for checking overdraft protection.

### 3.4 Mortgages

| Product | Description |
|---|---|
| Apex Fixed-Rate Mortgage | 10, 15, 20, and 30-year conforming fixed-rate loans |
| Apex Adjustable-Rate Mortgage (ARM) | 5/6, 7/6, and 10/6 SOFR-indexed adjustable products |
| Apex Jumbo Mortgage | Non-conforming loans above the FHFA conforming limit; portfolio-retained |
| Apex Government Mortgage | FHA and VA insured/guaranteed lending |
| Apex Construction-to-Permanent | Single-close construction financing converting to permanent term |
| Apex Investment Property Mortgage | 1–4 unit non-owner-occupied residential financing |

Mortgage origination is executed on **ApexOrigin**; servicing is retained in-house for portfolio loans and sub-serviced for agency-sold loans. Governing documents: `ANB-RTL-FRM-0002` Mortgage Application and `ANB-CBK-POL-0001` Loan Approval Policy.

### 3.5 Corporate Banking

Coverage for corporates with annual revenue above $500 million, financial institutions, sovereigns, and public sector entities:

- Bilateral and syndicated term lending, revolving credit facilities, and bridge financing
- Debt Capital Markets (investment-grade and leveraged issuance) via Apex Securities LLC
- Equity Capital Markets (IPO, follow-on, convertibles) via Apex Securities LLC
- Mergers & acquisitions advisory
- Transaction banking: liquidity management, global payments, receivables and payables
- Trade finance: documentary credits, standby letters of credit, guarantees, supply-chain finance
- Escrow, agency, and trustee services via Apex Trust Company, N.A.

### 3.6 Commercial Lending

For businesses with revenue between $10 million and $500 million:

- Commercial term loans and revolving lines of credit
- Commercial real estate (CRE) — acquisition, construction, and permanent financing
- Equipment finance and leasing
- Asset-based lending (ABL) against receivables and inventory
- SBA 7(a) and 504 lending (US only)
- Owner-occupied property finance and business acquisition finance

### 3.7 Treasury

Treasury products serve both internal balance-sheet management and client requirements:

- Wholesale funding: certificates of deposit, commercial paper, senior and subordinated debt issuance
- Securities portfolio management (HQLA, agency MBS, municipals)
- Repurchase and reverse repurchase agreements
- Foreign exchange: spot, forward, swaps, non-deliverable forwards
- Interest rate derivatives: swaps, caps, floors, collars (client hedging and ALM)
- Funds Transfer Pricing (FTP) administration across all business units
- Intraday liquidity and nostro management

### 3.8 Investments

- **Apex Invest** — self-directed brokerage platform (equities, ETFs, fixed income, options).
- **Apex Managed Portfolios** — discretionary model portfolios across five risk profiles.
- **Apex Retirement Services** — Traditional and Roth IRAs, SEP-IRAs, and employer 401(k) recordkeeping.
- **Apex Funds** — proprietary mutual funds and ETFs managed by Apex Asset Management, Inc.
- **Apex Structured Notes** — principal-protected and yield-enhancement notes (Restricted distribution; suitability-gated).

### 3.9 Credit Cards

| Card | Segment | Positioning |
|---|---|---|
| Apex Cash Rewards Card | Mass consumer | Flat cash-back on all purchases |
| Apex Travel Signature Card | Affluent consumer | Travel points, lounge access, no FX fee |
| Apex Platinum Elite Card | Private client | Annual fee, concierge, premium travel protection |
| Apex Secured Card | Credit-building | Cash-collateralised; graduation pathway |
| Apex Business Card | Small business | Expense controls, employee cards, accounting integration |
| Apex Corporate Card | Commercial / corporate | Central billing, T&E controls, ApexLedger integration |

### 3.10 Insurance Partnerships

Apex Insurance Agency, LLC distributes third-party underwritten products. The Bank does not underwrite insurance risk.

| Partner (underwriter) | Products Distributed |
|---|---|
| Meridian Life Assurance Company | Term life, whole life, annuities |
| Northgate Property & Casualty Group | Homeowners, renters, auto |
| Sentinel Title Insurance Company | Title insurance for mortgage originations |
| Harborview Specialty Insurance | Commercial property, general liability, cyber |

All distribution operates under `ANB-CMP-POL-0009` Insurance Distribution & Suitability Policy (planned) with mandatory disclosure that products are not FDIC insured, not bank guaranteed, and may lose value.

### 3.11 Digital Banking

- **Apex Mobile** — iOS and Android application; biometric authentication, mobile deposit, card controls, dispute initiation.
- **Apex Online** — responsive web banking for consumer and small business.
- **Apex Business Online** — multi-user entitlement platform with dual-authorisation payment release.
- **Apex Instant** — real-time person-to-person payments (RTP and FedNow rails).
- **Apex Connect** — developer portal and open banking APIs (account information, payment initiation) for accredited third parties.
- **Apex Assist** — virtual assistant with authenticated servicing and human handoff to Customer Support.

### 3.12 Wealth Management

| Tier | Eligibility | Service Model |
|---|---|---|
| Apex Wealth Advisory | $250,000 – $2,000,000 investable assets | Advisor-led, model portfolios |
| Apex Private Client | $2,000,000 – $25,000,000 | Dedicated banker, bespoke lending, tax-aware planning |
| Apex Family Office Services | Above $25,000,000 | Multi-generational planning, consolidated reporting, philanthropic advisory |
| Apex Trust & Estate Services | All tiers | Trustee, executor, custody, and estate administration via Apex Trust Company, N.A. |

### 3.13 International Banking

- Multi-currency accounts in 24 currencies
- Cross-border payments via SWIFT, SEPA, CHAPS, Fedwire, RTGS, and NEFT (India)
- Correspondent banking and nostro/vostro account services (subject to enhanced due diligence)
- Documentary trade finance and export credit agency financing
- Global payroll and treasury services for multinational clients
- Expatriate banking packages for relocated corporate employees

---

## 4. Geographic Presence

### 4.1 Headquarters

**One Apex Plaza, 285 Greenwich Street, New York, NY 10007, United States.** Houses the Executive Committee, Corporate Centre functions, Corporate & Investment Banking, Treasury & Markets trading floors, and the Board room. Designated primary site for Group governance; secondary governance site is Charlotte under the Business Continuity Plan.

### 4.2 Regional Offices

| Office | Role | Coverage |
|---|---|---|
| Charlotte, North Carolina | US Operations Centre; secondary governance site | Southeast US; enterprise operations and disaster recovery |
| Chicago, Illinois | Midwest regional headquarters | Commercial Banking Midwest |
| Dallas, Texas | Southwest regional headquarters; card operations | Southwest US; consumer cards |
| San Francisco, California | West regional headquarters; technology hub | West US; digital engineering |
| Toronto, Canada | Canada country head office | Canada |
| London, United Kingdom | EMEA regional headquarters | UK, Ireland, EMEA markets |
| Frankfurt, Germany | EU regional headquarters (Apex Bank Europe SE) | Eurozone |
| Dubai, UAE | Middle East and Africa regional headquarters | UAE, Saudi Arabia, South Africa |
| Singapore | APAC regional headquarters | Southeast Asia, Australia |
| Hong Kong SAR | North Asia hub | Hong Kong SAR, Japan |
| Mumbai, India | Apex Global Services; India country office | India; global operations support |
| Hyderabad, India | Apex Global Services — technology delivery centre | Global technology support |
| São Paulo, Brazil | Latin America regional office | Brazil, Mexico |
| Sydney, Australia | Australia country office | Australia |

### 4.3 Branches

| Region | Retail Branches | ATMs |
|---|---|---|
| Northeast US | 486 | 1,240 |
| Southeast US | 402 | 1,010 |
| Midwest US | 358 | 890 |
| Southwest US | 291 | 720 |
| West US | 243 | 610 |
| International (full-service and corporate branches) | 62 | 130 |
| **Total** | **1,842** | **4,600** |

Branch formats: **Flagship** (full-service, advisory suites, safe deposit), **Community** (standard retail), **Express** (self-service assisted), and **In-Store** (partner retail locations). Branch operating standards are defined in `ANB-RTL-SOP-0004` Branch Operations Manual (planned).

### 4.4 Countries Served

Nineteen countries of licensed operation:

**Americas (5)** — United States, Canada, Mexico, Brazil, Cayman Islands (booking centre)
**EMEA (8)** — United Kingdom, Ireland, Germany, France, Netherlands, Switzerland, Luxembourg, South Africa
**Middle East (2)** — United Arab Emirates, Saudi Arabia
**Asia-Pacific (4)** — India, Singapore, Hong Kong SAR, Japan, Australia

*(Australia is served through the Sydney country office; total licensed jurisdictions = 19 including Cayman Islands booking centre.)*

Clients in additional jurisdictions are served on a cross-border basis only where permitted under `ANB-CMP-POL-0011` Cross-Border Marketing & Solicitation Policy (planned).

---

## 5. Employee Structure

### 5.1 Job Levels and Grades

| Grade | Level Band | Standard Title | Typical Scope |
|---|---|---|---|
| G1 | Entry | Associate | Teller, Operations Associate, Contact Centre Associate |
| G2 | Professional | Analyst | Credit Analyst, Compliance Analyst, Software Engineer I |
| G3 | Professional | Senior Analyst | Senior Credit Analyst, Software Engineer II, Auditor |
| G4 | Supervisory | Officer / Assistant Manager | Assistant Branch Manager, Team Lead, Senior Engineer |
| G5 | Management | Assistant Vice President (AVP) | Branch Manager, Compliance Officer, Engineering Manager |
| G6 | Management | Vice President (VP) | Relationship Manager, Product Manager, Risk Manager |
| G7 | Senior Management | Senior Vice President (SVP) | Regional Manager, Head of Function (sub-department) |
| G8 | Senior Management | Executive Director (ED) | Divisional lead, Head of large function |
| G9 | Executive | Managing Director (MD) | Department Head, Head of Customer Support/Administration |
| G10 | Executive | Group Head / Division Executive | Business Unit Head, CISO, CDO, CMO, CPO |
| G11 | Executive Committee | Chief Officer (C-suite) | CFO, COO, CRO, CCO, GC, CIO, CHRO, CAE |
| G12 | Group Executive | Group Chief Executive Officer | Group CEO |

### 5.2 Titles by Function (Illustrative and Canonical)

| Department | G2–G3 | G5–G6 | G7–G9 |
|---|---|---|---|
| Retail Banking | Personal Banker | Branch Manager (AVP) | Regional Retail Director (SVP/ED) |
| Corporate Banking | Credit Analyst | Relationship Manager (VP) | Sector Head (ED/MD) |
| Risk | Risk Analyst | Risk Manager (VP) | Head of Credit Risk (MD) |
| Compliance | Compliance Analyst | Compliance Officer (AVP/VP) | Head of Financial Crime (MD) |
| Information Security | Security Analyst | Security Engineering Manager (VP) | Head of Cyber Defence (ED) |
| IT Operations | Software Engineer | Engineering Manager (VP) | Head of Platform Engineering (MD) |
| Finance | Financial Analyst | Finance Manager (VP) | Group Financial Controller (MD) |
| Internal Audit | Auditor | Audit Manager (VP) | Head of Audit — Business Line (ED) |

### 5.3 Approval Hierarchy — Financial Authority (Non-Credit Expenditure)

| Grade | Single-Transaction Limit | Annual Cumulative Limit |
|---|---|---|
| G1–G3 | $5,000 | $25,000 |
| G4 | $25,000 | $150,000 |
| G5 (AVP) | $100,000 | $600,000 |
| G6 (VP) | $500,000 | $3,000,000 |
| G7 (SVP) | $2,000,000 | $12,000,000 |
| G8 (ED) | $10,000,000 | $50,000,000 |
| G9 (MD) | $25,000,000 | $120,000,000 |
| G10 (Group Head) | $100,000,000 | Business plan limit |
| G11 (ExCo member) | $250,000,000 | Approved budget |
| Board of Directors | Above $250,000,000 | Unlimited within charter |

**Rules of application.** Authority is personal and non-delegable except through a written, time-bounded delegation recorded in ApexServe. Transaction splitting to remain below a threshold is a Code of Conduct violation. All expenditure above $1,000,000 additionally requires Procurement (PRC) sourcing sign-off; above $10,000,000 requires Finance (FIN) and Legal (LEG) sign-off.

### 5.4 Approval Hierarchy — Credit Authority

| Authority Level | Consumer Unsecured | Consumer Secured / Mortgage | Commercial / Corporate |
|---|---|---|---|
| Automated decisioning (ApexOrigin scorecard) | ≤ $25,000 | ≤ $500,000 conforming | Not applicable |
| Branch Manager (G5) | ≤ $50,000 | Referral only | Not applicable |
| Credit Manager (G6) | ≤ $150,000 | ≤ $1,500,000 | ≤ $1,000,000 |
| Senior Credit Officer (G7) | ≤ $250,000 | ≤ $5,000,000 | ≤ $10,000,000 |
| Regional Credit Committee | — | ≤ $15,000,000 | ≤ $50,000,000 |
| Group Credit Committee (GrCC) | — | > $15,000,000 | ≤ $500,000,000 |
| Board Risk Committee | — | — | > $500,000,000 |

All credit exceptions to policy, regardless of amount, escalate one authority level above the level that would otherwise approve the exposure.

### 5.5 Decision Matrix (RACI)

| Decision Type | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| New product launch | Product Manager (G6) | Business Unit Head (G10) | Risk, Compliance, Legal, Finance, ITO | NPAC, Internal Audit |
| Credit exposure above $50M | Relationship Manager (G6) | Chief Risk Officer (G11) | Corporate Banking, Legal | Group Credit Committee |
| Material technology change | Change Owner (G5) | Head of IT Operations (G11) | Information Security, affected business | CAB, Internal Audit |
| Policy issuance or amendment | Policy Author (G5–G6) | Department Head (G9–G11) | Legal, Compliance, EKMO | All staff in scope |
| Vendor onboarding above $1M | Category Manager (G6) | Chief Procurement Officer (G10) | Legal, Risk, Information Security, Finance | Business sponsor |
| Regulatory filing | Regulatory Reporting Manager (G6) | Chief Financial Officer (G11) | Compliance, Legal | Disclosure Committee |
| Employee termination for conduct | HR Business Partner (G6) | Department Head (G9–G11) | Legal, Compliance | CHRO |
| Data classification change | Data Steward (G5) | Chief Data Officer (G10) | Information Security, Legal | Data Governance Council |
| Public communication / press release | Communications Manager (G6) | Chief Marketing Officer (G10) | Legal, Compliance, Investor Relations | ExCo |
| Business continuity invocation | Site Incident Manager (G6) | Chief Operating Officer (G11) | ITO, ISC, affected business, Communications | Board, regulators |

---

## 6. Corporate Policies Overview

This section describes the corporate policy estate that governs Apex National Bank. Each policy listed here **will be issued as a separate controlled document**; this section states scope and ownership only and does not constitute the policy itself. Full text, control requirements, and procedures reside in the referenced documents.

| Policy | Owner | Scope Summary | Classification |
|---|---|---|---|
| **Information Security Policy** | Information Security (ISC) | Enterprise control requirements for confidentiality, integrity, and availability of information assets; applies to all employees, contractors, and third parties. Subordinate standards cover encryption, endpoint, network, and cloud. | Internal |
| **Password & Authentication Standard** | Information Security (ISC) | Credential complexity, rotation, MFA enforcement, privileged access, service accounts, and prohibition of shared credentials. | Internal |
| **Leave Policy** | Human Resources (HRM) | Annual leave, sick leave, parental leave, bereavement, sabbatical, jurisdiction-specific statutory entitlements, mandatory two-week consecutive absence for designated sensitive roles. | Internal |
| **Travel Policy** | Human Resources (HRM) | Booking channels, class-of-travel entitlement by grade, pre-approval thresholds, high-risk destination clearance, per-diem rates. | Internal |
| **Expense Policy** | Finance (FIN) | Reimbursable and non-reimbursable categories, receipt evidence, submission deadlines, corporate card usage, entertainment and gift limits, anti-bribery interaction. | Internal |
| **Risk Policy (Enterprise Risk Management)** | Risk (RSK) | Risk taxonomy, risk appetite statement, Three Lines of Defence, RCSA methodology, KRI thresholds, escalation and acceptance protocols. | Confidential |
| **AML Policy** | Compliance (CMP) | BSA/AML program, customer risk rating, transaction monitoring, CTR and SAR obligations, sanctions screening, correspondent banking due diligence, record retention. | Confidential |
| **KYC Policy** | Compliance (CMP) | Customer Identification Program, CDD and EDD standards, beneficial ownership identification, PEP handling, periodic refresh cycles by risk tier. | Confidential |
| **Vendor Management (Third-Party Risk) Policy** | Procurement (PRC) | Vendor tiering, due diligence depth, contractual control requirements, ongoing monitoring, concentration risk, exit and substitutability planning. | Internal |
| **Loan Approval Policy** | Corporate Banking (CBK) with Risk (RSK) | Credit authority grid, underwriting standards, collateral valuation, exception handling, covenant setting, and documentation requirements. | Confidential |
| **Compliance Policy** | Compliance (CMP) | Regulatory change management, compliance risk assessment, testing and monitoring, complaints oversight, conduct and market abuse surveillance. | Internal |
| **Business Continuity Policy & Plan** | IT Operations (ITO) with Administration (ADM) | Business impact analysis, recovery time and recovery point objectives, critical process inventory, alternate site activation, crisis communication. | Confidential |
| **Disaster Recovery Policy & Plan** | IT Operations (ITO) | Technology recovery architecture, tiering of applications, failover procedures, annual recovery testing and evidence retention. | Confidential |
| **Document Retention Policy & Schedule** | Administration (ADM) with Legal (LEG) | Record classes, minimum retention periods, legal hold override, defensible disposal, archival and destruction certification. | Internal |
| **Data Classification Standard** | Information Security (ISC) with Chief Data Officer | Five-tier classification model, labelling obligations, handling rules per tier, declassification, and cross-border transfer constraints. | Internal |
| **Remote Work Policy** | Human Resources (HRM) | Eligibility by role, hybrid attendance expectations, home-office security requirements, equipment provision, cross-border remote work prohibition without tax and regulatory clearance. | Internal |
| **Code of Conduct** | Human Resources (HRM) with Legal (LEG) | Ethical standards, conflicts of interest, personal account dealing, outside business activities, gifts and entertainment, anti-bribery, speak-up protections, disciplinary framework. | Internal |
| **Procurement Policy** | Procurement (PRC) | Sourcing thresholds, competitive bidding requirements, purchase-order discipline, contract execution authority, supplier diversity commitments. | Internal |
| **Privacy & Data Protection Policy** | Legal (LEG) with Compliance (CMP) | Handling of PII and NPI, GLBA and GDPR obligations, consent, subject access rights, breach notification timelines. | Confidential |
| **Model Risk Management Policy** | Risk (RSK) | Model inventory, development standards, independent validation, performance monitoring, and use of AI/ML models. | Confidential |
| **Incident Management Policy** | IT Operations (ITO) with Information Security (ISC) | Severity classification, escalation timelines, war-room protocol, regulatory notification triggers, post-incident review. | Internal |
| **Fraud Risk Management Policy** | Compliance (CMP) with Risk (RSK) | Internal and external fraud typologies, detection controls, investigation protocol, loss recognition and recovery. | Confidential |
| **Marketing & Communications Standard** | Marketing (MKT) | Brand usage, regulated advertising review, disclosure requirements, social media governance, spokesperson authorisation. | Internal |

---

## 7. Departments

The fifteen departments below are described using a uniform structure: **Purpose · Responsibilities · Important systems · Typical documents owned · Typical approvals · Typical interactions**.

### 7.1 Human Resources (`HRM`)

- **Purpose.** Attract, develop, compensate, and govern the conduct of the workforce so that the Bank has the capability and culture required to execute strategy within regulatory expectations.
- **Responsibilities.** Workforce planning and recruitment; onboarding and offboarding; compensation and benefits administration; performance and talent management; learning and mandatory training compliance; employee relations, grievances, and disciplinary process; organizational design and job architecture; regulatory conduct regimes (e.g., certification of material risk takers); diversity, equity, and inclusion.
- **Important systems.** ApexPeople (HRMS), ApexLearn (learning management), ApexServe (HR case management), ApexID (joiner–mover–leaver identity triggers), ApexInsight (workforce analytics), ApexDocs (personnel file repository).
- **Typical documents owned.** Employee Handbook; Leave Policy; Travel Policy; Remote Work Policy; Code of Conduct; job descriptions and grade definitions; compensation guidelines; employment contracts and offer letters; performance review records; disciplinary and grievance case files; training completion registers.
- **Typical approvals.** Hiring requisitions and offers; salary and promotion decisions within budget; leave exceptions; disciplinary outcomes; role grade assignment; access requests for HR-restricted data.
- **Typical interactions.** Legal (employment law, terminations); Finance (payroll funding, headcount budget); Compliance (conduct certification, mandatory training evidence); Information Security (joiner–mover–leaver access); all Department Heads (workforce planning); Internal Audit (control testing).

### 7.2 Finance (`FIN`)

- **Purpose.** Maintain the integrity of financial records, produce accurate internal and external reporting, and steward capital and expense discipline across the Group.
- **Responsibilities.** General ledger control and month-end close; statutory and regulatory reporting (Call Reports, FR Y-9C, IFRS/US GAAP consolidation); budgeting, forecasting, and business planning; management information and profitability analysis; product control and valuation oversight; tax compliance and transfer pricing; capital planning and stress testing (in partnership with Risk and Treasury); expense governance and accounts payable.
- **Important systems.** ApexLedger (SAP S/4HANA general ledger and accounts payable); ApexPlan (financial planning and consolidation); ApexInsight (analytics and management reporting); ApexRegRep (regulatory reporting engine); ApexCore (product ledgers feed); ApexServe (finance service requests).
- **Typical documents owned.** Expense Policy; Chart of Accounts standard; month-end close procedures; financial statements and disclosure packs; regulatory return filings; capital plan; budget submissions; accounting position papers; intercompany and transfer pricing documentation.
- **Typical approvals.** Journal entries above materiality thresholds; expense reimbursements above line-manager limits; budget reallocations; accounting policy elections; write-offs and provisions; vendor invoice release.
- **Typical interactions.** All departments (budget and expense); Treasury (funding, FTP, liquidity reporting); Risk (credit loss provisioning, CECL); Internal Audit and external auditors; Legal (contract accounting); Procurement (purchase-order and invoice matching); Regulators (via Compliance and Legal).

### 7.3 Retail Banking (`RTL`)

- **Purpose.** Serve consumer and small-business customers through branches and digital channels, growing primary banking relationships with suitable products and fair outcomes.
- **Responsibilities.** Branch network operations and cash management; deposit account opening and servicing; consumer and small-business lending origination; mortgage origination and referral; card acquisition; digital channel product ownership; sales practices governance and suitability; branch physical security and safe deposit; community reinvestment activity.
- **Important systems.** ApexCore (deposits and loan servicing); ApexOrigin (loan and mortgage origination); Apex360 (CRM); ApexTeller (branch teller platform); ApexMobile / ApexOnline (digital channels); ApexKYC (onboarding due diligence); ApexServe (branch incident and service tickets).
- **Typical documents owned.** Retail Account Opening Policy; Branch Operations Manual; product terms and conditions and fee schedules; account agreements and disclosures; mortgage and loan application forms; branch cash-handling procedures; sales practice standards; branch audit checklists.
- **Typical approvals.** Account opening exceptions; fee waivers within grade limits; consumer credit within delegated authority; cash differences and vault reconciliation sign-off; overdraft decisions; branch opening, relocation, and closure (escalated to Business Unit Head).
- **Typical interactions.** Customer Support (service escalations, complaints); Compliance (KYC, fair lending, complaint themes); Risk (credit quality, operational loss events); Marketing (campaigns and offers); IT Operations (channel availability); Administration (facilities and records).

### 7.4 Corporate Banking (`CBK`)

- **Purpose.** Originate and manage credit, transaction banking, and capital markets relationships for corporate, institutional, and public-sector clients within approved risk appetite.
- **Responsibilities.** Client coverage and relationship management; credit origination, structuring, and documentation; syndication and distribution; transaction banking and trade finance delivery; capital markets and advisory execution in conjunction with Apex Securities LLC; portfolio monitoring, covenant tracking, and annual review; pricing and return-on-capital discipline; client onboarding coordination with Compliance.
- **Important systems.** ApexOrigin (credit workflow and approvals); ApexCredit (limits, exposures, covenants); ApexTrade (trade finance); ApexPay (payments hub); Apex360 (CRM and pipeline); ApexRisk (rating models and RWA); ApexDocs (credit files and executed agreements).
- **Typical documents owned.** Credit applications and credit memoranda; term sheets and commitment letters; loan and security agreements; syndication documents; annual credit reviews; covenant compliance certificates; client account plans; trade finance instruments.
- **Typical approvals.** Credit approvals within delegated authority; pricing exceptions; waiver and amendment requests; limit increases; documentation deviations (with Legal); client onboarding sign-off (with Compliance).
- **Typical interactions.** Risk (credit approval, rating validation, watchlist); Legal (documentation, security perfection); Compliance (KYC, sanctions, cross-border); Treasury (funding, hedging, FX); Finance (revenue recognition, capital consumption); Operations within IT Operations (loan booking and settlement).

### 7.5 Treasury (`TRY`)

- **Purpose.** Manage the Bank's liquidity, funding, capital structure, and structural interest-rate and currency exposures, and provide market access to client-facing businesses.
- **Responsibilities.** Daily liquidity and cash-flow management; wholesale funding issuance; investment securities portfolio management; interest-rate risk in the banking book (IRRBB); FX position management; collateral and central bank facility management; Funds Transfer Pricing methodology and rates; LCR, NSFR, and internal liquidity stress testing; ALCO secretariat.
- **Important systems.** ApexTreasury (treasury and trading platform); ApexRisk (market risk and VaR); ApexLedger (accounting interface); ApexPay (settlement); Bloomberg and Refinitiv market data terminals; SWIFT gateway.
- **Typical documents owned.** Liquidity and Funding Policy; Contingency Funding Plan; Investment Policy Statement; FTP methodology document; ALCO packs and minutes; hedge designation and effectiveness documentation; dealing mandates and broker lists.
- **Typical approvals.** Funding transactions within board-approved limits; investment purchases and sales; hedge designations; limit excess ratification; counterparty dealing approvals (with Risk); intraday liquidity buffers.
- **Typical interactions.** Finance (capital, accounting, regulatory ratios); Risk (market risk limits, counterparty credit); Corporate Banking (client hedging and funding needs); IT Operations (trade capture and settlement); Compliance (market conduct surveillance); Internal Audit.

### 7.6 Legal (`LEG`)

- **Purpose.** Protect the Bank from legal risk, ensure enforceability of its commitments, and provide the corporate secretariat for the Board and its committees.
- **Responsibilities.** Legal advisory across all business units; contract drafting, negotiation, and template ownership; litigation and dispute management; regulatory enforcement response coordination; corporate governance and entity management; intellectual property and brand protection; privacy and data protection legal opinions; legal hold administration; outside counsel management.
- **Important systems.** ApexLegal (matter and spend management); ApexDocs (contract repository and clause library); ApexServe (legal request intake); ApexVault (legal hold and archive); board portal (Directors' Desk).
- **Typical documents owned.** Contract templates (MSA, NDA, vendor agreement, loan agreement); Board and committee minutes and resolutions; corporate entity records; litigation case files; legal opinions and memoranda; power-of-attorney registers; regulatory correspondence log; legal hold notices.
- **Typical approvals.** Execution of contracts above delegated business authority; deviations from approved contract templates; settlement of litigation within authority; engagement of outside counsel; use of corporate seal and signing authority; public disclosures with legal implications.
- **Typical interactions.** All departments (advisory); Procurement (vendor contracting); Compliance (regulatory interpretation); Corporate Banking (credit documentation); Human Resources (employment matters); Internal Audit; Board of Directors and Corporate Secretary function.

### 7.7 Compliance (`CMP`)

- **Purpose.** Provide independent Second Line oversight that the Bank conducts business in accordance with applicable laws, regulations, and internal conduct standards, with particular focus on financial crime.
- **Responsibilities.** Regulatory change management and impact assessment; compliance risk assessment, monitoring, and testing; AML/CFT program including transaction monitoring, CTR and SAR filing; sanctions screening and OFAC compliance; KYC/CDD/EDD standards and quality assurance; conduct and market abuse surveillance; complaints oversight and root-cause reporting; consumer protection and fair lending monitoring; regulatory examination management; training content ownership for regulatory modules.
- **Important systems.** ApexGuard (transaction monitoring and case management); ApexKYC (client due diligence and screening); ApexWatch (trade and communications surveillance); ApexServe (compliance queries and attestations); ApexInsight (compliance MI); ApexDocs (regulatory correspondence).
- **Typical documents owned.** AML Policy; KYC Policy; Compliance Policy; Sanctions Policy; compliance risk assessments; monitoring and testing reports; SAR and CTR filings; regulatory examination responses; conduct rule breach records; annual AML program effectiveness report.
- **Typical approvals.** High-risk customer onboarding and PEP relationships; correspondent banking relationships; SAR filing decisions; new product compliance sign-off; marketing material regulatory review; cross-border activity clearance; compliance policy exceptions.
- **Typical interactions.** Retail Banking and Corporate Banking (onboarding, monitoring alerts); Risk (shared taxonomy, aggregated reporting); Legal (regulatory interpretation, enforcement); Internal Audit (assurance over the program); Information Security (fraud and cyber-enabled crime); Regulators (examinations and filings).

### 7.8 Risk (`RSK`)

- **Purpose.** Own the enterprise risk framework and provide independent challenge to risk-taking so that exposures remain within Board-approved appetite.
- **Responsibilities.** Enterprise risk taxonomy and appetite framework; credit risk policy, underwriting standards, and independent credit approval; market and liquidity risk oversight; operational risk including RCSA, loss data collection, and KRI monitoring; model risk management and independent validation; stress testing and scenario analysis; portfolio analytics, watchlist, and problem-asset management; risk reporting to ExCo and Board Risk Committee.
- **Important systems.** ApexRisk (credit, market, and operational risk platform); ApexCredit (exposures and limits); ApexModel (model inventory and validation); ApexInsight (risk MI and dashboards); ApexCore and ApexOrigin (data sources); ApexServe (risk acceptance workflow).
- **Typical documents owned.** Enterprise Risk Management Policy; Risk Appetite Statement; credit policy and underwriting standards; RCSA templates and results; risk assessment reports; model validation reports; stress test results; watchlist and impaired asset reports; risk acceptance and exception registers.
- **Typical approvals.** Credit exposures above business delegated authority; risk acceptances and policy exceptions; risk rating overrides; model approval and periodic revalidation; limit setting and limit breach ratification; new product risk sign-off.
- **Typical interactions.** Corporate Banking and Retail Banking (credit decisions); Treasury (market and liquidity limits); Finance (provisioning, capital); Compliance (financial crime and conduct risk); Information Security and IT Operations (technology and cyber risk); Internal Audit; Board Risk Committee.

### 7.9 Information Security (`ISC`)

- **Purpose.** Protect the confidentiality, integrity, and availability of Apex National Bank information and technology assets against internal and external threats.
- **Responsibilities.** Security policy and standards authorship; identity and access management governance including privileged access; vulnerability management and penetration testing; security architecture review of change and new technology; threat intelligence and 24×7 Security Operations Centre monitoring; security incident detection, response, and forensics; data loss prevention and encryption standards; third-party security assessment; security awareness programme; regulatory cyber reporting.
- **Important systems.** ApexShield (SIEM and SOC tooling); ApexID (SailPoint identity governance, Microsoft Entra ID, CyberArk privileged access); ApexScan (vulnerability management); ApexDLP (data loss prevention); ApexServe (security incidents and access requests); ApexInsight (security metrics).
- **Typical documents owned.** Information Security Policy; Password & Authentication Standard; Data Classification Standard; Security Incident Response Plan; encryption and key management standard; secure development standard; penetration test reports; vulnerability remediation plans; third-party security assessments.
- **Typical approvals.** Privileged access grants and recertification; firewall and network exception requests; security architecture sign-off for new systems and cloud services; risk acceptance for unremediated vulnerabilities; external data transfers; exceptions to the Password Standard.
- **Typical interactions.** IT Operations (change, patching, infrastructure); Risk (technology risk reporting); Compliance (cyber-enabled financial crime, regulatory notification); Procurement (vendor security due diligence); Human Resources (insider risk, joiner–mover–leaver); Internal Audit; all departments (awareness and incident reporting).

### 7.10 IT Operations (`ITO`)

- **Purpose.** Deliver and operate the technology platforms on which all banking services depend, meeting availability, performance, and resilience commitments.
- **Responsibilities.** Application development and maintenance; production support and service management; infrastructure, network, data centre, and cloud operations; change and release management; capacity and performance management; disaster recovery execution and testing; payment and settlement operations processing; end-user computing and service desk; technology asset and licence management; data engineering in partnership with the Chief Data Officer.
- **Important systems.** ApexServe (ServiceNow — incident, problem, change, request); ApexCore (core banking platform operations); ApexPay (payments hub); ApexCloud (hybrid cloud control plane); ApexMonitor (observability and alerting); ApexBuild (CI/CD pipeline); ApexVault (backup and archive).
- **Typical documents owned.** Change Management Procedure; Disaster Recovery Plan; Business Continuity technical annexes; runbooks and operational procedures; architecture design documents; service level agreements and operating level agreements; incident reports and post-incident reviews; capacity plans; technology asset register.
- **Typical approvals.** Production change authorisation via CAB; emergency change approval; release go/no-go decisions; infrastructure provisioning; system access at operating-system and database level (with Information Security); decommissioning of applications.
- **Typical interactions.** All departments (service delivery); Information Security (secure change, incident response); Risk (technology and resilience risk); Procurement (hardware, software, cloud contracts); Finance (technology cost allocation); Customer Support (channel outages); Internal Audit.

### 7.11 Customer Support (`CST`)

- **Purpose.** Resolve customer enquiries, service requests, disputes, and complaints across all channels with consistency, speed, and fair outcomes.
- **Responsibilities.** Contact centre operations (voice, chat, secure message, social); account servicing transactions; card disputes and chargeback processing under Regulation E and Regulation Z; complaint intake, investigation, resolution, and regulatory reporting; fraud claim intake and referral; escalation and executive complaint handling; customer authentication and identity verification; service quality assurance and call monitoring; vulnerable-customer handling.
- **Important systems.** Apex360 (CRM and case management); ApexCore (account servicing); ApexServe (workflow and escalation); ApexAssist (virtual assistant and agent assist); ApexVoice (telephony and call recording); ApexInsight (service analytics and complaint MI).
- **Typical documents owned.** Complaint Handling Procedure; dispute and chargeback procedures; contact centre operating manual; customer authentication standard; service level definitions; call quality scorecards; complaint root-cause reports; escalation matrices.
- **Typical approvals.** Goodwill credits and fee reversals within grade limits; provisional credit on disputes; account restriction and unrestriction; complaint closure at executive level; deviation from standard authentication (supervisor approval only).
- **Typical interactions.** Retail Banking (account and branch issues); Compliance (complaint themes, fair treatment, regulatory reporting); Risk (operational loss events, fraud); IT Operations (channel incidents); Legal (litigation-threat complaints); Marketing (communication of service changes).

### 7.12 Internal Audit (`IAD`)

- **Purpose.** Provide the Board Audit Committee with independent, objective assurance over the adequacy and effectiveness of governance, risk management, and internal control.
- **Responsibilities.** Risk-based annual audit planning; execution of audit engagements across all departments and subsidiaries; issue identification, rating, and tracking to closure; validation of management remediation; continuous auditing and data analytics; regulatory examination support and issue read-across; investigation support for material conduct matters; quality assurance and improvement programme conforming to IIA standards.
- **Important systems.** ApexAudit (audit management, workpapers, issue tracking); ApexInsight (data analytics for continuous auditing); ApexDocs (evidence repository); ApexServe (evidence requests); read-only access to ApexCore, ApexLedger, ApexRisk, ApexGuard.
- **Typical documents owned.** Internal Audit Charter; annual audit plan; audit engagement reports; issue and action tracking register; validation memoranda; Audit Committee reporting packs; quality assurance review results.
- **Typical approvals.** Audit report issuance; issue rating and severity; acceptance of management remediation evidence; closure of audit findings; audit plan changes (Audit Committee approval).
- **Typical interactions.** Board Audit Committee (primary reporting line); all departments (audit engagements); Risk and Compliance (Second Line coordination and reliance); external auditors; regulators (examination coordination).

### 7.13 Marketing (`MKT`)

- **Purpose.** Build and protect the Apex brand, generate qualified demand for banking products, and ensure all external communication is accurate, fair, and compliant.
- **Responsibilities.** Brand strategy and identity governance; product marketing and campaign management; digital marketing, search, and content; customer segmentation and lifecycle marketing analytics; corporate communications and media relations; internal communications; sponsorships and community engagement; regulated advertising review workflow; market research and competitive intelligence.
- **Important systems.** Apex360 (campaign management and customer segments); ApexReach (marketing automation and email); ApexInsight (campaign performance analytics); ApexBrand (digital asset management); ApexDocs (approved marketing collateral of record); ApexServe (marketing request intake).
- **Typical documents owned.** Brand & Communications Standard; marketing plans and campaign briefs; approved advertising copy and disclosures; press releases; social media guidelines; sponsorship agreements (with Legal); market research reports; internal communication templates.
- **Typical approvals.** Campaign launch within budget; brand usage and co-branding; press release issuance (with Legal and Investor Relations); advertising copy after Compliance review; sponsorship commitments within authority.
- **Typical interactions.** Compliance (advertising review, fair marketing); Legal (contracts, IP, disclosure); Retail Banking and Wealth (product campaigns); Customer Support (service messaging); Procurement (agency contracts); Information Security (customer-facing domain and phishing protection).

### 7.14 Procurement (`PRC`)

- **Purpose.** Obtain goods and services at optimal total cost and acceptable risk, and govern the third-party estate throughout the vendor lifecycle.
- **Responsibilities.** Category strategy and strategic sourcing; competitive tendering (RFI, RFP, RFQ); contract negotiation with Legal; purchase-order and requisition control; third-party risk intake, tiering, and due diligence coordination; ongoing vendor performance and SLA management; vendor concentration and substitutability analysis; contract renewal and exit management; supplier diversity and sustainability programmes.
- **Important systems.** ApexSource (source-to-contract); ApexLedger (procure-to-pay, purchase orders, invoices); ApexVendor (third-party risk register and monitoring); ApexDocs (executed contract repository, jointly with Legal); ApexServe (procurement requests).
- **Typical documents owned.** Procurement Policy; Third-Party Risk Management Policy; RFP documents and evaluation scorecards; vendor due diligence packs; vendor risk assessments; contract summaries and obligation registers; vendor performance reviews; exit plans for critical vendors.
- **Typical approvals.** Supplier selection recommendations; purchase orders within authority; contract execution referral to authorised signatory; vendor tier assignment; single-source and emergency purchase justification; vendor onboarding and offboarding.
- **Typical interactions.** All departments (demand intake); Legal (contract terms); Information Security (vendor security assessment); Risk (third-party and concentration risk); Finance (budget, invoice, and payment); Internal Audit; Compliance (vendors with regulatory exposure).

### 7.15 Administration (`ADM`)

- **Purpose.** Provide the corporate services, physical environment, and records and knowledge infrastructure that allow the Bank to operate safely and retrievably.
- **Responsibilities.** Corporate real estate and facilities management; physical security, access control, and guarding; workplace services, mail, and reprographics; travel administration and corporate travel desk; fleet and corporate services; records management, retention, and defensible disposal; **Enterprise Knowledge Management Office (EKMO)** — document standards, taxonomy, metadata, and the enterprise knowledge platform; business continuity site logistics; health, safety, and environment.
- **Important systems.** ApexDocs (enterprise document management — system of record); ApexVault (archive, legal hold, and defensible disposal); ApexWorkplace (facilities and space management); ApexAccess (physical access control and badging); ApexServe (facilities and records requests); ApexInsight (records and knowledge analytics).
- **Typical documents owned.** Master Company Profile (this document); Document Retention Schedule; Document Naming and Versioning Standard; Enterprise Metadata Standard; knowledge taxonomy; facilities and physical security procedures; site continuity plans; health and safety records; records destruction certificates.
- **Typical approvals.** Document publication and republication in ApexDocs; document classification assignment and change; records destruction authorisation (with Legal for hold clearance); physical access to restricted zones; facilities expenditure within authority; taxonomy and metadata schema changes (via Enterprise Knowledge Council).
- **Typical interactions.** Legal (retention, legal hold); Information Security (physical and information security convergence); IT Operations (document platform operations); Human Resources (workplace services); all departments (records and knowledge standards); Internal Audit (records control testing).

---

## 8. Enterprise Systems

All system names below are canonical. Downstream procedures, incident reports, access requests, and audit workpapers must refer to systems by these names.

| System | Name | Underlying Platform | Owner | Criticality | Description |
|---|---|---|---|---|---|
| Core Banking | **ApexCore** | Custom-integrated Temenos Transact on IBM z/OS with DB2 | IT Operations | Tier 1 | Authoritative ledger for deposits, loans, and customer master. Processes approximately 41 million transactions per day. Real-time posting for digital channels; end-of-day batch for interest accrual, fee assessment, and statement generation. RTO 2 hours, RPO 0 (synchronous replication New York ↔ Charlotte). |
| Loan Origination | **ApexOrigin** | nCino on Salesforce platform | Corporate Banking / Retail Banking | Tier 1 | End-to-end origination for consumer, mortgage, commercial, and corporate credit. Holds application data, scorecards, credit memoranda, approval trail, and document checklist. Integrates to ApexCredit for limits and ApexCore for booking. |
| Credit Exposure | **ApexCredit** | Moody's Analytics CreditLens | Risk | Tier 1 | Consolidated obligor and group exposure, limits, collateral, covenants, and watchlist. Source for large exposure reporting. |
| CRM | **Apex360** | Salesforce Financial Services Cloud | Retail Banking (consumer) / Corporate Banking (institutional) | Tier 1 | Single client view, interaction history, pipeline, service cases, campaign membership, and household/group hierarchies. Feeds Customer Support case management. |
| HRMS | **ApexPeople** | Workday | Human Resources | Tier 1 | Worker master data, organizational hierarchy, positions and grades, compensation, absence, performance, and payroll integration. Authoritative source of employee identity for ApexID provisioning. |
| Document Management | **ApexDocs** | OpenText Content Suite with Microsoft SharePoint front end | Administration (EKMO) | Tier 1 | Enterprise system of record for controlled documents: policies, procedures, contracts, credit files, customer documents, audit workpapers. Enforces naming, versioning, classification labels, retention codes, approval workflow, and full-text plus metadata search. |
| Records Archive | **ApexVault** | OpenText InfoArchive with immutable WORM storage | Administration | Tier 2 | Long-term archive, legal hold enforcement, defensible disposal, and destruction certification for records past active use. |
| **Email & Collaboration** | **Apex Mail** | Microsoft 365 — Exchange Online, Teams, OneDrive | IT Operations | Tier 1 | Corporate email, chat, meetings, and personal file storage. Journaled to ApexArchive for surveillance and e-discovery. Email is *not* an approved system of record — controlled documents must reside in ApexDocs. |
| Identity Management | **ApexID** | SailPoint IdentityIQ, Microsoft Entra ID, CyberArk PAM | Information Security | Tier 1 | Joiner–mover–leaver automation from ApexPeople, role-based entitlements, access certification (quarterly for privileged, semi-annual for standard), MFA enforcement, single sign-on, and privileged session recording. |
| Ticketing / ITSM | **ApexServe** | ServiceNow | IT Operations | Tier 1 | Incident, problem, change, and service request management for technology and shared services. Also hosts HR cases, procurement requests, access requests, and risk acceptance workflows. Authoritative record of approvals executed via workflow. |
| Accounting / ERP | **ApexLedger** | SAP S/4HANA | Finance | Tier 1 | General ledger, sub-ledgers, accounts payable and receivable, fixed assets, procure-to-pay, and expense management. Consolidation feed to ApexPlan. |
| Financial Planning | **ApexPlan** | Oracle EPM | Finance | Tier 2 | Budgeting, forecasting, consolidation, and management reporting. |
| Analytics & Data | **ApexInsight** | Snowflake data platform with Microsoft Power BI and dbt | Chief Data Officer | Tier 1 | Enterprise data warehouse and analytics layer. Certified datasets, data lineage, and business intelligence for all departments. Governed by the Data Governance Council. |
| Risk Platform | **ApexRisk** | SAS Risk Management with in-house extensions | Risk | Tier 1 | Credit risk rating and RWA calculation, market risk VaR and sensitivities, operational risk loss database, RCSA and KRI management, and stress testing engine. |
| Model Governance | **ApexModel** | Custom on ApexInsight | Risk | Tier 2 | Model inventory, documentation, validation status, performance monitoring, and AI/ML model registry. |
| Compliance Platform | **ApexGuard** | NICE Actimize | Compliance | Tier 1 | AML transaction monitoring, alert triage, case management, SAR/CTR preparation and e-filing to FinCEN, and sanctions transaction filtering. |
| Client Due Diligence | **ApexKYC** | Fenergo with Refinitiv World-Check screening | Compliance | Tier 1 | Customer onboarding, CIP verification, beneficial ownership capture, risk rating, PEP and adverse media screening, and periodic refresh scheduling. |
| Surveillance | **ApexWatch** | Behavox with Bloomberg Vault integration | Compliance | Tier 2 | Trade and communications surveillance for market abuse and conduct risk. |
| Payments Hub | **ApexPay** | Volante Payments with in-house routing | IT Operations | Tier 1 | Orchestration across Fedwire, ACH, RTP, FedNow, SWIFT, SEPA, CHAPS, and RTGS/NEFT rails, with sanctions screening interlock to ApexGuard. |
| Treasury & Trading | **ApexTreasury** | Murex MX.3 | Treasury | Tier 1 | Trade capture, position keeping, and valuation for FX, rates, and securities; ALM and liquidity analytics. |
| Trade Finance | **ApexTrade** | Finastra Trade Innovation | Corporate Banking | Tier 2 | Letters of credit, guarantees, collections, and supply-chain finance. |
| Security Operations | **ApexShield** | Microsoft Sentinel with CrowdStrike endpoint | Information Security | Tier 1 | SIEM, endpoint detection and response, 24×7 SOC monitoring, and automated containment playbooks. |
| Audit Management | **ApexAudit** | AuditBoard | Internal Audit | Tier 2 | Audit planning, workpapers, issue tracking, and Audit Committee reporting. |
| Sourcing & Vendor Risk | **ApexSource / ApexVendor** | Coupa with ProcessUnity third-party risk | Procurement | Tier 2 | Source-to-contract, vendor due diligence, tiering, and continuous monitoring. |
| Learning | **ApexLearn** | Cornerstone OnDemand | Human Resources | Tier 3 | Mandatory and elective training delivery, completion tracking, and attestation evidence. |

**Criticality tiers.** Tier 1 = RTO ≤ 4 hours, RPO ≤ 15 minutes, annual DR test mandatory. Tier 2 = RTO ≤ 24 hours, RPO ≤ 4 hours. Tier 3 = RTO ≤ 72 hours. Tier assignment is owned by IT Operations and ratified by the Operational Risk Committee.

---

## 9. Document Classification

Every document created at Apex National Bank must carry exactly one classification label. The label is applied in the document header, in the ApexDocs metadata field `classification`, and in the filename suffix where applicable.

| Code | Label | Definition | Typical Examples | Handling Rules |
|---|---|---|---|---|
| **C0** | **Public** | Approved for unrestricted external release. Disclosure causes no harm. | Annual report, press releases, published product terms, branch locator, careers content, marketing brochures. | Requires Marketing and Legal approval before release. No further distribution controls once published. Must be published from an approved channel. |
| **C1** | **Internal** | Intended for all Apex employees and authorised contractors. Disclosure would cause minor embarrassment or inefficiency. | This Master Company Profile, Employee Handbook, Travel Policy, org charts, internal newsletters, standard operating procedures. | Do not post externally. May be shared with vendors only under an executed NDA. Email within the Apex domain permitted. Default classification when none is assigned. |
| **C2** | **Confidential** | Sensitive business, customer, or employee information. Disclosure would cause material financial, regulatory, or reputational harm. | Customer account records, KYC files, credit memoranda, salary data, risk assessments, board papers of routine nature, vendor contracts, incident reports. | Access on a need-to-know basis with documented entitlement. Encryption required in transit and at rest. External email requires encryption. Printing discouraged; printed copies must be secured or shredded. Watermarking recommended. |
| **C3** | **Restricted** | Highly sensitive information limited to a defined, named group. Disclosure would cause severe harm or regulatory breach. | SAR filings and AML investigations, material non-public information (MNPI), pre-announcement M&A files, litigation strategy, penetration test results, cryptographic key material, executive compensation detail. | Named-individual access lists maintained in ApexID and reviewed quarterly. Storage only in designated ApexDocs restricted libraries. No forwarding. Printing prohibited without CISO or Department Head approval. All access is logged and reviewed. Information barriers apply where MNPI is involved. |
| **C4** | **Highly Confidential** | The Bank's most sensitive material, where disclosure would cause existential, systemic, or criminal-law consequences. | Group recovery and resolution plan, unpublished stress test results, live regulatory enforcement matters, strategic M&A of the Group itself, root credentials and HSM key ceremonies, active insider investigations. | Access approved individually by an ExCo member and the CISO. Air-gapped or dedicated secure enclave storage. No email transmission under any circumstance — secure collaboration workspace only. Physical copies numbered, registered, and destroyed under witness. Access logs reviewed monthly by Internal Audit. |

**Rules of application.**

1. **Default is C1 (Internal).** An unlabelled document is treated as C1 but is a documentation control exception recorded by EKMO.
2. **Highest-component rule.** A compilation inherits the highest classification of any component.
3. **Downgrade requires approval.** Only the document Owner, with concurrence from Information Security for C3/C4, may reduce a classification, and the rationale must be recorded in the version history.
4. **Customer data floor.** Any document containing customer PII or NPI is C2 at minimum.
5. **Time-based declassification.** MNPI-related C3 documents may be reclassified to C2 after public announcement, with Legal confirmation.

---

## 10. Document Naming Standards

### 10.1 Document Identifier Format

```
ANB-<DEPT>-<TYPE>-<SEQ>
```

| Component | Rule | Example |
|---|---|---|
| `ANB` | Fixed organisation prefix. Subsidiaries use `ANBUK`, `ANBEU`, `ANBGS`. | `ANB` |
| `<DEPT>` | Three-letter canonical department code from Section 2.4. | `CMP` |
| `<TYPE>` | Three-letter document type code from the table below. | `POL` |
| `<SEQ>` | Four-digit zero-padded sequence, assigned by ApexDocs, unique within department and type. | `0001` |

**Example:** `ANB-CMP-POL-0001` = Apex National Bank · Compliance · Policy · sequence 1 (the AML Policy).

### 10.2 Document Type Codes

| Code | Type | Code | Type |
|---|---|---|---|
| `POL` | Policy | `FRM` | Form |
| `STD` | Standard | `TPL` | Template |
| `SOP` | Standard Operating Procedure | `CTR` | Contract / Agreement |
| `GDL` | Guideline | `RPT` | Report |
| `MAN` | Manual | `MIN` | Minutes |
| `PLN` | Plan | `MEM` | Memorandum |
| `REF` | Reference Document | `REG` | Regulatory Filing |
| `HBK` | Handbook | `TRN` | Training Material |
| `CHK` | Checklist | `LOG` | Register / Log |
| `MTX` | Matrix | `PRE` | Presentation |

### 10.3 Filename Convention

```
<DocumentID>_<ShortTitle>_v<Major>.<Minor>_<STATUS>_<YYYYMMDD>.<ext>
```

**Rules.**

- `ShortTitle` — PascalCase or hyphenated, maximum 40 characters, no spaces, no special characters other than hyphen.
- `STATUS` — one of `DRAFT`, `REVIEW`, `APPROVED`, `PUBLISHED`, `SUPERSEDED`, `ARCHIVED`.
- `YYYYMMDD` — date of the version, not the date of download.
- Total path length must not exceed 200 characters.
- Restricted (C3) and Highly Confidential (C4) documents append the classification code: `..._C3`.

**Valid examples.**

```
ANB-ADM-REF-0001_MasterCompanyProfile_v4.0_PUBLISHED_20260630.md
ANB-CMP-POL-0001_AML-Policy_v7.2_PUBLISHED_20260315.pdf
ANB-HRM-POL-0002_Leave-Policy_v3.1_APPROVED_20260210.docx
ANB-ISC-SOP-0003_Security-Incident-Response_v5.0_PUBLISHED_20251118_C3.pdf
ANB-IAD-RPT-0142_Audit-RetailBranchCash-Q2FY26_v1.0_APPROVED_20260630_C2.pdf
ANB-CBK-CTR-0002_MasterLoanAgreement-Template_v2.3_PUBLISHED_20260420.docx
```

**Invalid examples and reasons.**

| Filename | Defect |
|---|---|
| `AML Policy final FINAL v2.docx` | No document ID; spaces; ambiguous version |
| `ANB-AML-POL-0001_...` | `AML` is not a canonical department code — must be `CMP` |
| `ANB-CMP-POL-1_Policy_v7.docx` | Sequence not four-digit; version not `Major.Minor` |
| `ANB-CMP-POL-0001_AMLPolicy_v7.2.pdf` | Missing `STATUS` and date components |

### 10.4 Customer and Transaction Record Naming

Operational records follow a distinct convention because they are indexed by relationship rather than document sequence:

```
<RecordType>_<CustomerID|AccountNumber>_<Descriptor>_<YYYYMMDD>.<ext>
```

**Examples:**

```
KYC_CUS-04928311_CDD-Refresh_20260512.pdf
LOAN_ACC-8871200456_CreditMemo_20260228.pdf
STMT_ACC-1029384756_Monthly_20260630.pdf
DISP_CAS-00417723_ChargebackEvidence_20260601.pdf
```

Customer identifiers use the format `CUS-########`; account numbers `ACC-##########`; case numbers `CAS-########`; and vendor identifiers `VEN-######`. These formats are canonical and must be used in all downstream systems and documents.

---

## 11. Versioning Standards

### 11.1 Version Number Semantics

Versions use `Major.Minor` for published documents; a third `Patch` element is used only in the working draft space and is not published.

| Element | Increment Trigger | Approval Required | Example |
|---|---|---|---|
| **Major** (`X`.0) | Change in scope, obligations, control requirements, risk position, or approval authority. Any change that alters what a reader must *do*. | Full approval chain per Section 12; re-attestation may be required | v3.4 → v4.0 |
| **Minor** (x.`Y`) | Clarification, added example, updated system name, corrected reference, non-material procedural refinement. | Document Owner approval; Approver notified | v4.0 → v4.1 |
| **Patch** (x.y.`Z`) | Typographical, formatting, metadata, or hyperlink correction with no meaning change. Draft space only; folded into the next Minor release. | Document Custodian | v4.1.2 |

The first published version of any document is **v1.0**. Pre-publication drafts are numbered **v0.1** onward.

### 11.2 Approval Workflow

```
DRAFT ──► REVIEW ──► APPROVED ──► PUBLISHED ──► UNDER REVISION ──► SUPERSEDED ──► ARCHIVED ──► DESTROYED
  │          │           │             │                                                          ▲
  │          │           │             └── periodic review passes with no change ──► PUBLISHED    │
  │          └── rejected ──► DRAFT                                                               │
  └── abandoned ─────────────────────────────────────────────────────────────────────────────────┘
```

| Stage | Description | System State |
|---|---|---|
| **Draft** | Author development. Not citable. Visible to author and named collaborators only. | ApexDocs draft library |
| **Review** | Circulated to mandatory reviewers (always includes Legal and Compliance for policies). Comments resolved and dispositioned in writing. | ApexDocs review workflow; comments retained |
| **Approved** | Signed by the Approver per the Approval Matrix. Effective date set. | Immutable version created |
| **Published** | Released to the audience defined by classification. Indexed for enterprise search. Prior version automatically moved to Superseded. | Live in ApexDocs; searchable |
| **Under Revision** | A new draft exists; the published version remains authoritative until the successor is published. | Both versions visible with clear banner |
| **Superseded** | Replaced by a newer version. Read-only. Watermarked `SUPERSEDED`. Retained for audit trail. | ApexDocs superseded library |
| **Archived** | Beyond active use but within the retention period. | ApexVault, immutable storage |
| **Destroyed** | Retention expired and no legal hold. Destruction certified. | Destruction certificate retained permanently |

### 11.3 Superseded Documents

- A superseded version is never deleted while within its retention period; it is the evidence of what the control required at a point in time.
- Superseded documents are automatically watermarked and carry a banner: *"SUPERSEDED — replaced by [Document ID] v[X.Y] effective [date]. Not for operational use."*
- Search results for superseded documents are de-prioritised and visually flagged; retrieval requires acknowledgement of superseded status.
- Any document cited in litigation, a regulatory examination, or an audit finding is placed under legal hold and cannot be destroyed regardless of retention expiry.

### 11.4 Archival

| Record Class | Active Retention | Archive Retention | Total Minimum |
|---|---|---|---|
| Corporate governance records (Board minutes, charters) | Permanent | Permanent | Permanent |
| Policies and standards (superseded versions) | 3 years | 7 years | 10 years |
| Customer account records | Life of relationship | 7 years after closure | 7 years post-closure |
| AML/BSA records (CTR, SAR, CDD) | 5 years | — | 5 years (regulatory minimum) |
| Credit files | Life of facility | 7 years after final settlement | 7 years post-settlement |
| Employee personnel records | Duration of employment | 7 years after separation | 7 years post-separation |
| Financial and accounting records | 2 years | 8 years | 10 years |
| Contracts | Term of contract | 7 years after expiry | 7 years post-expiry |
| Audit workpapers and reports | 3 years | 4 years | 7 years |
| Security incident and forensic records | 2 years | 5 years | 7 years |
| Marketing materials (published) | 1 year | 4 years | 5 years |
| Email and instant messaging | 1 year in mailbox | 6 years journaled | 7 years |

The authoritative schedule is `ANB-ADM-STD-0002` Document Retention Schedule; the table above is a summary and is superseded by that document where they differ in detail.

---

## 12. Approval Matrix

### 12.1 Approval Authority by Document Type

| Document Type | Author | Mandatory Reviewers | Approver | Ratification / Notification |
|---|---|---|---|---|
| Enterprise Policy (bank-wide) | Department SME (G5–G6) | Legal, Compliance, Risk, EKMO | Department Head (G11) **and** COO | ExCo; Board committee where regulatorily required |
| Departmental Policy (single department) | Department SME (G5–G6) | Legal, Compliance, EKMO | Department Head (G9–G11) | ExCo notification |
| Standard | Function lead (G6) | Owning Department Head, Information Security (if technical) | Department Head (G9–G10) | EKMO registration |
| Standard Operating Procedure (SOP) | Process owner (G4–G5) | Line manager, Risk (if control-bearing) | Function Head (G7–G9) | Department Head notification |
| Guideline | SME (G4–G5) | Line manager | Function Head (G7) | — |
| Form / Template | Process owner (G4–G5) | Legal (if contractual), Compliance (if regulated) | Function Head (G7) | EKMO registration |
| Contract — standard template, unmodified | Business sponsor (G5–G6) | Procurement | Authorised signatory per financial authority (Section 5.3) | Legal notification |
| Contract — non-standard or amended terms | Business sponsor (G5–G6) | Legal (mandatory), Procurement, Information Security (if data access), Risk (if Tier 1 vendor) | General Counsel or delegate **and** value-based signatory | ExCo if above $10M |
| Credit approval | Relationship Manager (G6) | Credit Analyst, Risk | Per Credit Authority grid (Section 5.4) | Group Credit Committee reporting |
| Internal Audit report | Audit Manager (G6) | Audited Department Head (factual accuracy only) | Chief Audit Executive (G11) | Board Audit Committee |
| Risk assessment / RCSA | Process owner (G5) | Risk (Second Line challenge) | Department Head (G9–G11) | Operational Risk Committee |
| Regulatory filing | Regulatory Reporting Manager (G6) | Finance, Compliance, Legal | Chief Financial Officer or Chief Compliance Officer (G11) | Disclosure Committee; Board where required |
| SAR / CTR filing | Financial Crime Investigator (G4–G5) | AML Team Lead | BSA Officer (G8, within Compliance) | Financial Crime Committee (aggregate only — individual SARs are C3) |
| Board / Committee minutes | Corporate Secretariat (G6) | Committee Chair | Committee (approval at next meeting) | Board of Directors |
| Incident report (Severity 1–2) | Incident Manager (G5–G6) | Information Security, Risk | Head of IT Operations (G11) or CISO (G10) | ExCo; regulator where notification thresholds met |
| Marketing material — regulated product | Marketing Manager (G5) | Compliance (mandatory), Legal, Product owner | Chief Marketing Officer (G10) | — |
| Press release / public statement | Communications Manager (G6) | Legal, Compliance, Investor Relations | Chief Marketing Officer (G10); Group CEO for market-moving statements | Board notification |
| Master reference documents (this profile, taxonomy, metadata standard) | EKMO (G5–G6) | Legal, Compliance, all Department Heads | Chief Operating Officer (G11) | Enterprise Knowledge Council; ExCo |

### 12.2 Universal Approval Rules

1. **Separation of duties.** The author of a document may never be its sole approver. A minimum of two distinct individuals must participate in any approval.
2. **Grade sufficiency.** An approver must hold a grade at or above the level specified. Acting arrangements must be recorded in writing in ApexServe with defined start and end dates.
3. **Evidence.** Approval is valid only when captured in ApexDocs workflow or ApexServe. Approval by email is permitted only during a declared business continuity event and must be reconciled into the system of record within five business days.
4. **Conflict of interest.** An approver with a personal or financial interest in the outcome must recuse and escalate one level.
5. **Independence of the Second and Third Lines.** Business management may not approve, amend, or veto Risk, Compliance, or Internal Audit opinions, ratings, or reports.
6. **Expiry.** An approval that has not resulted in publication within 90 days lapses and must be re-obtained.

---

## 13. Business Terminology

The following definitions are canonical for Apex National Bank. Downstream documents must use these terms consistently and must not redefine them locally.

| Term | Definition |
|---|---|
| **Account Holder** | A natural or legal person named on a deposit, loan, or investment account with rights of ownership or signature. |
| **Adverse Media** | Negative news screening performed during onboarding and periodic refresh to detect reputational or criminal risk associated with a customer. |
| **Asset & Liability Management (ALM)** | The discipline of managing the structural mismatch between the maturity, repricing, and currency profile of assets and liabilities. |
| **Beneficial Owner** | A natural person who ultimately owns 25% or more of a legal entity, or who exercises effective control over it. |
| **Book of Record** | The authoritative system or ledger whose data prevails in any reconciliation dispute. For deposits and loans this is ApexCore; for financials, ApexLedger. |
| **Business Continuity Plan (BCP)** | The documented set of arrangements enabling a critical business process to continue at an acceptable level following disruption. |
| **Charge-Off** | The accounting recognition that a loan balance is unlikely to be collected, removing it from performing assets while collection efforts may continue. |
| **Correspondent Banking** | A relationship in which Apex provides account and payment services to another financial institution, subject to enhanced due diligence. |
| **Credit Memorandum** | The written analysis and recommendation supporting a credit decision, containing borrower analysis, structure, risk rating, covenants, and approval signatures. |
| **Customer Due Diligence (CDD)** | The baseline process of identifying and verifying a customer, understanding the purpose of the relationship, and assigning a risk rating. |
| **Debt Service Coverage Ratio (DSCR)** | Net operating income divided by total debt service; a core commercial and CRE underwriting metric. |
| **Debt-to-Income Ratio (DTI)** | A consumer borrower's monthly debt obligations divided by gross monthly income. |
| **Enhanced Due Diligence (EDD)** | Additional scrutiny applied to higher-risk customers, including source-of-wealth verification and senior approval. |
| **Exception** | A documented, approved deviation from a policy, standard, or underwriting criterion, with a defined owner and expiry date. |
| **Expected Credit Loss (ECL)** | The probability-weighted estimate of credit losses over the life of an exposure, used for provisioning under CECL/IFRS 9. |
| **Exposure at Default (EAD)** | The expected outstanding amount owed by a borrower at the time of default. |
| **Funds Transfer Pricing (FTP)** | The internal mechanism by which Treasury charges business units for funding and credits them for deposits, isolating interest rate risk in Treasury. |
| **High-Quality Liquid Assets (HQLA)** | Unencumbered assets readily convertible to cash, counted toward the Liquidity Coverage Ratio. |
| **Impaired Asset** | An exposure where full recovery of principal and interest is no longer probable under the original terms. |
| **Information Barrier** | Controls preventing the flow of material non-public information between advisory and public-side functions. |
| **Know Your Customer (KYC)** | The overall programme encompassing customer identification, due diligence, screening, and ongoing monitoring. |
| **Legal Hold** | A directive suspending routine destruction of records relevant to actual or anticipated litigation, investigation, or examination. |
| **Line of Defence** | The Bank's control model: First Line owns and manages risk; Second Line sets policy and challenges; Third Line provides independent assurance. |
| **Loan-to-Value Ratio (LTV)** | Loan amount divided by the appraised value of pledged collateral. |
| **Loss Given Default (LGD)** | The proportion of exposure expected to be lost if a borrower defaults, after recoveries. |
| **Material Non-Public Information (MNPI)** | Information not publicly disclosed that a reasonable investor would consider important; subject to Restricted (C3) handling. |
| **Net Interest Margin (NIM)** | Net interest income divided by average interest-earning assets. |
| **Non-Performing Asset (NPA)** | A loan on which principal or interest is 90 days or more past due, or where collection is otherwise doubtful. |
| **Nostro / Vostro Account** | Nostro is Apex's account held at another bank; Vostro is another bank's account held at Apex. |
| **Operational Loss Event** | Any event resulting from inadequate or failed internal processes, people, systems, or external events, recorded in the operational loss database. |
| **Politically Exposed Person (PEP)** | An individual entrusted with a prominent public function, or their close associate or family member, requiring enhanced due diligence. |
| **Probability of Default (PD)** | The likelihood a borrower will default within a specified horizon, typically twelve months. |
| **Provision** | An accounting reserve established against expected credit losses. |
| **Recovery Point Objective (RPO)** | The maximum acceptable data loss measured in time, following a disruption. |
| **Recovery Time Objective (RTO)** | The maximum acceptable duration for restoring a process or system after a disruption. |
| **Relationship Manager (RM)** | The named individual accountable for the overall commercial relationship with a client. |
| **Risk Appetite** | The aggregate level and type of risk the Board is willing to accept in pursuit of strategy, expressed in quantitative limits and qualitative statements. |
| **Risk and Control Self-Assessment (RCSA)** | The structured First Line exercise of identifying risks, assessing controls, and agreeing remediation. |
| **Risk-Weighted Assets (RWA)** | Assets adjusted for credit, market, and operational risk, forming the denominator of regulatory capital ratios. |
| **Source of Funds / Source of Wealth** | The origin of the specific funds in a transaction, and the origin of a customer's total assets, respectively. |
| **System of Record** | The single authoritative repository for a class of information. For controlled documents this is ApexDocs. |
| **Three Lines of Defence** | See *Line of Defence*. |
| **Ultimate Beneficial Owner (UBO)** | See *Beneficial Owner*; the natural person at the top of an ownership chain. |
| **Watchlist** | The register of credit exposures showing deterioration but not yet impaired, subject to heightened monitoring. |

---

## 14. Acronyms

| Acronym | Expansion | Acronym | Expansion |
|---|---|---|---|
| **ABL** | Asset-Based Lending | **KRI** | Key Risk Indicator |
| **ACH** | Automated Clearing House | **KYC** | Know Your Customer |
| **AFG** | Apex Financial Group, Inc. | **LCR** | Liquidity Coverage Ratio |
| **ALCO** | Asset & Liability Committee | **LEI** | Legal Entity Identifier |
| **ALM** | Asset & Liability Management | **LGD** | Loss Given Default |
| **AML** | Anti-Money Laundering | **LTV** | Loan-to-Value |
| **ANB** | Apex National Bank, N.A. | **MAS** | Monetary Authority of Singapore |
| **ARM** | Adjustable-Rate Mortgage | **MD** | Managing Director (Grade G9) |
| **ATM** | Automated Teller Machine | **MFA** | Multi-Factor Authentication |
| **AUM** | Assets Under Management | **MNPI** | Material Non-Public Information |
| **AVP** | Assistant Vice President (Grade G5) | **MSA** | Master Services Agreement |
| **BaFin** | Bundesanstalt für Finanzdienstleistungsaufsicht | **NDA** | Non-Disclosure Agreement |
| **BCP** | Business Continuity Plan | **NEFT** | National Electronic Funds Transfer (India) |
| **BIC** | Bank Identifier Code | **NIM** | Net Interest Margin |
| **BSA** | Bank Secrecy Act | **NPA** | Non-Performing Asset |
| **CAB** | Change Advisory Board | **NPAC** | New Product Approval Committee |
| **CAE** | Chief Audit Executive | **NPI** | Nonpublic Personal Information |
| **CCPA** | California Consumer Privacy Act | **NSFR** | Net Stable Funding Ratio |
| **CDD** | Customer Due Diligence | **OCC** | Office of the Comptroller of the Currency |
| **CECL** | Current Expected Credit Loss | **OFAC** | Office of Foreign Assets Control |
| **CET1** | Common Equity Tier 1 | **ORC** | Operational Risk Committee |
| **CFPB** | Consumer Financial Protection Bureau | **PAM** | Privileged Access Management |
| **CIB** | Corporate & Investment Banking | **PCI DSS** | Payment Card Industry Data Security Standard |
| **CIP** | Customer Identification Program | **PD** | Probability of Default |
| **CISO** | Chief Information Security Officer | **PEP** | Politically Exposed Person |
| **CMB** | Commercial Banking | **PII** | Personally Identifiable Information |
| **CRB** | Consumer & Retail Banking | **PRA** | Prudential Regulation Authority (UK) |
| **CRE** | Commercial Real Estate | **RACI** | Responsible, Accountable, Consulted, Informed |
| **CRM** | Customer Relationship Management | **RBI** | Reserve Bank of India |
| **CTR** | Currency Transaction Report | **RCSA** | Risk and Control Self-Assessment |
| **DGC** | Data Governance Council | **RFP** | Request for Proposal |
| **DLP** | Data Loss Prevention | **RM** | Relationship Manager |
| **DR** | Disaster Recovery | **ROA / ROE** | Return on Assets / Return on Equity |
| **DSCR** | Debt Service Coverage Ratio | **RPO** | Recovery Point Objective |
| **DTI** | Debt-to-Income | **RTGS** | Real-Time Gross Settlement |
| **EAD** | Exposure at Default | **RTO** | Recovery Time Objective |
| **ECB** | European Central Bank | **RTP** | Real-Time Payments |
| **ECL** | Expected Credit Loss | **RWA** | Risk-Weighted Assets |
| **ED** | Executive Director (Grade G8) | **SAR** | Suspicious Activity Report |
| **EDD** | Enhanced Due Diligence | **SBA** | Small Business Administration |
| **EKC / EKMO** | Enterprise Knowledge Council / Office | **SEC** | Securities and Exchange Commission |
| **ETO** | Enterprise Technology & Operations | **SEPA** | Single Euro Payments Area |
| **ExCo** | Executive Committee | **SIEM** | Security Information and Event Management |
| **FCA** | Financial Conduct Authority (UK) | **SLA** | Service Level Agreement |
| **FCC** | Financial Crime Committee | **SOC** | Security Operations Centre |
| **FDIC** | Federal Deposit Insurance Corporation | **SOP** | Standard Operating Procedure |
| **FFIEC** | Federal Financial Institutions Examination Council | **SOX** | Sarbanes-Oxley Act |
| **FinCEN** | Financial Crimes Enforcement Network | **SVP** | Senior Vice President (Grade G7) |
| **FINRA** | Financial Industry Regulatory Authority | **SWIFT** | Society for Worldwide Interbank Financial Telecommunication |
| **FRB** | Federal Reserve Board | **TM** | Treasury & Markets |
| **FTP** | Funds Transfer Pricing | **UBO** | Ultimate Beneficial Owner |
| **FX** | Foreign Exchange | **VaR** | Value at Risk |
| **GAAP** | Generally Accepted Accounting Principles | **VP** | Vice President (Grade G6) |
| **GDPR** | General Data Protection Regulation | **WAM** | Wealth & Asset Management |
| **GL** | General Ledger | **HKMA** | Hong Kong Monetary Authority |
| **GLBA** | Gramm-Leach-Bliley Act | **HQLA** | High-Quality Liquid Assets |
| **GrCC** | Group Credit Committee | **HSA** | Health Savings Account |
| **GSC** | Apex Global Services (Mumbai / Hyderabad) | **IAM** | Identity and Access Management |
| **HELOC** | Home Equity Line of Credit | **IBAN** | International Bank Account Number |
| **HRMS** | Human Resource Management System | **IFRS** | International Financial Reporting Standards |
| **IRRBB** | Interest Rate Risk in the Banking Book | **ITSM** | IT Service Management |
| **KPI** | Key Performance Indicator | **WORM** | Write Once, Read Many |

---

## 15. Future Document Dependency

The following enterprise documents will be authored under this profile. Each inherits its department code, ownership, classification model, naming convention, and approval path from the sections above. Document IDs listed here are **reserved** and must be used when the documents are created.

| # | Document ID | Document Title | Owning Dept | Approver | Class | Review Cycle |
|---|---|---|---|---|---|---|
| 1 | `ANB-HRM-HBK-0001` | Employee Handbook | HRM | CHRO | C1 | Annual |
| 2 | `ANB-HRM-POL-0002` | Leave Policy | HRM | CHRO | C1 | Annual |
| 3 | `ANB-HRM-POL-0003` | Remote Work Policy | HRM | CHRO | C1 | Annual |
| 4 | `ANB-HRM-POL-0004` | Code of Conduct | HRM | Group CEO | C1 | Annual |
| 5 | `ANB-HRM-POL-0005` | Compensation & Incentive Governance Policy | HRM | Compensation Committee | C2 | Annual |
| 6 | `ANB-FIN-POL-0001` | Expense Policy | FIN | CFO | C1 | Annual |
| 7 | `ANB-FIN-POL-0002` | Travel Policy | FIN | CFO | C1 | Annual |
| 8 | `ANB-FIN-SOP-0003` | Month-End Close Procedure | FIN | Group Financial Controller | C2 | Annual |
| 9 | `ANB-FIN-STD-0004` | Chart of Accounts Standard | FIN | Group Financial Controller | C1 | Biennial |
| 10 | `ANB-RSK-POL-0001` | Enterprise Risk Management Policy | RSK | Board Risk Committee | C2 | Annual |
| 11 | `ANB-RSK-STD-0002` | Risk & Control Self-Assessment Standard | RSK | CRO | C2 | Annual |
| 12 | `ANB-RSK-TPL-0003` | Risk Assessment Template | RSK | CRO | C2 | Biennial |
| 13 | `ANB-RSK-POL-0004` | Model Risk Management Policy | RSK | CRO | C2 | Annual |
| 14 | `ANB-CMP-POL-0001` | Anti-Money Laundering (AML) Policy | CMP | Board Public Responsibility & Compliance Committee | C2 | Annual |
| 15 | `ANB-CMP-POL-0002` | Know Your Customer (KYC) Policy | CMP | CCO | C2 | Annual |
| 16 | `ANB-CMP-FRM-0003` | Customer KYC Form | CMP | BSA Officer | C2 | Annual |
| 17 | `ANB-CMP-SOP-0004` | Suspicious Activity Report (SAR) Filing Procedure | CMP | BSA Officer | C3 | Annual |
| 18 | `ANB-CMP-POL-0005` | Sanctions & OFAC Screening Policy | CMP | CCO | C2 | Annual |
| 19 | `ANB-CMP-POL-0006` | Compliance Policy (Regulatory Change & Monitoring) | CMP | CCO | C1 | Annual |
| 20 | `ANB-ISC-POL-0001` | Information Security Policy | ISC | CISO and COO | C1 | Annual |
| 21 | `ANB-ISC-STD-0002` | Password & Authentication Standard | ISC | CISO | C1 | Annual |
| 22 | `ANB-ISC-SOP-0003` | Security Incident Response Plan | ISC | CISO | C3 | Annual |
| 23 | `ANB-ISC-STD-0004` | Data Classification Standard | ISC | CISO and CDO | C1 | Annual |
| 24 | `ANB-ITO-PLN-0001` | Business Continuity Plan | ITO | COO | C2 | Annual + test |
| 25 | `ANB-ITO-PLN-0002` | Disaster Recovery Plan | ITO | CIO | C2 | Annual + test |
| 26 | `ANB-ITO-SOP-0003` | Change Management Procedure | ITO | Head of IT Operations | C1 | Annual |
| 27 | `ANB-ITO-TPL-0004` | Incident Report Template | ITO | Head of IT Operations | C2 | Biennial |
| 28 | `ANB-RTL-POL-0001` | Retail Account Opening Policy | RTL | Head of Consumer & Retail Banking | C2 | Annual |
| 29 | `ANB-RTL-FRM-0002` | Mortgage Application Form | RTL | Head of Mortgage (ED) | C2 | Annual |
| 30 | `ANB-RTL-MAN-0003` | Branch Operations Manual | RTL | Head of Consumer & Retail Banking | C2 | Annual |
| 31 | `ANB-CBK-POL-0001` | Loan Approval Policy | CBK / RSK | CRO and Head of CIB | C2 | Annual |
| 32 | `ANB-CBK-CTR-0002` | Master Loan Agreement Template | CBK | General Counsel | C2 | Annual |
| 33 | `ANB-CBK-TPL-0003` | Credit Memorandum Template | CBK | Head of Credit Risk | C2 | Biennial |
| 34 | `ANB-TRY-POL-0001` | Liquidity & Funding Policy | TRY | ALCO and Board Risk Committee | C2 | Annual |
| 35 | `ANB-TRY-PLN-0002` | Contingency Funding Plan | TRY | Group Treasurer and CFO | C3 | Annual |
| 36 | `ANB-LEG-CTR-0001` | Master Services Agreement (Vendor Contract) Template | LEG | General Counsel | C1 | Annual |
| 37 | `ANB-LEG-STD-0002` | Board & Committee Minutes Standard | LEG | Corporate Secretary | C2 | Biennial |
| 38 | `ANB-PRC-POL-0001` | Procurement Policy | PRC | CPO and CFO | C1 | Annual |
| 39 | `ANB-PRC-POL-0002` | Third-Party (Vendor) Risk Management Policy | PRC | CPO and CRO | C1 | Annual |
| 40 | `ANB-IAD-TPL-0001` | Internal Audit Report Template | IAD | Chief Audit Executive | C2 | Biennial |
| 41 | `ANB-IAD-REF-0002` | Internal Audit Charter | IAD | Board Audit Committee | C1 | Annual |
| 42 | `ANB-CST-SOP-0001` | Complaint Handling Procedure | CST | Head of Customer Support | C1 | Annual |
| 43 | `ANB-MKT-STD-0001` | Brand & Communications Standard | MKT | CMO | C1 | Annual |
| 44 | `ANB-ADM-STD-0002` | Document Retention Schedule | ADM | COO and General Counsel | C1 | Annual |
| 45 | `ANB-ADM-STD-0005` | Enterprise Metadata Standard | ADM (EKMO) | COO | C1 | Annual |

**Cross-reference obligation.** Every document above must include, in its metadata block, a `Related Documents` field citing `ANB-ADM-REF-0001` (this profile) and any documents on which it directly depends. Relationships are maintained as structured metadata in ApexDocs, not merely as prose, so that the enterprise knowledge platform can resolve dependency graphs, detect orphaned references, and identify documents affected by a change to this profile.

---

## 16. Appendix

### Appendix A — Corporate Abbreviations

| Abbreviation | Meaning |
|---|---|
| **ANB** | Apex National Bank, National Association (the Bank) |
| **AFG** | Apex Financial Group, Inc. (the Group; NYSE: APXN) |
| **ANBUK / ANBEU** | Apex National Bank (UK) plc / Apex Bank Europe SE |
| **ASL** | Apex Securities LLC (broker-dealer) |
| **AAM** | Apex Asset Management, Inc. |
| **ATC** | Apex Trust Company, N.A. |
| **AIA** | Apex Insurance Agency, LLC |
| **GSC** | Apex Global Services (Mumbai and Hyderabad) |
| **EKMO / EKC** | Enterprise Knowledge Management Office / Enterprise Knowledge Council |
| **HQ** | One Apex Plaza, 285 Greenwich Street, New York |
| **CLT / CHI / DAL / SFO** | Charlotte, Chicago, Dallas, San Francisco regional offices |
| **LDN / FRA / DXB / SGP / HKG / MUM** | London, Frankfurt, Dubai, Singapore, Hong Kong, Mumbai offices |

**Canonical department codes:** `HRM` `FIN` `RTL` `CBK` `TRY` `LEG` `CMP` `RSK` `ISC` `ITO` `CST` `IAD` `MKT` `PRC` `ADM`

**Canonical business unit codes:** `CRB` `CMB` `CIB` `WAM` `TM` `ETO` `CC`

**Canonical identifier formats:** `CUS-########` (customer) · `ACC-##########` (account) · `CAS-########` (case) · `VEN-######` (vendor) · `EMP-######` (employee) · `INC-########` (incident) · `CHG-########` (change) · `AUD-######` (audit engagement)

### Appendix B — Document Ownership Model

Every controlled document has exactly four named roles. These roles are recorded as metadata in ApexDocs and are enforced by workflow.

| Role | Definition | Accountability | Typical Grade |
|---|---|---|---|
| **Owner** | The department accountable for the accuracy, currency, and completeness of the content. Ownership is departmental, not personal, and survives staff changes. | Content correctness; review completion; retirement decision | Department (Head is G9–G11) |
| **Custodian** | The named individual who maintains the document day to day, coordinates reviews, and manages the ApexDocs record. | Operational maintenance; metadata quality; version hygiene | G5–G6 |
| **Approver** | The individual with authority to authorise publication, per the Approval Matrix. Cannot be the author. | Fitness for purpose; control adequacy; regulatory alignment | G7–G12 |
| **Audience** | The defined population required to read, acknowledge, or apply the document, expressed as departments, grades, or entitlement groups. | Compliance with the document's requirements | All |

**Supporting principles.**

1. **One owner only.** Joint ownership is not permitted; where two departments have interest, one is Owner and the other is a mandatory Reviewer recorded in metadata.
2. **Ownership transfer.** Reorganisation requires formal reassignment through EKMO within 30 days; orphaned documents are reported monthly to the Enterprise Knowledge Council.
3. **Review discipline.** A document past its review date by more than 90 days is automatically flagged `OVERDUE REVIEW` in search results and escalated to the Owner's Department Head.
4. **Retirement.** Only the Owner may retire a document, and only after confirming that no other controlled document references it or that all referring documents have been updated.

### Appendix C — Knowledge Taxonomy

The enterprise knowledge taxonomy is a four-level hierarchy. Every document is classified to exactly one Level 4 node, which fully determines its Level 1–3 ancestry.

| L1 Domain | L2 Category (examples) | L3 Sub-category (examples) | L4 Document Type |
|---|---|---|---|
| **1. Governance & Legal** | Corporate Governance · Legal Affairs · Corporate Secretariat | Board Governance · Litigation · Entity Management · Contracts | POL · STD · MIN · CTR · MEM |
| **2. Risk & Compliance** | Credit Risk · Market Risk · Operational Risk · Financial Crime · Regulatory Compliance · Model Risk | Underwriting Standards · AML/CFT · Sanctions · KYC · RCSA · Stress Testing | POL · STD · SOP · RPT · FRM · LOG |
| **3. Customer & Products** | Deposit Products · Lending Products · Cards · Investments · Insurance · Digital Channels | Product Terms · Disclosures · Applications · Servicing | POL · SOP · FRM · TPL · GDL |
| **4. Banking Operations** | Branch Operations · Payments & Settlement · Loan Servicing · Trade Operations · Customer Servicing | Cash Handling · Reconciliation · Disputes · Complaints | SOP · MAN · CHK · LOG · RPT |
| **5. Finance & Treasury** | Financial Control · Regulatory Reporting · Planning & Analysis · Liquidity & Funding · Tax | Close & Consolidation · Capital · FTP · Provisioning | POL · SOP · RPT · REG · STD |
| **6. Technology & Data** | Application Management · Infrastructure & Cloud · Information Security · Data Governance · Resilience | Change · Incident · Access · Architecture · Continuity | POL · STD · SOP · PLN · RPT |
| **7. People & Workplace** | Employment · Reward · Learning · Conduct · Workplace Services | Hiring · Leave · Performance · Training · Facilities | POL · HBK · SOP · FRM · TRN |
| **8. Corporate Services** | Procurement & Vendors · Records & Knowledge · Marketing & Communications · Real Estate | Sourcing · Third-Party Risk · Retention · Brand | POL · STD · CTR · SOP · GDL |

**Taxonomy governance.** The taxonomy is owned by EKMO and amended only by the Enterprise Knowledge Council. Level 1 and Level 2 nodes are stable and may be changed at most annually; Level 3 nodes may be added quarterly. Documents are never assigned to a Level 1 or Level 2 node directly. Free-text tagging is permitted **in addition to**, never in place of, taxonomy classification.

### Appendix D — Enterprise Metadata Categories

Every document indexed in ApexDocs carries the metadata below. Fields marked **M** are mandatory at publication; the platform rejects publication without them. This schema is the contract between the document estate and the enterprise knowledge platform.

| Category | Field | M | Description |
|---|---|---|---|
| **Identity** | `document_id` | M | Canonical ID per Section 10.1 |
| | `title` | M | Full document title |
| | `short_title` | M | Filename-safe title, ≤ 40 characters |
| | `document_type` | M | Three-letter type code |
| | `language` | M | ISO 639-1 code; `en` is authoritative |
| **Ownership** | `owner_department` | M | Canonical department code |
| | `custodian` | M | Employee ID of maintainer |
| | `approver` | M | Employee ID of approving authority |
| | `audience` | M | Entitlement groups, departments, or grades |
| **Lifecycle** | `version` | M | `Major.Minor` |
| | `status` | M | Draft · Review · Approved · Published · Superseded · Archived |
| | `created_date` | M | ISO 8601 |
| | `effective_date` | M | ISO 8601 |
| | `last_updated` | M | ISO 8601 |
| | `review_cycle` | M | Annual · Biennial · Event-driven |
| | `next_review_date` | M | ISO 8601 |
| | `supersedes` | | Document ID and version replaced |
| **Classification & Handling** | `classification` | M | C0–C4 per Section 9 |
| | `handling_caveats` | | e.g. `NO-FORWARD`, `INFORMATION-BARRIER`, `PRINT-PROHIBITED` |
| | `contains_pii` | M | Boolean |
| | `contains_mnpi` | M | Boolean |
| | `geographic_restriction` | | Jurisdictions where access is permitted |
| **Regulatory** | `regulatory_driver` | | e.g. BSA, GLBA, SOX, GDPR, Reg E, Basel III |
| | `retention_code` | M | Code from the Document Retention Schedule |
| | `legal_hold` | M | Boolean; set by Legal only |
| | `record_class` | M | Class from Section 11.4 |
| **Business Context** | `taxonomy_l1` … `taxonomy_l4` | M | Four-level taxonomy path per Appendix C |
| | `business_unit` | M | Canonical BU code |
| | `applicable_entities` | M | Legal entities in scope |
| | `applicable_geographies` | M | Countries in scope |
| | `systems_referenced` | | Canonical system names cited in the document |
| **Relationship** | `related_documents` | M | Document IDs of dependencies |
| | `superseded_by` | | Successor document ID |
| | `parent_document` | | Governing policy for a subordinate standard or SOP |
| | `referenced_by` | | Derived; maintained automatically by the platform |
| **Retrieval & Knowledge** | `keywords` | M | Controlled vocabulary terms |
| | `extracted_entities` | | Organisations, systems, roles, regulations detected in content |
| | `extracted_topics` | | Topic model output for discovery |
| | `summary_short` | | One-sentence machine-generated abstract |
| | `summary_detailed` | | Paragraph-level machine-generated abstract |
| **Quality & Assurance** | `confidence_score` | | Platform-assigned confidence in derived metadata (heuristic, not a probability) |
| | `metadata_source` | M | `authored` · `derived` · `hybrid` |
| | `completeness_score` | | Percentage of recommended fields populated |
| | `last_validated_by` | | Employee ID of last metadata reviewer |

**Metadata principles.**

1. **Authored beats derived.** Where a human-entered value and a machine-derived value conflict, the authored value prevails and the discrepancy is logged for review.
2. **Derived metadata is advisory.** Machine-generated summaries, topics, entities, and confidence scores support discovery. They are never a substitute for reading the document and carry no approval authority.
3. **Metadata is a control.** Incomplete or inaccurate metadata is a documentation control deficiency reportable to the Enterprise Knowledge Council and testable by Internal Audit.
4. **Schema stability.** Field names are stable identifiers. Additions are permitted quarterly; removals and renames require Enterprise Knowledge Council approval and a migration plan, because downstream systems bind to these names.

---

**End of Document**

`ANB-ADM-REF-0001` · Version 4.0 · Classification: Internal (C1) · Owner: Enterprise Knowledge Management Office, Administration (ADM) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled and valid only on the date printed. The authoritative version resides in ApexDocs.*
