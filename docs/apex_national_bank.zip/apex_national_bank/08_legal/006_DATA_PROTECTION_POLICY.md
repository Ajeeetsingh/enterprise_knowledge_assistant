# Apex National Bank — Data Protection Policy

**Enterprise Policy | Internal Controls for PII, SPI, Classification, Encryption, AI, and Retention**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-POL-0005` |
| **Document Title** | Data Protection Policy |
| **Version** | 1.0 |
| **Owner** | Legal (LEG) — Privacy with Information Security (ISC) and CDO |
| **Custodian** | Chiara Romano, Head of Privacy & Data Protection (G8) — `EMP-600303` |
| **Approver** | Margaret Sullivan, GC (G11); Nadia Ferreira, CISO (G10) — `EMP-100010` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T8` / `T6` → Data Protection → `POL` |
| **Business Process** | `BP-KNW-RET`, `BP-SEC-IR`, `BP-VEN-DD`, `BP-MDL-INV` |
| **System of Record** | ApexDocs · ApexDLP · ApexID · ApexVault · ApexShield |
| **Customer-Facing Companion** | `ANB-LEG-POL-0004` Privacy Policy |

---

## 2. Purpose

Define mandatory internal controls for protecting Personal Data and Sensitive Personal Data across the Bank’s systems, people, and vendors — including classification, encryption, access, DLP, retention, deletion, incident reporting, Privacy by Design, and restrictions on AI/ML, RAG, and model training.

---

## 3. Scope

All employees, contractors, and vendors processing Bank Data. All environments: production, DR, UAT, analytics, and AI platforms. Complements `ANB-ISC-POL-0001` and `ANB-ISC-STD-0004`.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **PII / Personal Data** | Per `ANB-LEG-POL-0004` |
| **SPI** | Sensitive Personal Data / special category data |
| **Bank Data** | Customer, employee, and confidential business data |
| **Production Data** | Data in live ApexCore / ApexCredit / ApexKYC etc. |
| **Synthetic Data** | Artificially generated data not identifying real persons |
| **RAG** | Retrieval-augmented generation systems using document corpora |
| **Tokenisation** | Replacement of sensitive values with tokens |

---

## 5. Roles

| Role | Responsibility |
|---|---|
| Head of Privacy `EMP-600303` | Policy; DPIA; RoPA |
| CISO `EMP-100010` | Technical control baseline |
| Data Owners | Approve access and purpose |
| Data Stewards | Quality; classification labels |
| Model Risk `EMP-400204` | AI/ML data use with Privacy |
| Employees | Handle data per classification |

---

## 6. Data Classification Mapping

| Class (`ANB-ISC-STD-0004`) | Personal Data Examples | Handling |
|---|---|---|
| C1 Internal | Aggregated non-identifying MI | Internal systems |
| C2 Confidential | Customer name+account; KYC packs | Need-to-know; encryption |
| C3 Restricted | Full ID numbers + auth data; SAR files; biometric templates | Strict need-to-know; enhanced logging |

Misclassification is a control failure — correct via Data Steward workflow.

---

## 7. Encryption and Key Management

**DP-1.** Personal Data in transit: TLS 1.2+ (1.3 preferred).  
**DP-2.** Personal Data at rest in approved stores: AES-256 or equivalent.  
**DP-3.** Keys managed via approved KMS / HSM; no keys in source code.  
**DP-4.** Laptop/endpoint encryption mandatory (ISC standard).  
**DP-5.** Removable media with Personal Data prohibited unless ISC exception.

---

## 8. Access Controls

| Control | Standard |
|---|---|
| Identity | ApexID; joiner-mover-leaver from ApexPeople |
| Least privilege | Role-based; privileged via CyberArk |
| MFA | Required for remote and privileged access (`ANB-ISC-STD-0002`) |
| Recertification | Quarterly privileged; semi-annual standard |
| Query access | Production ad-hoc SQL prohibited without Data Governance approval (align Investigations Manual) |

Access to `CUS-`, `KYC-`, `SAR-`, `EMP-` data logged and monitored.

---

## 9. Backups and DR Copies

Backups inherit classification of source data. DR replicas at `SIT-0002` / cloud regions per `ANB-ITO-PLN-0002` must maintain equivalent controls. Backup retention ≠ business retention — disposal schedules apply to backup media per ApexVault standards.

---

## 10. DLP

ApexDLP monitors exfiltration channels (email, web, endpoints). Channels blocked/quarantined per rules for C2/C3 patterns (PAN, SSN, etc.). Exceptions via ISC `BP-SEC-EXC`. Deliberate bypass is gross misconduct (`ANB-HRM-POL-0004`).

---

## 11. Retention and Deletion

| Requirement | Reference |
|---|---|
| Retention codes | `ANB-ADM-POL-0001` (`RET-CUS-7Y`, `RET-AML-5Y`, etc.) |
| Legal hold override | `LHD-########` — `ANB-LEG-SOP-0006` |
| Deletion | Secure delete / crypto-erase; certify for vendor returns `DES-########` |
| Right to erasure | Assess against legal retention; document denial grounds |

---

## 12. Incident Reporting

Suspected Personal Data breach:

```
Detect → Report immediately via ApexServe / ApexShield (Sev path)
        → ISC triage (ANB-ISC-SOP-0003)
        → Privacy + Legal assess notification duties
        → Regulators / individuals notified as required
        → REV- / INC- records; lessons learned
```

Do not investigate privately or notify customers without Privacy/Legal clearance.

---

## 13. Privacy by Design

New products, channels, and vendors require:

1. Privacy impact screening  
2. DPIA if high risk (profiling, large-scale SPI, systematic monitoring)  
3. Data minimisation and purpose limitation  
4. Security architecture sign-off  
5. RoPA update  

Credit products (`ANB-CBK-POL-0001`, retail lending) and digital onboarding must complete screening before launch.

---

## 14. Vendor Data

Vendors processing Personal Data require:

- MSA/DPA (`ANB-LEG-AGR-0002` Schedule E)  
- TPRM / `VRA-########`  
- Transfer impact assessment if cross-border  
- No subprocessors without approval  
- Return/destruction on exit  

---

## 15. AI Systems; Model Training; RAG; Synthetic Data

| Rule ID | Requirement |
|---|---|
| **AI-1** | Inventory AI systems touching Personal Data in ApexModel (`MDL-########`) |
| **AI-2** | No training of foundation models on production customer data without GC + CISO + Model Risk written approval |
| **AI-3** | Vendor AI features off by default for Bank Data unless DPA expressly allows |
| **AI-4** | RAG corpora must be classification-controlled; no C3 SAR/ privileged content in general RAG indexes |
| **AI-5** | Prefer synthetic or anonymised data for development/testing |
| **AI-6** | Production data in lower environments only via approved masking/tokenisation patterns |
| **AI-7** | Human oversight for adverse customer decisions per `ANB-LEG-POL-0004` / `ANB-RSK-POL-0004` |
| **AI-8** | Prompt/log retention minimised; no pasting C3 into unapproved public LLMs |

Violations escalate to Privacy, Model Risk, and ISC; may trigger `REV-` and disciplinary process.

---

## 16. Production Data Handling

| Environment | Personal Data Rule |
|---|---|
| Production | Full controls; change via CAB |
| UAT / Dev | Masked/synthetic default |
| Analytics | Approved platforms; purpose-limited extracts |
| Endpoints | No local stores of bulk C2/C3 |
| Email | No bulk customer exports; use secure channels |

---

## 17. Decision Tree — Data Use Request

```
Request to use dataset
        │
        ├─ Contains Personal Data? ──NO──► Standard InfoSec path
        ├─ Purpose documented & lawful? ──NO──► Reject
        ├─ AI training / RAG? ──► AI-1..AI-8 gates
        ├─ Vendor / offshore? ──► DPA + TPRM + transfer tool
        └─ Approve with minimisation & retention limit
```

---

## 18. Examples

**Masked UAT:** ApexOrigin UAT uses tokenised `CUS-` identifiers; real SSNs not present.

**Blocked RAG:** Proposal to index ApexGuard SAR narratives into enterprise chatbot — **rejected** under AI-4; C3 exclusion.

**Vendor AI:** SaaS vendor seeks to use Bank emails to train models — contractually prohibited; `MSA-` Schedule E.

---

## 19. Related Documents

`ANB-LEG-POL-0004` · `ANB-LEG-AGR-0001` · `ANB-LEG-AGR-0002` · `ANB-LEG-SOP-0006` · `ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-STD-0004` · `ANB-ISC-SOP-0003` · `ANB-ADM-POL-0001` · `ANB-RSK-POL-0004` · `ANB-RSK-FRM-0002` · `ANB-CMP-SOP-0004` · `ANB-HRM-POL-0004` · `ANB-ITO-PLN-0002` · `ANB-CBK-POL-0001` · `ANB-RTL-GDL-0001`

---

## 20. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | C. Romano | Initial Data Protection Policy; AI/RAG controls |

---

## Appendix A — Control Mapping (Extract)

| Control Theme | Linked CTL / Process |
|---|---|
| Access | ApexID recertification |
| Encryption | ISC encryption standard |
| DLP | ApexDLP policies |
| Vendor | `CTL` via TPRM |
| Retention | `RET-*` codes |
| AI | ApexModel inventory |

## Appendix B — DPIA Trigger List

Large-scale monitoring; systematic SPI; automated significant decisions; new biometric auth; cross-border novel transfers; AI credit decisioning expansion.

---

**End of Document** — `ANB-LEG-POL-0005` v1.0
