# Apex National Bank — Litigation Management Procedure

**Standard Operating Procedure | Legal Holds, Discovery, Privilege, Counsel, and Settlements**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-SOP-0006` |
| **Document Title** | Litigation Management Procedure |
| **Version** | 1.0 |
| **Owner** | Legal (LEG) — Litigation |
| **Custodian** | Jonathan Pierce, Head of Litigation & Investigations Legal (G8) — `EMP-600302` |
| **Approver** | Margaret Sullivan, General Counsel (G11) — `EMP-100006` |
| **Classification** | Confidential (C3) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T8` → Litigation & Disputes → `SOP` |
| **Business Process** | `BP-LEG-MAT`, `BP-LEG-HOLD`, `BP-KNW-RET` |
| **System of Record** | ApexLegal · ApexVault · ApexDocs · Apex Mail journal |
| **Related Documents** | `ANB-ADM-POL-0001`, `ANB-LEG-SOP-0007`, `ANB-LEG-POL-0005`, `ANB-CMP-MAN-0001` |

---

## 2. Purpose

Establish the Bank’s end-to-end process for managing civil litigation, regulatory enforcement litigation, arbitration, and related discovery — including legal holds, evidence preservation, privilege, outside counsel, settlements, and coordination with Financial Crime and Employment matters.

---

## 3. Scope

All legal matters `LIT-########` involving the Bank or Affiliates as party, subpoena recipient, or third-party discovery target. Criminal referrals coordinated with Compliance/Fraud but privilege and hold rules still apply. Ordinary customer complaints without litigation threat follow `ANB-CST-SOP-0001` / `ANB-RTL-MAN-0004` until Legal intake.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Matter** | `LIT-########` in ApexLegal |
| **Legal Hold** | `LHD-########` — preservation obligation |
| **ESI** | Electronically stored information |
| **Privilege** | Attorney-client / work product |
| **Outside Counsel** | External firm matter `OLC-########` |
| **Custodian** | Employee/system holding potentially relevant data |
| **Production Set** | Documents produced under Bates / load file |

---

## 5. Roles

| Role | Employee | Responsibility |
|---|---|---|
| GC | `EMP-100006` | Ultimate authority; Board-sensitive matters |
| Head of Litigation | `EMP-600302` | Procedure; matter assignment |
| Employment Legal | `EMP-600301` | Employment claims |
| Regulatory Response Legal | `EMP-600305` | Overlap with exams / enforcement |
| Business contact | Named G6+ | Fact gathering |
| ITO / ISC | ESI collections | Forensic imaging as directed |
| Outside Counsel | `OLC-` firm | Advocacy under engagement letter |

---

## 6. Matter Intake and Assignment

```
Claim / summons / subpoena / arbitration notice / threat letter
        → ApexServe Legal intake / ApexLegal LIT-########
        → Conflict check
        → Assign Litigation counsel + business contact
        → Assess insurance notice
        → Issue Legal Hold LHD-######## (if preservation duty)
        → Engage OLC- if needed
```

**SLA:** Critical process/service of papers — notify Litigation same day; default response calendaring within 24 hours of intake.

---

## 7. Legal Hold (`BP-LEG-HOLD`)

**LIT-HOLD-1.** When litigation is pending or reasonably anticipated, issue `LHD-########` to custodians and IT systems.

**Hold notice contents:** matter description (high level); preservation scope; prohibition on deletion; contact; acknowledgment.

| System | Preservation Action |
|---|---|
| Apex Mail | Journal + custodian mailbox hold |
| ApexDocs / ApexVault | Object hold; suspend disposition |
| ApexCore / ApexCredit | Record retain flags as directed |
| Laptops / mobile | Collection / hold instruction |
| Chat (Teams) | Hold via M365 compliance |

**Release:** Only when Litigation counsel issues written release; coordinate `ANB-ADM-POL-0001` disposition restart.

Failure to preserve after hold = potential spoliation — escalate to GC immediately.

---

## 8. Evidence Preservation and Chain of Custody

| Step | Requirement |
|---|---|
| Identification | Data map by custodian/system |
| Collection | Forensic sound methods for key custodians |
| Chain of custody | Log collector, hash, time, transfer (`EVID` artefacts) |
| Processing | Privilege screen before production |
| Storage | Secure repository; C3 |

Do not alter metadata; do not run “cleanup” projects on held custodians.

---

## 9. Court Orders; Subpoenas; Discovery

**9.1** Service of process: route to Litigation immediately; do not accept informal service without counsel instruction.  
**9.2** Subpoenas for customer records: consider privacy, GLBA, and right to notice; coordinate `ANB-LEG-POL-0004`; never produce SAR files improperly (`ANB-CMP-SOP-0004`).  
**9.3** Discovery plans: proportionality; clawback orders (FRE 502) sought where appropriate.  
**9.4** Depositions: prepare witnesses; privilege instructions.

---

## 10. Privilege

| Rule | Detail |
|---|---|
| Labeling | Privilege / Work Product on Legal materials |
| Circulation | Limit distribution; prefer counsel-directed |
| Dual-purpose | Careful — business advice may not be privileged |
| Waiver | Only GC / Head of Litigation may authorize |
| Common interest | Written agreement before sharing with Affiliates/co-defendants |

Investigations by Financial Crime remain confidential; Legal coordinates privilege overlays when dual-track (`ANB-CMP-MAN-0001`).

---

## 11. Outside Counsel

| Step | Standard |
|---|---|
| Selection | Approved panel; conflicts cleared |
| Engagement | Engagement letter `OLC-########`; budgets |
| Billing | ApexLegal spend management; guidelines |
| Strategy | Bank Litigation counsel retains control of settlement authority path |
| Diversity / performance | Periodic panel review |

---

## 12. Expert Witnesses

Retained via Outside Counsel or directly with engagement letters. Independence and disclosure obligations managed. Work product protected where applicable.

---

## 13. Settlement Approvals

| Amount / Sensitivity | Approver |
|---|---|
| ≤ USD 250,000 routine | Head of Litigation |
| ≤ USD 2,000,000 | General Counsel |
| ≤ USD 10,000,000 | GC + CFO |
| > USD 10,000,000 or novel precedent / class action | ExCo / Board as charter requires |
| Employment settlements | Employment Legal + CHRO path |
| Regulatory consent orders | GC + CCO + CEO; Board committees per `ANB-LEG-REF-0003` |

Settlements documented; confidentiality clauses vetted; no admission language without GC approval.

---

## 14. Regulatory Litigation and Criminal Referrals

Enforcement actions and contested regulatory proceedings: joint ownership with `EMP-600305` / `ANB-LEG-SOP-0007`. Criminal referrals (e.g., fraud) coordinated with Fraud `EMP-400106`, BSA Officer, and GC — preserve privilege and holds.

---

## 15. Document Production

```
Request → Scope negotiation → Custodian collection
        → Process / OCR → Privilege review
        → Redaction (PII, privilege, SAR)
        → Produce with log → Clawback if needed
```

Production sets tracked in ApexLegal; load files retained.

---

## 16. Legal Timelines (Illustrative US Federal)

| Event | Typical Timeline |
|---|---|
| Answer after service | 21 days (or order) |
| Hold issuance | Within 48 hours of anticipation |
| Initial disclosures | Per scheduling order |
| Settlement authority pack | 5 business days before mediation |

Calendaring owned by assigned counsel; defaults prohibited.

---

## 17. Decision Tree — Hold vs No Hold

```
New dispute signal
        │
        ├─ Complaint filed / arbitration commenced? ──► Hold mandatory
        ├─ Credible threat + relevant ESI at risk? ──► Hold
        ├─ Routine complaint, no counsel threat? ──► Monitor CST path
        └─ Regulatory exam document request only? ──► SOP-0007; hold if enforcement reasonably anticipated
```

---

## 18. Examples

**Civil:** Vendor claims under `MSA-202605-0088` — `LIT-202607-0018`; hold `LHD-202607-0018` to Procurement/ITO custodians; OLC engaged `OLC-202608-0007`; settlement within GC authority.

**Customer subpoena:** Requests full file including monitoring — produce account docs; withhold SAR; move for protective order if needed.

**Employment:** Former employee claim — Employment Legal lead; hold on manager mailbox; coordinate HR `EMP-200201`.

---

## 19. Related Documents

`ANB-LEG-SOP-0007` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-LEG-AGR-0002` · `ANB-ADM-POL-0001` · `ANB-CMP-SOP-0004` · `ANB-CMP-MAN-0001` · `ANB-HRM-AGR-0001` · `ANB-HRM-POL-0004` · `ANB-RSK-FRM-0002` · `ANB-CBK-CTR-0002` · `ANB-LEG-REF-0003` · `ANB-CST-SOP-0001`

---

## 20. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | J. Pierce | Initial litigation management procedure |

---

## Appendix A — Legal Hold Acknowledgment Fields

Hold ID; custodian EMP; systems in scope; acknowledgment timestamp; escalation if no ack in 5 days.

## Appendix B — Settlement Memorandum Minimum Contents

Matter ID; claims; reserve; settlement amount; non-monetary terms; authority level; Board/ExCo need; reputational assessment; lessons for ORC if control failure.

---

**End of Document** — `ANB-LEG-SOP-0006` v1.0 · C3
