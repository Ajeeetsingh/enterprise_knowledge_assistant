# Apex National Bank — Master Loan Agreement

**Controlled Credit Agreement Template | Bilateral Facilities for Commercial and Corporate Borrowers**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-CTR-0002` |
| **Document Title** | Master Loan Agreement Template |
| **Version** | 2.3 |
| **Owner** | Legal (LEG) with Corporate Banking (CBK) |
| **Custodian** | Ananya Krishnan, Head of Commercial Contracts (G8) — `EMP-600304` |
| **Approver** | Margaret Sullivan, General Counsel (G11) — `EMP-100006` |
| **Credit Concurrence** | Lars Henriksson, Head of Credit Risk (G9) — `EMP-400201` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T2` → `T2.1` Credit Risk → Documentation → `CTR` |
| **Business Process** | `BP-CRD-DOC`, `BP-CRD-APPR`, `BP-SRV-BOOK`, `BP-CORP-COV` |
| **System of Record** | ApexLegal · ApexDocs · ApexCredit · ApexOrigin |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-CBK-POL-0002`, `ANB-CBK-SOP-0001`, `ANB-CBK-TPL-0003` |

> **Usage.** Populate for each facility `FAC-########`. Instance stored as `CON-########`. Schedules customize economics, collateral (`COL-`), guarantors, and covenants (`COV-`).

---

## 2. Purpose

Provide the Bank’s standard bilateral loan agreement text for revolving and term facilities, ensuring enforceability of repayment, default, security, and covenant frameworks consistent with credit approval (`ANB-CBK-SOP-0001`).

---

## 3. Scope

Commercial and corporate bilateral facilities under `ANB-CBK-POL-0001`. Syndicated forms use separate agented templates. Trade instruments (`LC-`, `BG-`) may be issued under facility sublimits per Schedule 2 and `ANB-CBK-MAN-0001`.

---

## 4. Form of Agreement — Operative Provisions

**MASTER LOAN AGREEMENT**  
**Contract Instance:** `CON-########` · **Facility:** `FAC-########`  
**Dated as of:** ________  
**Borrower:** ________ (`CORP-########` / `CUS-########`)  
**Lender:** Apex National Bank, N.A.

### ARTICLE I — DEFINITIONS AND INTERPRETATION

**Section 1.01 Certain Definitions.**  
“**Affiliate**,” “**Business Day**,” “**Capital Lease**,” “**Change of Control**,” “**Collateral**,” “**Commitment**,” “**Default**,” “**Event of Default**,” “**GAAP**,” “**Guarantor**,” “**Interest Period**,” “**Lien**,” “**Loan Documents**,” “**Material Adverse Effect**,” “**Obligations**,” “**Permitted Lien**,” “**SOFR**,” “**Subsidiary**,” and other terms have meanings in Schedule 1.01.

“**Facility ID**” means `FAC-________`.  
“**Limit ID**” means `LMT-________`.  
“**Borrowing**” means a draw of Loans.  
“**Letter of Credit**” means an LC issued under Schedule 2 (`LC-########`).  
“**Bank Guarantee**” means a guarantee issued under Schedule 2 (`BG-########`).

**Section 1.02 Interpretation.** Headings illustrative; including means without limitation; accounting terms per GAAP unless redefined.

### ARTICLE II — THE FACILITY

**Section 2.01 Commitment.** Subject to terms hereof, Lender agrees to make Loans to Borrower from time to time during the Availability Period in an aggregate principal amount not exceeding the Commitment set forth in Schedule 2.01 (the “**Facility**”).

**Section 2.02 Types of Facilities.** Schedule 2.01 specifies whether the Facility is a Revolving Credit Facility, Term Loan, or combination, and any ABL borrowing base.

**Section 2.03 Requests for Borrowings.** Borrower shall deliver an irrevocable Borrowing Request by timing in Schedule 2.03 via authenticated channel. Each Borrowing shall be in minimum amounts stated therein.

**Section 2.04 Letters of Credit and Guarantees.** If Schedule 2 so provides, Lender may issue LCs/BGs within the LC Sublimit; LC exposure reduces Availability. Issuance subject to `ANB-CBK-MAN-0001` and sanctions clearance.

**Section 2.05 Repayment of Loans.**  
(a) **Revolving Loans.** Principal outstanding due on the Maturity Date; interim clean-down if Schedule requires.  
(b) **Term Loans.** Amortisation per Schedule 2.05; remaining principal on Maturity Date.  
(c) All Obligations due on acceleration under Article VII.

**Section 2.06 Prepayments.**  
(a) Optional prepayment upon notice, subject to break-funding.  
(b) Mandatory prepayment upon: asset sales (net proceeds), insurance proceeds not reinvested, Change of Control, or borrowing base deficiency (ABL), as Schedule 2.06 provides.

**Section 2.07 Interest.**  
(a) Loans bear interest at Term SOFR (or Base Rate) plus Applicable Margin in Schedule 2.07.  
(b) Interest payable on Interest Payment Dates.  
(c) Default interest: Applicable Margin + **2.00%** per annum upon Event of Default.  
(d) Computation: actual/360 for SOFR Loans unless Schedule states otherwise.

**Section 2.08 Fees.** Commitment fee on unused Commitment; LC fees; amendment fees — Schedule 2.08. FTP-aware pricing per credit approval and `ANB-TRY-MAN-0001` is an internal Bank matter and does not modify Borrower’s payment obligation.

**Section 2.09 Evidence of Debt.** Lender’s ApexCore / ApexCredit records are prima facie evidence of Obligations.

### ARTICLE III — CONDITIONS

**Section 3.01 Conditions Precedent to Effectiveness.** Including: executed Loan Documents; perfected Collateral (`ANB-CBK-POL-0002`); KYC/CIP clear (`ANB-CMP-POL-0002`); resolutions; opinions; insurance; no Default; payment of fees.

**Section 3.02 Conditions to Each Credit Extension.** Accuracy of representations; no Default; Borrowing Request; borrowing base certificate if ABL; sanctions screening satisfactory.

### ARTICLE IV — REPRESENTATIONS AND WARRANTIES

Borrower represents and warrants that:

**4.01** Organization; power; authority.  
**4.02** Enforceability of Loan Documents.  
**4.03** No conflict with law, charter, or material agreements.  
**4.04** Financial statements (`FIN-########`) fairly present; no Material Adverse Effect since date thereof.  
**4.05** No material litigation except as disclosed on Schedule 4.05 (`LIT-` matters).  
**4.06** Compliance with law; anti-corruption; sanctions; AML.  
**4.07** Beneficial ownership information accurate.  
**4.08** Title to properties; Collateral as represented.  
**4.09** Margin regulations; Investment Company Act.  
**4.10** Solvency.  
**4.11** Taxes filed and paid.  
**4.12** Full disclosure — no material misstatement in credit materials including memorandum under `ANB-CBK-TPL-0003`.

Representations deemed repeated on each Credit Extension date.

### ARTICLE V — AFFIRMATIVE COVENANTS

Until Obligations paid in full:

**5.01** Financial reporting as Schedule 5.01 (quarterly/annual; covenant compliance certificate referencing `COV-########`).  
**5.02** Notices of Default, Material Adverse Effect, ERISA events, litigation material.  
**5.03** Preservation of existence; conduct of business.  
**5.04** Payment of taxes and obligations.  
**5.05** Maintenance of insurance.  
**5.06** Maintenance of properties.  
**5.07** Books and records; inspection rights for Lender and regulators.  
**5.08** Compliance with laws; sanctions; anti-corruption.  
**5.09** Use of proceeds as stated in Schedule 5.09 (not for prohibited purposes).  
**5.10** Further assurances; perfection of Collateral.  
**5.11** KYC refresh cooperation (`ANB-CMP-POL-0002`).  
**5.12** Beneficial ownership updates within ten (10) Business Days of change.

### ARTICLE VI — NEGATIVE COVENANTS

Borrower shall not, without Lender consent:

**6.01** Incur Indebtedness except Permitted Indebtedness.  
**6.02** Create Liens except Permitted Liens.  
**6.03** Merge, consolidate, or Dispose of all/substantially all assets.  
**6.04** Make Restricted Payments except as Schedule 6.04 permits.  
**6.05** Make Investments except Permitted Investments.  
**6.06** Engage in unrelated lines of business.  
**6.07** Enter into affiliate transactions except arm’s-length.  
**6.08** Amend organizational documents in adverse manner.  
**6.09** Change fiscal year without notice.  
**6.10** Use proceeds to buy margin stock in violation of Regulations T/U/X.

**Section 6.11 Financial Covenants.** Maintain as of each Test Date the ratios in Schedule 6.11 (e.g., Max Consolidated Leverage; Min Interest Coverage), tested per definitions — covenant IDs `COV-________`.

### ARTICLE VII — EVENTS OF DEFAULT AND ACCELERATION

**Section 7.01 Events of Default.** Each of the following is an Event of Default:

(a) Failure to pay principal when due;  
(b) Failure to pay interest/fees within three (3) Business Days;  
(c) Breach of covenant in Articles V/VI uncured within cure period (if any);  
(d) Breach of financial covenant (no cure unless waiver);  
(e) Representation false in any material respect;  
(f) Cross-default to Material Indebtedness (≥ threshold in Schedule 7.01);  
(g) Insolvency, bankruptcy, receivership;  
(h) Judgment above threshold unpaid;  
(i) Actual or asserted invalidity of Loan Documents/Guarantee/Collateral;  
(j) Change of Control;  
(k) ERISA event with Material Adverse Effect;  
(l) Material Adverse Effect as determined in good faith by Lender;  
(m) Sanctions or AML violation.

**Section 7.02 Remedies.** Upon Event of Default, Lender may: (i) terminate Commitments; (ii) declare all Obligations immediately due; (iii) demand cash collateral for LC exposure; (iv) exercise Collateral rights; (v) set off deposits (`ACC-##########`); (vi) pursue any other rights at law/equity.

**Section 7.03 Application of Proceeds.** Per intercreditor/security documents; otherwise to Obligations in Lender’s discretion.

### ARTICLE VIII — GUARANTEE (IF APPLICABLE)

**Section 8.01** Each Guarantor absolutely, unconditionally guarantees punctual payment of Obligations (Schedule 8).  
**Section 8.02** Guarantee continues until Obligations paid; waives certain defenses to extent permitted.  
**Section 8.03** Contribution among Guarantors as Schedule provides.

### ARTICLE IX — SECURITY

**Section 9.01** Obligations secured by Collateral described in Security Agreement / Mortgages (`COL-########`) per `ANB-CBK-POL-0002`.  
**Section 9.02** Borrower shall maintain perfection and priority.  
**Section 9.03** Release of Collateral only per Loan Documents and Bank collateral release authority.

### ARTICLE X — YIELD PROTECTION; ILLEGALITY; TAXES

**10.01** Increased costs; capital adequacy.  
**10.02** Illegality / inability to determine SOFR — Base Rate fallback / successor rate protocol.  
**10.03** Taxes — gross-up for Indemnified Taxes; FATCA; forms (W-9/W-8).

### ARTICLE XI — ASSIGNMENT; PARTICIPATIONS

Lender may assign or participate with Borrower consent not unreasonably withheld (except to Competitors listed on Schedule 11); consent not required for assignment to Affiliate or upon Event of Default. Borrower may not assign without Lender consent.

### ARTICLE XII — MISCELLANEOUS

**12.01** Notices (including electronic).  
**12.02** Amendments; Waivers — written only; waivers not continuing. Waiver authority internal to Bank per `ANB-CBK-POL-0001` §12.  
**12.03** Expenses; indemnity; damage waiver.  
**12.04** Right of setoff.  
**12.05** Governing Law — State of New York.  
**12.06** Waiver of jury trial.  
**12.07** Submission to jurisdiction — New York County.  
**12.08** Counterparts; electronic signatures.  
**12.09** Entire Agreement.  
**12.10** Severability.  
**12.11** PATRIOT Act notice.  
**12.12** No advisory or fiduciary relationship.  
**12.13** Acknowledgement regarding any supported QFCs.  
**12.14** Confidentiality of Lender information regarding Borrower — subject to regulatory disclosure rights (`ANB-LEG-SOP-0007`).

---

## 5. Schedules (Required Attachments)

| Schedule | Content |
|---|---|
| 1.01 | Definitions |
| 2.01 | Commitment; Facility type; IDs `FAC-` / `LMT-` |
| 2.03 | Borrowing mechanics |
| 2.05 | Amortisation |
| 2.06 | Mandatory prepayments |
| 2.07 | Applicable Margin grid by `CRR-` / pricing grid |
| 2.08 | Fees |
| 2 | LC/BG sublimits |
| 4.05 | Disclosed litigation |
| 5.01 | Reporting |
| 5.09 | Use of proceeds |
| 6.04 / 6.11 | Restricted payments; financial covenants `COV-` |
| 7.01 | Cross-default threshold |
| 8 | Guarantors |
| 9 | Collateral list `COL-` |
| 11 | Competitors |

---

## 6. Signature Blocks

```
BORROWER:                         LENDER:
CORP-________                     APEX NATIONAL BANK, N.A.

By: ________________  SIG-____   By: ________________  SIG-____
Name/Title/Date                   Name/Title/Date

GUARANTOR (if any):
By: ________________  SIG-____
```

---

## 7. Worked Example — Meridian Facility

| Field | Value |
|---|---|
| CON | `CON-20260612-1001` |
| FAC / LMT | `FAC-10028441` / `LMT-10028441` |
| Borrower | Meridian Advanced Materials Inc. `CORP-10000001` / `CUS-10028441` |
| Commitment | USD 75,000,000 RCF |
| Margin | SOFR + 2.25% |
| Maturity | 2029-06-12 |
| Covenants | `COV-10028441-01` Debt/EBITDA ≤ 3.5x; `COV-10028441-02` Interest cover ≥ 3.0x |
| Collateral | `COL-10028441-GSA`; `COL-10028441-RE` |
| Approval | GrCC 2026-06-12 per `ANB-CBK-SOP-0001` |
| RM / Analyst | `EMP-300301` / `EMP-300302` |

---

## 8. Approval Authorities (Documentation)

| Action | Approver |
|---|---|
| Use of standard template | Credit Admin + Legal |
| Material negotiated deviation | Legal + Credit Risk |
| Waiver of Event of Default | Per `ANB-CBK-POL-0001` waiver grid |
| Release of Collateral | `ANB-CBK-POL-0002` |

---

## 9. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-POL-0002` · `ANB-CBK-SOP-0001` · `ANB-CBK-TPL-0003` · `ANB-CBK-GDL-0001` · `ANB-CBK-MAN-0001` · `ANB-CMP-POL-0001`/`0002` · `ANB-RSK-FRM-0001` · `ANB-TRY-MAN-0001` · `ANB-LEG-AGR-0001` · `ANB-LEG-SOP-0006` · `ANB-LEG-SOP-0007` · `ANB-ADM-MTX-0001`

---

## 10. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 2.0 | 2025-04-20 | Legal / CBK | SOFR permanent hardwired |
| 2.3 | 2026-07-31 | A. Krishnan | Alignment to CBK domain entities; QFC ack |

---

## Appendix A — Conditions Precedent Checklist (Excerpt)

- [ ] Executed Agreement `CON-`  
- [ ] Security agreements; UCC filed  
- [ ] KYC Clear  
- [ ] Insurance binders  
- [ ] Officer’s certificate  
- [ ] Opinion of counsel (as required)  
- [ ] First Borrowing Request  

## Appendix B — Event of Default Notice Legend

Notices of Default shall reference `FAC-` and be delivered per Section 12.01; copy Credit Administration `EMP-300307` and Special Assets if payment or insolvency default.

---

**End of Document** — `ANB-CBK-CTR-0002` v2.3
