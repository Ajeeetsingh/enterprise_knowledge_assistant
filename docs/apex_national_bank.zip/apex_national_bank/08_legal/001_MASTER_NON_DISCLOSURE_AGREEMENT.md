# Apex National Bank — Master Non-Disclosure Agreement

**Controlled Agreement Form | Mutual Confidentiality for External Parties**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-AGR-0001` |
| **Document Title** | Master Non-Disclosure Agreement |
| **Version** | 1.0 |
| **Owner** | Legal Department (LEG) |
| **Custodian** | Margaret Sullivan, General Counsel & Corporate Secretary (G11) — `EMP-100006` |
| **Approver** | General Counsel (`EMP-100006`) |
| **Status** | Approved — Published Form |
| **Classification** | Internal (C1) — executed instances may be C2/C3 |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Biennial |
| **Retention** | `RET-POL-10Y` (form); executed NDAs per `ANB-ADM-POL-0001` |
| **Taxonomy** | `T8` → `T8.2` Legal Agreements → `AGR` |
| **Business Process** | `BP-VEN-CTR`, `BP-LEG-MAT`, `BP-PRC-TPRM` |
| **System of Record** | ApexLegal · ApexDocs · ApexSource |
| **Related Documents** | See §20 |

> **Authority.** This is the Bank’s standard mutual NDA form for vendors, advisors, bidders, counterparties, and other external parties. Deviations require Legal approval under `ANB-ADM-MTX-0001`. Canonical legal entities for Domain 8 are defined in Appendix A.

---

## 2. Purpose

To protect Confidential Information of Apex National Bank and the counterparty during evaluation, negotiation, due diligence, and ongoing relationships, while preserving the Bank’s ability to meet regulatory, supervisory, and judicial obligations.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| Mutual NDA with external legal persons | Employee confidentiality (covered by `ANB-HRM-AGR-0001` / Code of Conduct) |
| Pre-contract diligence; RFP; advisory | Customer account secrecy alone (also GLBA / Privacy Policy) |
| Cross-border disclosures under this form | Substitution for data processing agreement (DPA) — use MSA schedules |

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Agreement** | This Master NDA, including schedules and any Order Form referencing it — instance ID `NDA-########` |
| **Disclosing Party** | Party disclosing Confidential Information |
| **Receiving Party** | Party receiving Confidential Information |
| **Confidential Information** | As defined in Clause 1 |
| **Bank** | Apex National Bank, N.A. and designated Affiliates listed in Schedule 1 |
| **Affiliate** | Entity controlling, controlled by, or under common control with a Party |
| **Representatives** | Employees, officers, directors, professional advisors under confidentiality duties |
| **Personal Data** | PII/NPI as under `ANB-LEG-POL-0004` / `ANB-LEG-POL-0005` |
| **Trade Secret** | Information qualifying as trade secret under applicable law |

---

## 5. Form of Agreement — Operative Clauses

**MASTER NON-DISCLOSURE AGREEMENT**  
**Instance:** `NDA-########` · **Effective Date:** ________  
**Parties:** (1) Apex National Bank, N.A. (“**Bank**”); (2) ________ (“**Counterparty**”)

### CLAUSE 1 — Confidential Information

**1.1** “Confidential Information” means all non-public information, whether oral, written, electronic, or in any other form, disclosed by or on behalf of a Disclosing Party, including without limitation: business plans; financial data; customer and employee data; product designs; security architecture; source code; model documentation; pricing; credit files; vendor assessments; and the existence and terms of discussions between the Parties.

**1.2** Confidential Information includes information marked “Confidential,” “C2,” “C3,” or equivalent, and information that a reasonable person would understand to be confidential given its nature or the circumstances of disclosure.

**1.3** Confidential Information includes **Trade Secrets** and materials classified under `ANB-ISC-STD-0004` as Confidential (C2) or Restricted (C3).

**1.4 Exclusions.** Confidential Information does not include information that: (a) is or becomes public other than by breach; (b) was rightfully known to Receiving Party without restriction before disclosure; (c) is independently developed without use of Confidential Information; or (d) is rightfully received from a third party without confidentiality duty.

### CLAUSE 2 — Mutual Obligations; Non-Use

**2.1** Receiving Party shall: (a) hold Confidential Information in strict confidence; (b) use it solely for the **Permitted Purpose** stated in Schedule 2; (c) not reverse-engineer, decompile, or derive underlying models/algorithms except as expressly permitted; and (d) apply protections no less rigorous than those for its own similar information, and in no event less than reasonable care.

**2.2** Receiving Party shall not use Bank Confidential Information to compete with the Bank, solicit Bank customers using such information, or train AI/ML systems except as expressly authorized in writing under `ANB-LEG-POL-0005` and `ANB-RSK-POL-0004`.

### CLAUSE 3 — Disclosure Restrictions

**3.1** Receiving Party shall not disclose Confidential Information to any third party except: (a) Representatives with a need to know who are bound by written confidentiality obligations no less protective; (b) permitted disclosures under Clause 4; or (c) with prior written consent of Disclosing Party (consent ID `SIG-########` where executed via ApexLegal).

**3.2** Receiving Party remains liable for breaches by its Representatives and subcontractors.

### CLAUSE 4 — Permitted Disclosures

**4.1 Regulatory / Supervisory.** Either Party may disclose Confidential Information to bank regulators, supervisors, or self-regulatory organizations with jurisdiction (including OCC, Federal Reserve, FinCEN, FCA, and equivalent), or as required to respond to examinations under `ANB-LEG-SOP-0007`, without prior notice where legally prohibited from giving notice; otherwise Receiving Party shall give prompt notice to the extent legally permitted.

**4.2 Legal Process.** Disclosure compelled by court order, subpoena, or applicable law is permitted if Receiving Party: (a) provides prompt notice (unless prohibited); (b) reasonably cooperates in seeking protective order; and (c) discloses only the portion legally required.

**4.3 Professional Advisors.** Disclosure to legal counsel and auditors under professional confidentiality is permitted.

### CLAUSE 5 — Banking Confidentiality and Customer Information

**5.1** Counterparty acknowledges that Bank customer information is subject to GLBA, applicable privacy laws, and `ANB-LEG-POL-0004`. Customer NPI shall be treated as C2 minimum and C3 where investigation- or SAR-adjacent.

**5.2** Counterparty shall not request, and Bank shall not disclose pursuant to this NDA alone, the existence or non-existence of any Suspicious Activity Report (`SAR-########`) or related investigation (`INV-AML-########` / `AML-CASE-########`), consistent with `ANB-CMP-SOP-0004`.

**5.3** Access to production customer data requires a separate data processing / MSA schedule under `ANB-LEG-AGR-0002` and vendor risk clearance (`ANB-RSK-FRM-0002`, `ANB-PRC-POL-0002`).

### CLAUSE 6 — Trade Secrets; Intellectual Property

**6.1** Trade Secrets shall be protected for so long as they remain trade secrets.

**6.2** No license under any patent, copyright, trademark, or other IP is granted except the limited right to use Confidential Information for the Permitted Purpose.

**6.3** All Bank IP, including Apex-branded systems (ApexCore, ApexCredit, ApexTrade, etc.), remains Bank property. Feedback may be used by Bank without restriction unless designated as Counterparty Trade Secret in writing.

### CLAUSE 7 — Return / Destruction

**7.1** Upon written request or termination, Receiving Party shall promptly return or securely destroy Confidential Information and certify destruction in writing (certificate ID `DES-########`), except: (a) archival copies required by law or bona fide records retention policy; (b) automatic backup copies purged on ordinary cycles; and (c) materials under legal hold (`LHD-########`) per `ANB-LEG-SOP-0006`.

**7.2** Destruction of Bank data shall meet standards in `ANB-LEG-POL-0005` and `ANB-ADM-POL-0001`.

### CLAUSE 8 — Term; Survival

**8.1** This Agreement continues for **three (3) years** from Effective Date unless earlier terminated by either Party on thirty (30) days’ written notice.

**8.2** Obligations survive for **five (5) years** after termination regarding Confidential Information, and indefinitely regarding Trade Secrets and Personal Data for so long as applicable law requires.

### CLAUSE 9 — Injunctive Relief

**9.1** Breach may cause irreparable harm. Disclosing Party is entitled to injunctive or other equitable relief without proving actual damages or posting bond to the extent permitted by law, in addition to other remedies.

### CLAUSE 10 — Data Classification Mapping

| Bank Classification (`ANB-ISC-STD-0004`) | NDA Treatment |
|---|---|
| C1 Internal | Confidential Information if non-public |
| C2 Confidential | Confidential Information — enhanced controls |
| C3 Restricted | Confidential Information — need-to-know; no offshore without approval |

### CLAUSE 11 — Cross-Border Transfers

**11.1** Cross-border transfer of Personal Data requires compliance with `ANB-LEG-POL-0004` / `0005` (SCCs, UK IDTA, or other transfer tools as applicable) and shall not occur under this NDA alone without a DPA.

### CLAUSE 12 — Relationship with Other Policies

**12.1** This NDA is complementary to `ANB-LEG-POL-0004` (Privacy Policy) and `ANB-LEG-POL-0005` (Data Protection Policy). In conflict regarding Personal Data, the stricter obligation controls.

**12.2** Vendor engagements additionally require `ANB-LEG-AGR-0002` (or `ANB-LEG-CTR-0001` template lineage) and TPRM clearance.

### CLAUSE 13 — No Obligation to Proceed

**13.1** Neither Party is obligated to enter any further agreement or transaction by executing this NDA.

### CLAUSE 14 — No Warranty

**14.1** Confidential Information is provided “as is.” Disclosing Party does not warrant accuracy or completeness, except that it has the right to disclose for the Permitted Purpose.

### CLAUSE 15 — Governing Law; Venue

**15.1** This Agreement is governed by the laws of the State of New York, without regard to conflicts principles.

**15.2** Exclusive jurisdiction: state or federal courts located in New York County, New York, except that Bank may seek injunctive relief in any jurisdiction where breach occurs.

### CLAUSE 16 — Miscellaneous

**16.1** Entire agreement regarding confidentiality of disclosures hereunder; supersedes prior NDAs on same subject unless Schedule 3 preserves them.  
**16.2** Amendments only in writing signed by authorized signatories (`SIG-########`).  
**16.3** Assignment only with consent, except Bank may assign to Affiliate.  
**16.4** Severability; waiver must be written.  
**16.5** Counterparts / electronic signatures permitted (ESIGN / eIDAS as applicable).  
**16.6** Notices to addresses in Schedule 1.

---

## 6. Schedules (Form)

### Schedule 1 — Parties and Affiliates

Bank Affiliates may include: Apex Financial Group, Inc.; Apex National Bank (UK) plc; Apex Bank Europe SE; Apex Securities LLC; Apex Asset Management, Inc.; Apex Trust Company, N.A.; Apex Global Services.

### Schedule 2 — Permitted Purpose

Describe: e.g., “Evaluation of proposed managed services for ApexATM FLM under RFP-________.”

### Schedule 3 — Prior Agreements

List any surviving NDAs by `NDA-` ID.

---

## 7. Approval Authorities

| Action | Approver |
|---|---|
| Use of standard form (no redlines) | Business sponsor G6+ after Legal form publication |
| Material redlines | Legal counsel + GC delegate |
| Acceptance of unilateral counterparty paper | Legal mandatory |
| Disclosure of C3 under NDA | Data Owner + Legal |

---

## 8. Example Executed Agreement

| Field | Value |
|---|---|
| Instance | `NDA-20260315-0044` |
| Counterparty | Helix Field Services Inc. (prospective ATM FLM vendor) |
| Permitted Purpose | Diligence for ApexATM replenishment services |
| Bank signatory | `SIG-20260315-0088` — Legal counsel delegate |
| Counterparty signatory | `SIG-20260315-0089` |
| Linked vendor diligence | `VRA-202604-0099` path / `ANB-RSK-FRM-0002` |
| Classification | C2 |

---

## 9. Process Flow — NDA Execution

```
Business need identified
        → Intake ApexServe / ApexLegal
        → Issue ANB-LEG-AGR-0001 form (NDA-########)
        → Negotiate redlines (if any)
        → Dual signature SIG-
        → Store ApexDocs / ApexLegal
        → If vendor path → continue ANB-LEG-AGR-0002 + TPRM
```

---

## 10. Obligations and Exceptions

**Obligations:** confidentiality; limited use; Representative management; regulatory cooperation; return/destruction.

**Exceptions:** Clause 1.4 exclusions; Clause 4 permitted disclosures; legal hold retention.

---

## 11. Cross-Domain References

| Domain | Documents |
|---|---|
| Governance | `ANB-ADM-REF-0001`, `ANB-ADM-STD-0005`/`0006`/`0007`, `ANB-ADM-MTX-0001`, `ANB-ADM-POL-0001`, `ANB-ISC-STD-0004` |
| HR | `ANB-HRM-POL-0004`, `ANB-HRM-AGR-0001` |
| Finance | `ANB-FIN-POL-0001` (where diligence on financials) |
| Compliance | `ANB-CMP-POL-0001`, `ANB-CMP-SOP-0004` |
| Risk / Vendor | `ANB-RSK-FRM-0002`, `ANB-PRC-POL-0002` |
| Legal siblings | `ANB-LEG-AGR-0002`, `ANB-LEG-POL-0004`, `ANB-LEG-POL-0005`, `ANB-LEG-SOP-0006`, `ANB-LEG-SOP-0007` |

---

## 12. Review Cycle / Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | M. Sullivan / Contracts | Initial published Master NDA |

---

## 13. Appendices

### Appendix A — Canonical Legal Entity Register (Domain 8)

| Entity | Format | Example | System |
|---|---|---|---|
| NDA Instance | `NDA-########` | `NDA-20260315-0044` | ApexLegal |
| Contract / Agreement Instance | `CON-########` | `CON-20260401-1002` | ApexLegal |
| MSA Instance | `MSA-########` | `MSA-202605-0088` | ApexLegal |
| Clause Reference | `CLA-###` | `CLA-012` | ApexDocs clause library |
| Signature Event | `SIG-########` | `SIG-20260315-0088` | ApexLegal |
| Destruction Certificate | `DES-########` | `DES-20261201-0012` | ApexVault |
| Legal Hold | `LHD-########` | `LHD-202608-0044` | ApexVault |
| Litigation Matter | `LIT-########` | `LIT-202607-0018` | ApexLegal |
| Regulatory Request | `REG-REQ-########` | `REG-REQ-202609-0033` | ApexLegal / ApexDocs |
| Outside Counsel Matter | `OLC-########` | `OLC-202608-0007` | ApexLegal |
| Corrective Action Plan (Legal/Reg) | `CAP-LEG-########` | `CAP-LEG-202610-0002` | ApexAudit / ApexLegal |
| Data Subject Request | `DSR-########` | `DSR-202608-1144` | ApexServe / Privacy |
| Statement of Work | `SOW-########` | `SOW-202606-0044` | ApexSource |
| Change Request | `CRQ-########` | `CRQ-202607-0019` | ApexServe |

#### A.1 Legal Personnel (Extended)

| Employee ID | Name | Role |
|---|---|---|
| `EMP-100006` | Margaret Sullivan | General Counsel & Corporate Secretary |
| `EMP-600301` | Beatriz Cardoso | Head of Employment Legal |
| `EMP-600302` | Jonathan Pierce | Head of Litigation & Investigations Legal |
| `EMP-600303` | Chiara Romano | Head of Privacy & Data Protection (DPO liaison) |
| `EMP-600304` | Ananya Krishnan | Head of Commercial Contracts |
| `EMP-600305` | Michael Okonkwo | Head of Regulatory Response Legal |

### Appendix B — Signature Block (Bank)

```
APEX NATIONAL BANK, N.A.

By: _______________________________    SIG-________
Name: _____________________________
Title: ____________________________
Date: _____________________________
```

### Appendix C — Clause Index

`CLA-001` Confidential Information · `CLA-002` Non-Use · `CLA-003` Disclosure Restrictions · `CLA-004` Permitted Disclosures · `CLA-005` Banking Confidentiality · `CLA-006` IP/Trade Secrets · `CLA-007` Return/Destruction · `CLA-008` Survival · `CLA-009` Injunctive Relief · `CLA-010` Classification · `CLA-011` Cross-Border · `CLA-012` Policy Relationship · `CLA-015` Governing Law

---

**End of Document** — `ANB-LEG-AGR-0001` v1.0
