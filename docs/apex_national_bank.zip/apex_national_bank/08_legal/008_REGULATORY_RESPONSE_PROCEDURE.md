# Apex National Bank — Regulatory Response Procedure

**Standard Operating Procedure | Examinations, Information Requests, Submissions, and CAP Tracking**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-SOP-0007` |
| **Document Title** | Regulatory Response Procedure |
| **Version** | 1.0 |
| **Owner** | Legal (LEG) with Compliance (CMP) — Regulatory Affairs |
| **Custodian** | Michael Okonkwo, Head of Regulatory Response Legal (G8) — `EMP-600305` |
| **Co-Custodian** | James Whitfield, Head of Regulatory Affairs (G8) — `EMP-400108` |
| **Approver** | Margaret Sullivan, GC (G11); Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C3) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T2` / `T8` → Regulatory Engagement → `SOP` |
| **Business Process** | `BP-REG-EXAM`, `BP-REG-CHG`, `BP-LEG-MAT`, `BP-AUD-VAL` |
| **System of Record** | ApexDocs · ApexLegal · ApexAudit · ApexRegRep |
| **Related Documents** | `ANB-CMP-SOP-0009`, `ANB-LEG-SOP-0006`, `ANB-CMP-GDL-0008`, `ANB-LEG-REF-0003` |

---

## 2. Purpose

Ensure timely, accurate, privileged-aware, and consistent responses to regulators — including information requests, horizontal reviews, onsite examinations, and enforcement — with clear ownership, validation, executive approval, submission controls, and post-exam corrective action tracking.

---

## 3. Scope

Requests from and examinations by OCC, Federal Reserve, FDIC, CFPB, FinCEN, SEC (where ASL implicated), FCA, ECB/local EU, RBI, and other supervisors. Internal Audit coordination included for exam readiness. Ordinary FinCEN CTR/SAR filings follow `ANB-CMP-SOP-0007` / `0004` / `0009` unless part of an exam request.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Regulatory Request** | `REG-REQ-########` |
| **Exam** | Formal supervisory examination |
| **MRIA / MRIT / Matter Requiring Attention** | Supervisory finding categories (or local equivalents) |
| **CAP** | Corrective Action Plan `CAP-LEG-########` (or CMP/RSK-owned CAP linked) |
| **Exam Room** | Secure physical/virtual data room |
| **Supervisory Correspondence** | Formal letters logged in ApexDocs |

---

## 5. Roles

| Role | Employee | Responsibility |
|---|---|---|
| Head of Regulatory Response Legal | `EMP-600305` | Legal review; privilege; enforcement |
| Head of Regulatory Affairs | `EMP-400108` | Exam management; coordinator |
| CCO | `EMP-100005` | BSA/AML and conduct exams |
| CRO | `EMP-100004` | Safety & soundness / risk exams |
| CFO | `EMP-100002` | Capital / reporting exams |
| GC | `EMP-100006` | Privilege; Board escalation |
| CAE | `EMP-100009` | Independent issue validation coordination |
| Business SMEs | As assigned | Source documents; accuracy attestations |

---

## 6. Request Intake Workflow

```
Regulator request received (portal / letter / email / onsite)
        → Log REG-REQ-######## same day (Regulatory Affairs)
        → Classify: Info Request / Exam / Enforcement / Horizontal
        → Assign Legal + Compliance/Risk/Finance owners
        → Scoping call (internal)
        → Data collection plan
        → Validation & Legal review
        → Executive approval (as required)
        → Submission via approved channel
        → Archive acknowledgment
        → Post-response issues / CAP
```

**REG-1.** No employee sends documents to a regulator without intake logging and owner approval.  
**REG-2.** Informal examiner questions during onsite still logged if material.

---

## 7. Information Requests and Document Collection

| Step | Standard |
|---|---|
| Scope | Written clarification if ambiguous |
| Sources | ApexDocs, ApexCore extracts, ApexCredit, ApexKYC, ApexGuard (non-SAR detail rules), ApexRisk, ApexAudit |
| Completeness | SME attestation |
| Consistency | Cross-check figures with FIN (`EMP-600106`) where financial |
| Privilege | Legal screens privileged materials; privilege log |
| SAR / Tip-off | Never produce SAR or tip-off content improperly — BSA Officer + Legal |

Customer complaints themes, KYC files (`KYC-`, `EDD-`), facilities (`FAC-`), and vendor files (`VRA-`, `MSA-`) commonly requested — use canonical IDs.

---

## 8. Onsite Inspections and Examinations

| Phase | Actions |
|---|---|
| Pre-exam | Request list management; room setup; coordinator roster; training for SMEs |
| Kickoff | Scope confirmation; logistics |
| Ongoing | Daily debrief internal; track requests `REG-REQ-` child IDs |
| Interviews | SME prep; Legal/Compliance attend as needed |
| Exit meeting | Capture preliminary findings |
| Final letter | Board committee routing per `ANB-LEG-REF-0003` |

Exam rooms: no unapproved devices; clean desk; visitor logging.

---

## 9. Evidence Validation

Before submission:

1. Source system identified  
2. Date range correct  
3. Definitions match regulator glossary  
4. Dual review (SME + independent checker for quantitative)  
5. Legal privilege/privacy review  
6. Version freeze in ApexDocs  

Filename per `ANB-ADM-STD-0007`.

---

## 10. Executive Approvals

| Submission Type | Approver |
|---|---|
| Routine information request | Regulatory Affairs Head + SME department head |
| Material exam response | CCO or CRO (as applicable) + Regulatory Response Legal |
| Enforcement response / consent | GC + CEO; Board committee as required |
| Capital / financial restatement related | CFO + GC |
| Cross-border concurrent exams | Head of Regulatory Affairs + local GC |

---

## 11. Submission Workflow

```
Package finalized
        → Legal sign-off recorded
        → Executive approval SIG- / ApexServe
        → Submit via secure regulator portal / encrypted channel
        → Capture submission ID / timestamp
        → Store REG-REQ- package C3 in ApexDocs
```

Late submission risk: escalate to CCO/GC **T-3 business days** before deadline.

---

## 12. Post-Examination Actions and CAP Tracking

| Finding Level | Response |
|---|---|
| Observation | Management action; track |
| MRA / equivalent | CAP with owner, milestones, evidence |
| MRIA / matter requiring immediate attention | ExCo visibility; accelerated CAP |
| Enforcement | Litigation/enforcement protocol + Board |

CAP ID `CAP-LEG-########` (or linked `ISS-CMP-` / audit issue). Validation of closure: second line and/or Internal Audit (`BP-AUD-VAL`). ORC/FCC/BRC/BPR reporting per finding theme (AML → FCC/BPR; credit → GrCC/BRC; tech → BTR).

---

## 13. Lessons Learned

Within **30 days** of final exam letter:

- Thematic gaps  
- Documentation quality issues  
- Training needs (`ANB-HRM-POL-0008`)  
- Control design changes (`ANB-CMP-GDL-0008`, RCSA updates)  
- Update playbooks in ApexDocs  

---

## 14. Decision Tree — Privilege Assertion

```
Document responsive?
        │
        ├─ Pure business record ──► Produce (privacy redact as needed)
        ├─ Legal advice communication ──► Privilege review — log if withhold
        ├─ SAR / SAR supporting investigative file ──► BSA Officer + Legal special path
        └─ Unclear ──► Withhold pending Legal decision; seek extension if required
```

---

## 15. Examples

**OCC BSA exam request:** `REG-REQ-202609-0033` seeks TM coverage metrics and sample `SAR-` statistics (aggregate only). Package built from ApexGuard/ApexInsight; individual SAR narratives not produced; CCO approves; submitted day 12 of 14.

**Horizontal fintech review:** Requests vendor `MSA-` and `VRA-` for cloud `VEN-008812`; Privacy redacts unrelated customer lists; TPRM SME attests.

**Onsite liquidity exam:** Treasury (`EMP-100018` / `EMP-600501`) provides LCR evidence aligned to `ANB-TRY-MAN-0001` / `RAM-0003`.

---

## 16. Coordination with Other Domains

| Domain | Interaction |
|---|---|
| Compliance | AML/Sanctions/Conduct exams; `ANB-CMP-SOP-0009` |
| Risk | Credit/ops/model exams; stress packs |
| Finance | Call Report / capital reconciliations |
| Retail / CBK | Product files, complaints, facilities |
| ITO / ISC | Tech/cyber exams; DR evidence `DR-` |
| HR | Conduct / accountability exams |
| Litigation | Parallel enforcement → `ANB-LEG-SOP-0006` |

---

## 17. Related Documents

`ANB-LEG-SOP-0006` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-LEG-REF-0003` · `ANB-CMP-POL-0001` · `ANB-CMP-SOP-0004` · `ANB-CMP-SOP-0009` · `ANB-CMP-GDL-0008` · `ANB-RSK-POL-0001` · `ANB-RSK-STMT-0001` · `ANB-TRY-MAN-0001` · `ANB-CBK-POL-0001` · `ANB-RTL-RPT-FY26-0001` · `ANB-IAD-REF-0002` · `ANB-ADM-STD-0007` · `ANB-ADM-POL-0001` · `ANB-HRM-POL-0008`

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | M. Okonkwo / J. Whitfield | Initial regulatory response procedure |

---

## Appendix A — REG-REQ Minimum Metadata

Request ID; regulator; date received; due date; classification; internal owner; Legal owner; related exam; submission status; archive path.

## Appendix B — Exam Room Rules (Summary)

Badges; no photos; no removal of documents without log; clean room end of day; visitor register; secure wipe of shared drives post-exam.

## Appendix C — Escalation Matrix

| Risk | Escalate | Timing |
|---|---|---|
| Missed deadline likely | CCO/CRO + GC | Immediate |
| Potential criminal referral | GC | Immediate |
| Material MRIA | CEO + Board committee chair | Same day as known |
| Media leak of confidential exam | MKT + GC + CEO | Immediate |

---

**End of Document** — `ANB-LEG-SOP-0007` v1.0 · C3
