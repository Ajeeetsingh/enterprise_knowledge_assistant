# Apex National Bank — Privacy Policy

**Enterprise Policy | Customer and Individual Privacy Notice and Control Framework**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-POL-0004` |
| **Document Title** | Privacy Policy |
| **Version** | 1.0 |
| **Owner** | Legal (LEG) with Compliance (CMP) |
| **Custodian** | Chiara Romano, Head of Privacy & Data Protection (G8) — `EMP-600303` |
| **Approver** | Margaret Sullivan, General Counsel (G11); Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Internal (C1) — customer-facing extract may be Public |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T8` → Privacy & Data Protection → `POL` |
| **Business Process** | `BP-CST-CMPL`, `BP-ONB-KYC`, `BP-LEG-MAT`, `BP-KNW-RET` |
| **System of Record** | ApexDocs · ApexServe (DSR) · ApexKYC · ApexCore |
| **Related Documents** | `ANB-LEG-POL-0005`, `ANB-ISC-STD-0004`, `ANB-ADM-POL-0001`, `ANB-CMP-POL-0002` |

---

## 2. Purpose

Explain how Apex National Bank collects, uses, shares, and protects Personal Data of customers, prospects, website users, and other individuals, and establish internal standards for lawful processing under GLBA, GDPR/UK GDPR, CCPA/CPRA, India’s DPDP Act, and other applicable regimes.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| Customer / prospect Personal Data | Employee HR processing (employee privacy notice) |
| Online / mobile / branch collection | Anonymous aggregated statistics |
| Vendors processing on Bank’s behalf | Purely corporate trade secrets without Personal Data |

Applies to Group entities listed in `ANB-ADM-REF-0001` with local addenda.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Personal Data / PII** | Information relating to an identified or identifiable individual |
| **NPI** | Nonpublic personal information under GLBA |
| **SPI / Sensitive Personal Data** | Special category / sensitive data (health, biometrics, etc.) |
| **Processing** | Any operation on Personal Data |
| **Controller / Business** | Bank determining purposes/means |
| **Processor / Service Provider** | Vendor processing on Bank’s behalf (`MSA-` / DPA) |
| **DSR** | Data Subject Request `DSR-########` |
| **Lawful Basis** | GDPR Art. 6 (and Art. 9 if special category) ground |

---

## 5. Roles and Responsibilities

| Role | Employee / Function | Responsibility |
|---|---|---|
| Head of Privacy | `EMP-600303` Chiara Romano | Policy custodian; DSR oversight |
| General Counsel | `EMP-100006` | Legal accountability |
| CCO | `EMP-100005` | Regulatory privacy interface |
| CISO | `EMP-100010` Nadia Ferreira | Security controls |
| CDO | Per profile | Data governance |
| Business Data Owners | Department heads | Purpose limitation in processes |
| CST / Branch | Frontline | Collection notices; DSR intake |

---

## 6. Collection of Personal Data

| Category | Examples | Typical Sources |
|---|---|---|
| Identity | Name, DOB, government ID | Onboarding `KYC-`, branch, ApexMobile |
| Contact | Address, email, phone | Applications, updates |
| Financial | Account `ACC-`, transactions `TXN-`, income | ApexCore, ApexOrigin |
| Credit | Scores, bureau data | Credit applications `APP-` / `MTG-` / `PLN-` |
| Technical | Device ID, IP, cookies | ApexOnline / ApexMobile |
| Usage | Login, clickstream | Digital channels |
| Audio/CCTV | Call recordings, branch CCTV | ApexVoice; branch security |
| Marketing | Preferences, consent flags | Apex360 / ApexReach |

**Children:** Products not directed to children under 13 (US COPPA). Youth savings require adult co-owner (`ANB-RTL-GDL-0001`).

---

## 7. Purposes and Lawful Bases

| Purpose | Lawful Basis (GDPR) | US / Other |
|---|---|---|
| Account opening / CIP / KYC | Legal obligation; contract | GLBA / BSA |
| Credit decisioning | Contract; legitimate interests; legal obligation | FCRA / ECOA |
| Payment processing | Contract | UCC / network rules |
| Fraud / AML / sanctions | Legal obligation; legitimate interests | BSA / OFAC |
| Service communications | Contract | GLBA |
| Marketing | Consent or legitimate interests (soft opt-in where lawful) | TCPA / CAN-SPAM / consent |
| Analytics / improvement | Legitimate interests | GLBA limitations |
| Regulatory response | Legal obligation | `ANB-LEG-SOP-0007` |

Sensitive data processed only with explicit consent or legal necessity (e.g., biometric authentication opt-in).

---

## 8. Cookies and Digital Tracking

| Type | Purpose | Control |
|---|---|---|
| Strictly necessary | Session, security | Always on |
| Functional | Preferences | Manage in cookie centre |
| Analytics | Traffic measurement | Consent where required |
| Advertising | Personalised ads | Consent / opt-out |

Do-not-track: Bank responds per published digital standards. CCPA GPC signals honored for California residents where applicable.

---

## 9. Individual Rights

| Right | Regime | Bank Process |
|---|---|---|
| Access / Know | GDPR / CCPA / DPDP | `DSR-########` via ApexServe / privacy portal |
| Correction | GDPR / DPDP | DSR + ApexCore update |
| Deletion / Erasure | GDPR / CCPA / DPDP | Assess legal retention holds (`ANB-ADM-POL-0001`, BSA) |
| Portability | GDPR | Structured export where applicable |
| Restrict / Object | GDPR | Case-by-case |
| Opt-out sale/share | CCPA | Bank does not sell Personal Data for monetary consideration; targeted advertising opt-out provided |
| Withdraw consent | All consent-based | Marketing preference centre |
| Appeal | CCPA | Privacy team review |

**SLA:** Acknowledge DSR within **10 days**; complete within **30 days** (extendable as law permits). Identity verification mandatory (`BP-CST-AUTH`).

---

## 10. Retention

Retention per `ANB-ADM-POL-0001` / `ANB-ADM-STD-0002`: e.g., `RET-CUS-7Y`, `RET-AML-5Y`, credit files longer where required. Deletion/anonymisation after period unless legal hold `LHD-########`.

---

## 11. Third Parties and Sharing

| Recipient | Purpose | Control |
|---|---|---|
| Service providers | Hosting, KYC vendors, card processors | `ANB-LEG-AGR-0002` DPA; TPRM |
| Credit bureaus | Underwriting | Permissible purpose |
| Payment networks | Clearing | Network rules |
| Regulators / law enforcement | Legal obligation | `ANB-LEG-SOP-0007`; SAR confidentiality |
| Affiliates | Joint offering / servicing | GLBA affiliate rules; opt-outs where required |
| Successors | Merger / sale | Notice as required |

No disclosure of SAR existence to customers (`ANB-CMP-SOP-0004`).

---

## 12. Cross-Border Transfers

Transfers from EEA/UK use SCCs / UK IDTA / adequacy. India DPDP transfer rules observed for India entity processing. US Group processing of EU data documented in transfer register. Offshore vendor processing requires Privacy + ISC + Risk approval (`ANB-LEG-AGR-0002` Clause 14).

---

## 13. Marketing and Consent

| Channel | Rule |
|---|---|
| Email | Opt-in / soft opt-in per jurisdiction; unsubscribe |
| SMS / autodial | Prior express consent (TCPA) |
| Push | In-app preference |
| Branch | Fair marketing; no pressure (`ANB-RTL-MAN-0004`) |

Consent records retained with timestamp and version of notice.

---

## 14. Security

Security measures per `ANB-LEG-POL-0005` and `ANB-ISC-POL-0001`: encryption, access control, monitoring, incident response. Breach notification per GLBA, GDPR 72-hour, state laws, DPDP — coordinated by ISC + Privacy + Legal.

---

## 15. Complaint Handling

Privacy complaints logged as `CMP-########` and/or `DSR-########`. Escalate to `EMP-600303`. Customers may also complain to supervisory authorities (e.g., CFPB, ICO, local DPA, India Data Protection Board). Service recovery per `ANB-RTL-MAN-0004` without admitting legal liability inappropriately.

---

## 16. AI / Automated Decisions

Credit and fraud models (`MDL-########`) may involve automated processing. Adverse credit actions include adverse action notices (FCRA). Significant GDPR automated decisions include meaningful information and contest rights where applicable. Training restrictions in `ANB-LEG-POL-0005`.

---

## 17. Examples

**DSR Access:** Customer `CUS-04928311` submits `DSR-202608-1144` via ApexOnline. Identity verified; package produced from ApexCore/Apex360 within 30 days; SAR materials excluded.

**Marketing opt-out:** `CUS-03115590` unsubscribes; ApexReach suppressed within 10 business days.

**Vendor share:** World-Check screening via `VEN-012044` under DPA; purpose limited to sanctions/PEP.

---

## 18. Policy Statements

**PRIV-1.** Lawful basis documented for each processing activity in RoPA.  
**PRIV-2.** Privacy by Design for new products (`ANB-LEG-POL-0005`).  
**PRIV-3.** No sale of NPI.  
**PRIV-4.** DSRs tracked to closure with metrics for Board/BPR as required.  
**PRIV-5.** Conflicts between regimes → stricter standard for the data subject population.

---

## 19. Related Documents

`ANB-LEG-POL-0005` · `ANB-LEG-AGR-0001` · `ANB-LEG-AGR-0002` · `ANB-LEG-SOP-0006` · `ANB-LEG-SOP-0007` · `ANB-ISC-POL-0001` · `ANB-ISC-STD-0004` · `ANB-ADM-POL-0001` · `ANB-CMP-POL-0001`/`0002` · `ANB-CMP-SOP-0004` · `ANB-RSK-POL-0004` · `ANB-RTL-MAN-0004` · `ANB-CST-SOP-0001` · `ANB-HRM-POL-0004` · `ANB-ADM-REF-0001`

---

## 20. Review Cycle / Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | C. Romano | Initial enterprise Privacy Policy |

---

## Appendix A — Jurisdiction Addenda Pointers

| Region | Addendum Owner |
|---|---|
| US GLBA / CCPA | Privacy + CMP |
| UK GDPR | ANBUK DPO liaison |
| EU GDPR | Apex Bank Europe SE |
| India DPDP | India country counsel + Privacy |

## Appendix B — DSR Intake Channels

Privacy portal; ApexServe; authenticated CST; branch form → Privacy Ops queue.

---

**End of Document** — `ANB-LEG-POL-0004` v1.0
