# Apex National Bank — Employment Agreement

**Controlled Agreement Form | Individual Employment Terms for Bank Staff**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-AGR-0001` |
| **Document Title** | Employment Agreement |
| **Version** | 1.0 |
| **Owner** | Legal (LEG) — Employment Legal with Human Resources (HRM) |
| **Custodian** | Beatriz Cardoso, Head of Employment Legal (G8) — `EMP-600301` |
| **Approver** | Margaret Sullivan, General Counsel (G11); Yvonne Carter, CHRO (G11) — `EMP-100008` |
| **Classification** | Confidential (C2) — executed agreements C2/C3 |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T7` → `T7.1` Employment → `AGR` |
| **Business Process** | `BP-HR-HIRE`, `BP-HR-ONB`, `BP-HR-EXIT`, `BP-HR-COND` |
| **System of Record** | ApexPeople · ApexLegal · ApexDocs |
| **Related Documents** | `ANB-HRM-HBK-0001`, `ANB-HRM-POL-0004`, `ANB-HRM-POL-0002`/`0003`/`0005`/`0006`/`0008`, `ANB-HRM-SOP-0007` |

---

## 2. Purpose

Document the terms of employment between Apex National Bank (or designated Affiliate employer) and an individual employee (`EMP-######`), integrating Handbook and policy obligations into a binding agreement for confidentiality, IP, conduct, and post-employment restrictions where enforceable.

---

## 3. Scope

Employees of Apex National Bank, N.A. and participating Affiliates. Contractors use vendor/contractor agreements under `ANB-LEG-AGR-0002`, not this form. Material Risk Takers may receive supplemental schedules (remuneration / regulatory references).

Instance ID: `EMPAGR-########` linked to `EMP-######`.

---

## 4. Operative Clauses

**EMPLOYMENT AGREEMENT**  
**Instance:** `EMPAGR-########` · **Employee ID (upon hire):** `EMP-______`  
**Employer:** Apex National Bank, N.A. (or Affiliate named in Schedule A)  
**Employee:** ________

### CLAUSE 1 — Employment and Position

**1.1** Employer employs Employee in the position of ________, grade G__, department ________, location ________ (`SIT-####` / `BRN-####` if branch), reporting to ________ (`EMP-______`).

**1.2** Duties include those in the job description and reasonable additional duties. Employee shall devote full working time and attention to Employer (subject to approved Outside Business Activities under `ANB-HRM-POL-0004`).

### CLAUSE 2 — Start Date; Probation

**2.1** Commencement Date: ________.  
**2.2** Probationary period: **ninety (90) days** unless Schedule A states otherwise (or local law minimum). During probation, either party may terminate per Clause 10 with shortened notice as Schedule A / local law permits.  
**2.3** Employment is at-will where permitted by governing law, except as Schedule A (UK/EU/other) provides fixed notice or protections. Nothing herein limits statutory rights that cannot be waived.

### CLAUSE 3 — Compensation

**3.1** Base salary: ________ per annum, payable per payroll cycle, subject to withholdings.  
**3.2** Incentive compensation: eligibility under applicable plan and `ANB-HRM-POL-0005` / performance policy `ANB-HRM-POL-0006`; discretionary unless plan states otherwise; subject to risk adjustment, malus, and clawback for MRTs and as policy provides.  
**3.3** Employer may modify roles/compensation prospectively as permitted by law and policy.

### CLAUSE 4 — Benefits

**4.1** Employee may participate in benefit plans per eligibility (medical, retirement, leave under `ANB-HRM-POL-0002`, etc.). Plans may be amended or terminated.  
**4.2** Leave, remote work, and travel governed by `ANB-HRM-POL-0002`, `ANB-HRM-POL-0003`, `ANB-FIN-POL-0002`.

### CLAUSE 5 — Hours; Workplace

**5.1** Normal hours per Handbook / local schedule; branch and cash roles require on-site presence per `ANB-RTL-MAN-0003` / operational necessity.  
**5.2** Hybrid arrangements only as approved under Remote Work Policy.

### CLAUSE 6 — Background Checks; Representations

**6.1** Employment conditioned on satisfactory background screening per `ANB-HRM-SOP-0007` and ongoing fitness.  
**6.2** Employee represents that information provided in application is true; no restriction preventing employment; will disclose regulatory bars.

### CLAUSE 7 — Confidentiality

**7.1** Employee shall protect Confidential Information (as in `ANB-LEG-AGR-0001` definition adapted to employment) during and after employment.  
**7.2** Customer NPI, SAR-related information, privilege materials, and C3 data require heightened care (`ANB-LEG-POL-0004`/`0005`, `ANB-CMP-SOP-0004`).  
**7.3** Obligations survive termination indefinitely for Trade Secrets and as long as law requires for Personal Data.

### CLAUSE 8 — Intellectual Property

**8.1** All Work Product created within scope of employment is work made for hire / assigned to Employer, including code, models, documents, and inventions.  
**8.2** Employee hereby assigns all rights worldwide; shall execute further documents.  
**8.3** Pre-existing IP listed on Schedule B is excluded if identified before Commencement.

### CLAUSE 9 — Code of Conduct; Conflicts; Policies

**9.1** Employee shall comply with `ANB-HRM-POL-0004` Code of Conduct, AML/KYC training (`ANB-CMP-POL-0001`, `ANB-HRM-POL-0008`), Information Security (`ANB-ISC-POL-0001`), and all applicable policies in ApexDocs.  
**9.2** Conflicts of interest, personal account dealing, gifts, and outside activities per Code.  
**9.3** Policies may be updated; material updates communicated via ApexLearn / ApexPeople.

### CLAUSE 10 — Termination

**10.1** **At-will jurisdictions:** Either party may terminate at any time, with or without cause, subject to final pay and statutory requirements.  
**10.2** **Notice jurisdictions:** Notice periods in Schedule A (e.g., UK: statutory/contractual).  
**10.3** **For cause** (including without limitation): gross misconduct; fraud; material policy breach; conviction of relevant offense; regulatory prohibition; unauthorized disclosure of Confidential Information; harassment.  
**10.4** Garden leave: Employer may require Employee to remain away from duties during notice while remaining employed and bound by duties (where lawful).  
**10.5** Exit clearance per `BP-HR-EXIT`; return of property (Clause 12); access revocation via ApexID (`EMP-500202` path).

### CLAUSE 11 — Restrictive Covenants

**11.1 Non-Solicitation of Employees.** For **twelve (12) months** post-termination, Employee shall not knowingly solicit Bank employees to leave, where enforceable.  
**11.2 Non-Solicitation of Customers.** For **twelve (12) months**, Employee shall not solicit customers with whom Employee had material contact in the last twelve months of employment for competing products, where enforceable.  
**11.3 Non-Compete.** Only if Schedule C attached and enforceable under governing law (often limited to senior/MRT roles; blue-pencil / reform where permitted).  
**11.4** Restrictive covenants supplemental to confidentiality; severable.

### CLAUSE 12 — Return of Property

**12.1** Upon request or termination, Employee shall return all Employer property: devices, badges, documents, data, access tokens; permanently delete Employer data from personal devices subject to legal hold (`LHD-########`).  
**12.2** Certification of return may be required (`DES-` / exit form).

### CLAUSE 13 — Data Protection; Monitoring

**13.1** Employer processes Employee Personal Data per employee privacy notice and `ANB-LEG-POL-0004`/`0005`.  
**13.2** Employee acknowledges monitoring of systems, email, and recorded lines where lawful and notified (e.g., ApexWatch surveillance for relevant roles).

### CLAUSE 14 — Regulatory Cooperation

**14.1** Employee shall cooperate with internal investigations, audits, regulators, and litigation holds (`ANB-LEG-SOP-0006`, `ANB-LEG-SOP-0007`) during and after employment regarding matters arising from employment.

### CLAUSE 15 — Governing Law

**15.1** Schedule A specifies governing law and venue (default for US hires: state of primary work location / New York for corporate roles as stated).

### CLAUSE 16 — Entire Agreement; Acknowledgment

**16.1** This Agreement, Handbook acknowledgments, and policy attestations constitute the employment terms regarding subjects covered; at-will status (if applicable) not modified except by signed writing by CHRO/GC authorized signatory.  
**16.2** Employee acknowledges receipt of Code of Conduct and mandatory training obligations.

---

## 5. Schedules

| Schedule | Content |
|---|---|
| A | Employer entity; location; notice; governing law; probation |
| B | Pre-existing IP |
| C | Non-compete (if any) |
| D | MRT / certification regime addendum |
| E | Sign-on / relocation (if any) |

---

## 6. Example Executed Agreement

| Field | Value |
|---|---|
| Instance | `EMPAGR-20260115-0412` |
| Employee | Jamal Robertson `EMP-300106` |
| Position | Teller G1 — `BRN-0412` / `SIT-0412` |
| Manager | `EMP-300103` / `EMP-300107` |
| Probation | 90 days |
| Restrictive covenants | Confidentiality + employee non-solicit (no non-compete) |
| Signatures | `SIG-20260115-0412A` (Bank HR) / `SIG-20260115-0412B` (Employee) |

---

## 7. Approval Authorities

| Action | Approver |
|---|---|
| Standard form US G1–G5 | HR + Employment Legal form use |
| Non-compete Schedule C | Employment Legal + CHRO |
| G10+ / ExCo agreements | GC + CHRO + Compensation Committee as required |
| Settlement of employment claims | Per `ANB-LEG-SOP-0006` / authority matrix |

---

## 8. Related Documents

`ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0004` · `ANB-HRM-POL-0005` · `ANB-HRM-POL-0006` · `ANB-HRM-POL-0008` · `ANB-HRM-SOP-0007` · `ANB-LEG-AGR-0001` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-LEG-SOP-0006` · `ANB-CMP-POL-0001` · `ANB-ISC-POL-0001` · `ANB-RTL-MAN-0003` · `ANB-ADM-REF-0001`

---

## 9. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | B. Cardoso | Initial employment agreement form |

---

## Appendix A — Signature Block

```
EMPLOYER                                    EMPLOYEE

By: _____________________ SIG-____          _____________________ SIG-____
Name/Title/Date                             Name/Date
```

## Appendix B — Local Law Overlay Note

UK/EU/India hires use Schedule A overlays for statutory particulars, working time, and enforceable restriction limits. Do not use US at-will language in those overlays.

---

**End of Document** — `ANB-HRM-AGR-0001` v1.0
