# Apex National Bank — Vendor Master Services Agreement

**Controlled Agreement Form | Enterprise MSA for Goods, Services, and Technology Vendors**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-AGR-0002` |
| **Document Title** | Vendor Master Services Agreement |
| **Version** | 1.0 |
| **Owner** | Legal (LEG) with Procurement (PRC) |
| **Custodian** | Ananya Krishnan, Head of Commercial Contracts (G8) — `EMP-600304` |
| **Approver** | Margaret Sullivan, General Counsel (G11) — `EMP-100006`; Ian McAllister, CPO (G10) — `EMP-100013` |
| **Classification** | Internal (C1) — executed instances C2+ |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T8` → `T8.1` Procurement & Vendors → `AGR` |
| **Business Process** | `BP-VEN-CTR`, `BP-VEN-DD`, `BP-VEN-EXIT`, `BP-PRC-TPRM` |
| **System of Record** | ApexLegal · ApexSource · ApexVendor · ApexDocs |
| **Template Lineage** | Implements reserved `ANB-LEG-CTR-0001` MSA template family |
| **Related Documents** | `ANB-LEG-AGR-0001`, `ANB-PRC-POL-0001`/`0002`, `ANB-RSK-FRM-0002`, `ANB-ISC-POL-0001` |

---

## 2. Purpose

Establish the master contractual framework under which Apex National Bank procures services and technology from vendors, including SLAs, security, audit, subprocessors, liability, BC/DR, and compliance obligations aligned with OCC third-party guidance and the Bank’s TPRM framework.

---

## 3. Scope

Tier 1–3 vendors providing services involving Bank systems, data, or premises. Professional services, SaaS, managed services, and outsourcing. Individual purchases may be via SOW (`SOW-########`) under this MSA (`MSA-########` / `CON-########`).

---

## 4. Definitions

| Term | Definition |
|---|---|
| **MSA** | This Master Services Agreement instance `MSA-########` |
| **SOW** | Statement of Work `SOW-########` |
| **Services** | Services described in SOWs |
| **Bank Data** | Data provided by or on behalf of Bank, including Personal Data |
| **Subprocessor** | Downstream processor of Bank Data |
| **SLA** | Service levels in Schedule B |
| **Vendor** | Counterparty legal entity `VEN-######` |

---

## 5. Operative Clauses

### CLAUSE 1 — Structure; Order of Precedence

**1.1** Structure: MSA + Schedules + SOWs + Change Requests (`CRQ-########`).  
**1.2** Precedence: (1) SOW expressly overriding clauses; (2) Data Protection Schedule; (3) MSA body; (4) other schedules.  
**1.3** Related NDA (`NDA-########` / `ANB-LEG-AGR-0001`) remains in force for pre-MSA diligence materials.

### CLAUSE 2 — Scope of Work

**2.1** Vendor shall perform Services per each SOW: deliverables, milestones, acceptance criteria, location, and Key Personnel.  
**2.2** No exclusivity unless SOW states otherwise.  
**2.3** Bank may engage other vendors for similar services.

### CLAUSE 3 — Payment Terms

**3.1** Fees as in SOW; invoices via ApexLedger / AP under `ANB-FIN-SOP-0008` vendor payment path.  
**3.2** Payment within **forty-five (45) days** of valid invoice unless SOW states otherwise.  
**3.3** Disputed amounts may be withheld pending resolution; undisputed amounts paid.  
**3.4** Expenses only if pre-approved and consistent with `ANB-FIN-POL-0001` / Travel Policy.  
**3.5** Taxes: Bank responsible for VAT/GST as applicable if Vendor provides valid tax docs; Vendor responsible for income taxes on fees.

### CLAUSE 4 — Change Requests

**4.1** Changes to scope, fees, or SLAs require written `CRQ-########` approved by Bank authorized signatory and Vendor.  
**4.2** Vendor shall not proceed with material changes without approved CRQ.  
**4.3** Bank may request equitable fee reduction for Bank-caused delays documented in CRQ.

### CLAUSE 5 — Service Levels; Availability; Support

**5.1** Vendor shall meet SLAs in Schedule B (availability, response, restore).  
**5.2** Service credits are Bank’s remedy for SLA failure unless chronic failure constitutes material breach.  
**5.3** Support hours, severity definitions, and escalation matrix in Schedule B.  
**5.4** For Tier 1 / CBS-supporting vendors, availability targets align with `ANB-RSK-POL-0007` and `ANB-ITO-PLN-0002` impact tolerances.

### CLAUSE 6 — Security; Cybersecurity

**6.1** Vendor shall implement administrative, technical, and physical safeguards consistent with `ANB-ISC-POL-0001`, applicable FFIEC guidance, and Schedule C (Security Requirements).  
**6.2** Mandatory: encryption in transit and at rest for Bank Data; MFA for remote access; vulnerability management; logging; secure SDLC for custom software.  
**6.3** Security incidents affecting Bank Data: notify Bank within **twenty-four (24) hours** of confirmation (or sooner if law requires) via designated ISC channel; cooperate with `ANB-ISC-SOP-0003`.  
**6.4** Annual SOC 2 Type II or ISO 27001 (or agreed equivalent) for Tier 1/2; right to questionnaire and evidence under TPRM (`VRA-########`).

### CLAUSE 7 — Audit Rights

**7.1** Bank (and Internal Audit `EMP-100009` path, and regulators) may audit Vendor’s controls relevant to Services and Bank Data upon reasonable notice, or without notice if Regulatory Request (`REG-REQ-########`) so requires.  
**7.2** Vendor shall provide policies, logs, SOC reports, and access to personnel.  
**7.3** Frequency: annually for Tier 1; otherwise risk-based.  
**7.4** Cost: Bank bears ordinary audit cost unless material non-compliance found — then Vendor bears reasonable costs of follow-up.

### CLAUSE 8 — Subprocessors

**8.1** Vendor shall not engage Subprocessors of Bank Data without prior written approval (or use of pre-approved Schedule D list).  
**8.2** Vendor remains fully liable for Subprocessors.  
**8.3** Flow-down of confidentiality, security, audit, and privacy obligations mandatory.  
**8.4** Changes to Subprocessors: thirty (30) days’ notice; Bank may object on reasonable data-protection grounds.

### CLAUSE 9 — Insurance

**9.1** Vendor maintains, at its cost: (a) Commercial General Liability ≥ USD 2M per occurrence / USD 4M aggregate; (b) Professional Liability / E&O ≥ USD 5M (Tier 1 technology ≥ USD 10M); (c) Cyber Liability ≥ USD 5M (Tier 1 ≥ USD 10M); (d) Workers’ Compensation as required by law.  
**9.2** Certificates on request; additional insured endorsements where customary.

### CLAUSE 10 — Term; Termination

**10.1** MSA term as stated on cover; SOWs may have independent terms.  
**10.2** Termination for convenience: Bank may terminate SOW/MSA on **ninety (90) days’** notice (Tier 1 exit assistance per Clause 11).  
**10.3** Termination for cause: material breach uncured thirty (30) days after notice; immediate for willful misconduct, sanctions violation, or confirmed data exfiltration.  
**10.4** Regulatory required exit: Bank may terminate immediately if regulator directs or TPRM requires (`ANB-RSK-FRM-0002` exit plans).

### CLAUSE 11 — Exit; Transition; BC/DR

**11.1** Upon termination, Vendor shall provide reasonable transition assistance for up to **one hundred eighty (180) days** (Tier 1) at then-current rates unless termination for Vendor cause — then at no charge for ordinary assistance.  
**11.2** Return/destruction of Bank Data per `ANB-LEG-AGR-0001` Clause 7 and Schedule E; certify `DES-########`.  
**11.3** Vendor BC/DR plans shall meet RTO/RPO in SOW and be testable; material BC/DR test results available to Bank annually. Align with `ANB-RSK-POL-0007` / `ANB-ITO-PLN-0002` for CBS dependencies (e.g., `VEN-008812` cloud; `VEN-003301` SWIFT connectivity).

### CLAUSE 12 — Confidentiality

**12.1** Mutual confidentiality per incorporated NDA terms or Schedule F (substantively `ANB-LEG-AGR-0001`).  
**12.2** Bank may disclose to regulators and under legal process per NDA Clause 4.

### CLAUSE 13 — Compliance Obligations

**13.1** Vendor shall comply with applicable law and Bank policies flowed down: AML/sanctions awareness for relevant staff; anti-bribery; modern slavery; data protection.  
**13.2** No services involving sanctioned parties (`ANB-CMP-SOP-0005`).  
**13.3** Background checks for Vendor personnel with unescorted Bank premises or production access — standards coordinated with `ANB-HRM-SOP-0007` overlays.  
**13.4** Recordkeeping sufficient for Bank examination readiness (`ANB-LEG-SOP-0007`).

### CLAUSE 14 — Data Protection

**14.1** Schedule E (DPA) applies to Personal Data processing; roles controller/processor as stated.  
**14.2** Vendor shall not use Bank Data to train third-party AI models or Vendor foundation models without explicit written approval under `ANB-LEG-POL-0005` and `ANB-RSK-POL-0004`.  
**14.3** Cross-border transfers only via approved transfer mechanisms.

### CLAUSE 15 — Intellectual Property

**15.1** Vendor IP remains Vendor’s; Bank IP and Bank Data remain Bank’s.  
**15.2** Work product created specifically for Bank under SOW (“**Work Product**”) vests in Bank upon payment, unless SOW states license model.  
**15.3** Vendor grants Bank a perpetual, worldwide license to use Vendor IP embedded in Work Product as needed to use Services/deliverables.

### CLAUSE 16 — Representations and Warranties

**16.1** Each Party represents due organization and authority.  
**16.2** Vendor warrants Services will be performed professionally, conform to SOW, and not infringe third-party IP.  
**16.3** Disclaimer: except as stated, no other warranties (merchantability/fitness) to extent permitted by law.

### CLAUSE 17 — Indemnification

**17.1** Vendor indemnifies Bank against third-party claims arising from: (a) IP infringement by Services; (b) Vendor’s breach of data protection/security; (c) bodily injury/property damage from Vendor negligence; (d) employment claims by Vendor personnel.  
**17.2** Bank indemnifies Vendor against claims arising from Bank Data unlawfully provided or Bank’s material modification of deliverables.

### CLAUSE 18 — Liability

**18.1** Subject to Clause 18.2, each Party’s aggregate liability under an SOW shall not exceed the greater of (i) fees paid/payable under that SOW in the **twelve (12) months** before the claim, or (ii) USD ________ (as negotiated; Tier 1 floors apply).  
**18.2** **Unlimited / higher cap carve-outs:** confidentiality breach regarding C3; data protection breach; fraud; willful misconduct; IP indemnity; bodily injury; amounts that cannot be limited by law.  
**18.3** Neither Party liable for indirect/consequential damages except under carve-outs.

### CLAUSE 19 — Insurance; Risk Allocation Continuity

See Clause 9. Failure to maintain insurance is material breach.

### CLAUSE 20 — Governing Law; Dispute Resolution

**20.1** New York law.  
**20.2** Negotiation → mediation (optional) → courts in New York County.  
**20.3** Bank may seek injunctive relief anywhere for security/confidentiality breaches.

### CLAUSE 21 — Miscellaneous

Notices; assignment (Vendor may not assign without consent; Bank may assign to Affiliate); export control; entire agreement; severability; counterparts; survival of Clauses 6–8, 11–18, 20.

---

## 6. Example Schedules

### Schedule A — SOW Cover (Template Fields)

SOW ID; MSA ID; Vendor `VEN-`; Services description; Fees; Term; Bank sponsor `EMP-`; Acceptance criteria; Dependencies on Bank systems (ApexCore, ApexATM, etc.).

### Schedule B — SLA Example (Managed Connectivity)

| Metric | Target | Credit |
|---|---|---|
| Availability | 99.90% monthly | 5% monthly fee per 0.1% below |
| Sev1 response | 15 minutes | Per matrix |
| Sev1 restore | 4 hours | Per matrix |

### Schedule C — Security Minimums

Align ISC standards; privileged access logging; annual pen test summary; no shared credentials.

### Schedule D — Approved Subprocessors

List legal names, locations, services.

### Schedule E — Data Protection (DPA Summary)

Subject matter; duration; types of data (CUS-, employee EMP-); deletion; audit; SCCs module.

### Schedule F — BC/DR

RTO/RPO; last test date; invocation contacts.

---

## 7. Vendor Onboarding References

```
NDA (ANB-LEG-AGR-0001) → TPRM intake (ANB-RSK-FRM-0002 / ANB-PRC-POL-0002)
        → VRA-######## → Security review (ISC)
        → MSA negotiation (this AGR-0002)
        → SOW-######## → Signatures SIG-
        → ApexVendor active → Ongoing monitoring
```

Example: `MSA-202605-0088` with `VEN-015522` (card processing) supporting `CBS-00000001`; `VRA-202608-0018`; exit plan on file for `RAM-0010`.

---

## 8. Approval Authorities

| Action | Approver |
|---|---|
| Standard MSA no material redline | Legal + CPO path per value (`ANB-ADM-MTX-0001`) |
| Liability cap below Tier 1 floor | GC + CRO |
| Offshore processing of C2/C3 | Privacy (`EMP-600303`) + ISC + Risk |
| Termination for convenience Tier 1 | Business sponsor G9+ + PRC + Legal |

---

## 9. Related Documents

`ANB-LEG-AGR-0001` · `ANB-LEG-CTR-0001` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-LEG-SOP-0006` · `ANB-LEG-SOP-0007` · `ANB-PRC-POL-0001` · `ANB-PRC-POL-0002` · `ANB-RSK-FRM-0002` · `ANB-RSK-POL-0007` · `ANB-ITO-PLN-0002` · `ANB-ISC-POL-0001` · `ANB-ISC-SOP-0003` · `ANB-CMP-SOP-0005` · `ANB-FIN-SOP-0008` · `ANB-CBK-POL-0001` (where vendor supports credit ops)

---

## 10. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | A. Krishnan | Initial Vendor MSA form (AGR-0002) |

---

## Appendix A — Signature Blocks

Bank and Vendor signature blocks with `SIG-########`; witnesses optional.

## Appendix B — Chronic SLA Failure Definition

Three Sev1 misses in rolling six months or availability below 99.5% for two consecutive months → material breach rights without prejudice to credits.

---

**End of Document** — `ANB-LEG-AGR-0002` v1.0
