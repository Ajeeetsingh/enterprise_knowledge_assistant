# Apex National Bank — Capital Expenditure Policy

**Corporate Policy | Capitalisation, Depreciation, Capital Projects, and Fixed Asset Control**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-POL-0006` |
| **Document Title** | Apex National Bank — Capital Expenditure Policy |
| **Version** | 1.0 |
| **Owner** | Finance Department (FIN) — Group Financial Control |
| **Custodian** | Gemma Ashworth, Group Financial Controller (G9) — `EMP-600101` (CapEx Controller) |
| **CapEx & Fixed Assets Manager** | Priya Menon (G6) — `EMP-600121` (reports to Group Financial Controller) |
| **Approver** | Priya Raghunathan, Chief Financial Officer (G11) — `EMP-100002` |
| **Secondary Reviewers** | Anneke Visser (`EMP-600105`); Teresa Villanueva (`EMP-600110`); Ian McAllister CPO (`EMP-100013`); Legal; ITO Architecture |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-20 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-28 |
| **Review Cycle** | Annual (next review 2027-07-28); useful-life table reviewed with external auditors |
| **Supersedes** | None — initial published CapEx policy under the 2026 controlled-document programme |
| **Retention** | `RET-FIN-10Y` |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T5` Finance & Treasury → Capital & Fixed Assets → Capital Governance → `POL` |
| **Business Process** | `BP-FIN-CAP` Capital Project & Fixed Asset Lifecycle (**new process**) |
| **Related Processes** | `BP-FIN-BUD`, `BP-FIN-JRNL`, `BP-FIN-AP`, `BP-PRC-P2P`, `BP-ITO-CHG`, `BP-AUD-SOX` |
| **Governing Body** | Executive Committee; Board of Directors (projects > $50M); Board Audit Committee (accounting policy) |
| **System of Record** | ApexPlan (Oracle EPM — capital budget & forecast) · ApexLedger (SAP S/4HANA — CIP, fixed assets, depreciation) · ApexSource/ApexVendor (Coupa/ProcessUnity — sourcing) · ApexDocs |
| **Keywords** | CapEx, capitalisation, depreciation, CIP, fixed assets, useful life, branch construction, software capitalisation, SOX |
| **Related Documents** | See §19 |

> **Standing.** This Policy defines when expenditure is capitalised versus expensed, how capital projects are approved and controlled, and how assets are depreciated and retired. Ordinary employee expense is governed by `ANB-FIN-POL-0001`. Procurement of vendors and POs is governed by `ANB-PRC-POL-0001` and settled under `ANB-FIN-SOP-0008`. Project approval thresholds follow `ANB-ADM-MTX-0001` §7.3.

---

## 2. Purpose

Capital expenditure shapes the Bank's balance sheet for years. Mis-classification between capital and operating expense distorts earnings, regulatory capital, and management information. Weak project control creates budget overruns, stranded CIP balances, and audit qualifications.

This Policy therefore:

1. Sets a clear **capitalisation threshold** and recognition criteria under US GAAP (primary for `BOOK-USGAAP-ANB`) with IFRS alignment for `BOOK-IFRS-UK` / `BOOK-IFRS-EU`.
2. Defines **approval authority** for capital projects per `ANB-ADM-MTX-0001` §7.3.
3. Prescribes **useful lives and depreciation** (straight-line) by asset class.
4. Establishes the **end-to-end process `BP-FIN-CAP`** from business case through CIP, in-service transfer, depreciation, impairment, and disposal.
5. Embeds **SOX and anti-fraud controls** over project creation, vendor payment, and asset existence.
6. Distinguishes **technology investment, branch construction, furniture, and infrastructure** treatments with worked examples.

---

## 3. Scope

### 3.1 In Scope

| Category | Coverage |
|---|---|
| Property, plant, and equipment | Buildings, leasehold improvements, furniture, vehicles, ATM/branch equipment |
| Technology hardware | Servers, network, end-user devices above threshold (where capitalised) |
| Internally developed software | Eligible development-phase costs |
| Licensed / purchased software | Capitalisable licences meeting threshold and life criteria |
| Construction in progress (CIP) | All `150xxx` CIP balances until in-service |
| Capital projects | Identifiers `CAP-YYYY-####` tracked in ApexPlan and ApexLedger |
| Asset retirement and disposal | Sale, scrap, donation, write-off |
| Impairment indicators | Triggered reviews |

### 3.2 Out of Scope

| Excluded | Governed By |
|---|---|
| Employee expense reimbursements and corporate card opex | `ANB-FIN-POL-0001`, `ANB-FIN-POL-0007` |
| Operating leases (IFRS 16 / ASC 842 right-of-use accounting detail) | Group Accounting Policy Manual; Controller guidance notes |
| Credit impairments and CECL | Risk / Credit policies |
| Inventory and trading assets | Markets / Treasury policies |
| Pure SaaS subscriptions with no capitalisable component | Operating expense; CoA tech opex |

### 3.3 Applicability

All legal entities consolidating into Apex Group, all business units (`CRB`, `CMB`, `CIB`, `WAM`, `TM`, `ETO`, `CC`), and all departments (`HRM`, `FIN`, `RTL`, `CBK`, `TRY`, `LEG`, `CMP`, `RSK`, `ISC`, `ITO`, `CST`, `IAD`, `MKT`, `PRC`, `ADM`).

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Capital Expenditure (CapEx)** | Expenditure that meets capitalisation criteria and is recognised as an asset |
| **Capitalisation Threshold** | **$5,000 USD** (or local currency equivalent) **and** useful life **greater than one year** |
| **Capital Project** | Approved initiative tracked as `CAP-YYYY-####` (e.g. `CAP-2026-0142`) |
| **CIP** | Construction in Progress — asset under construction/development, GL range `150xxx`, not yet depreciated |
| **Fixed Asset** | Capitalised item with identifier `FA-########` in ApexLedger Fixed Assets |
| **In-Service Date** | Date the asset is ready for its intended use; depreciation start |
| **Useful Life** | Period over which the asset is depreciated per §8 |
| **Business Case** | Documented investment rationale, NPV/strategic case, risk, and funding source |
| **CapEx Controller** | Group Financial Controller role for capital governance (`EMP-600101`) |
| **Component Accounting** | Separate capitalisation of significant components with different lives where material |
| **Impairment** | Carrying amount exceeds recoverable amount; write-down required |
| **Budget Code** | `BUD-FY26-<DEPT>-CAPEX` for capital; never fund CapEx from OPEX budgets without formal reclass |

---

## 5. Roles and Responsibilities

| Role | Named Holder | Responsibility |
|---|---|---|
| Chief Financial Officer (G11) | `EMP-100002` Priya Raghunathan | Owns this Policy; concurs on projects ≤ $5M; ExCo/Board papers for larger projects |
| Group Financial Controller / CapEx Controller (G9) | `EMP-600101` Gemma Ashworth | Custodian; capitalisation policy judgments; CIP ageing; useful-life table; auditor liaison |
| CapEx & Fixed Assets Manager (G6) | `EMP-600121` Priya Menon | Day-to-day CIP, asset master data, depreciation runs, project close-out, physical verification coordination |
| Head of FP&A (G9) | `EMP-600105` Anneke Visser | Capital plan, forecast, and portfolio prioritisation in ApexPlan |
| Head of Financial Operations (G8) | `EMP-600102` Marcel Delacroix | AP integration, PO/invoice matching to capital projects |
| Head of Accounts Payable (G7) | `EMP-600112` Colin Devereaux | Pays capital vendor invoices against `PO-########` / `INV-##########` |
| Head of Internal Controls & SOX (G8) | `EMP-600110` Teresa Villanueva | `CTL-FIN-CAP-*` design and testing |
| Head of Tax (G8) | `EMP-600107` Miriam Rosenthal | Tax depreciation / capital allowances divergence tracking |
| Chief Procurement Officer (G10) | `EMP-100013` Ian McAllister | Sourcing strategy for capital vendors |
| Head of Category Management (G8) | `EMP-600401` Ethan Brookfield | Category strategies (facilities, tech hardware, construction) |
| Head of Procurement Operations (G8) | `EMP-600402` Angela Duarte | PO release, vendor onboarding via ApexVendor (`VND-########`) |
| Business Unit Head (G10) | Per BU | Approves projects ≤ $5M with CFO concurrence; owns benefits realisation |
| Project Sponsor | Named G8+ | Accountable for scope, budget, timeline, and in-service declaration |
| ITO / Facilities Project Manager | Named | Executes delivery; maintains evidence pack |
| Cost Centre Manager | Per benefiting `CC-*` | Budget owner for depreciation and run-cost impact |
| Internal Audit | IAD | Independent testing of capitalisation and existence |

### 5.1 RACI — Process `BP-FIN-CAP` (New)

| Activity | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Raise business case | Project Sponsor | BU Head | FP&A, PRC, ITO/Facilities, Risk | CapEx Manager |
| Approve project | Per §9 / MTX §7.3 | Approving body | CFO, Legal, CISO as needed | Board Secretariat if Board-level |
| Create `CAP-YYYY-####` | `EMP-600121` | `EMP-600101` | FP&A | Sponsor |
| Procure / issue PO | PRC Operations | CPO | Sponsor | AP |
| Capitalise to CIP | Fixed Assets / FinOps | CapEx Controller | Tax | External Audit (as needed) |
| Declare in-service | Sponsor + CapEx Manager | CapEx Controller | ITO/Facilities | FP&A |
| Run depreciation | `EMP-600121` | `EMP-600101` | — | Cost Centre Managers |
| Impair / dispose | CapEx Manager | CapEx Controller | BU Head, Tax | IAD |
| SOX testing | Internal Controls | `EMP-600110` | CapEx Manager | Audit Committee |

---

## 6. Policy Statements

**C-1 — Threshold.** An item is capitalised only if cost is **≥ $5,000 USD** (or local equivalent determined by Tax/Controller rate table) **and** useful life **> 1 year**. Items failing either test are expensed under `ANB-FIN-POL-0001` or via AP opex, unless component aggregation rules in §7.3 apply.

**C-2 — No artificial splitting.** Purchasing related assets in tranches below $5,000 to avoid capitalisation or to avoid approval thresholds is prohibited and is a conduct matter under `ANB-HRM-POL-0004`.

**C-3 — Project mandatory.** Capital spend ≥ $25,000 (or any multi-asset programme) requires a `CAP-YYYY-####` project in ApexPlan before PO release, except emergency replacements approved retrospectively within 5 business days.

**C-4 — Approval per Matrix §7.3.**  
- ≤ $5,000,000 — Business Unit Head (G10) **with CFO concurrence**  
- $5,000,000 – $50,000,000 — ExCo  
- > $50,000,000 — Board of Directors  

**C-5 — Budget.** Capital projects consume `BUD-FY26-<DEPT>-CAPEX` (or multi-year capital plan envelopes). Funding from OPEX requires formal reclassification approved by FP&A and CapEx Controller.

**C-6 — CIP discipline.** Costs remain in `150xxx` until the asset is ready for intended use. Ageing CIP > 180 days without in-service plan is escalated monthly to the CapEx Controller and sponsor.

**C-7 — Straight-line depreciation.** Unless a component or residual-value exception is approved by the CapEx Controller, depreciation is **straight-line** to nil residual over the useful lives in §8, commencing the month of in-service (half-month convention as configured in ApexLedger).

**C-8 — Existence and custody.** Assets `FA-########` are subject to periodic physical verification. Ghost assets and unrecorded disposals are control failures.

**C-9 — Software rules.** Only eligible internally developed software costs (application development stage) are capitalised; preliminary project and post-implementation training/maintenance are expensed. Licensed software capitalised only when criteria in §7.5 are met.

**C-10 — SOX.** Capitalisation judgments, CIP transfers, and depreciation are SOX-relevant. Circumventing ApexLedger asset controls is prohibited.

---

## 7. Capitalisation Criteria

### 7.1 Recognition Tests

Capitalise when **all** of the following are met:

1. Probable future economic benefit to the Bank.  
2. Cost reliably measured.  
3. Cost ≥ $5,000 USD (or local equivalent).  
4. Useful life > 1 year.  
5. The Bank controls the asset (owned or capital-lease / finance-lease equivalent as determined by Controller).

### 7.2 Cost Elements Included

| Included in Asset Cost | Excluded (Expense) |
|---|---|
| Purchase price / construction contract cost | Training and change management |
| Non-recoverable taxes and duties | General overhead not directly attributable |
| Freight and installation to bring to location/condition | Preliminary research / ideation |
| Architect and engineering fees directly attributable | Marketing launch events |
| Interest capitalised only where permitted by accounting policy for long construction | Routine repairs and maintenance |
| Eligible internal software development labour (timesheet-evidenced) | Data conversion and post-go-live support |

### 7.3 Aggregation

Identical or functionally interdependent items purchased together that individually fall below $5,000 may be capitalised as a **pooled asset** when the aggregate is ≥ $5,000 and useful life > 1 year (e.g. a branch furniture package). Pooling decisions are approved by `EMP-600121` and documented on the asset master.

### 7.4 Subsequent Expenditure

| Nature | Treatment |
|---|---|
| Extends useful life or increases capacity | Capitalise if threshold met |
| Routine maintenance / repair | Expense |
| Replacement of a separately depreciated component | Capitalise new component; derecognise replaced component's net book value |
| Cosmetic refresh without extended life | Expense |

### 7.5 Technology and Software

| Type | Capitalise? | Notes |
|---|---|---|
| IT hardware ≥ threshold, life 3–5y | Yes | Asset class IT Hardware |
| Cloud configuration with no control of underlying resource | Generally No | Expense SaaS |
| Internally developed software — development phase | Yes | Evidence: design docs, timesheets, `CAP-` project |
| Internally developed — preliminary / post-implementation | No | Expense |
| Perpetual / term licence ≥ threshold, life 3y typical | Yes if controlled and life >1y | Asset class Software Licensed |
| Security tooling platform build | Yes when criteria met | See example `CAP-2026-0088` |

### 7.6 Branch Construction and Leasehold

Branch build-outs and renovations capitalise eligible construction and leasehold improvement costs to CIP, then to Leasehold Improvements or Buildings as appropriate. Landlord contributions are accounted per Controller guidance (deferred incentive vs cost reduction). Furniture packages follow Furniture useful life (7y) unless pooled components differ.

---

## 8. Useful Lives and Depreciation

Depreciation method: **straight-line**. Lives below are Group standards for `BOOK-USGAAP-ANB`; IFRS books use the same economic lives unless local statutory override is documented by Tax/Controller.

| Asset Class | Useful Life | Typical GL (asset) | Depreciation Expense (illustrative) |
|---|---|---|---|
| Buildings | 40 years | Per CoA PPE buildings | Occupancy / depreciation |
| Leasehold improvements | **Lesser of 10 years or remaining lease term** (including reasonably certain renewals per Controller) | Leasehold PPE | Depreciation |
| Furniture & fixtures | 7 years | Furniture PPE | `650100` Depreciation Furniture (expense example) |
| IT hardware | 3–5 years (default 4 unless tech architecture specifies) | IT PPE | Tech depreciation |
| Software — internally developed | 5 years | Intangible / software | Amortisation |
| Software — licensed | 3 years | Intangible / software | Amortisation |
| Vehicles | 5 years | Vehicles PPE | Depreciation |
| ATM / branch equipment | 7 years | Branch equipment PPE | Depreciation |

**Residual value.** Default nil unless CapEx Controller approves a documented residual (e.g. certain vehicles).

**Impairment.** Sponsors must notify `EMP-600121` when indicators arise (technology obsolescence, branch closure, project abandonment). Abandoned CIP is expensed promptly — it is not left to age.

---

## 9. Approval Tables — Capital Projects (`ANB-ADM-MTX-0001` §7.3)

| Total Project Cost (life-of-project) | Approver | Additional Requirements |
|---|---|---|
| ≤ $5,000,000 | Business Unit Head (G10) **with CFO concurrence** | Business case in ApexPlan; PRC sourcing plan; CISO for tech; Facilities for construction |
| $5,000,000 – $50,000,000 | ExCo | CFO paper; Risk opinion for material operational risk; Legal for material contracts |
| > $50,000,000 | Board of Directors | ExCo recommendation; full investment paper; Audit Committee informed on accounting impact |
| Unbudgeted capital > $1,000,000 | CFO **and** relevant ExCo member | Per Matrix §7.3 unbudgeted commitment rule |
| Life increase / budget overrun > 10% or > $500,000 | One level above original approver | Re-baseline in ApexPlan before further PO release |

**Aggregation rule.** Phased programmes that are economically one investment are approved on **total connected value**, not phase 1 alone (`ANB-ADM-MTX-0001` R-9).

---

## 10. Decision Tables

### 10.1 Capitalise vs Expense

| Scenario | Decision | Rationale |
|---|---|---|
| Laptop $2,200, 3-year life | Expense | Below $5,000 threshold |
| Storage array $48,000, 5-year life | Capitalise | Meets threshold and life |
| 40 chairs at $180 = $7,200 for one branch fit-out | Capitalise as pooled furniture | Aggregation §7.3 |
| Annual SaaS $120,000 | Expense | No controlled PPE/intangible meeting criteria |
| Internal build of loan-origination module, $2.1M development | Capitalise eligible phase | Software developed, 5y |
| Training for that module $180,000 | Expense | Post-implementation / training |
| Paint and carpet refresh $9,500, no life extension | Expense | Maintenance |
| HVAC replacement extending life $85,000 | Capitalise | Subsequent expenditure §7.4 |

### 10.2 Approver Selection

| Project | Amount | Path |
|---|---|---|
| Branch renovation Charlotte | $4.2M | BU Head RTL (G10) + CFO concurrence |
| Cybersecurity platform | $18M | ExCo |
| Data centre campus expansion | $62M | Board |

---

## 11. Procedures / Process Flow — `BP-FIN-CAP`

> **Process note.** `BP-FIN-CAP` is introduced by this Policy as a **new** controlled business process under `ANB-ADM-GDL-0001`. It covers capital project initiation through asset retirement.

```
SPONSOR / BU          FP&A / PRC           CAPEX CONTROL           AP / LEDGER
   │                     │                      │                      │
   ├─ Business case      │                      │                      │
   │  CAP request ──────►│                      │                      │
   │                     ├─ Capital plan fit    │                      │
   │                     │  sourcing strategy ──┤                      │
   │◄─ Approval per §9 ──┼──────────────────────┤                      │
   │                     │                      ├─ Open CAP-YYYY-####  │
   │                     │                      │  budget BUD-*-CAPEX  │
   ├─ Requisition ──────►│ PO-######## ─────────┼─────────────────────►│
   │                     │ VND-########         │                      ├─ INV match
   │                     │                      ├─ Post CIP 150xxx     │
   ├─ In-service cert ───┼─────────────────────►│                      │
   │                     │                      ├─ CIP → FA-########   │
   │                     │                      ├─ Start depreciation  │
   │                     │                      ├─ Close project       │
```

### 11.1 Project Stages

| Stage | Gate | Evidence |
|---|---|---|
| Initiate | Business case approved | ApexPlan case ID; minutes/approval ID |
| Setup | `CAP-YYYY-####` active | Project master; WBS; budget |
| Procure | PO released | `PO-########`, `VND-########` |
| Execute | CIP postings | Invoices `INV-##########`, timesheets for internal software |
| In-service | Transfer from CIP | In-service certificate; `FA-########` |
| Operate | Depreciation monthly | ApexLedger FA run; cost centre charge |
| Close | Project closure | Final cost report; lessons; benefits tracker |
| Retire | Disposal approval | Disposal form; sale proceeds; gain/loss journal `JE-YYYYMM-######` |

### 11.2 CIP GL (`150xxx`)

All construction and development costs accumulate in CIP accounts in the `150xxx` series until in-service. Sub-accounts distinguish construction, software development, and equipment-in-install as configured in `ANB-FIN-STD-0004`. Monthly CIP reconciliations are performed by `EMP-600121` and reviewed by `EMP-600101`.

### 11.3 Month-End

Capital activity is a close checkpoint under `ANB-FIN-SOP-0003`: CIP reconciliation, depreciation posting, in-service cut-off, and abandonment review must complete before Hard Close.

---

## 12. Fraud, SOX, and Anti-Bribery Controls

| Risk | Control |
|---|---|
| Fictitious assets | Physical verification cycle; photo/geo evidence for branch assets; ITO CMDB match for tech |
| Vendor kickbacks on construction | PRC dual control; `ANB-PRC-POL-0002` due diligence; Conflict declarations (`ANB-HRM-POL-0004`) |
| CapEx used to hide opex overruns | CapEx Controller review of coding; Internal Audit sampling |
| Premature capitalisation | In-service certificate dual sign-off (Sponsor + `EMP-600121`) |
| Evergreen CIP | 180-day ageing escalation |
| Related-party vendors | ApexVendor screening; CPO escalation |
| Public official facilitation in permitting | GC + CCO involvement; never pay unofficial fees |

SOX controls `CTL-FIN-CAP-01` through `CTL-FIN-CAP-08` cover project approval evidence, CIP transfer authorisation, depreciation completeness, and disposal authorisation — owned by `EMP-600110`.

---

## 13. Examples

### 13.1 Branch Renovation — `CAP-2026-0142`

**Project.** Renovation of Charlotte Uptown branch `SIT-0412`, benefiting cost centre `CC-RTL-412`.

| Attribute | Value |
|---|---|
| Project ID | `CAP-2026-0142` |
| Sponsor | Retail Operations executive (G10 BU path) |
| Budget | $4,200,000 — `BUD-FY26-RTL-CAPEX` |
| Approval | BU Head (G10) + CFO concurrence (`EMP-100002`) — within ≤ $5M band |
| Vendor | General contractor `VND-00488211`; furniture `VND-00490102` |
| PO / Invoices | `PO-00914422`; progressive `INV-1000288741` et seq. |
| CIP | Costs accumulate in `150xxx` through construction |
| In-service | Phased: public area 2026-11-15; back office 2026-12-01 |
| Assets | Leasehold improvements (min 10y / lease term); furniture `FA-` pool 7y; branch equipment 7y |
| Depreciation | Straight-line from in-service months; furniture expense example `650100` |
| CapEx Manager | `EMP-600121` Priya Menon maintains FA masters; Controller `EMP-600101` reviews CIP transfer |

### 13.2 Cybersecurity Platform — `CAP-2026-0088`

**Project.** Enterprise detection-and-response platform for Information Security, cost centre `CC-ISC-100`, delivered with ITO (`CC-ITO-100` run-cost impact).

| Attribute | Value |
|---|---|
| Project ID | `CAP-2026-0088` |
| Amount | $18,400,000 life-of-project (licences, implementation, eligible internal build) |
| Approval | **ExCo** ($5M–$50M band) with CFO paper |
| CISO / ITO | Architecture and security design sign-off mandatory |
| Capital vs expense split | Eligible platform build and perpetual/controlled licence components capitalised (software developed 5y / licensed 3y); ongoing SaaS telemetry and training expensed |
| Procurement | Category lead `EMP-600401`; operations `EMP-600402`; CPO `EMP-100013` |
| SOX | High — access to production security tooling; `EMP-600110` includes in ITGC/CapEx testing |
| Books | Capex in local entity books; consolidates to `BOOK-CONS-GROUP` |

### 13.3 Below-Threshold Tech Accessory

`EMP-500103` Andrés Villalobos purchases diagnostic hardware at $3,800. Life exceeds one year but amount is below $5,000 → **expense** via AP or expense policy path; not `CAP-` and not `FA-`.

### 13.4 Attempted Split Purchase

A manager attempts three $4,500 server purchases on consecutive days for one cluster. CapEx Manager aggregates to $13,500, requires `CAP-` project, and escalates to Employee Relations for threshold evasion attempt.

---

## 14. Approval Tables — Policy Governance

| Action | Authority |
|---|---|
| Policy major version | CFO `EMP-100002` |
| Useful-life table change | CapEx Controller + external auditor consultation; CFO approval |
| Threshold change ($5,000) | CFO; Board Audit Committee notification |
| Emergency capital without prior `CAP-` | BU Head + CapEx Controller; ratify within 5 business days |
| Asset disposal NBV > $100,000 | CapEx Controller + BU Head; > $1M also CFO |
| Impairment > $5M | CFO; Audit Committee notification |

---

## 15. Records and Retention

| Record | Identifier | System | Retention |
|---|---|---|---|
| Business case / approval | `CAP-YYYY-####` | ApexPlan / ApexServe | `RET-FIN-10Y` |
| Vendor / PO / Invoice | `VND-` / `PO-` / `INV-` | ApexSource / ApexLedger | `RET-FIN-10Y` |
| CIP and FA master | `FA-########` | ApexLedger | Life of asset + `RET-FIN-10Y` |
| In-service certificate | Linked to `CAP-` / `FA-` | ApexDocs | `RET-FIN-10Y` |
| Depreciation journals | `JE-YYYYMM-######` | ApexLedger | `RET-FIN-10Y` |
| Physical verification | Campaign ID | ApexDocs | `RET-FIN-10Y` |

---

## 16. Review Cycle

| Trigger | Action | Owner |
|---|---|---|
| Annual | Full policy review | `EMP-600101` → CFO |
| Audit adjustment to lives | Update §8; communicate to FA team | CapEx Controller |
| Material IFRS/US GAAP change | Interim amendment | Controller + Tax |
| Repeated CIP ageing breaches | Process tightening in `BP-FIN-CAP` | `EMP-600121` |
| Budget cycle | Capital portfolio refresh | `EMP-600105` |

Next scheduled review: **2027-07-28**.

---

## 17. Related Documents

| Document ID | Title | Relationship |
|---|---|---|
| `ANB-ADM-REF-0001` | Company Profile | Entities, systems, departments, BUs |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | Metadata |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | Taxonomy |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | Naming |
| `ANB-ADM-POL-0001` | Records Retention Policy | `RET-FIN-10Y` |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | **§7.3 capital project approvals**; §7.1 procurement authority |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | Registers **`BP-FIN-CAP`** |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | ExCo / Board / Audit Committee |
| `ANB-HRM-HBK-0001` | Employee Handbook | Conduct; asset custody expectations |
| `ANB-HRM-POL-0002` | Leave Policy | (cross-ref set completeness) |
| `ANB-FIN-POL-0002` | Travel Policy | Travel vs capital boundary |
| `ANB-HRM-POL-0003` | Remote Work Policy | Home equipment generally expense |
| `ANB-HRM-POL-0004` | Code of Conduct | Fraud, conflicts, anti-bribery |
| `ANB-HRM-POL-0006` | Performance Management Policy | Sponsor accountability |
| `ANB-HRM-SOP-0007` | Recruitment SOP | (cross-ref set completeness) |
| `ANB-HRM-POL-0008` | Training and Certification Policy | Training always expense |
| `ANB-FIN-POL-0001` | Expense Policy | Opex boundary; capitalisation screen |
| `ANB-FIN-BUD-0005` | Budget FY2026 | `BUD-FY26-*-CAPEX` |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard | PPE, CIP `150xxx`, depreciation accounts |
| `ANB-FIN-SOP-0003` | Month-End Close Procedure | CIP and FA close checkpoints |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy (this document) | — |
| `ANB-FIN-POL-0007` | Corporate Card Policy | Cards must not procure capital outside PRC |
| `ANB-FIN-SOP-0008` | Vendor Payment Procedure | Capital invoice payment |
| `ANB-FIN-MTX-0009` | Finance Approval Authority Matrix | Journals and FA master approvals |
| `ANB-PRC-POL-0001` | Procurement Policy | Mandatory sourcing for capital vendors |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy | Contractor and builder risk |

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-08-01 | `EMP-600101` Gemma Ashworth; operating design `EMP-600121` Priya Menon | Initial policy; introduces `BP-FIN-CAP`; $5,000 threshold; Matrix §7.3 alignment |

---

## Appendix A — Asset Identifier and Project Patterns

| Object | Pattern | Example |
|---|---|---|
| Capital project | `CAP-YYYY-####` | `CAP-2026-0142`, `CAP-2026-0088` |
| Fixed asset | `FA-########` | `FA-00091827` |
| Vendor | `VND-########` | `VND-00488211` |
| Purchase order | `PO-########` | `PO-00914422` |
| Invoice | `INV-##########` | `INV-1000288741` |
| Journal | `JE-YYYYMM-######` | `JE-202611-000482` |
| Budget | `BUD-FY26-<DEPT>-CAPEX` | `BUD-FY26-RTL-CAPEX` |

---

## Appendix B — Currencies and Local Equivalents

Threshold application uses USD as the reference. For GBP, EUR, INR, AED, SGD, HKD, JPY, AUD, CHF, CAD, BRL, MXN, and other operating currencies, `EMP-600107` / Controller publish a quarterly local-equivalent table in ApexDocs. Approvers must not cherry-pick FX rates to avoid the threshold.

---

## Appendix C — In-Service Certificate (Minimum Content)

1. `CAP-YYYY-####` and asset description  
2. Location / cost centre (`CC-*`)  
3. Ready-for-intended-use confirmation  
4. Final capitalisable cost summary (exclusions listed)  
5. Useful life and asset class  
6. Sponsor signature and `EMP-600121` acceptance  
7. Date of transfer from CIP `150xxx` to FA  

---

## Appendix D — SOX Control Summary

| Control ID | Description |
|---|---|
| `CTL-FIN-CAP-01` | Project approval matched to Matrix §7.3 before PO |
| `CTL-FIN-CAP-02` | CIP postings require active `CAP-` |
| `CTL-FIN-CAP-03` | In-service dual authorisation |
| `CTL-FIN-CAP-04` | Monthly depreciation completeness |
| `CTL-FIN-CAP-05` | CIP ageing review ≤ 180 days |
| `CTL-FIN-CAP-06` | Disposal / impairment authorised |
| `CTL-FIN-CAP-07` | Useful-life changes approved by Controller |
| `CTL-FIN-CAP-08` | Physical verification sampling |

---

## Appendix E — Multi-Book and Multi-Currency Notes

Capital projects frequently span more than one legal entity and more than one reporting book. Sponsors must state at initiation:

1. **Owning legal entity** and primary book (`BOOK-USGAAP-ANB`, `BOOK-IFRS-UK`, `BOOK-IFRS-EU`).  
2. **Cross-charge or cost-sharing** arrangements with other entities (intercompany partner coding per `ANB-FIN-STD-0004`).  
3. **Functional currency** of the owning entity and expected transaction currencies (USD, GBP, EUR, INR, AED, SGD, HKD, JPY, AUD, CHF, CAD, BRL, MXN as applicable).  
4. Whether consolidation to `BOOK-CONS-GROUP` requires elimination of intercompany capital mark-ups (Tax/`EMP-600107` transfer-pricing documentation).

FX differences on CIP denominated in a non-functional currency are treated per Group Accounting Policy; they are not an informal “plug” to opex. CapEx Manager `EMP-600121` escalates unresolved FX CIP breaks to `EMP-600101` before Hard Close.

---

## Appendix F — Infrastructure and Facilities Portfolio Controls

Large infrastructure programmes (data centres, core network, cash-operations centres) require, in addition to §9 approvals:

| Control | Requirement |
|---|---|
| Architecture board | ITO architecture approval before technical CapEx > $1M |
| Security design | CISO (or delegate) for any system touching customer data or payments |
| Facilities board | ADM/Facilities endorsement for construction and landlord works |
| Benefit tracking | FP&A (`EMP-600105`) records expected run-rate savings or risk reduction; 12-month post-implementation review |
| Contingency | Contingency draw > 50% of contingency envelope requires sponsor re-approval at the original authority level |

Branch construction programmes must map each site to a cost centre (e.g. `CC-RTL-412`) and must not park completed-site costs in a corporate holding CIP without in-service transfer.

---

## Appendix G — Disposal and Retirement Checklist

1. Identify `FA-########` and net book value.  
2. Confirm asset is idle, obsolete, sold, or destroyed; attach evidence.  
3. Obtain disposal authority per §14.  
4. Remove from insurance schedules where applicable.  
5. Post disposal journal `JE-YYYYMM-######` (clear cost and accumulated depreciation; recognise proceeds and gain/loss).  
6. Update CMDB / facilities register for tech and branch assets.  
7. File pack under `RET-FIN-10Y`.

---

*End of Document — ANB-FIN-POL-0006 v1.0*
