# Apex National Bank — Expense Policy

**Corporate Policy | Business Expense, Entertainment, Reimbursement, and Fraud Control**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-POL-0001` |
| **Document Title** | Apex National Bank — Expense Policy |
| **Version** | 1.0 |
| **Owner** | Finance Department (FIN) — Financial Operations |
| **Custodian** | Rosa Delgado, Corporate Travel & Expense Manager (G6) — `EMP-600104` |
| **Approver** | Priya Raghunathan, Chief Financial Officer (G11) — `EMP-100002` |
| **Secondary Reviewers** | Marcel Delacroix (`EMP-600102`); Teresa Villanueva (`EMP-600110`); Samuel A. Okonkwo (CCO); Grace Mwangi (Employee Relations) |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-15 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-28 |
| **Review Cycle** | Annual (next review 2027-07-28); category limits reviewed with budget cycle |
| **Supersedes** | None — initial published policy under the 2026 controlled-document programme |
| **Retention** | `RET-FIN-10Y` — Financial Records (10 years from fiscal year end) |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T5` Finance & Treasury → Expense & Procure-to-Pay Control → Expense Governance → `POL` |
| **Business Process** | `BP-FIN-EXP` Expense Management & Reimbursement |
| **Related Processes** | `BP-FIN-TRVL`, `BP-FIN-CARD`, `BP-FIN-AP`, `BP-FIN-JRNL`, `BP-HR-COND`, `BP-AUD-SOX` |
| **Governing Body** | Executive Committee; Board Audit Committee (control effectiveness reporting) |
| **System of Record** | ApexLedger (expense claims, corporate card, journals) · ApexServe (pre-approvals, exceptions) · ApexDocs (this policy) |
| **Keywords** | expense, reimbursement, entertainment, hospitality, receipt, fraud, SOX, anti-bribery, cost centre, GL coding |
| **Related Documents** | See §19 |

> **Standing.** This Policy is the Group's authoritative instrument for employee-initiated expenditure. Where this Policy and `ANB-FIN-POL-0002` Travel Policy both apply, both must be satisfied. Where this Policy and `ANB-HRM-POL-0004` Code of Conduct conflict on gifts, entertainment, or anti-bribery, the Code prevails.

---

## 2. Purpose

Apex National Bank reimburses costs that are necessary to conduct its business. Expense spending is small relative to the Group's cost base, yet it is among the highest-risk channels the Bank operates: the person who benefits from the transaction is often the person who initiates and evidences it.

This Policy therefore:

1. Defines **what the Bank will and will not pay for**, by category and circumstance.
2. Sets **evidence, receipt, and submission standards** that make every claim auditable.
3. Establishes **approval authority** consistent with `ANB-ADM-MTX-0001` §7.1 and §7.2.
4. Controls **entertainment, hospitality, and gifts** as anti-bribery instruments under the FCPA, UK Bribery Act, and equivalent regimes.
5. Prescribes **accounting treatment** — general ledger, cost centre, tax code, and books — so expenditure posts correctly at source.
6. Defines **fraud detection, audit, and consequence** so misuse is identified and treated as a conduct matter, not an administrative inconvenience.

Travel booking rules, class of service, destination risk, and duty of care are governed by `ANB-FIN-POL-0002`. This Policy governs what may be claimed after travel (and for non-travel business expense) and how that claim is evidenced, approved, and accounted for.

---

## 3. Scope

### 3.1 In Scope

| Category | Coverage |
|---|---|
| Reimbursable out-of-pocket expense | Costs personally incurred and claimed via `EXP-##########` in ApexLedger |
| Corporate card expenditure | All spend on cards issued under `ANB-FIN-POL-0007`, settled centrally or claimed |
| Travel-related expense settlement | Meals, ground transport, incidentals, and related claims linked to `TRV-########` |
| Entertainment and hospitality | Client entertainment, internal events, business gifts, prospect hospitality |
| Professional memberships and training claimed as expense | Where not procured via purchase order under `ANB-PRC-POL-0001` |
| Local transport and supplies | Same-day local business costs not requiring a travel request |
| Non-employee claims | Non-executive directors and approved third parties claiming through the Group |

### 3.2 Out of Scope

| Excluded | Governed By |
|---|---|
| Vendor invoices on purchase order or contract | `ANB-FIN-SOP-0008`; `ANB-PRC-POL-0001` |
| Capital expenditure and fixed asset purchases | `ANB-FIN-POL-0006` |
| Payroll, salary, incentive, and benefit payments | ApexPeople; `ANB-HRM-HBK-0001` |
| Relocation packages as employment terms | Global Mobility / `ANB-HRM-SOP-0007` |
| Booking rules, class of travel, destination risk, duty of care | `ANB-FIN-POL-0002` |
| Customer remediation and goodwill payments | Complaints handling procedures |
| Charitable and political contributions above delegated limits | `ANB-ADM-MTX-0001` §7.2; Code of Conduct |

### 3.3 Relationship to Travel Policy

`ANB-FIN-POL-0002` determines **whether and how** travel may be undertaken. This Policy determines **what may be claimed and how it is evidenced, approved, and accounted for**. A trip that complies with the Travel Policy may still produce a claim this Policy rejects. Both instruments must be satisfied before reimbursement or card clearance.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Business Expense** | A cost necessarily incurred in performing the Group's business that would not have been incurred otherwise |
| **Claimant** | The individual who incurred the cost and submits the claim |
| **Approver** | The individual with delegated authority under `ANB-ADM-MTX-0001` §7.2 and `ANB-FIN-MTX-0009` |
| **Expense Category** | Canonical classification `EXP-CAT-*` used in ApexLedger (§8) |
| **Itemised Receipt** | Merchant document showing merchant name, date, individual items, tax, and total; a card slip showing only a total is **not** sufficient |
| **Business Purpose** | Specific statement of why the cost was incurred, naming the deliverable, meeting, client, or event |
| **Guest** | Any person other than Bank employees present at entertainment, identified by full name and organisation |
| **Public Official** | Officer or employee of a government, agency, state-owned enterprise, public international organisation, political party, or candidate — including employees of state-owned banks and sovereign wealth funds |
| **Per Diem** | Fixed daily meal and incidentals allowance under `ANB-FIN-POL-0002`; no itemised meal receipts required when elected |
| **Out-of-Policy Item** | Claim line breaching a stated limit; permissible only with documented exception approval |
| **Split Transaction** | Dividing one economic transaction across claims, cards, dates, or people to stay below an approval threshold — prohibited |
| **Corporate Card** | Apex Corporate Card under `ANB-FIN-POL-0007`, identifier `CARD-########` |
| **Expense Claim** | Settlement record in ApexLedger, identifier `EXP-##########` |
| **Travel Request** | Pre-approval record in ApexServe, identifier `TRV-########` |

---

## 5. Roles and Responsibilities

| Role | Named Holder | Responsibility |
|---|---|---|
| Chief Financial Officer (G11) | `EMP-100002` Priya Raghunathan | Owns this Policy; approves material exceptions; ExCo expense oversight with Group CEO |
| Head of Financial Operations (G8) | `EMP-600102` Marcel Delacroix | Owns the expense operating model, audit programme, late-claim exceptions, and reimbursement integrity |
| Corporate Travel & Expense Manager (G6) | `EMP-600104` Rosa Delgado | Custodian; owns category definitions, limits, system configuration, and claimant guidance |
| Expense Audit Officer (G4) | `EMP-600120` Joaquín Herrera | Executes pre-payment and post-payment audit; raises exceptions and suspected fraud |
| Head of Accounts Payable (G7) | `EMP-600112` Colin Devereaux | Executes reimbursement runs and corporate card settlement posting |
| Finance Manager — Corporate Centre Cost Control (G6) | `EMP-600103` Sandeep Bhatt | Monitors expense against `BUD-FY26-*-OPEX`; reports variances |
| Group Financial Controller (G9) | `EMP-600101` Gemma Ashworth | Owns accounting treatment, accruals for unclaimed expense, and period cut-off |
| Head of Internal Controls & SOX (G8) | `EMP-600110` Teresa Villanueva | Owns `CTL-FIN-EXP-*` design, testing, and SOX evidence |
| Head of Tax (G8) | `EMP-600107` Miriam Rosenthal | Owns tax code determination and entertainment deductibility guidance |
| Chief Compliance Officer | `EMP-100005` Samuel A. Okonkwo | Owns anti-bribery pre-clearance and Gifts & Entertainment Register |
| Line Manager / Approver | Grades G4+ as applicable | Reviews claims; personally accountable for approvals granted |
| Cost Centre Manager | Per `ANB-FIN-STD-0004` | Accountable for expense charged to the cost centre and budget impact |
| Claimant | All individuals | Submits accurate, evidenced, policy-compliant claims within deadline |
| Internal Audit (IAD) | `EMP-100009` Thomas Nakamura (CAE) | Independent assurance over the expense control environment |

### 5.1 RACI — Process `BP-FIN-EXP`

| Activity | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Incur expense | Claimant | Claimant | Line manager (pre-approval where required) | — |
| Submit claim | Claimant | Claimant | — | Line manager |
| Approve claim | Line manager / delegate | Approver personally | Finance for out-of-policy | Cost Centre Manager |
| Pre-payment audit | `EMP-600120` | `EMP-600102` | Claimant, Approver | — |
| Reimburse | Accounts Payable | `EMP-600112` | Treasury (funding) | Claimant |
| Post-payment audit | `EMP-600120` | `EMP-600102` | Internal Audit | `EMP-600110` |
| Anti-bribery pre-clearance | Compliance | CCO | Legal | Claimant, Approver |
| Accrue unclaimed expense | Financial Control | `EMP-600101` | Financial Operations | External Audit |
| Escalate suspected misconduct | `EMP-600102` | CFO | Employee Relations, Compliance, Legal | CHRO |
| Policy amendment | `EMP-600104` | CFO | HR, Compliance, Legal, IAD | All staff |

---

## 6. Policy Statements

**E-1 — Necessity.** The Bank reimburses costs necessary to conduct its business. Convenience, preference, and comfort are not necessity.

**E-2 — Personal statements.** Every claim is a personal attestation. Inflating a claim, claiming a personal cost as business, or submitting fabricated evidence is fraud and is treated as gross misconduct under `ANB-HRM-POL-0004` §14.

**E-3 — No self-approval.** No individual may approve their own claim, or a claim from which they personally benefit. Approvers may not approve claims of their own manager without escalation one level above.

**E-4 — No splitting.** Dividing a transaction to remain below an approval threshold is a Code of Conduct violation (`ANB-ADM-MTX-0001` R-8).

**E-5 — Receipts.** Itemised receipts are mandatory for every line of $25 USD (or local equivalent) and above, and for all entertainment regardless of amount. See §10.

**E-6 — Timeliness.** Claims must be submitted within **30 calendar days** of the expense date (or return date for travel). Late claims require documented exception (§11.3).

**E-7 — Entertainment controls.** Guest names and organisations are mandatory. Entertainment ≤ $500 per head requires G6+ approval; > $500 per head requires G9+ and Compliance pre-clearance; any value involving a public official requires General Counsel **and** CCO (`ANB-ADM-MTX-0001` §7.2).

**E-8 — Public officials.** Anything of value provided to or received from a public official requires prior GC and CCO approval, without exception. Facilitation payments are prohibited absolutely.

**E-9 — Correct coding.** Every claim line carries expense category, GL account, cost centre, tax code, and — where applicable — `TRV-########`, `CARD-########`, or budget code. Mis-coding to avoid budget scrutiny is a control breach.

**E-10 — Corporate card primacy.** Where a claimant holds an Apex Corporate Card under `ANB-FIN-POL-0007`, business spend must be charged to the card unless the merchant does not accept cards or a documented exception applies.

**E-11 — SOX integrity.** Expense postings supporting management reporting and financial statements are subject to `CTL-FIN-EXP-*` controls owned by `EMP-600110`. Circumventing system controls is a disciplinary matter.

**E-12 — Alcohol.** Alcohol is not reimbursable on individual meals. It may be reimbursable within reasonable limits at client entertainment under §9, never where the claimant will drive, is on-call, or holds a safety-sensitive role.

---

## 7. Expense Categories

| Category ID | Description | Typical Use | Primary GL |
|---|---|---|---|
| `EXP-CAT-TRAVEL` | Air, rail, hotel, travel-related ground (when not TMC-billed) | Linked to `TRV-########` | `750100` |
| `EXP-CAT-MEALS` | Individual meals while travelling or working away (actuals) | Non-entertainment | `750200` |
| `EXP-CAT-ENTERTAIN` | Client / prospect entertainment and hospitality | Guest list mandatory | `750300` |
| `EXP-CAT-SUPPLIES` | Office and business supplies | Non-PO minor purchases | `720400` |
| `EXP-CAT-TRAINING` | External courses, conferences, exam fees claimed as expense | Align with `ANB-HRM-POL-0008` | `770100` |
| `EXP-CAT-TECH` | Minor tech accessories not capitalised / not via PO | Below CapEx threshold | `730300` / tech opex per CoA |
| `EXP-CAT-PROF` | Professional memberships and subscriptions | Annual dues | `740500` |
| `EXP-CAT-LOCAL-TRANS` | Taxi, rideshare, parking, mileage (non-overnight) | Same metro area | `750100` |
| `EXP-CAT-CLIENT-GIFT` | Business gifts given | Register rules apply | `750200` |
| `EXP-CAT-OTHER` | Residual — requires Finance Operations review before payment | Exception path | Per coding guidance |

Full category-to-GL mapping is in **Appendix A**. Budget posting uses `BUD-FY26-<DEPT>-OPEX` (or CAPEX only where CapEx Policy applies — ordinary expense never posts to CapEx budgets).

---

## 8. Non-Reimbursable Expenses

The following are **never** reimbursable, whether claimed out-of-pocket or charged to a corporate card (personal use of the card must be repaid under `ANB-FIN-POL-0007`):

| Item | Notes |
|---|---|
| Fines, penalties, traffic and parking tickets | Including congestion and toll violations attributable to the employee |
| Personal entertainment, minibar, in-room films, spa | Including gym day passes |
| Personal grooming, clothing, laundry (except extended travel per Travel Policy) | See `ANB-FIN-POL-0002` |
| Companion, spouse, partner, or family costs | Except Group CEO-approved formal Bank functions, reported as taxable benefit |
| Upgrades beyond Travel Policy entitlement | Personal buy-up only |
| Separately purchased travel insurance | Corporate cover applies |
| Loss or damage to personal property | Subject to corporate travel cover process, not expense claim |
| Peer-to-peer short-let accommodation | Not an approved channel |
| Airline club memberships (except approved lounge access on entitled itineraries) | — |
| Alcohol on individual meals | Client entertainment may allow reasonable alcohol under §9 |
| Charitable or political donations via expense | Separate contribution process |
| Home internet / personal mobile (except approved remote-work stipend) | `ANB-HRM-POL-0003` |
| Commuting between home and designated office | Handbook §10.2 |
| Interest, late fees, or personal credit card charges | Except Bank-caused delay documented by Finance |
| Cash gifts, gift cards to clients without Compliance clearance | Anti-bribery |
| Any expenditure breaching `ANB-HRM-POL-0004` | Including facilitation payments |

---

## 9. Entertainment, Hospitality, and Gifts

### 9.1 Alignment with Code of Conduct

Entertainment and gifts are governed jointly with `ANB-HRM-POL-0004` §9. The stricter rule applies. All entertainment claims require:

1. Business purpose naming the relationship objective.
2. Full guest names and organisations.
3. Itemised receipt.
4. Per-head cost calculation (total ÷ number of attendees including Bank staff present).
5. Gifts & Entertainment Register entry where required by the Code or this Policy.

### 9.2 Per-Head Thresholds (`ANB-ADM-MTX-0001` §7.2)

| Per-Head Amount | Approver | Additional Requirement |
|---|---|---|
| ≤ $500 USD (or local equivalent) | G6 or above | Guest list; anti-bribery awareness attestation on claim |
| > $500 USD per head | G9 or above | Compliance pre-clearance **before** the event where practicable; else within 2 business days with justification |
| Any value involving a public official | General Counsel **and** CCO | No exceptions; event may not proceed without dual clearance |
| Gifts given or received > $250 | Compliance pre-clearance **and** G7+ | Register entry mandatory |

### 9.3 Internal Events

Team meals and internal celebrations post to `EXP-CAT-ENTERTAIN` / GL `750200` with "internal" guest designation. Alcohol is limited to modest quantities. Events exceeding $100 per employee require Department Head (G9+) approval and Cost Centre Manager budget confirmation.

### 9.4 Frequency and Pattern Controls

Repeated entertainment of the same external party within a quarter is flagged by continuous monitoring. Pattern reviews are performed by `EMP-600120` and escalated to Compliance where inducement risk is indicated.

---

## 10. Receipt and Evidence Requirements

| Circumstance | Evidence Required |
|---|---|
| Under $25, non-entertainment, non-gift | None required (business purpose still mandatory) |
| $25 and above | Itemised receipt or invoice |
| Any entertainment or gift | Itemised receipt **plus** attendee / recipient list |
| Hotel | Folio showing room rate, taxes, and itemised incidentals |
| Mileage | Origin, destination, business purpose, distance; rate per statutory schedule |
| Foreign currency | Receipt in original currency; ApexLedger converts at the Bank's daily rate; claimant may attach card FX evidence |
| Missing receipt | Missing-receipt declaration signed by employee and countersigned by line manager; **maximum three items or $250 aggregate per claim** — identical to `ANB-FIN-POL-0002` §11 |
| Per diem (travel) | No meal receipts; per `ANB-FIN-POL-0002` election rules (actuals and per diem may not be mixed on one trip) |

**Card slips alone are insufficient** where an itemised receipt is required. Photograph or PDF upload to ApexLedger is mandatory; paper retention by the claimant is not a substitute for system attachment.

---

## 11. Submission, Approval, and Settlement

### 11.1 Claim Content

Each `EXP-##########` must include: expense date; category; amount and currency; business purpose; cost centre; GL (system-defaulted from category, overridable with justification); tax code; receipt attachments; `TRV-########` where travel-related; `CARD-########` where card-funded; guest details for entertainment.

### 11.2 Submission Deadline

| Rule | Standard |
|---|---|
| Standard deadline | **30 calendar days** from expense date or trip return date |
| Approver SLA | 10 business days from submission |
| Reimbursement | Next available payroll or AP reimbursement run after approval and audit clearance |
| Period cut-off | Claims not submitted by close are accrued by Financial Control under `ANB-FIN-SOP-0003` |

### 11.3 Late Claims

| Delay | Treatment |
|---|---|
| 31–60 days | Line manager + `EMP-600104` acknowledgement; payment permitted if otherwise compliant |
| 61–90 days | Department Head (G9+) exception; reported in monthly compliance pack |
| > 90 days | CFO delegate exception via `EMP-600102`; presumption of non-payment unless documented force majeure |
| After employment end | Only pre-approved exit claims within 15 days of last day; otherwise forfeited |

### 11.4 Approval Authority (`ANB-ADM-MTX-0001` §7.2)

| Claim Value / Type | Approver | Additional |
|---|---|---|
| Routine ≤ $1,000 | Line manager (G4+) | Receipt ≥ $25 |
| Routine $1,000 – $10,000 | G6+ | Itemised receipts; purpose statement |
| Routine > $10,000 | G8+ | Financial Operations review (`EMP-600102` or delegate) |
| Entertainment ≤ $500 / head | G6+ | Guest list |
| Entertainment > $500 / head | G9+ | Compliance pre-clearance |
| Public official — any value | GC **and** CCO | Dual approval |
| ExCo member claims | Reporting line per matrix; Group CEO claims require Independent Chair notification path per Travel/Handbook norms | Finance Operations review |

Financial authority for non-expense commitments remains per §7.1; expense claims use §7.2 thresholds above.

### 11.5 Payment Methods

Reimbursement posts through Accounts Payable using `PAY-ACH` (US default), `PAY-SEPA`, `PAY-FAST`/local rails, or payroll deduction offset where advances or personal card use must be recovered. Corporate card central bill settles to `PAY-CARD` programme settlement, not employee reimbursement.

---

## 12. Accounting Treatment

### 12.1 Books and Currencies

| Book | Entity Context |
|---|---|
| `BOOK-USGAAP-ANB` | Apex National Bank N.A. (USD functional) |
| `BOOK-IFRS-UK` | UK entities (GBP) |
| `BOOK-IFRS-EU` | EU entities (EUR) |
| `BOOK-CONS-GROUP` | Group consolidation |

Claims are entered in transaction currency (USD, GBP, EUR, INR, AED, SGD, HKD, JPY, AUD, CHF, CAD, BRL, MXN as applicable) and translated per ApexLedger FX tables.

### 12.2 Cost Centres (examples)

| Cost Centre | Description |
|---|---|
| `CC-FIN-100` | Controller |
| `CC-FIN-200` | Financial Operations |
| `CC-FIN-300` | FP&A |
| `CC-FIN-400` | Regulatory Reporting |
| `CC-RTL-100` | Retail Ops HQ |
| `CC-RTL-412` | Charlotte Uptown SIT-0412 |
| `CC-CBK-200` | CIB Coverage |
| `CC-ITO-100` | IT Ops |
| `CC-ISC-100` | Information Security |
| `CC-HRM-100` | Human Resources |
| `CC-CMP-100` / `CC-RSK-100` / `CC-TRY-100` / `CC-ADM-100` / `CC-PRC-100` / `CC-MKT-100` / `CC-LEG-100` / `CC-IAD-100` / `CC-CST-100` | Respective departments |

Claimants must charge the cost centre that benefits from the spend. Cross-charging requires Cost Centre Manager acknowledgement.

### 12.3 Tax Codes

| Code | Use |
|---|---|
| `TAX-US-SALES` / `TAX-US-USE` | US taxable purchases |
| `TAX-UK-VAT-STD` / `TAX-EU-VAT-STD` | Recoverable / irrecoverable VAT per Tax guidance |
| `TAX-IN-GST` | India GST |
| `TAX-EXEMPT` | Documented exempt supplies |

`EMP-600107` Miriam Rosenthal publishes entertainment deductibility guidance each tax year; claimants must not force `TAX-EXEMPT` to improve recovery.

### 12.4 Journal Illustration

Employee reimbursement approved claim:

- Debit `750100` / `750200` / relevant GL — cost centre as claimed  
- Credit employee reimbursement payable  
- Settlement: Debit payable / Credit cash via `PAY-ACH`  
- Journal reference pattern `JE-YYYYMM-######`

Corporate card: merchant charge accrues to card liability; employee allocates expense lines within 30 days; unallocated balances escalate under Card Policy.

---

## 13. Fraud Controls and Audit Requirements

### 13.1 Prohibited Behaviours (illustrative, non-exhaustive)

Duplicate claims; altered receipts; claiming personal expenditure; fictitious attendees; mileage inflation; split transactions; claiming per diem and actuals on the same trip; using another employee's card; coercing subordinates to host entertainment for the approver's benefit.

### 13.2 Monitoring (`EMP-600120`)

Continuous monitoring flags: duplicates; round-number patterns; weekend/holiday spend without itinerary; entertainment without attendees; MCC codes inconsistent with category; repeat missing-receipt declarations; claims from employees with prior exceptions; public-official keywords without GC/CCO clearance.

### 13.3 Audit Coverage

| Control | Frequency | Owner |
|---|---|---|
| Pre-payment review — claims > $5,000 | 100% | Expense Audit |
| Pre-payment risk-weighted sample ≤ $5,000 | Monthly sample | Expense Audit |
| Post-payment analytics | Continuous | Expense Audit + SOX |
| SOX `CTL-FIN-EXP-*` testing | Per `EMP-600110` plan | Internal Controls |
| Internal Audit thematic review | Per IAD plan | IAD |
| External audit sample | Year-end | External auditors |

Findings feed Operational Risk reporting. Suspected fraud is escalated to Employee Relations and, where appropriate, Financial Crime / Legal. Records retention: `RET-FIN-10Y`.

---

## 14. Procedures / Process Flow — `BP-FIN-EXP`

```
CLAIMANT                 APPROVER              EXPENSE AUDIT           AP / FINOPS
   │                        │                       │                      │
   ├─ Incur cost; capture   │                       │                      │
   │  receipt at source     │                       │                      │
   ├─ Create EXP-########## │                       │                      │
   │  code CC / GL / tax    │                       │                      │
   │  attach evidence ─────►│                       │                      │
   │                        ├─ Verify necessity,    │                      │
   │                        │  policy, attendees,   │                      │
   │                        │  budget ──────────────┤                      │
   │                        │                       ├─ Sample / 100% >$5k  │
   │                        │                       │  fraud analytics     │
   │◄─ Query / reject ──────┼───────────────────────┤                      │
   │                        ├─ Approve ─────────────┼─────────────────────►│
   │                        │                       │                      ├─ Reimburse /
   │                        │                       │                      │  clear card
   │◄─ Settlement ──────────┼───────────────────────┼──────────────────────┤
   │                        │                       ├─ Post-pay audit ─────►│
```

### 14.1 Step Detail

1. **Pre-approve** where required (international travel via `TRV-`; entertainment > $500/head via Compliance; public official via GC+CCO).
2. **Incur** and capture itemised evidence immediately.
3. **Submit** `EXP-##########` within 30 days in ApexLedger.
4. **Approve** within 10 business days at the correct grade.
5. **Audit** per §13.3 before payment release where thresholds apply.
6. **Post** to GL / cost centre / tax; settle via AP.
7. **Retain** claim pack under `RET-FIN-10Y`.

---

## 15. Decision Tables

### 15.1 Category Decision

| Situation | Category | Notes |
|---|---|---|
| Flight booked outside TMC in documented emergency | `EXP-CAT-TRAVEL` | Must reference `TRV-` and emergency rationale |
| Dinner with three clients at $140/head | `EXP-CAT-ENTERTAIN` | G6+; guest list |
| Dinner with regulator staff at $90/head | `EXP-CAT-ENTERTAIN` | **GC + CCO** before event |
| Same-day taxi to client site | `EXP-CAT-LOCAL-TRANS` | No `TRV-` if no overnight/air |
| CFA exam fee claimed personally | `EXP-CAT-TRAINING` | Align with Training Policy funding rules |
| $80 stapler set for branch | `EXP-CAT-SUPPLIES` | Prefer ApexSource for repeat supply |

### 15.2 Missing Receipt Decision

| Aggregate Missing | Items | Outcome |
|---|---|---|
| ≤ $250 and ≤ 3 lines | Declaration + manager countersignature | Payable if otherwise compliant |
| Exceeds either limit | Resubmit with evidence or obtain Department Head + FinOps exception | Else reject |
| Pattern of missing receipts (≥2 claims in 6 months) | Card and claim privilege review | `EMP-600104` + ER as needed |

---

## 16. Approval Tables

### 16.1 Operational Approvals

| Matter | Authority |
|---|---|
| Routine claim ≤ $1k | Line manager G4+ |
| Routine $1k–$10k | G6+ |
| Routine > $10k | G8+ and Finance review |
| Entertainment ≤ $500/head | G6+ |
| Entertainment > $500/head | G9+ and Compliance |
| Public official | GC and CCO |
| Late claim 61–90 days | Department Head G9+ |
| Late claim > 90 days | CFO delegate (`EMP-600102`) |
| Policy major version | CFO `EMP-100002` |
| Category limit change | Custodian + Head of Financial Operations; CFO if material |

### 16.2 Financial Authority Cross-Reference

Expenditure commitments (PO, contracts) use `ANB-ADM-MTX-0001` §7.1 by grade. Employee expense claims use §7.2. Capitalisable purchases use `ANB-FIN-POL-0006` and §7.3.

---

## 17. Examples

### 17.1 Client Entertainment — Within Threshold

`EMP-300301` Henry Bakshi (G6) hosts two CMB clients in Chicago. Total bill $420 ($140/head including himself). He submits `EXP-1002847731` under `EXP-CAT-ENTERTAIN`, GL `750200`, cost centre `CC-CBK-200`, tax `TAX-US-SALES`, with itemised receipt and guest names. His manager (G7+) approves. No Compliance pre-clearance required (≤ $500/head, no public official).

### 17.2 High-Value Entertainment — Compliance Path

`EMP-300103` Amara Okoye plans a hospitality event at $620/head for a prospect day. She obtains Compliance pre-clearance, records the Register entry, and secures G9 approval before the event. Claim `EXP-1002848802` attaches clearance reference. Posting: `750200` / `CC-CBK-200` / `BUD-FY26-CBK-OPEX`.

### 17.3 Public Official — Dual Clearance

`EMP-500103` Andrés Villalobos is asked to host a lunch with a municipal technology official while discussing a potential civic banking relationship. **Any value** requires General Counsel and CCO approval before acceptance. Until dual clearance is recorded in ApexServe, no booking and no claim is permitted.

### 17.4 Supplies Claim — Cost Centre Discipline

`EMP-600103` Sandeep Bhatt reviews a cluster of `EXP-CAT-SUPPLIES` claims against `CC-FIN-200` that should have used ApexSource catalogue. He redirects repeat purchases to `EMP-600402` Angela Duarte (Procurement Operations) and declines further out-of-channel supply claims above $200 without PRC exception.

### 17.5 Travel Settlement Alignment

`EMP-300301` returns from São Paulo trip `TRV-00218844` and submits `EXP-9928014471` within 30 days with itemised receipts; entertainment dinner $146/head with attendee list — consistent with Travel Policy §11 and this Policy §9–§10. Reviewed by Financial Operations before release.

### 17.6 Fraud Pattern Escalation

`EMP-600120` Joaquín Herrera identifies duplicate ride-share claims on consecutive days without matching `TRV-` or calendar evidence. Claim held; Employee Relations case opened under Code of Conduct. Card privileges under `CARD-PROG-TRAVEL` suspended pending outcome.

---

## 18. Review Cycle

| Trigger | Action | Owner |
|---|---|---|
| Annual review | Full policy re-approval | Custodian → CFO |
| Budget cycle | Category caps and per-head limits | `EMP-600104` with `EMP-600105` FP&A |
| Audit finding | Remediation within 30 days | `EMP-600102` |
| Regulatory / bribery law change | Interim amendment | Compliance + Legal + Custodian |
| System change (ApexLedger) | Configuration and procedure update | `EMP-600104` with ITO |

Next scheduled review: **2027-07-28**.

---

## 19. Related Documents

| Document ID | Title | Relationship |
|---|---|---|
| `ANB-ADM-REF-0001` | Company Profile | Grades, departments, systems, reserved identifiers |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | Controlled metadata |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `T5` classification |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `EXPN` naming; OCR receipts |
| `ANB-ADM-POL-0001` | Records Retention Policy | `RET-FIN-10Y` |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | §7.1 financial authority; §7.2 expense |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `BP-FIN-EXP` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | Audit / ORC reporting |
| `ANB-HRM-HBK-0001` | Employee Handbook | Conduct summary; exit clearance |
| `ANB-HRM-POL-0002` | Leave Policy | Personal days on trip extensions |
| `ANB-FIN-POL-0002` | Travel Policy | Travel rules; receipt/missing-receipt alignment |
| `ANB-HRM-POL-0003` | Remote Work Policy | Home-office cost boundary |
| `ANB-HRM-POL-0004` | Code of Conduct | Gifts, entertainment, anti-bribery, discipline |
| `ANB-HRM-POL-0006` | Performance Management Policy | Conduct/performance intersection |
| `ANB-HRM-SOP-0007` | Recruitment SOP | Candidate travel/expense boundary |
| `ANB-HRM-POL-0008` | Training and Certification Policy | Training expense interaction |
| `ANB-FIN-POL-0001` | Expense Policy (this document) | — |
| `ANB-FIN-BUD-0005` | Budget FY2026 | `BUD-FY26-*-OPEX` |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard | GL and cost centre structure |
| `ANB-FIN-SOP-0003` | Month-End Close Procedure | Expense accruals and cut-off |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy | Capital vs expense boundary |
| `ANB-FIN-POL-0007` | Corporate Card Policy | Card programmes and reconciliation |
| `ANB-FIN-SOP-0008` | Vendor Payment Procedure | PO invoice path (out of scope here) |
| `ANB-FIN-MTX-0009` | Finance Approval Authority Matrix | Finance AL levels |
| `ANB-PRC-POL-0001` | Procurement Policy | Preferred channel for vendor spend |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy | TMC and card issuer oversight |

---

## 20. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-08-01 | `EMP-600104` Rosa Delgado | Initial published policy; aligns with Travel Policy v1.0, Code of Conduct v1.0, and `ANB-ADM-MTX-0001` §7.2 |

---

## Appendix A — Expense Category → GL Mapping

| Expense Category | GL Account | GL Description | Default Tax Treatment |
|---|---|---|---|
| `EXP-CAT-TRAVEL` | `750100` | Travel | Jurisdiction-dependent; often `TAX-EXEMPT` fare / local VAT on hotel |
| `EXP-CAT-MEALS` | `750200` | Meals & Entertainment | Partial deductibility per Tax guidance |
$1750300` | Meals & Entertainment | Partial deductibility; Register linkage |
| `EXP-CAT-CLIENT-GIFT` | `750200` | Meals & Entertainment | Often non-deductible; Tax review |
| `EXP-CAT-PROF` | `740500` | Professional Memberships | Generally deductible operating expense |
| `EXP-CAT-SUPPLIES` | `720400` | Office Supplies | `TAX-US-SALES` / local VAT |
| `EXP-CAT-TRAINING` | `770100` | Training External | Per Training Policy |
| `EXP-CAT-LOCAL-TRANS` | `750100` | Travel | Mileage may be `TAX-EXEMPT` allowance |
| `EXP-CAT-TECH` | `730300` | Telecom / tech opex as coded | CapEx screen if ≥ $5,000 and >1 year life |
| `EXP-CAT-OTHER` | As directed by FinOps | — | Requires `EMP-600104` coding note |

**Capitalisation screen.** Any single item ≥ $5,000 USD (or local equivalent) with useful life > 1 year must be evaluated under `ANB-FIN-POL-0006` before expense posting. Furniture and equipment that should be capitalised must not be forced through `EXP-CAT-SUPPLIES`.

---

## Appendix B — SOX Control Reference (Summary)

| Control ID | Description | Evidence |
|---|---|---|
| `CTL-FIN-EXP-01` | No self-approval enforced in ApexLedger | System configuration extract |
| `CTL-FIN-EXP-02` | Threshold routing to G6 / G8 / Finance review | Workflow logs |
| `CTL-FIN-EXP-03` | Receipt mandatory ≥ $25 | Attachment completeness report |
| `CTL-FIN-EXP-04` | Entertainment guest data mandatory | Exception report |
| `CTL-FIN-EXP-05` | Public official dual approval | ApexServe clearance IDs |
| `CTL-FIN-EXP-06` | Pre-payment audit > $5,000 | Audit checklists signed by `EMP-600120` |
| `CTL-FIN-EXP-07` | Period expense accrual completeness | Close checklist `ANB-FIN-SOP-0003` |

---

## Appendix C — Quick Reference for Claimants

1. Is it necessary for Bank business? If not, do not claim.  
2. Prefer corporate card (`ANB-FIN-POL-0007`) where issued.  
3. Capture itemised receipts at the point of spend (≥ $25; all entertainment).  
4. Record guests immediately for any entertainment.  
5. Public official? Stop — obtain GC + CCO clearance first.  
6. Submit `EXP-##########` within 30 days.  
7. Code the correct `EXP-CAT-*`, cost centre, and tax code.  
8. Never split transactions. Never claim personal costs.  
9. Missing receipt: declaration path limited to three items / $250.  
10. Travel booking rules live in `ANB-FIN-POL-0002` — read them before you fly.

---

*End of Document — ANB-FIN-POL-0001 v1.0*
