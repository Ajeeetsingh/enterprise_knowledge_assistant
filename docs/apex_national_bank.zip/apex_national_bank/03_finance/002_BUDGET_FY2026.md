# Apex National Bank — Enterprise Budget FY2026

## Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-BUD-0005` |
| **Document Title** | Apex National Bank — Enterprise Budget FY2026 |
| **Version** | 1.0 |
| **Status** | Approved — In Force |
| **Classification** | `C2` Restricted — Sensitive Financial Plan Data |
| **Owner** | Finance Department (FIN) — Financial Planning & Analysis |
| **Document Owner (named)** | `EMP-600105` Anneke Visser, Head of Financial Planning & Analysis (G9) |
| **Approver** | `EMP-100002` Priya Raghunathan, Chief Financial Officer (G11) |
| **Ratification** | Executive Committee (2025-12-04); Board of Directors (2025-12-11) |
| **Author** | `EMP-600103` Sandeep Bhatt, Finance Manager — Corporate Centre Cost Control (G6) |
| **Effective Date** | 2026-01-01 |
| **Budget Period** | `AP-2026-01` through `AP-2026-12` (`FY-2026`) |
| **Next Review Date** | 2026-04-15 (Q1 reforecast `CQ-2026-Q1`) |
| **Review Cycle** | Quarterly reforecast; annual replacement |
| **Retention Code** | `RET-FIN-10Y` (10 years from fiscal year end) |
| **Taxonomy** | `T5` Finance & Treasury → `T5.3` Planning & Analysis → Budgeting → `BUD` |
| **Business Process** | `BP-FIN-PLAN` Budgeting & Forecasting |
| **Related Processes** | `BP-FIN-CLOSE`, `BP-FIN-EXP`, `BP-FIN-CAPEX`, `BP-FIN-AP`, `BP-FIN-COA`, `BP-AUD-SOX` |
| **System of Record** | ApexPlan (Oracle EPM Cloud); commitment control in ApexSource; actuals from ApexLedger |
| **Supporting Systems** | ApexInsight (management reporting), ApexVendor (vendor commitments), ApexRegRep (regulatory capital views), ApexDocs (document control), ApexServe (workflow) |
| **Publication Location** | ApexDocs → Finance → Planning & Analysis → Budgets (restricted) |
| **Distribution** | Board, ExCo, Department Heads (G9+), Cost Centre Managers (own CC extract only), Internal Audit, External Audit |
| **Language** | English (US) — authoritative version |
| **Supersedes** | `ANB-FIN-BUD-0005` FY2025 edition (archived under `RET-FIN-10Y`) |

> **Classification notice.** This document is `C2` Restricted. Aggregate plan figures are materially non-public information ahead of external reporting. Distribution outside the named list requires CFO written approval. Holders are bound by `ANB-HRM-POL-0005` Code of Conduct confidentiality duties and personal account dealing restrictions. Cost Centre Managers receive extracts limited to their own cost centres and budget codes.

---

## 1. Purpose

This document is the Board-approved financial plan for Apex National Bank and Apex Financial Group, Inc. for the fiscal year ending 31 December 2026. It sets revenue targets, operating expense envelopes, capital allocation, provision expectations, headcount limits, and the governance rules by which every department, business unit, cost centre, and capital project is managed.

The budget is a **control instrument**, not a forecast and not an aspiration. Every dollar of operating expense is committed against a budget code in ApexPlan, checked at commitment in ApexSource, posted to the Chart of Accounts under `ANB-FIN-STD-0004`, and reported at each close under `ANB-FIN-SOP-0003`. Expenditure without available budget is an exception requiring the approvals in §12 and `ANB-ADM-MTX-0001` §7.3 — not an administrative afterthought.

This document also establishes the canonical FY2026 budget entities: budget codes (`BUD-FY26-<DEPT>-OPEX` / `BUD-FY26-<DEPT>-CAPEX` / `BUD-FY26-GRP-CAPEX`), cost centre linkages, capital project identifiers (`CAP-2026-####`), and the variance thresholds that trigger escalation.

---

## 2. Scope

### 2.1 In Scope

| Area | Coverage |
|---|---|
| Revenue plan | Net interest income and noninterest income by business unit and profit centre |
| Operating expense plan | Noninterest operating expense by department, cost centre, and natural account range `700000`–`799999` |
| Capital expenditure plan | Capitalisable investment by project (`CAP-2026-####`); Group CapEx pool |
| Headcount plan | Permanent FTE and contingent worker envelope by department |
| Provision plan | Expected credit loss provision by portfolio (`800000`–`849999`) |
| Interest expense plan | Funding cost (`500000`–`599999`) managed with Treasury |
| Balance sheet plan | Loan and deposit growth, securities, funding mix |
| Capital plan | CET1 trajectory consistent with Capital Planning (`EMP-600111` Arun Balakrishnan) |
| Allocation plan | Enterprise pool allocation drivers and recipient charges |

### 2.2 Out of Scope

| Excluded | Governed By |
|---|---|
| Day-to-day expenditure authority limits | `ANB-FIN-MTX-0009`; `ANB-ADM-MTX-0001` §7.3 |
| Capitalisation criteria and asset accounting | `ANB-FIN-POL-0006` Capital Expenditure Policy |
| Individual compensation decisions | `ANB-HRM-POL-0006`; Compensation & Human Capital Committee |
| ICAAP methodology and stress-test design | Capital Planning & Stress Testing |
| Statutory reporting of actuals | `ANB-FIN-SOP-0003`; `ANB-FIN-STD-0004` |
| Vendor payment execution | `ANB-FIN-SOP-0008` |
| Expense claim rules | `ANB-FIN-POL-0001`; travel rules in `ANB-FIN-POL-0002` |

---

## 3. Objectives

| # | Objective | Metric | FY2026 Target |
|---|---|---|---|
| O1 | Modest top-line growth with positive operating leverage | Revenue vs FY2025 $58.2B | **$61.5B** (+5.7%) |
| O2 | Earnings delivery | Net income | **$13.1B** (FY2025: $12.6B) |
| O3 | Efficiency improvement | Efficiency ratio (opex ÷ total revenue) | **65.0%** (FY2025: ~65.7%) |
| O4 | Capital strength | Year-end CET1 | **12.6%–13.0%** (FY2025: 12.8%) |
| O5 | Technology & cyber investment protected | Tech total (opex+capex view) / Cyber | **$4.2B** / **$480M** |
| O6 | Expense discipline | Full-year opex vs plan | Within **±1.0%** |
| O7 | Budget accuracy | Absolute departmental variance at year end | ≤ 3% for ≥ 12 of 15 core departments |
| O8 | Capital delivery | CapEx deployed vs $2.8B plan | ≥ **92%** |

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Budget** | Board-approved financial plan for a fiscal year; locked after ratification; changed only through §12 |
| **Budget Code** | Canonical identifier for a budget envelope; format `BUD-FY26-<DEPT>-OPEX`, `BUD-FY26-<DEPT>-CAPEX`, or `BUD-FY26-GRP-CAPEX` |
| **Budget Owner** | Individual accountable for delivery within a budget code, normally the Cost Centre Manager |
| **Commitment** | Binding obligation to spend, recognised at purchase order issue in ApexSource / ApexVendor |
| **Available Budget** | Approved budget less actuals less commitments less accruals |
| **Reforecast** | Revised view of full-year outturn produced each quarter; the Board budget itself does not change without §12 amendment |
| **Variance** | Actual (or forecast) minus budget; favourable / unfavourable signed per FP&A convention |
| **Enterprise Pool** | Centrally held opex or CapEx redistributed by published allocation keys |
| **Profit Centre** | Revenue accountability unit (`PC-CRB-001`, `PC-CMB-001`, `PC-CIB-001`, `PC-WAM-001`, `PC-TM-001`) |
| **Cost Centre** | Expense accountability unit (`CC-<DEPT>-###`) per `ANB-FIN-STD-0004` |

---

## 5. Roles and Responsibilities

| Role | Named Holder | Responsibility |
|---|---|---|
| CFO | `EMP-100002` Priya Raghunathan | Approves this Budget; owns financial plan integrity; escalates Board amendments |
| Head of FP&A | `EMP-600105` Anneke Visser | Document Owner; owns ApexPlan load, variance framework, reforecast calendar |
| Group Financial Controller | `EMP-600101` Gemma Ashworth | Owns actuals integrity, period close linkage, CoA alignment |
| Head of Financial Operations | `EMP-600102` Marcel Delacroix | Commitment control operations; expense and AP budget checks |
| Finance Manager — Cost Control | `EMP-600103` Sandeep Bhatt | Corporate Centre pools; allocation methodology |
| Head of Regulatory Reporting | `EMP-600106` Farhan Siddiqui | Regulatory capital and Call Report / FINREP consistency of plan views |
| Head of Capital Planning | `EMP-600111` Arun Balakrishnan | CET1, RWA, and capital distribution capacity within plan |
| Head of Internal Controls & SOX | `EMP-600110` Teresa Villanueva | Budget-related SOX controls (`CTL-FIN-BUD-*`) |
| CIO | `EMP-100007` Arjun Patel | Technology opex/CapEx delivery within ITO envelopes |
| CISO | `EMP-100010` Nadia Ferreira | Cybersecurity investment ($480M) delivery and risk acceptance |
| CHRO | `EMP-100008` Yvonne Carter | FTE envelope, compensation pools, training ($95M) governance |
| Head of CRB | `EMP-100014` Gregory Lin | CRB revenue and RTL / branch CapEx accountability |
| Department Heads | G9+ per department | Own departmental opex and CapEx codes; first-line variance ownership |
| Cost Centre Managers | Per CC register | Day-to-day spend within available budget |
| Chief Audit Executive | `EMP-100009` Thomas Nakamura | Independent assurance over budget control design and operating effectiveness |

### 5.1 RACI — Budget Lifecycle

| Activity | R | A | C | I |
|---|---|---|---|---|
| Build departmental submissions | Dept FP&A / CC Managers | Dept Head | FP&A | CFO |
| Consolidate Group plan | FP&A | Head of FP&A | GFC, Capital Planning, Treasury | ExCo |
| Approve CapEx ≤ $5M | BU Head + CFO | CFO | CIO/CISO as relevant | FP&A |
| Approve CapEx $5–50M | ExCo | ExCo | CFO, Risk | Board (info) |
| Approve CapEx > $50M | Board | Board | ExCo, CFO | Capital Planning |
| Lock budget in ApexPlan | FP&A | Head of FP&A | Finance Systems | All Budget Owners |
| Monthly variance pack | FP&A | Head of FP&A | Dept Heads | ExCo |
| Quarterly reforecast | FP&A | CFO | ExCo | Board |
| Formal budget amendment | FP&A | CFO / ExCo / Board per threshold | GFC | Audit Committee (material) |

---

## 6. Macro and Financial Assumptions

### 6.1 Macroeconomic Assumptions (Planning Case)

| Assumption | FY2026 Planning Case | Sensitivity Note |
|---|---|---|
| US Fed funds (year-average) | 3.75%–4.00% | ±25 bps → ~$420M NII sensitivity |
| US 10-year Treasury (year-average) | 4.10% | Curve steepening benefits securities reinvestment |
| US unemployment (year-average) | 4.3% | Drives retail credit cost |
| US real GDP growth | 1.8% | Commercial loan demand |
| GBP/USD average | 1.27 | UK subsidiary translation |
| EUR/USD average | 1.09 | EU subsidiary translation |
| Equity markets (S&P 500 total return) | +6% | WAM fee sensitivity |

### 6.2 Volume and Balance Sheet Assumptions

| Item | FY2025 Actual | FY2026 Plan | Growth |
|---|---|---|---|
| Total assets | $1.34T | $1.41T | +5.2% |
| Deposits | $912B | $958B | +5.0% |
| Loans, net | $684B | $722B | +5.6% |
| Allowance for credit losses (BS `130100`) | Per FY2025 close | Build consistent with $4.5B PCL | — |
| CET1 ratio | 12.8% | 12.7%–12.9% path | Capital returned within appetite |
| Branches | 1,842 | 1,868 | +26 net (Southeast expansion) |
| Group FTE | 78,400 | 79,850 | +1.8% |

### 6.3 Credit Cost Assumptions

| Portfolio | FY2026 PCL ($M) | Notes |
|---|---|---|
| Consumer / card / retail | 2,450 | Soft landing; early delinquency stable |
| Residential mortgage | 380 | Low loss given default; HPI flat |
| Commercial & industrial | 980 | Selective CRE office stress retained |
| Markets / other | 690 | Incl. reserve model updates |
| **Total provision (IS `800000`–`849999`)** | **4,500** | Separately controlled from opex |

### 6.4 Rate, FX, and Funding Assumptions

Treasury (`CC-TRY-100`, `PC-TM-001`) owns the interest expense plan. Group interest expense is planned at **$19.2B** (`500000`–`599999`), producing net interest income of **$30.8B** when set against planned interest income of **$50.0B**. Noninterest (fee) income is planned at **$30.7B** (`600000`–`649999`), with other income / gains of **$0.0B** net at planning case (gains/losses held at zero for baseline; managed in reforecast). **Total revenue plan = $61.5B.**

FX translation impact on Group revenue is planned at **−$180M** versus constant-currency, held in Corporate Centre and not allocated to BU scorecards for incentive purposes.

---

## 7. Group Financial Plan Summary

### 7.1 Consolidated Income Statement Plan

| Line | FY2025 Actual ($B) | FY2026 Plan ($B) | Δ |
|---|---|---|---|
| Interest income (`400000`–`499999`) | 47.1 | 50.0 | +2.9 |
| Interest expense (`500000`–`599999`) | (18.4) | (19.2) | (0.8) |
| **Net interest income** | **28.7** | **30.8** | **+2.1** |
| Noninterest / fee income (`600000`–`649999`) | 29.5 | 30.7 | +1.2 |
| Other income / gains (`650000`–`699999`) | 0.0 | 0.0 | — |
| **Total revenue** | **58.2** | **61.5** | **+3.3** |
| Provision for credit losses (`800000`–`849999`) | (3.9) | (4.5) | (0.6) |
| Operating expenses (`700000`–`799999`) | (38.2) | (40.0) | (1.8) |
| **Income before tax** | **16.1** | **17.0** | **+0.9** |
| Tax expense (`850000`–`899999`) | (3.5) | (3.9) | (0.4) |
| **Net income** | **12.6** | **13.1** | **+0.5** |

### 7.2 Business Unit Revenue Plan

| Profit Centre | BU | FY2025 Revenue ($B) | FY2026 Plan ($B) | Growth |
|---|---|---|---|---|
| `PC-CRB-001` | Consumer & Retail Banking | 21.4 | 22.55 | +5.4% |
| `PC-CMB-001` | Commercial Banking | 9.8 | 10.35 | +5.6% |
| `PC-CIB-001` | Corporate & Investment Banking | 14.1 | 14.90 | +5.7% |
| `PC-WAM-001` | Wealth & Asset Management | 7.6 | 8.05 | +5.9% |
| `PC-TM-001` | Treasury & Markets | 5.3 | 5.65 | +6.6% |
| **Group** | | **58.2** | **61.50** | **+5.7%** |

### 7.3 Key Operating Ratios

| Ratio | FY2025 | FY2026 Plan |
|---|---|---|
| Efficiency ratio | 65.6% | 65.0% |
| Net interest margin (taxable-equivalent, mgmt) | 2.42% | 2.45% |
| PCL / average loans | 0.57% | 0.62% |
| ROTCE (plan) | 14.1% | 14.4% |
| Compensation ratio (personnel ÷ revenue) | 31.8% | 31.4% |

---

## 8. Operating Expense Plan by Department

Total Group operating expense plan: **$40.00B**. Personnel (`710000`–`719999`) is the largest component at **$19.30B**. Technology cash and run-cost view (opex in `730000`–`739999` plus technology CapEx) totals **$4.20B**. Cybersecurity investment (opex + CapEx attributed to cyber programme) is **$480M**. Enterprise training & development is **$95M** (`770000`–`779999` and HR delivery).

### 8.1 Department Opex Summary

| Dept | FTE Plan | Primary Cost Centres | Budget Code (Opex) | Opex Plan ($M) |
|---|---|---|---|---|
| RTL | 31,850 | `CC-RTL-100`, `CC-RTL-412` | `BUD-FY26-RTL-OPEX` | 11,850 |
| CST | 11,550 | `CC-CST-100` | `BUD-FY26-CST-OPEX` | 3,420 |
| ITO | 9,900 | `CC-ITO-100` | `BUD-FY26-ITO-OPEX` | 4,680 |
| CBK | 7,980 | `CC-CBK-200` | `BUD-FY26-CBK-OPEX` | 2,960 |
| RSK | 2,900 | `CC-RSK-100` | `BUD-FY26-RSK-OPEX` | 1,380 |
| FIN | 2,380 | `CC-FIN-100/200/300/400` | `BUD-FY26-FIN-OPEX` | 920 |
| CMP | 1,990 | `CC-CMP-100` | `BUD-FY26-CMP-OPEX` | 860 |
| HRM | 1,200 | `CC-HRM-100` | `BUD-FY26-HRM-OPEX` | 540 |
| ISC | 960 | `CC-ISC-100` | `BUD-FY26-ISC-OPEX` | 780 |
| ADM | 1,040 | `CC-ADM-100` | `BUD-FY26-ADM-OPEX` | 410 |
| IAD | 790 | `CC-IAD-100` | `BUD-FY26-IAD-OPEX` | 290 |
| LEG | 730 | `CC-LEG-100` | `BUD-FY26-LEG-OPEX` | 450 |
| TRY | 655 | `CC-TRY-100` | `BUD-FY26-TRY-OPEX` | 480 |
| MKT | 655 | `CC-MKT-100` | `BUD-FY26-MKT-OPEX` | 620 |
| PRC | 390 | `CC-PRC-100` | `BUD-FY26-PRC-OPEX` | 240 |
| WAM / CMB / Apex Securities (BU-aligned) | 4,480 | BU cost centres per register | `BUD-FY26-WAM-OPEX` / `BUD-FY26-CMB-OPEX` / `BUD-FY26-SEC-OPEX` | 3,120 |
| Enterprise Pools (Facilities, Deprec, FDIC/assessments, contingency) | — | `CC-ADM-100`, `CC-FIN-400` | `BUD-FY26-GRP-OPEX` (pool) | 7,000 |
| **Total** | **79,850** | | | **40,000** |

> Note: `BUD-FY26-GRP-OPEX` holds centrally governed pools before allocation. After monthly allocation journals (`900000`–`909999` memo / IC where required), departmental management reports show fully loaded cost. Statutory books retain natural account integrity per `ANB-FIN-STD-0004`.

### 8.2 Natural Account Composition (Group)

| GL Range | Description | FY2026 Plan ($M) |
|---|---|---|
| `710000`–`719999` | Personnel / payroll / benefits | 19,300 |
| `720000`–`729999` | Occupancy & facilities | 3,850 |
| `730000`–`739999` | Technology & telecom | 2,580 |
| `740000`–`749999` | Professional services | 1,720 |
| `750000`–`759999` | Travel, meals, entertainment (`750100` / `750200` / `750300`) | 290 |
| `760000`–`769999` | Marketing & communications | 980 |
| `770000`–`779999` | Training & development | 95 |
| `780000`–`789999` | Compliance, risk, audit, legal external | 1,485 |
| `790000`–`799999` | Other OpEx / depreciation / amortisation | 9,700 |
| **Total opex** | | **40,000** |

Depreciation and amortisation within `790100`–`790300` are planned at **$2.85B**. FDIC and regulatory assessments within `790000`–`799999` are planned at **$1.25B**. Remaining other OpEx covers card rewards accounting presentation where classified as expense, operational losses, and miscellaneous.

### 8.3 Department Detail Tables

#### 8.3.1 Retail Banking (RTL) — `BUD-FY26-RTL-OPEX` — $11,850M

| Category | GL | Plan ($M) | Notes |
|---|---|---|---|
| Personnel | `710000`–`719999` | 7,420 | Branch + product ops; FTE 31,850 |
| Occupancy | `720000`–`729999` | 1,980 | 1,842+ branches; utilities; leases |
| Technology (retail apps run) | `730000`–`739999` | 620 | Channel platforms (charge-in from ITO) |
| Professional services | `740000`–`749999` | 180 | Temporary branch support |
| Travel / meals / entertainment | `750100`–`750300` | 45 | District management |
| Marketing (retail campaigns) | `760000`–`769999` | 310 | Joint with MKT |
| Training | `770000`–`779999` | 28 | Branch certification |
| Compliance/risk ops support | `780000`–`789999` | 95 | Branch compliance officers |
| Other / deprec branch FF&E | `790000`–`799999` | 1,172 | Incl. `790100` |
| **Total** | | **11,850** | Primary CC: `CC-RTL-100`; Southeast expansion ops in `CC-RTL-412` |

#### 8.3.2 Customer Service (CST) — `BUD-FY26-CST-OPEX` — $3,420M

| Category | Plan ($M) |
|---|---|
| Personnel | 2,480 |
| Occupancy (contact centres) | 220 |
| Technology / telephony | 410 |
| Professional / BPO overflow | 95 |
| Travel / meals | 18 |
| Training | 22 |
| Other | 175 |
| **Total** | **3,420** |

#### 8.3.3 Information Technology (ITO) — `BUD-FY26-ITO-OPEX` — $4,680M

| Category | Plan ($M) | Notes |
|---|---|---|
| Personnel | 1,920 | Engineers, run teams, GSC Hyderabad/Mumbai |
| Technology vendors / cloud / telecom | 1,850 | Core of Group tech opex |
| Professional services | 420 | System integrators (opex-classified) |
| Occupancy (data halls share) | 180 | |
| Travel / training | 55 | |
| Other / deprec IT hardware | 255 | `790200` |
| **Total** | **4,680** | CapEx for tech projects under `BUD-FY26-ITO-CAPEX` / Group CapEx |

#### 8.3.4 Corporate Banking (CBK) — `BUD-FY26-CBK-OPEX` — $2,960M

Supports `PC-CMB-001` and `PC-CIB-001` coverage. Personnel $1,980M; occupancy $210M; technology $240M; professional $180M; travel/meals/entertainment `750100`–`750300` $95M (client coverage); marketing $40M; training $18M; compliance/risk ops $85M; other $112M.

#### 8.3.5 Risk (RSK) — `BUD-FY26-RSK-OPEX` — $1,380M

Personnel $920M; models & data technology $180M; professional (external model validation) $95M; travel $22M; training $15M; compliance/risk specialised `780000`–`789999` $90M; other $58M. Credit provision **is not** in this envelope.

#### 8.3.6 Finance (FIN) — `BUD-FY26-FIN-OPEX` — $920M

| Cost Centre | Mandate | Plan ($M) |
|---|---|---|
| `CC-FIN-100` | Financial Control / GFC (`EMP-600101`) | 280 |
| `CC-FIN-200` | FP&A (`EMP-600105`) | 210 |
| `CC-FIN-300` | Financial Operations / T&E / AP (`EMP-600102`) | 245 |
| `CC-FIN-400` | Regulatory Reporting, Capital, SOX, Tax (`EMP-600106`, `EMP-600111`, `EMP-600110`) | 185 |
| **Total** | | **920** |

Natural account mix: personnel $610M; technology (ApexLedger, ApexPlan, ApexInsight, ApexRegRep run-charge) $145M; professional (external audit fees opex portion, consultants) $85M; travel $18M; training $12M; other $50M.

#### 8.3.7 Compliance (CMP) — `BUD-FY26-CMP-OPEX` — $860M

Personnel $580M; surveillance technology $120M; professional / external reviews $70M; travel $15M; training $25M; specialised compliance `780000` $30M; other $20M.

#### 8.3.8 Human Resources (HRM) — `BUD-FY26-HRM-OPEX` — $540M

Personnel (HR staff) $320M; HRIS / ApexPeople run $85M; professional (search, advisors) $40M; travel $12M; **enterprise training delivery support** (programme management of $95M Group training) $35M within HRM plus charges to `770000` across departments; other $48M. Compensation pools for the Bank sit in departmental personnel lines, not in HRM opex.

#### 8.3.9 Information Security (ISC) — `BUD-FY26-ISC-OPEX` — $780M

Includes the opex portion of the **$480M cybersecurity investment** (remainder in CapEx `CAP-2026-0088`). Personnel $310M; security tooling & SOC $320M; professional (red team, advisory) $75M; training $18M; other $57M. Owned with CISO `EMP-100010` Nadia Ferreira; CIO alignment mandatory for platform spend.

#### 8.3.10 Other Departments (summary)

| Dept | Budget Code | Plan ($M) | Primary drivers |
|---|---|---|---|
| ADM | `BUD-FY26-ADM-OPEX` | 410 | Corporate real estate ops, EKMO, executive support |
| IAD | `BUD-FY26-IAD-OPEX` | 290 | Audit staff; co-source `780000` |
| LEG | `BUD-FY26-LEG-OPEX` | 450 | Counsel; external legal in `780000`–`789999` |
| TRY | `BUD-FY26-TRY-OPEX` | 480 | Treasury ops (interest expense **excluded**) |
| MKT | `BUD-FY26-MKT-OPEX` | 620 | Brand, digital, sponsorships `760000`–`769999` |
| PRC | `BUD-FY26-PRC-OPEX` | 240 | Procurement ops; savings targets tracked separately |
| WAM | `BUD-FY26-WAM-OPEX` | 1,420 | Advisor force; platform |
| CMB | `BUD-FY26-CMB-OPEX` | 980 | Middle-market coverage |
| SEC | `BUD-FY26-SEC-OPEX` | 720 | Apex Securities LLC |

#### 8.3.11 Enterprise Pools — $7,000M

| Pool | Plan ($M) | Allocation Basis |
|---|---|---|
| Group facilities & workplace | 2,200 | Occupied sq ft / FTE |
| Group depreciation & amortisation (`790100`–`790300`) | 2,850 | Asset ownership / project beneficiary |
| FDIC & regulatory assessments | 1,250 | Deposit base / RWA keys |
| Contingency & management reserve | 400 | CFO release only |
| Unallocated central / transition | 300 | Time-limited; ExCo visibility |
| **Total pools** | **7,000** | |

---

## 9. Capital Budget FY2026

**Total capital budget: $2.80B**, held under `BUD-FY26-GRP-CAPEX` with departmental CapEx sub-codes. Approval thresholds follow `ANB-ADM-MTX-0001` §7.3 and `ANB-FIN-POL-0006`:

| CapEx Amount | Approval |
|---|---|
| ≤ $5M | BU Head + CFO |
| $5M – $50M | ExCo |
| > $50M | Board |

### 9.1 Priority Capital Projects

| Project ID | Title | Plan ($M) | Sponsor | Approval Body | Opex Impact |
|---|---|---|---|---|---|
| `CAP-2026-0210` | Core banking upgrade | 920 | CIO `EMP-100007` | Board | Run-cost benefit from FY2027 |
| `CAP-2026-0088` | Cyber platform | 310 | CISO `EMP-100010` | Board | Part of $480M cyber programme |
| `CAP-2026-0099` | Data centre resilience | 285 | CIO | ExCo | Occupancy / power opex +$18M |
| `CAP-2026-0031` | Branch expansion Southeast | 420 | Head CRB `EMP-100014` | Board | RTL opex +$95M run-rate |
| `CAP-2026-0142` | Charlotte branch renovation | 95 | Head CRB | ExCo | Temporary dual-run occupancy |
| `CAP-2026-0155` | Payments modernisation | 210 | CIB / ITO | ExCo | |
| `CAP-2026-0178` | ApexRegRep enhancement | 85 | FIN Reg Reporting `EMP-600106` | ExCo | |
| `CAP-2026-0190` | Workplace & HQ optimisation | 140 | ADM / CHRO | ExCo | |
| `CAP-2026-0225` | ATM & self-service refresh | 125 | RTL | BU Head+CFO / ExCo (phased) | |
| `CAP-2026-0240` | Credit risk data platform | 110 | RSK | ExCo | |
| Other approved < $50M portfolio | Various | 100 | Various | Per matrix | |
| **Total** | | **2,800** | | | |

CIP and fixed asset postings use `150000`–`159999` / `160000`–`169999` per `ANB-FIN-STD-0004`. In-service assets depreciate to `790100`–`790300`.

### 9.2 Technology Investment Bridge ($4.2B)

| Component | ($M) |
|---|---|
| ITO technology opex (`730000`–`739999` and related) | 1,850 |
| ISC security tooling opex | 320 |
| Other departments' technology charges | 410 |
| Technology CapEx (share of $2.8B: core, cyber, DC, payments, data, RegRep) | 1,620 |
| **Total technology investment view** | **4,200** |

Cybersecurity programme total **$480M** = ISC cyber opex **$170M** + `CAP-2026-0088` **$310M**.

---

## 10. Headcount and Training Plan

| Dept | FY2025 FTE | FY2026 Plan FTE | Δ |
|---|---|---|---|
| RTL | 31,600 | 31,850 | +250 |
| CST | 11,400 | 11,550 | +150 |
| ITO | 9,700 | 9,900 | +200 |
| CBK | 7,900 | 7,980 | +80 |
| RSK | 2,850 | 2,900 | +50 |
| FIN | 2,340 | 2,380 | +40 |
| CMP | 1,960 | 1,990 | +30 |
| HRM | 1,180 | 1,200 | +20 |
| ISC | 910 | 960 | +50 |
| Other listed depts + WAM/CMB/SEC | 8,560 | 8,690 | +130 |
| **Group** | **78,400** | **79,850** | **+1,450** |

Contingent workers are capped at **8.5%** of departmental FTE unless CHRO and CFO jointly approve. Training investment **$95M** funds mandatory modules in `ANB-HRM-POL-0008` (including expense certification `E-11`), role-based compliance, cyber awareness, and leadership curricula. Training spend posts primarily to `770000`–`779999`.

---

## 11. Cost Centre Allocation Methodology

### 11.1 Principles

1. **Direct first.** Costs are booked to the consuming cost centre whenever the consuming activity is identifiable at source.
2. **Pools are explicit.** Enterprise pools in §8.3.11 are the only systematic reallocations.
3. **No circular allocations.** Maximum two-stage allocation (pool → department → optional product).
4. **Books preserved.** Allocations for management reporting may use `900000`–`909999` memorandum / IC accounts; US GAAP primary book `BOOK-USGAAP-ANB` retains natural account integrity.
5. **Profit centre alignment.** Revenue remains on `PC-*-001`; allocated opex does not create synthetic revenue.

### 11.2 Standard Drivers

| Pool | Driver | System |
|---|---|---|
| Facilities | Usable sq ft | ApexPlan allocation module |
| IT run | Service tickets + compute units + named application ownership | ApexInsight + CMDB |
| Cyber | Priority systems criticality × user count | ISC scoring |
| HR / training | Average FTE | ApexPeople |
| Compliance monitoring | Monitored population / alert volume | CMP metrics |
| FDIC/assessments | Period-average deposits / RWA | ApexRegRep |

Allocation journals are proposed by `EMP-600103` Sandeep Bhatt, approved by Head of FP&A, and posted under GFC standards before Soft Close of each `AP-2026-MM`.

---

## 12. Variance Analysis Framework

### 12.1 Thresholds

| Absolute variance vs YTD budget (opex or revenue, departmental) | Action |
|---|---|
| ≤ ±5% | Department Head explains in monthly pack; no escalation |
| > ±5% and ≤ ±10% | FP&A review + CFO notification; remediation plan within 10 business days |
| > ±10% | ExCo notification; formal remediation; potential budget freeze on discretionary lines (`750000`–`769999`, non-critical `740000`) |

Revenue shortfalls in profit centres use the same bands, with Head of BU accountable and CFO informed at the ±5% band.

### 12.2 CapEx Variance

| Condition | Action |
|---|---|
| Project forecast cost > approved +10% or +$5M | Re-approval at original approval tier or higher |
| Schedule slip > 90 days on Board-level project | ExCo status; Board paper if benefits year shifts |
| Underspend > 20% at Q3 with no reforecast redeploy | Funds returned to `BUD-FY26-GRP-CAPEX` contingency |

### 12.3 Commitment Control

ApexSource rejects purchase orders that would breach available budget unless an override is approved:

| Override | Approver |
|---|---|
| ≤ $250k and ≤ 2% of CC annual budget | Head of FP&A |
| Above that, within departmental envelope | CFO |
| Requires formal budget amendment | §12.4 |

### 12.4 Formal Budget Amendments

| Amendment type | Approver |
|---|---|
| Reallocation within a department, same natural account class, ≤ $10M | Department Head + Head of FP&A |
| Cross-department reallocation ≤ $25M | CFO |
| Change to Group opex or revenue plan totals | ExCo |
| Change > $100M to Group totals or any CET1-path impacting item | Board |

Amendments are versioned in ApexPlan and recorded in ApexDocs against this Document ID.

---

## 13. Budget Governance Calendar

| Window | Milestone | Owner |
|---|---|---|
| 2025-07 | Strategic guidance & planning assumptions issued | CFO / Head of FP&A |
| 2025-08–09 | Departmental submissions in ApexPlan | Dept Heads |
| 2025-10 | Challenge sessions; capital ranking | FP&A, CIO, CISO, Capital Planning |
| 2025-11 | ExCo draft review | ExCo |
| 2025-12-04 | ExCo ratification | ExCo |
| 2025-12-11 | Board approval | Board |
| 2026-01-01 | Budget live; ApexPlan locked | FP&A |
| Monthly M+6bd | Flash variance | FP&A |
| Monthly M+10bd | Full management pack | FP&A / GFC |
| 2026-04-15 | `CQ-2026-Q1` reforecast | CFO |
| 2026-07-15 | `CQ-2026-Q2` reforecast | CFO |
| 2026-10-15 | `CQ-2026-Q3` reforecast | CFO |
| 2026-11–12 | FY2027 budget cycle begins | FP&A |

Accounting periods `AP-2026-01` … `AP-2026-12` align to calendar months; consolidation period `FY-2026`. Hard Close discipline per `ANB-FIN-SOP-0003`.

---

## 14. Balance Sheet, Capital, and Liquidity Plan (Summary)

| Metric | FY2026 Plan |
|---|---|
| Period-end assets | $1.41T |
| Period-end deposits | $958B |
| Period-end loans, net of `130100` | $722B |
| CET1 | 12.6%–13.0% operating range |
| LCR (minimum management) | ≥ 120% |
| Dividend / buyback | Subject to Board capital plan; stress capacity confirmed by `EMP-600111` |

Intercompany balances eliminate in `BOOK-CONS-GROUP`. Local IFRS views use `BOOK-IFRS-UK` and `BOOK-IFRS-EU` with planning overlays only — legal entity statutory budgets are owned by local CFOs under Group totals.

---

## 15. Controls and Assurance

| Control ID | Description | Frequency | Owner |
|---|---|---|---|
| `CTL-FIN-BUD-01` | Board-approved budget loaded equals signed pack | Annual | Head of FP&A |
| `CTL-FIN-BUD-02` | Commitment control active on ApexSource | Continuous | Head of Fin Ops |
| `CTL-FIN-BUD-03` | Monthly variance pack issued by M+10bd | Monthly | Head of FP&A |
| `CTL-FIN-BUD-04` | Overrides logged and aged | Monthly | Cost Control |
| `CTL-FIN-BUD-05` | CapEx vs `CAP-2026-####` forecast reconciliation | Monthly | FP&A CapEx lead |
| `CTL-FIN-BUD-06` | Allocation keys approved and versioned | Quarterly | Cost Control |
| `CTL-FIN-BUD-07` | SOX: budget change authorisations complete | Quarterly | `EMP-600110` |

Internal Audit includes budget governance in the FY2026 audit plan. External audit uses this plan as the basis for analytical expectations but does not opine on the budget itself.

---

## 16. Related Documents

| Document ID | Title | Relationship |
|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | Canonical org, scale, systems, departments |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | Metadata fields |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy | Taxonomy path `T5.3` |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | ID and versioning |
| `ANB-ADM-POL-0001` | Records Retention Policy | `RET-FIN-10Y` |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | §7.3 budget & CapEx rules |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `BP-FIN-PLAN` |
| `ANB-ADM-STD-0002` | Document Retention Schedule | Retention schedule detail |
| `ANB-LEG-REF-0003` | (Legal reference as cited in governance set) | Legal hold / authority context |
| `ANB-HRM-HBK-0001` | Employee Handbook | Conduct and confidentiality |
| `ANB-HRM-POL-0002` | Leave Policy | Staffing / absence cost context |
| `ANB-FIN-POL-0002` | Travel Policy | Travel demand driving `750100` |
| `ANB-HRM-POL-0003` | Remote Work Policy | Facilities / occupancy assumptions |
| `ANB-HRM-POL-0004` | (HR policy cross-ref set) | Employment cost context |
| `ANB-HRM-POL-0005` | Code of Conduct | Confidentiality of C2 plan data |
| `ANB-HRM-POL-0006` | Performance Management Policy | Scorecards vs budget |
| `ANB-HRM-SOP-0007` | Recruitment SOP | FTE intake against envelope |
| `ANB-HRM-POL-0008` | Training and Certification Policy | $95M training plan |
| `ANB-FIN-POL-0001` | Expense Policy | Discretionary opex `750100`–`750300` |
| `ANB-FIN-BUD-0005` | This Budget | — |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard | Natural accounts, CC, PC, books, periods |
| `ANB-FIN-SOP-0003` | Financial Closing SOP | Actuals vs plan cadence |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy | CapEx capitalisation & approvals |
| `ANB-FIN-POL-0007` | Corporate Card Policy | Card spend within opex |
| `ANB-FIN-SOP-0008` | Vendor Payment Procedure | PO / invoice against budget |
| `ANB-FIN-MTX-0009` | Finance Approval Authority Matrix | Spend authority inside budget |

---

## 17. Appendix A — Cost Centre Register (Budget-Relevant)

| Cost Centre | Name | Dept | Budget Code Link | Budget Owner Role |
|---|---|---|---|---|
| `CC-FIN-100` | Financial Control | FIN | `BUD-FY26-FIN-OPEX` | GFC |
| `CC-FIN-200` | FP&A | FIN | `BUD-FY26-FIN-OPEX` | Head of FP&A |
| `CC-FIN-300` | Financial Operations | FIN | `BUD-FY26-FIN-OPEX` | Head of Fin Ops |
| `CC-FIN-400` | Reg Reporting / Capital / SOX / Tax | FIN | `BUD-FY26-FIN-OPEX` | Named heads |
| `CC-RTL-100` | Retail Network Operations | RTL | `BUD-FY26-RTL-OPEX` | Head of Retail Ops |
| `CC-RTL-412` | Southeast Expansion PMO | RTL | `BUD-FY26-RTL-OPEX` / CapEx `0031` | Expansion PMO |
| `CC-CBK-200` | Corporate & Commercial Coverage | CBK | `BUD-FY26-CBK-OPEX` | Head CBK Finance |
| `CC-ITO-100` | Technology Operations | ITO | `BUD-FY26-ITO-OPEX` | CIO delegate |
| `CC-ISC-100` | Information Security | ISC | `BUD-FY26-ISC-OPEX` | CISO delegate |
| `CC-HRM-100` | Human Resources | HRM | `BUD-FY26-HRM-OPEX` | CHRO delegate |
| `CC-CMP-100` | Compliance | CMP | `BUD-FY26-CMP-OPEX` | CCO delegate |
| `CC-RSK-100` | Risk Management | RSK | `BUD-FY26-RSK-OPEX` | CRO delegate |
| `CC-TRY-100` | Treasury | TRY | `BUD-FY26-TRY-OPEX` | Treasurer |
| `CC-ADM-100` | Administration | ADM | `BUD-FY26-ADM-OPEX` | Head of Admin |
| `CC-PRC-100` | Procurement | PRC | `BUD-FY26-PRC-OPEX` | Head of Procurement |
| `CC-MKT-100` | Marketing | MKT | `BUD-FY26-MKT-OPEX` | Head of Marketing |
| `CC-LEG-100` | Legal | LEG | `BUD-FY26-LEG-OPEX` | General Counsel delegate |
| `CC-IAD-100` | Internal Audit | IAD | `BUD-FY26-IAD-OPEX` | CAE |
| `CC-CST-100` | Customer Service | CST | `BUD-FY26-CST-OPEX` | Head of CST |

Profit centres: `PC-CRB-001`, `PC-CMB-001`, `PC-CIB-001`, `PC-WAM-001`, `PC-TM-001`.

---

## 18. Appendix B — Budget Code Register

| Budget Code | Type | Envelope ($M) | Owner |
|---|---|---|---|
| `BUD-FY26-RTL-OPEX` | Opex | 11,850 | RTL |
| `BUD-FY26-CST-OPEX` | Opex | 3,420 | CST |
| `BUD-FY26-ITO-OPEX` | Opex | 4,680 | ITO |
| `BUD-FY26-CBK-OPEX` | Opex | 2,960 | CBK |
| `BUD-FY26-RSK-OPEX` | Opex | 1,380 | RSK |
| `BUD-FY26-FIN-OPEX` | Opex | 920 | FIN |
| `BUD-FY26-CMP-OPEX` | Opex | 860 | CMP |
| `BUD-FY26-HRM-OPEX` | Opex | 540 | HRM |
| `BUD-FY26-ISC-OPEX` | Opex | 780 | ISC |
| `BUD-FY26-ADM-OPEX` | Opex | 410 | ADM |
| `BUD-FY26-IAD-OPEX` | Opex | 290 | IAD |
| `BUD-FY26-LEG-OPEX` | Opex | 450 | LEG |
| `BUD-FY26-TRY-OPEX` | Opex | 480 | TRY |
| `BUD-FY26-MKT-OPEX` | Opex | 620 | MKT |
| `BUD-FY26-PRC-OPEX` | Opex | 240 | PRC |
| `BUD-FY26-WAM-OPEX` | Opex | 1,420 | WAM |
| `BUD-FY26-CMB-OPEX` | Opex | 980 | CMB |
| `BUD-FY26-SEC-OPEX` | Opex | 720 | Apex Securities |
| `BUD-FY26-GRP-OPEX` | Opex pools | 7,000 | FP&A / CFO |
| `BUD-FY26-RTL-CAPEX` | CapEx | 640 | RTL (branches/ATM share) |
| `BUD-FY26-ITO-CAPEX` | CapEx | 1,320 | ITO |
| `BUD-FY26-ISC-CAPEX` | CapEx | 310 | ISC (`CAP-2026-0088`) |
| `BUD-FY26-FIN-CAPEX` | CapEx | 85 | FIN RegRep |
| `BUD-FY26-ADM-CAPEX` | CapEx | 140 | ADM workplace |
| `BUD-FY26-GRP-CAPEX` | CapEx master | 2,800 | CFO / FP&A (includes above) |

Departmental CapEx codes are subsets of `BUD-FY26-GRP-CAPEX` for commitment control; they must not double-count in consolidated CapEx reporting.

---

## 19. Appendix C — Capital Project Register

| Project ID | Title | CapEx ($M) | Budget Code | Status at Approval |
|---|---|---|---|---|
| `CAP-2026-0210` | Core banking upgrade | 920 | `BUD-FY26-ITO-CAPEX` | Board approved |
| `CAP-2026-0088` | Cyber platform | 310 | `BUD-FY26-ISC-CAPEX` | Board approved |
| `CAP-2026-0099` | Data centre resilience | 285 | `BUD-FY26-ITO-CAPEX` | ExCo approved |
| `CAP-2026-0031` | Branch expansion Southeast | 420 | `BUD-FY26-RTL-CAPEX` | Board approved |
| `CAP-2026-0142` | Charlotte branch renovation | 95 | `BUD-FY26-RTL-CAPEX` | ExCo approved |
| `CAP-2026-0155` | Payments modernisation | 210 | `BUD-FY26-ITO-CAPEX` | ExCo approved |
| `CAP-2026-0178` | ApexRegRep enhancement | 85 | `BUD-FY26-FIN-CAPEX` | ExCo approved |
| `CAP-2026-0190` | Workplace & HQ optimisation | 140 | `BUD-FY26-ADM-CAPEX` | ExCo approved |
| `CAP-2026-0225` | ATM & self-service refresh | 125 | `BUD-FY26-RTL-CAPEX` | Phased |
| `CAP-2026-0240` | Credit risk data platform | 110 | `BUD-FY26-ITO-CAPEX` / RSK sponsor | ExCo approved |
| Portfolio < $50M | Various | 100 | `BUD-FY26-GRP-CAPEX` | Per matrix |
| **Total** | | **2,800** | | |

---

## 20. Document Control

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2025-12-11 | `EMP-600103` Sandeep Bhatt | Board-approved FY2026 Enterprise Budget |

**Approval signatures (recorded in ApexDocs workflow):** Head of FP&A `EMP-600105` Anneke Visser; CFO `EMP-100002` Priya Raghunathan; ExCo ratification 2025-12-04; Board approval 2025-12-11.

— End of Document `ANB-FIN-BUD-0005` —
