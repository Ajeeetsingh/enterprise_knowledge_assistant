# Apex National Bank — Finance Approval Authority Matrix

**Finance Matrix | Domain Operationalisation of Enterprise Financial Authority**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-MTX-0009` |
| **Document Title** | Apex National Bank — Finance Approval Authority Matrix |
| **Version** | 1.0 |
| **Status** | Approved — In Force |
| **Classification** | Confidential (`C1`) Internal — authority-sensitive |
| **Owner** | Finance Department (FIN) |
| **Document Owner (named)** | `EMP-600102` Marcel Delacroix, Head of Financial Operations (G8) |
| **Custodian** | `EMP-600114` Rahul Bhattacharya, Head of Finance Systems (G7) — system limit configuration |
| **Approver** | `EMP-100002` Priya Raghunathan, Chief Financial Officer (G11) |
| **Secondary Approvers** | `EMP-600101` Gemma Ashworth, Group Financial Controller (G9); `EMP-100013` Ian McAllister, CPO (G10) — procurement-finance rows |
| **Author** | `EMP-600101` Gemma Ashworth, Group Financial Controller (G9) |
| **Created Date** | 2026-06-12 |
| **Effective Date** | 2026-08-01 |
| **Last Review Date** | 2026-07-25 |
| **Next Review Date** | 2027-07-25 |
| **Review Cycle** | Annual; interim update within 5 business days of any change to `ANB-ADM-MTX-0001` financial sections |
| **Retention Code** | `RET-FIN-10Y` (operating copies); authority instruments cross-filed with governance retention as applicable |
| **Taxonomy** | `T5` Finance & Treasury → `T5.1` Financial Control → Delegated Authority → `MTX` |
| **Business Process** | Cross-cutting: `BP-FIN-EXP`, `BP-FIN-AP`, `BP-FIN-PAY`, `BP-FIN-CARD`, `BP-FIN-CAP`, `BP-FIN-JRNL`, `BP-FIN-CLOSE`, `BP-FIN-PLAN`, `BP-FIN-COA`, `BP-AUD-SOX` |
| **System of Record** | ApexServe (delegations); ApexLedger / Expense / AP workflows (routed limits); ApexDocs (this matrix); ApexPlan (budget change); ApexPay / ApexTreasury (payment release) |
| **Publication Location** | ApexDocs → Finance → Financial Control → Matrices |
| **Parent Instrument** | `ANB-ADM-MTX-0001` Approval Authority Matrix — **this document operationalises and must not contradict** §§7.1–7.3 and §9 |
| **Language** | English (US) — authoritative version |
| **Supersedes** | Fragmented FinOps desk authority cards retired 2026-07-31 |
| **Keywords** | approval matrix, RACI, expense, vendor payment, capex, journal entry, treasury transfer, write-off, corporate card, accrual, FX reval, intercompany |

> **Hierarchy.** `ANB-ADM-MTX-0001` is the enterprise parent. This Finance Matrix provides decision tables, process-level approvers, and system routing detail for Finance-owned processes. If any cell herein would authorise a higher limit or weaker control than the parent, the parent prevails and this Matrix is corrected within five business days. Credit charge-offs and credit authority remain exclusively in `ANB-ADM-MTX-0001` §8 — they are not re-delegated here.

---

## 2. Purpose

The enterprise Approval Authority Matrix states *who may commit the Bank, up to what amount*. Finance still needs a domain instrument that tells AP, Controllership, FP&A, Treasury Operations, and Expense Ops exactly how those limits apply to journals, accruals, payment batches, capex capitalisation, budget changes, card limit increases, and non-credit write-offs.

This Matrix exists to:

1. **Operationalise** `ANB-ADM-MTX-0001` §7.1 (expenditure), §7.2 (expense), §7.3 (budget/capex), and §9 (vendor) for Finance execution teams.
2. Provide **decision tables** that systems (ApexLedger, ApexPay, Expense) can encode without local improvisation.
3. Enforce **segregation of duties** and four-eyes across high-risk finance actions.
4. Give Internal Audit and SOX testing a **single Finance-domain expected control**.
5. Clarify **what Finance does not own** (credit charge-offs, Board-reserved matters).

---

## 3. Scope

### 3.1 In Scope

Expense approvals; vendor payments; capital expenditure finance approvals; budget changes; journal entries; manual adjustments; operational treasury transfers; non-credit operational write-offs and small asset write-offs; procurement-finance approvals; emergency spending; corporate card limit increases; accrual journals; FX revaluation overlays; intercompany settlements and elimination approval bands; related RACI.

### 3.2 Out of Scope

| Excluded | Authority Home |
|---|---|
| Credit approval, forbearance, **credit charge-offs** | `ANB-ADM-MTX-0001` §8 |
| Board-reserved capital raising, dividends, M&A | Board charter |
| HR compensation actions | CHRO / Compensation Committee |
| Risk acceptance outside finance process waivers | `ANB-ADM-MTX-0001` §10 |
| Legal settlement authority above finance execution | General Counsel rows in enterprise matrix |

### 3.3 Applicability

All employees initiating or approving Finance transactions for Group entities on ApexLedger books including `BOOK-USGAAP-ANB` and consolidation `BOOK-CONS-GROUP`. Subsidiary boards may set lower limits only.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O1 | Zero contradictions with parent matrix | Quarterly consistency check by GFC vs `ANB-ADM-MTX-0001` |
| O2 | System limits = published limits | Finance Systems attestation each release |
| O3 | No threshold splitting | Conduct cases referenced to R-8 parent rule |
| O4 | Traceable approvals | 100% of in-scope actions in Apex* workflow or ApexServe |
| O5 | SOX testability | Each matrix row maps to a control ID where key |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Parent Matrix** | `ANB-ADM-MTX-0001` |
| **Single-Transaction Limit** | Maximum amount an individual grade may approve for a commitment or payment event (§7.1 parent) |
| **AL / Approval Level** | Finance routing level used in Expense and AP workflows (defined §8) |
| **Operational Treasury Transfer** | Movement of Group cash between owned accounts for liquidity/funding — not customer payment |
| **Non-Credit Write-Off** | Removal of a non-loan asset or receivable (e.g. aged AP debit balance, small FA disposal loss) — **not** a credit charge-off |
| **Emergency Spending** | Commitment or payment required to prevent material customer, regulatory, or safety harm under time pressure |
| **Manual Adjustment** | Non-standard GL journal outside automated subledger feed |
| **Delegation** | Time-bounded ApexServe instrument; may not exceed delegator authority; no sub-delegation |

Universal parent rules **R-1 through R-12** in `ANB-ADM-MTX-0001` §4 apply unchanged.

---

## 6. Roles and Responsibilities

| Role | Named Holder | Matrix Role |
|---|---|---|
| CFO (G11) | `EMP-100002` Priya Raghunathan | Approver of this Matrix; ≥ $50M journals; post-issuance unlock; top escalations |
| GFC (G9) | `EMP-600101` Gemma Ashworth | Controllership authority; journals $10M–$50M; close unlock; write-off bands |
| Head of FinOps (G8) | `EMP-600102` Marcel Delacroix | Document Owner; payment and expense operations authority |
| FP&A Lead | `EMP-600105` Anneke Visser | Budget change recommendations / concurrence |
| Reg Reporting | `EMP-600106` Farhan Siddiqui | Informed on authority changes affecting reporting attestations |
| Tax | `EMP-600107` Miriam Rosenthal | Tax journal / WHT authority concurrence |
| Product Control | `EMP-600108` Pieter Janssen | FX reval overlays / valuation adjustments |
| Accounting Policy | `EMP-600109` Rosalind Mbeki | Technical accounting approval for judgemental entries |
| SOX | `EMP-600110` Teresa Villanueva | Control mapping and test reliance |
| Head of AP | `EMP-600112` Colin Devereaux | Vendor payment batch authority within bands |
| AR Lead | `EMP-600113` Noriko Hayashi | AR adjustments / small credit memos within bands |
| Finance Systems | `EMP-600114` Rahul Bhattacharya | Custodian of system-encoded limits |
| Payroll Accounting | `EMP-600115` Bethany Clarke | Payroll accrual journals within bands |
| AP Analyst / Expense Audit | `EMP-600119` / `EMP-600120` | Prepare / detect; not sole approvers of own work |
| Close Manager / Recon Lead / AP Payments | `EMP-600122` / `EMP-600123` / `EMP-600124` | Process execution under this Matrix |
| Treasury Ops | `EMP-600501` Nikolai Petrov | Dual release operational transfers and wires |
| CPO / PRC Ops / Category | `EMP-100013` / `EMP-600402` / `EMP-600401` | Vendor and procurement finance interface |
| CAE | `EMP-100009` Thomas Nakamura | Assurance |

### 6.1 Master RACI — Authority Framework

| Activity | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Maintain this Matrix | FinOps + GFC | CFO | CPO, Treasury, SOX, Legal | All Finance; EKMO |
| Encode limits in systems | Finance Systems | Head of FinOps | GFC | Internal Audit |
| Grant personal delegation | Delegator via ApexServe | Delegator | HR (acting roles) | Process owners |
| Exception above Matrix | Per escalation row | CFO or parent matrix role | GFC, Legal | Audit Committee if persistent |
| Quarterly consistency check | GFC | CFO | ADM/EKMO | ExCo note if drift found |

---

## 7. Policy and Control Statements

**M1 — Parent supremacy.** No Finance approval may exceed `ANB-ADM-MTX-0001` §§7.1–7.3 or §9.

**M2 — Grade sufficiency.** Approver grade must meet or exceed the cell requirement.

**M3 — Four-eyes.** Originator ≠ sole approver for commitments, payments, journals, write-offs, transfers.

**M4 — Evidence.** ApexLedger / Expense / ApexPay / ApexServe only; email only in declared BCP with reconciliation in five business days (parent R-3).

**M5 — Aggregation.** Linked POs, invoices, journals, and card transactions that are one economic event are aggregated (parent R-9).

**M6 — No splitting.** (Parent R-8; Code of Conduct `ANB-HRM-POL-0004`.)

**M7 — Credit wall.** Credit charge-offs never approved under this Matrix.

**M8 — System parity.** Production workflow limits must match published tables; temporary loosenings require CFO.

**M9 — Close interaction.** Journal and unlock authorities align with `ANB-FIN-SOP-0003`.

**M10 — Retention.** Approval artefacts `RET-FIN-10Y`; SOX `RET-AUD-7Y`.

---

## 8. Finance Approval Levels (AL) — Expense Routing

These AL codes operationalise parent §7.2 without raising limits.

| AL | Meaning | Typical Approver |
|---|---|---|
| `AL-1` | Routine ≤ $1,000 | Line manager G4+ |
| `AL-2` | $1,000 – $10,000 | G6+ |
| `AL-3` | > $10,000 routine | G8+ with Finance review |
| `AL-4` | Travel domestic / standard | Line manager G5+ per Travel Policy |
| `AL-5` | Travel international | G7+ |
| `AL-6` | High-risk destination / public official / policy exception | G9+ and mandated consultees per parent §7.2 |
| `AL-7` | ExCo member expenses | Joint rules with CEO / CFO per Expense Policy |

Entertainment and gifts follow parent §7.2 dollar and Compliance pre-clearance rules exactly.

---

## 9. Matrix — Expense Approvals (`BP-FIN-EXP`, `BP-FIN-CARD`)

| Expense Type | Threshold | Approver | Additional |
|---|---|---|---|
| Routine business expense | ≤ $1,000 | Line manager G4+ | Receipt ≥ $25 |
| Routine business expense | $1,000 – $10,000 | G6+ | Itemised receipts; purpose |
| Routine business expense | > $10,000 | G8+ | Finance review (FinOps) |
| Travel — domestic | Any | Line manager G5+ | `ANB-FIN-POL-0002` channel |
| Travel — international | Any | G7+ | Compliance for high-risk destinations |
| Travel — high-risk | Any | G9+ **and** Physical Security | Briefing mandatory |
| Client entertainment | ≤ $500 / head | G6+ | Guest names; ABAC check |
| Client entertainment | > $500 / head | G9+ | Compliance pre-clearance |
| Gifts > $250 | — | Compliance + G7+ | G&E Register |
| Public official spend | Any | GC **and** CCO | No exceptions |
| Out-of-policy exception | Any | One level above normal + FinOps | Logged |
| Corporate card limit increase ≤ 20% temporary ≤ 90 days | — | Card programme manager + line G6+ | `ANB-FIN-POL-0007` |
| Corporate card limit increase > 20% or permanent | — | Head of FinOps | Risk score review |
| Corporate card limit increase for G8+ | — | GFC or CFO (for ExCo) | — |

**GL reminder:** Travel `750100`, Meals `750200`, Entertainment `750300` per CoA / Expense Policy mapping.

### 9.1 Example — Expense

Employee submits $12,400 client workshop claim. Routes to G8 approver (`AL-3`) with FinOps review. Guest list complete; Compliance clears. Posted after approval.

---

## 10. Matrix — Vendor Payments (`BP-FIN-AP`, `BP-FIN-PAY`)

Commitment authority follows parent §7.1 grade limits and §9 vendor onboarding. Payment **release** authorities below are operational and cannot exceed the underlying approved commitment.

| Decision | Threshold / Condition | Approver | Consultees |
|---|---|---|---|
| Onboard vendor < $50k non-critical | Per parent §9.1 | Category Manager G6 | — |
| Onboard $50k–$250k | Per parent | Head of Category G7 | Legal if non-standard |
| Onboard $250k–$1M | Per parent | Head of PRC Ops G8 (`EMP-600402`) | Legal, ISC |
| Onboard > $1M | Per parent | CPO | Legal, Risk, ISC, Finance |
| Tier 1 any value | Per parent | CPO **and** CRO | Full diligence |
| Sole-source > $250k | Per parent | CPO **and** CFO | IA informed |
| Approve PO / commitment | By grade §7.1 | Grade-sufficient officer | PRC > $1M; FIN+LEG > $10M |
| Approve matched PO invoice for payment schedule | Within matched PO | AP automated + batch approver | — |
| Approve Non-PO invoice | By amount §7.1 | Cost centre grade + AP validation | Tax |
| ACH/SEPA batch release | Batch total ≤ $25M | Head of AP or `EMP-600124` within delegated ≤ $5M | Treasury funding |
| ACH/SEPA batch release | > $25M | Head of FinOps | Treasury |
| Wire / SWIFT single payment | ≤ $1M | Head of AP + Treasury dual release | Sanctions Clear |
| Wire / SWIFT | $1M – $10M | Head of FinOps + Treasury dual | GFC notified |
| Wire / SWIFT | > $10M | GFC + Treasury dual | CFO notified |
| Wire / SWIFT | > $50M | CFO + Treasury dual | — |
| Urgent payment | See `ANB-FIN-SOP-0008` §16 | Head of AP / FinOps / GFC bands | Beneficiary confirmed |
| Duplicate override | Any | Head of AP or FinOps | SOX-visible |
| Vendor bank detail release | Any | Two AP officers | Independent confirmation |

### 10.1 Example — Vendor Payment

`INV-9928471103` for `VND-10028441` against `PO-778201`, $450,000. Match pass. Included in ACH batch approved by Colin Devereaux. Underlying PO approved previously by grade-sufficient sponsor under §7.1.

---

## 11. Matrix — Capital Expenditure (`BP-FIN-CAP`)

Parent §7.3 capital project thresholds apply to **project approval**. Finance capitalisation and payment steps:

| Decision | Threshold | Approver |
|---|---|---|
| Capital project business case | ≤ $5M | BU Head G10 with CFO concurrence |
| Capital project | $5M – $50M | ExCo |
| Capital project | > $50M | Board |
| Create `CAP-YYYY-####` master / budget in ApexPlan/FA | Within approved project | FP&A + FA accountant |
| Capitalise to `15xxxx` | Any | FA accountant + controller review; > $1M G6+ |
| Capex invoice payment | Per vendor payment matrix | AP + commitment authority already obtained |
| Scope increase ≤ 10% of approved project | — | Original project approver level |
| Scope increase > 10% | — | Escalate one level (parent logic) |
| Impair / abandon CIP | ≤ $500k | GFC |
| Impair / abandon CIP | > $500k | CFO |

---

## 12. Matrix — Budget Changes (`BP-FIN-PLAN`, ApexPlan)

Aligned to parent §7.3:

| Action | Threshold | Approver | Finance Concurrence |
|---|---|---|---|
| Operate within approved plan | — | Department Head G9–G11 | FP&A monitoring |
| Departmental budget increase | ≤ 5% | Department Head | Finance (FP&A) concurrence mandatory |
| Departmental budget increase | 5–15% | ExCo member **and** CFO | FP&A pack |
| Departmental budget increase | > 15% | ExCo | CFO |
| BU annual plan | Any | ExCo; Board ratify | CFO |
| Unbudgeted commitment | > $1M | CFO **and** relevant ExCo member | — |
| Cost reallocation between BUs | Any | CFO | FP&A |
| Forecast reforecast submission | Cycle | FP&A Lead (`EMP-600105`) quality; BU Head owns numbers | GFC for controllable P&L flash |

---

## 13. Matrix — Journal Entries and Manual Adjustments (`BP-FIN-JRNL`)

Operational detail supporting `ANB-FIN-SOP-0003` §10 — identical thresholds:

| Absolute Value (USD eq.) | Min Preparer | Min Approver | Extra |
|---|---|---|---|
| < $100,000 | G3+ | G4+ | Standard evidence |
| $100,000 – < $1M | G4+ | G6+ | Analytics |
| $1M – < $10M | G5+ | G8+ | GFC dashboard notify |
| $10M – < $50M | G6+ | G9 GFC | Memo |
| ≥ $50M | G7+ | CFO | GFC countersign; Disclosure Committee informed if capital/P&L significant |
| Prior-period error correction | Any | One level above normal; GFC if prior period | Accounting Policy |
| Period 13 audit adjustment | ≥ $10M | GFC + CFO | External audit alignment logged |

### 13.1 Accrual Journals

Same money thresholds. Methodological “plug to budget” forbidden. Vendor accruals tie to `PO-` / receipt evidence where available.

### 13.2 FX Revaluation

| Type | Approver |
|---|---|
| System FX reval run | Automated; Product Control / Treasury monitor |
| Manual FX overlay < $1M | Product Control G6+ or Controllership G6+ |
| Manual FX overlay $1M – $10M | Head of Product Control or GFC |
| Manual FX overlay > $10M | GFC; CFO if > $50M |

### 13.3 Intercompany

| Decision | Approver |
|---|---|
| Book IC invoice / settlement < $1M | Entity controllers both sides |
| IC settlement $1M – $10M | Controllers + FinOps |
| IC settlement > $10M | GFC |
| Elimination journal in `BOOK-CONS-GROUP` > $10M | GFC |
| IC imbalance acceptance above $1,000 at certify | GFC (must clear before external filing) |

### 13.4 Example — Journal

`JE-202608-004821` $482,600 cloud accrual — preparer G4, approver G6 — within < $1M band.

---

## 14. Matrix — Operational Treasury Transfers

Customer payments and trading settlements follow Treasury market procedures. **Operational** funding transfers between Group-owned accounts:

| Transfer Amount | Approver | Execution |
|---|---|---|
| ≤ $10M | Treasury Ops Lead G6 + second Treasury officer | ApexTreasury dual release |
| $10M – $50M | Head of FinOps or Treasurer delegate G8+ + dual release | Same |
| $50M – $250M | GFC or Group Treasurer + dual release | CFO informed |
| > $250M | CFO + dual release | ExCo notified if non-routine |

Sanctions/payment screening still applies when rails touch external banks.

---

## 15. Matrix — Write-Offs (Non-Credit)

**Not in scope:** loan/credit charge-offs (parent §8.3).

| Item | Threshold | Approver |
|---|---|---|
| Aged AP debit / vendor balance write-off | ≤ $25,000 | Head of AP |
| Aged AP debit | $25,000 – $100,000 | Head of FinOps |
| Aged AP debit | > $100,000 | GFC; > $1M CFO |
| Small fixed asset net book value disposal loss | ≤ $50,000 | FA controller G5+ |
| FA disposal loss | $50,000 – $500,000 | GFC |
| FA disposal loss | > $500,000 | CFO |
| Inventory / supply write-down (non-credit) | ≤ $100,000 | FinOps G8 |
| Inventory / supply write-down | > $100,000 | GFC / CFO bands as AP debit |
| Operational receivable (non-loan) e.g. employee debt | ≤ $10,000 | FinOps; HR informed |
| Operational receivable | > $10,000 | GFC; Legal if dispute |

All write-offs require evidence memo, GL accounts, and tax consideration (`EMP-600107` consulted when deductible characterisation uncertain).

---

## 16. Matrix — Procurement Finance Approvals

| Decision | Finance Role | Notes |
|---|---|---|
| Confirm budget availability | FP&A / cost centre controller | Before PO approve |
| Finance sign-off contracts > $10M | GFC or CFO per parent | With Legal |
| Accrue / capitalise correctly | Controllership | `7xxxxx` vs `15xxxx` |
| Early payment discount strategy | Head of AP + Treasury | Working capital |
| Vendor statement reconcile differences > $100k | Head of AP + Recon Lead | Escalate FinOps |

Procurement tiering and onboarding approvals remain CPO-led under parent §9.

---

## 17. Matrix — Emergency Spending

| Condition | Max without ExCo | Approver | After-Action |
|---|---|---|---|
| SEV1 operational continuity / critical vendor | ≤ $1M | Head of FinOps **and** on-call ExCo member notify within 24h | File in ApexServe 2 business days |
| SEV1 | $1M – $10M | CFO | Same |
| SEV1 | > $10M | CFO **and** Group CEO | Board notify if > $50M |
| Payment execution under emergency | Per wire/ACH rows | Still dual release + sanctions | Regularise invoice/PO within 10 business days |

Emergency does **not** waive beneficiary confirmation or sanctions Clear.

---

## 18. Matrix — Corporate Card Limit Increases (`BP-FIN-CARD`)

| Request | Approver |
|---|---|
| Temporary ≤ 20%, ≤ 90 days, cardholder ≤ G6 | Line G6+ and card programme manager |
| Temporary ≤ 20%, cardholder G7–G8 | Head of FinOps |
| Permanent increase any % | Head of FinOps; GFC for G9+ |
| Increase after policy breach / misuse flag | Denied until FinOps + ER clearance |
| ExCo card limit change | CFO |

---

## 19. Process Flows

### 19.1 Authority Application Flow

```
Identify transaction type
    → Select matrix section (§9–§18)
        → Aggregate related amounts (R-9)
            → Check parent grade cap (§7.1)
                → Route workflow in Apex*
                    → Four-eyes approval captured
                        → Execute (pay / post / transfer)
                            → Evidence retained RET-FIN-10Y
```

### 19.2 Conflict / Escalation Flow

```
Approver conflict or limit dispute
    → Escalate to Head of FinOps
        → GFC interpretation
            → CFO binding decision
                → Amend Matrix if rule gap (within 5 days if parent impacted)
```

---

## 20. Decision Tables

### 20.1 Which Matrix Applies?

| Question | If Yes |
|---|---|
| Is it a loan/credit loss charge-off? | Use parent §8 only — stop |
| Is it employee reimbursement/card? | §9 Expense |
| Is it vendor invoice/PO pay? | §10 Vendor |
| Is it project asset spend? | §11 Capex (+ §10 to pay) |
| Is it budget/forecast authority? | §12 |
| Is it GL journal/accrual/FX/IC? | §13 |
| Is it Group cash account transfer? | §14 |
| Is it non-loan balance removal? | §15 |
| Is it SEV1 spend? | §17 then execute via §10/§14 |

### 20.2 Journal vs Payment

| Action | Authority Lens |
|---|---|
| Recognize expense/accrual | Journal matrix §13 |
| Disburse cash to vendor | Payment matrix §10 (commitment already §7.1) |
| Both in one business event | Satisfy **both** |

### 20.3 Soft Close Impact

| Request after soft close | Allowed? |
|---|---|
| Normal AP invoice in closed period | No — next period or accrual path |
| Close journal on approved list | Yes per `ANB-FIN-SOP-0003` |
| Unlock request | GFC / CFO per close SOP |

---

## 21. Approval Tables — Consolidated Quick Reference

| Domain | $0–100k | $100k–1M | $1M–10M | $10M–50M | ≥ $50M |
|---|---|---|---|---|---|
| Journals | G4 review | G6 | G8 | GFC | CFO |
| Wires (release) | AP+Treasury | FinOps+Treasury | FinOps+Treasury | GFC+Treasury | CFO+Treasury |
| Non-credit write-off (AP) | Head AP / FinOps | FinOps / GFC | GFC | CFO | CFO |
| Op. treasury transfer | Tsy dual | Tsy dual | FinOps+dual | GFC+dual | CFO+dual |
| Expense (routine) | Mgr→G6 bands per §9 | — | G8+ Fin review for >$10k expense claims | Rare — escalate | CFO/ExCo path |

*Grade caps on commitments always overlay payment cells (parent §7.1).*

---

## 22. Examples

### 22.1 Budget Change

CMB requests 4% opex uplift mid-year. Department Head approves with Anneke Visser FP&A concurrence — within ≤5% parent rule. Encoded in ApexPlan.

### 22.2 Emergency Wire

Data-centre generator rental $275,000 same-day under SEV1 power event. Head of FinOps approves urgent path; Treasury dual-releases `PAY-WIRE`; sanctions Clear; PO regularised day+2 as `PO-778455`; invoice later matched.

### 22.3 Rejected Credit Write-Off Attempt

Commercial banker asks FinOps to “write off” $2M loan via operational write-off matrix. **Rejected.** Routed to credit charge-off process under parent §8.3.

### 22.4 Card Limit

G5 relationship manager requests 15% temporary limit increase for client roadshow — line G6 + card programme manager approve 60-day temporary increase under §18.

### 22.5 Intercompany Elimination

Elimination $18M in `BOOK-CONS-GROUP` requires GFC approval under §13.3; posted as `JE-202608-006200` class consolidation entry during T+6 close.

---

## 23. SOX Mapping (Illustrative Key Controls)

| Control | Matrix Anchor |
|---|---|
| `CTL-FIN-EXP-APPR` | §9 |
| `CTL-FIN-AP-04` batch approval | §10 |
| `CTL-FIN-CLOSE-02` journal thresholds | §13 |
| `CTL-FIN-PAY-WIRE` dual release | §10 / §14 |
| `CTL-FIN-WO-01` write-off memo | §15 |

Testing evidence retained `RET-AUD-7Y` in ApexAudit.

---

## 24. Related Documents

### 24.1 Foundation and Governance

| ID | Title |
|---|---|
| Company Profile | Foundation profile |
| `ANB-ADM-REF-0001` | Master Company Profile / Enterprise Reference |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy |
| `ANB-ADM-STD-0007` | Document Naming and Versioning |
| `ANB-ADM-POL-0001` | Records Retention Policy |
| `ANB-ADM-MTX-0001` | **Parent** Approval Authority Matrix |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide |
| `ANB-LEG-REF-0003` | Legal reference index |

### 24.2 Finance Siblings

| ID | Title |
|---|---|
| `ANB-FIN-POL-0001` | Expense Policy |
| `ANB-FIN-POL-0002` | Travel Policy |
| `ANB-FIN-BUD-0005` | Budget FY2026 |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard |
| `ANB-FIN-SOP-0003` | Financial Closing SOP |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy |
| `ANB-FIN-POL-0007` | Corporate Card Policy |
| `ANB-FIN-SOP-0008` | Vendor Payment Procedure |
| `ANB-FIN-MTX-0009` | This Matrix |

### 24.3 HR Set

| ID | Title |
|---|---|
| `ANB-HRM-HBK-0001` | Employee Handbook |
| `ANB-HRM-POL-0002` | Leave Policy |
| `ANB-HRM-POL-0003` | Remote Work Policy |
| `ANB-HRM-POL-0004` | Code of Conduct |
| `ANB-HRM-POL-0006` | Performance Management Policy |
| `ANB-HRM-POL-0008` | Training and Certification Policy |
| `ANB-HRM-SOP-0007` | Recruitment SOP |
| `ANB-FIN-POL-0002` | Travel Policy |

---

## 25. Review Cycle

| Trigger | Action |
|---|---|
| Annual | Full review; CFO re-approval |
| Parent matrix change | Conform within 5 business days |
| Material audit finding on authority | Interim update |
| System release affecting workflows | Finance Systems + FinOps verification |

Next review: **2027-07-25**.

---

## 26. Revision History

| Version | Date | Author | Approver | Summary |
|---|---|---|---|---|
| 0.1 | 2026-06-12 | GFC | — | Draft operationalisation of parent §§7 and 9 |
| 0.9 | 2026-07-20 | GFC / FinOps | CFO review | Added treasury, write-off, emergency, card rows |
| 1.0 | 2026-08-01 | `EMP-600101` Gemma Ashworth | `EMP-100002` Priya Raghunathan | Initial in-force publication |

---

## Appendix A — Parent Crosswalk

| Parent Section | This Matrix |
|---|---|
| §7.1 Expenditure limits | Overlay on §§10–12, 16–17 |
| §7.2 Expense | §9 |
| §7.3 Budget / capex | §§11–12 |
| §9 Vendor | §10 onboarding rows |
| §8 Credit | Explicitly excluded |
| §4 Universal rules | Adopted wholly as M-series |

---

## Appendix B — Delegation Template Fields (ApexServe)

Delegator EMP ID; Delegate EMP ID; scope (process codes); amount cap; start/end; prohibition on sub-delegation; SOX notification flag; system workflow ID updates.

---

## Appendix C — Grade Reference (Finance-Relevant)

| Grade | Parent single-tx limit |
|---|---|
| G4 | $25,000 |
| G5 | $100,000 |
| G6 | $500,000 |
| G7 | $2,000,000 |
| G8 | $10,000,000 |
| G9 | $25,000,000 |
| G10 | $100,000,000 |
| G11 | $250,000,000 |
| Board | Above $250,000,000 |

Finance process cells may set **stricter** (never looser) operational release rules.

---

## Appendix D — Entity Identifiers Used in Examples

| ID | Meaning |
|---|---|
| `JE-202608-004821` | Accrual journal |
| `INV-9928471103` | Vendor invoice |
| `PO-778201` / `PO-778455` | Purchase orders |
| `VND-10028441` | Vendor |
| `CAP-2026-0142` | Capital project |
| `PAY-ACH` / `PAY-WIRE` / `PAY-SWIFT` / `PAY-SEPA` | Rails |
| `BOOK-USGAAP-ANB` / `BOOK-CONS-GROUP` | Ledgers |
| `CC-*` | Cost centres |
| `TAX-*` | Tax codes |
| `AP-2026-MM` | Periods |

---

## Appendix E — Contacts for Interpretation

| Topic | Contact |
|---|---|
| Matrix interpretation | `EMP-600101` Gemma Ashworth |
| FinOps / payments / expense | `EMP-600102` Marcel Delacroix |
| System limits | `EMP-600114` Rahul Bhattacharya |
| Journals / close | `EMP-600122` James Okonkwo |
| Vendor pay | `EMP-600112` / `EMP-600124` |
| Procurement interface | `EMP-100013` / `EMP-600402` |
| Binding escalation | `EMP-100002` Priya Raghunathan |

---

## Appendix F — Worked Decision Paths

### F.1 Path — Non-PO Professional Services Invoice

1. Confirm category `VCAT-PROF` and that Non-PO is permitted for the engagement type.  
2. Validate vendor `VND-########` Active – Payable with beneficiary confirmation current.  
3. Apply parent §7.1 grade limit to the invoice amount for cost-centre approval.  
4. AP validates tax `TAX-*`, duplicate check, and sanctions status.  
5. Schedule on `PAY-ACH` unless wire exception justified under §10.  
6. If amount > $1,000,000, confirm PRC sourcing sign-off already exists (parent rule).  

### F.2 Path — Capex Asset Plus Vendor Pay

1. Confirm project `CAP-YYYY-####` approved under §11 / parent §7.3.  
2. PO raised in ApexSource; receiving and capitalisation coding to `15xxxx` reviewed by FA.  
3. Invoice matched per `ANB-FIN-SOP-0008`; payment release per §10.  
4. Placed-in-service triggers depreciation via `790100` in the next close under `ANB-FIN-SOP-0003`.  

### F.3 Path — Accrual Then True-Up

1. At T+2 close, preparer posts accrual `JE-YYYYMM-######` under §13 thresholds.  
2. Following month, invoice arrives; accrual reverses; invoice posts to `23xxxx`.  
3. Difference true-up follows the same journal thresholds on the net adjustment absolute value.  

### F.4 Path — Suspected Limit Split

If AP or Expense Audit (`EMP-600120`) detects two invoices or claims that are economically one event structured to remain under a grade threshold, payment/claim is held, FinOps investigates, and Employee Relations is engaged under `ANB-HRM-POL-0004`. Approval after aggregation must meet the correct cell.

---

## Appendix G — RACI Detail by Domain

### G.1 Expense

| Activity | R | A | C | I |
|---|---|---|---|---|
| Submit claim | Claimant | Claimant | — | Manager |
| Approve claim | Approver per §9 | Approver | FinOps (AL-3+) | Cost centre |
| Card limit change | Card programme | Head of FinOps | Line manager | SOX |

### G.2 Vendor Pay

| Activity | R | A | C | I |
|---|---|---|---|---|
| Onboard vendor | PRC Ops | CPO (tiered) | Legal/ISC/Risk | AP |
| Match invoice | AP Analyst | Head of AP | Requestor | — |
| Release payment | AP Payments / Treasury | Head of AP or FinOps per §10 | GFC (large wires) | Vendor |

### G.3 Journals / Close

| Activity | R | A | C | I |
|---|---|---|---|---|
| Prepare JE | Accountant | Entity controller | Policy/Tax | Close Manager |
| Approve JE | Reviewer per §13 | Approver | GFC (≥$10M) | SOX |
| Unlock period | Finance Systems | GFC / CFO | Close Manager | Disclosure secretary |

### G.4 Budget / Capex

| Activity | R | A | C | I |
|---|---|---|---|---|
| Budget increase request | Department finance | Approver per §12 | FP&A | GFC |
| Capex case | Project sponsor | BU Head / ExCo / Board | CFO concurrence bands | FA / PRC |

---

## Appendix H — System Encoding Checklist

Before any production release that touches approval routing, Finance Systems (`EMP-600114`) confirms:

1. Expense AL mapping matches §8–§9.  
2. Journal workflow thresholds match §13 and `ANB-FIN-SOP-0003`.  
3. ApexPay wire dual-release mandatory flags match §10 / §14.  
4. Delegation instruments in ApexServe cannot exceed encoded caps.  
5. Credit charge-off transaction types are **not** routed to FinOps write-off workflows.  
6. SOX reports can extract approver grade and amount for `CTL-FIN-*` testing.  

Sign-off stored in ApexDocs under change record; retained `RET-FIN-10Y`.

---

## Appendix I — Prohibited Patterns

| Pattern | Why Prohibited |
|---|---|
| Approving your own journal, claim, or payment | Breaches M3 / parent R-1 |
| Using operational write-off for loan losses | Breaches credit wall M7 |
| Paying Inactive or unverified beneficiary | Breaches `ANB-FIN-SOP-0008` |
| Email-only approval outside BCP | Breaches parent R-3 |
| Permanent “acting” without ApexServe dates | Breaches parent R-2 / R-7 |
| Raising serial POs under $1M to avoid PRC sign-off | Breaches parent R-8 / R-9 |

---

**End of Document — `ANB-FIN-MTX-0009` v1.0**

*This Matrix is a controlled document. Printed or locally saved copies are uncontrolled. The authoritative version resides in ApexDocs. Where this Matrix and `ANB-ADM-MTX-0001` diverge, the enterprise parent governs.*
