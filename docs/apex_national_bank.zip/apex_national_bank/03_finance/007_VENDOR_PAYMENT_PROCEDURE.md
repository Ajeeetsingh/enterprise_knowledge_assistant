# Apex National Bank — Vendor Payment Procedure

**Finance SOP | Procure-to-Pay Execution and Vendor Disbursements**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-SOP-0008` |
| **Document Title** | Apex National Bank — Vendor Payment Procedure |
| **Version** | 1.0 |
| **Status** | Approved — In Force |
| **Classification** | Internal (`C1`) |
| **Owner** | Finance Department (FIN) — Accounts Payable, jointly with Procurement (PRC) for onboarding and sourcing controls |
| **Document Owner (named)** | `EMP-600112` Colin Devereaux, Head of Accounts Payable (G7) |
| **Custodian** | `EMP-600112` Colin Devereaux, Head of Accounts Payable (G7) |
| **Approver** | `EMP-600102` Marcel Delacroix, Head of Financial Operations (G8); escalation ratification `EMP-600101` Gemma Ashworth, Group Financial Controller (G9) for control-design changes |
| **Secondary Approvers** | `EMP-100013` Ian McAllister, Chief Procurement Officer (G10) — vendor master and category policy interface; `EMP-600501` Nikolai Petrov, Treasury Operations — payment rail execution |
| **Author** | `EMP-600124` Chen Wei, AP Payments Manager (G5) |
| **Created Date** | 2026-06-08 |
| **Effective Date** | 2026-08-01 |
| **Last Review Date** | 2026-07-22 |
| **Next Review Date** | 2027-07-22 |
| **Review Cycle** | Annual |
| **Retention Code** | `RET-FIN-10Y` (invoice and payment records); tax invoices / reclaim support also `RET-TAX-10Y` where applicable |
| **Taxonomy** | `T5` Finance & Treasury → `T5.6` Expense & Procure-to-Pay Control → Vendor Payment → `SOP` |
| **Business Process** | `BP-FIN-AP` Accounts Payable; `BP-FIN-PAY` Payment Execution |
| **Related Processes** | `BP-FIN-EXP`, `BP-FIN-CARD`, `BP-FIN-CLOSE`, `BP-FIN-JRNL`, `BP-FIN-CAP`, `BP-AUD-SOX`, `BP-RECN-DAILY`, `BP-RECN-SUSP` |
| **System of Record** | ApexVendor (vendor master); ApexSource (requisition/PO/receipt); ApexLedger (AP invoice, match, accounting); ApexPay (payment instruction); ApexTreasury (funding, wire release); ApexServe (exceptions, sanctions caseing); ApexDocs (evidence) |
| **Publication Location** | ApexDocs → Finance → Financial Operations → Procedures |
| **Applies To** | All vendor disbursements for Apex Financial Group entities using the unified AP operating model |
| **Governing Body** | Financial Operations leadership; Third-Party / Procurement governance for onboarding |
| **Language** | English (US) — authoritative version |
| **Supersedes** | Informal AP desk procedures consolidated at v1.0 |
| **Keywords** | vendor payment, three-way match, invoice, ACH, wire, SEPA, SWIFT, sanctions, beneficiary confirmation, duplicate detection |

> **Standing.** This is an operating procedure for *how* the Bank pays vendors. Expenditure authority remains `ANB-ADM-MTX-0001` §7.1 and §9; Finance-domain operationalisation is `ANB-FIN-MTX-0009`. No payment may be released outside this procedure except under the documented emergency path in §16 with dual approval.

---

## 2. Purpose

Vendor payments are one of the highest-volume channels through which Group cash leaves controlled bank accounts. Fraud patterns — false invoices, bank-detail takeover, duplicate submissions, and purchase-order circumvention — concentrate here. Regulatory expectations for sanctions screening, tax documentation, and third-party risk attach to the same flow.

This procedure exists to:

1. Ensure every vendor paid is **onboarded, screened, and active** in ApexVendor with validated bank details.
2. Require **invoice validation** and, where applicable, **three-way matching** (PO–receipt–invoice) before payment scheduling.
3. Operate **controlled payment runs** (ACH, wire, SEPA, SWIFT) with Treasury interaction through ApexPay and ApexTreasury.
4. Enforce **tax validation**, **duplicate detection**, and **beneficiary confirmation** before first payment and on bank-detail change.
5. Manage **exceptions and urgent payments** without creating a parallel uncontrolled channel.
6. Maintain **SOX-relevant evidence** for AP and payment controls (`BP-AUD-SOX`).
7. Protect the close: AP cut-off and accruals align to `ANB-FIN-SOP-0003`.

---

## 3. Scope

### 3.1 In Scope

| Area | Coverage |
|---|---|
| Vendor master lifecycle (AP-relevant) | Onboarding hand-off from PRC, bank detail verification, status changes, hold/release |
| Invoice types | `INV-TYPE-PO`, `INV-TYPE-NONPO`, `INV-TYPE-UTILITY`, `INV-TYPE-LEASE`, `INV-TYPE-CREDITMEMO`, `INV-TYPE-INTERCO` |
| Matching | Two-way and three-way match; tolerances; GR/IR |
| Payment methods | `PAY-ACH`, `PAY-WIRE`, `PAY-SWIFT`, `PAY-SEPA` |
| Payment runs | Twice-weekly ACH; daily wires by exception; SEPA for EU entities |
| Controls | Sanctions interlock, duplicate check, tax codes `TAX-*`, segregation of duties |
| Categories | `VCAT-TECH`, `VCAT-FACILITIES`, `VCAT-PROF`, `VCAT-MKT`, `VCAT-HR`, `VCAT-FIN`, `VCAT-LEGAL`, `VCAT-DATA`, `VCAT-CLOUD`, `VCAT-BRANCH` |

### 3.2 Out of Scope

| Excluded | Governed By |
|---|---|
| Employee expense reimbursement and corporate card | `ANB-FIN-POL-0001`, `ANB-FIN-POL-0007`, `ANB-FIN-POL-0002` |
| Payroll and benefit remittances to employees | HRM / Payroll; ApexPeople |
| Customer remittances and refunds | Operations / Complaints playbooks |
| Credit charge-offs | `ANB-ADM-MTX-0001` §8 |
| Sourcing strategy and RFP methodology | PRC policies; CPO |
| Capital project approval (business case) | `ANB-FIN-POL-0006`; payment of approved capex vendors remains in scope |

### 3.3 Entities and Books

Invoices post to `BOOK-USGAAP-ANB` (or local books mapped to the unified CoA). AP control accounts use `23xxxx`. Capitalisable invoices hit `15xxxx` when asset criteria under `ANB-FIN-POL-0006` are met. Expense invoices use `7xxxxx` OpEx as coded on the PO or invoice.

---

## 4. Objectives

| # | Objective | Measure | Target |
|---|---|---|---|
| O1 | No payment to unapproved vendor | Payments to vendors not Active in ApexVendor | 0 |
| O2 | Match discipline | PO invoices paid without required match | 0 |
| O3 | Duplicate prevention | Duplicate invoices paid | 0 |
| O4 | Bank detail integrity | Payments to unverified beneficiary accounts | 0 |
| O5 | Cycle time | Median receipt-to-post for clean PO invoices | ≤ 3 business days |
| O6 | Discount capture | Early-pay discounts captured when ROI-positive | ≥ 90% of available |
| O7 | Sanctions | Payments released without clearing screen | 0 |
| O8 | Urgent payment hygiene | Urgent payments as % of volume | ≤ 5% |
| O9 | Close readiness | AP cut-off achieved per close calendar | 100% of periods |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Vendor** | Third party registered in ApexVendor with identifier `VND-########` |
| **Purchase Order** | Commitment document `PO-########` in ApexSource |
| **Invoice** | Supplier demand for payment `INV-##########` in ApexLedger AP |
| **Three-Way Match** | Comparison of PO, goods/services receipt, and invoice within tolerances |
| **Two-Way Match** | Comparison of PO and invoice (services where receipt is service entry/acceptance) |
| **Non-PO Invoice** | Invoice without PO; permitted only for approved categories with alternate controls |
| **Payment Batch** | Group of scheduled payment proposals released together |
| **Beneficiary Confirmation** | Independent verification that bank details belong to the vendor (call-back / secure channel) |
| **Sanctions Interlock** | Hard stop preventing payment instruction release until screening clears in ApexServe / financial crime systems |
| **GR/IR** | Goods Receipt / Invoice Receipt clearing account |
| **Tolerance** | Permitted mismatch: quantity **0%**; price **±2% or $100**, whichever is greater for absolute price difference testing as configured in §11 |
| **Urgent Payment** | Out-of-cycle payment approved under §16 |
| **Credit Memo** | `INV-TYPE-CREDITMEMO` reducing amounts owed |
| **Interco Invoice** | `INV-TYPE-INTERCO` between Group entities; settled per intercompany policy, still validated |

---

## 6. Roles and Responsibilities

| Role | Named Holder | Responsibility |
|---|---|---|
| Head of Accounts Payable (G7) | `EMP-600112` Colin Devereaux | Document Owner/Custodian; AP operating model; holds and releases |
| AP Payments Manager (G5) | `EMP-600124` Chen Wei | Payment run execution, bank file quality, urgent payment desk |
| AP Analyst (G4) | `EMP-600119` Divya Nair | Invoice intake, validation, match exceptions first line |
| Expense Audit Officer (G4) | `EMP-600120` Joaquín Herrera | Overlap review where vendor pay intersects expense abuse patterns |
| Head of Financial Operations (G8) | `EMP-600102` Marcel Delacroix | Approver of this SOP; FinOps escalation |
| Group Financial Controller (G9) | `EMP-600101` Gemma Ashworth | Accounting treatment, close cut-off, material write-offs interface |
| Chief Procurement Officer (G10) | `EMP-100013` Ian McAllister | Vendor onboarding policy ownership with PRC |
| Head of Procurement Operations (G8) | `EMP-600402` Angela Duarte | Onboarding execution, vendor status, category operations |
| Head of Category Management (G8) | `EMP-600401` Ethan Brookfield | Category strategy `VCAT-*`; sole-source justification quality |
| Treasury Operations Lead (G6) | `EMP-600501` Nikolai Petrov | ApexTreasury funding, wire release dual control |
| Head of Tax (G8) | `EMP-600107` Miriam Rosenthal | Tax code validity, withholding, reclaim documentation |
| Head of Internal Controls & SOX (G8) | `EMP-600110` Teresa Villanueva | AP/payment control inventory and testing |
| Head of Finance Systems (G7) | `EMP-600114` Rahul Bhattacharya | ApexLedger/ApexPay configuration, match engine |
| Reconciliation Lead (G4) | `EMP-600123` Fatima Al-Hassan | GR/IR and payment clearing reconciliations |
| Close Manager (G5) | `EMP-600122` James Okonkwo | AP cut-off coordination into `BP-FIN-CLOSE` |
| Chief Audit Executive (G11) | `EMP-100009` Thomas Nakamura | Independent assurance |

### 6.1 RACI — Vendor Payment Lifecycle

| Activity | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Vendor onboarding | PRC Ops / Category | CPO | Legal, ISC, Compliance, Finance | AP |
| Bank detail verification | AP master data / PRC Ops | Head of AP | Treasury | Vendor |
| Raise PO | Business requestor | Cost centre / budget owner | PRC | Vendor |
| Receive goods/services | Requestor / receiving | Requestor’s manager | PRC | AP |
| Invoice validate & post | AP Analyst | Head of AP | Tax, requestor | — |
| Three-way match | Match engine + AP | Head of AP | Requestor on exceptions | SOX |
| Schedule payment | AP Payments Manager | Head of AP | Treasury | Vendor |
| Fund & release payment | Treasury Ops | Head of Treasury Ops / FinOps | AP | GFC (large wires) |
| Sanctions screening | Financial Crime systems + ops | BSA/Financial Crime lead | AP, Treasury | — |
| Exception / urgent | AP Payments + approvers per matrix | Head of FinOps / GFC as §16 | PRC, Treasury | SOX |
| Period cut-off | Head of AP | GFC (close) | Close Manager | Entity controllers |

---

## 7. Policy and Control Statements

**P1 — No vendor, no pay.** Payment requires Active vendor `VND-########` in ApexVendor with cleared screening and verified bank details.

**P2 — Authority first.** Commitment and invoice approval must satisfy `ANB-ADM-MTX-0001` §7.1 / §9 and `ANB-FIN-MTX-0009`. AP does not create authority by paying.

**P3 — Match before pay.** `INV-TYPE-PO` requires successful two- or three-way match within tolerances, or a documented approved exception.

**P4 — Segregation.** The same individual may not create the vendor, enter the invoice, and release the payment. Bank-detail change and payment release are separated.

**P5 — Beneficiary confirmation.** First payment to new bank details, and every bank-detail change, requires out-of-band confirmation before release.

**P6 — Sanctions interlock.** ApexPay will not release a payment instruction while the sanctions status is Open or Blocked.

**P7 — Duplicate detection.** System duplicate check is mandatory; overrides require Head of AP or above.

**P8 — Tax codes.** Every invoice carries a valid `TAX-*` determination; withholding applied where required.

**P9 — No splitting.** Splitting invoices or POs to evade approval or match rules is misconduct under `ANB-HRM-POL-0004`.

**P10 — Urgent is exceptional.** Urgent payments follow §16; pattern abuse triggers FinOps review.

**P11 — Close cut-off.** Period parking rules in §17 align to `ANB-FIN-SOP-0003`; post-cut-off invoices accrue, not backdate, without waiver.

**P12 — Retention.** Payment packages `RET-FIN-10Y`; tax support `RET-TAX-10Y`; SOX samples `RET-AUD-7Y`.

---

## 8. Vendor Categories (`VCAT-*`)

| Code | Category | Typical PO Required | Notes |
|---|---|---|---|
| `VCAT-TECH` | Technology hardware/software (non-cloud) | Yes | ISC review often required at sourcing |
| `VCAT-FACILITIES` | Facilities, maintenance, real estate services | Yes above threshold | Utilities may use `INV-TYPE-UTILITY` |
| `VCAT-PROF` | Professional services | Yes | Statement of work attachment |
| `VCAT-MKT` | Marketing and events | Yes | Brand/Compliance where customer-facing |
| `VCAT-HR` | HR services, recruiting agencies | Yes | Data protection scrutiny |
| `VCAT-FIN` | Financial services vendors, market data (non-`VCAT-DATA`) | Yes | Licensing terms |
| `VCAT-LEGAL` | External counsel | Controlled Non-PO or panel PO | Legal must approve engagement |
| `VCAT-DATA` | Market / reference data | Yes | Usage audit rights |
| `VCAT-CLOUD` | Cloud infrastructure & SaaS | Yes | Commitment vs usage accruals at close |
| `VCAT-BRANCH` | Branch operations local vendors | Yes above $5,000; micro-PO policy below | Still require Active vendor |

---

## 9. Procedure — Vendor Onboarding (AP Hand-Off)

### 9.1 Prerequisites (Procurement-Led)

1. Business sponsor initiates vendor request in ApexSource / ApexVendor portal.
2. Category Manager assigns `VCAT-*` and preliminary tier.
3. Due diligence depth follows `ANB-ADM-MTX-0001` §9.1 (value/tier).
4. Legal / ISC / Risk / Compliance consultees complete as required.
5. CPO or delegate approves vendor creation per enterprise matrix.

### 9.2 AP Master Data Completion

1. AP / PRC Ops creates or activates `VND-########` with legal name, tax ID, addresses, payment terms, default `TAX-*` profile.
2. Bank details captured (account name, account number/IBAN, BIC/SWIFT, bank name, currency).
3. **Beneficiary confirmation** executed (§10) before status can become Payable.
4. Sanctions and adverse-media screening cleared.
5. Vendor status set to **Active – Payable**.
6. ApexVendor writes through to ApexLedger vendor master.

### 9.3 Example — Onboarding

Vendor **CloudNova Platforms LLC** onboarded as `VND-10028441`, category `VCAT-CLOUD`, payment terms Net 45, default rail `PAY-ACH` (USD), wire template reserved for emergency. Beneficiary confirmation completed 2026-07-09 via recorded call-back to finance contact on the vendor’s public domain email thread initiated by AP, not using contact details supplied only on the change form.

---

## 10. Beneficiary Confirmation and Bank Detail Change

### 10.1 When Required

| Event | Confirmation Required |
|---|---|
| New vendor first payment | Yes |
| Any change to bank account, IBAN, BIC, or beneficiary name | Yes |
| Change of payment entity / factoring assignment | Yes — treat as new beneficiary |
| Cosmetic address change only | No — documented verification of no payment-field change |

### 10.2 Method

1. AP initiates contact using **independently sourced** contact details (signed contract, prior verified email domain, reputable directory) — never solely the details on the inbound change request.
2. Confirm account name, account number/IBAN, BIC, currency.
3. Record confirmation reference in ApexVendor (date, AP officer, vendor person, channel).
4. Second AP officer (four-eyes) releases the bank detail to Payable status.
5. First payment after change may be limited value if Head of AP elects enhanced monitoring.

### 10.3 Red Flags (Hard Stop to Head of AP)

- Last-minute bank change immediately before large payment  
- Pressure to skip call-back  
- Email domain mismatch / look-alike domain  
- Beneficiary name ≠ legal vendor name without documented assignment  

---

## 11. Invoice Validation and Three-Way Matching

### 11.1 Invoice Intake

Invoices arrive via: approved e-invoice channel, vendor portal, or controlled AP inbox. Minimum fields: vendor `VND`, invoice number, invoice date, currency, amount, tax, bill-to entity, PO number if `INV-TYPE-PO`, bank reference if stated (does not override master without §10).

AP Analyst (`EMP-600119` or team) indexes invoice as `INV-##########`, assigns type, and runs validation checklist.

### 11.2 Invoice Types — Routing

| Type | Match Requirement | Approval Path |
|---|---|---|
| `INV-TYPE-PO` | Three-way (goods) or two-way (services acceptance) | Match engine; exceptions to requestor + AP |
| `INV-TYPE-NONPO` | No PO match; requires Non-PO justification code and approver per `ANB-FIN-MTX-0009` | Cost centre approver + AP audit sample |
| `INV-TYPE-UTILITY` | Schedule/contract reference; consumption report | Facilities / cost centre |
| `INV-TYPE-LEASE` | Lease schedule ID; Accounting/IFRS 16 team coding | Corporate Real Estate + FinOps |
| `INV-TYPE-CREDITMEMO` | Ties to original invoice/PO | AP; requestor if quantity/price dispute |
| `INV-TYPE-INTERCO` | Intercompany partner + confirmation | Both entity AP/controllers |

### 11.3 Three-Way Match Tolerances

| Element | Tolerance | Breach Action |
|---|---|---|
| Quantity | **0%** — invoice qty may not exceed receipt qty | Block; receipt adjustment or credit memo |
| Price | **±2%** of PO unit price **or $100** absolute per line, whichever rule the match engine applies as the greater allowable difference under configuration controlled by Finance Systems | Block to exception queue |
| Tax | Must match expected `TAX-*` calculation within $1 (rounding) or documented jurisdiction rule | Tax review |
| Currency | Must match PO currency unless documented FX invoice protocol | Block |

**Quantity never toleranced upward.** Under-receipt requires partial invoice or wait for receipt.

### 11.4 Example — Three-Way Match Success

- Vendor: `VND-10028441`  
- PO: `PO-778201` — 12 months cloud capacity reservation, $5,400,000  
- Receipt / service acceptance: August usage acceptance entered in ApexSource  
- Invoice: `INV-9928471103` — $450,000 for period, unit price within 0.5% of PO schedule  
- Match: Pass → scheduled for next ACH run  

### 11.5 Example — Price Tolerance Breach

Invoice line $102,500 vs PO $100,000 (2.5% and > $100). Match fails. Divya Nair routes exception to requestor. Outcome: either amended invoice, PO change order approved per procurement/finance authority, or short-pay with vendor agreement.

---

## 12. Tax Validation

1. Determine jurisdiction and supply type.  
2. Apply `TAX-*` code (e.g. US sales/use, VAT, GST).  
3. Validate tax ID on vendor master for reclaim jurisdictions.  
4. Calculate withholding where vendor is subject to WHT; record payable to tax authority separately.  
5. Head of Tax (`EMP-600107`) configures rule tables; AP escalates uncertain determinations.  
6. Retain tax invoices per `RET-TAX-10Y`.

India GST, Brazil *nota fiscal*, Mexico CFDI, and EU VAT e-invoicing rules apply to local entities as jurisdictional supplements maintained by Tax — AP may not override tax engine results without Tax approval.

---

## 13. Duplicate Detection

ApexLedger duplicate check keys include: vendor + invoice number + entity; vendor + amount + date ±3 days; attachment hash similarity where enabled.

| Result | Action |
|---|---|
| Exact duplicate | Hard block |
| Suspected duplicate | Exception queue; AP Analyst investigates |
| Override | Head of AP or FinOps G8; reason coded; SOX-visible |

---

## 14. Payment Batches and Rails

### 14.1 Standard Runs

| Rail | Frequency | Use |
|---|---|---|
| `PAY-ACH` | **Twice weekly** (e.g. Tuesday / Thursday) | Default US domestic |
| `PAY-WIRE` | **Daily by exception** | Urgency, beneficiary requirements, large-value policy |
| `PAY-SEPA` | Per EU entity calendar (typically 2–3× weekly) | EUR payments for EU entities |
| `PAY-SWIFT` | By exception with Treasury | Cross-border non-SEPA |

### 14.2 Payment Proposal Procedure (`BP-FIN-PAY`)

1. AP Payments Manager runs payment proposal for due invoices not on hold.  
2. System applies holds: match fail, sanctions Open, vendor Inactive, dispute flag, incomplete beneficiary confirmation.  
3. Proposal reviewed for anomalies (new beneficiaries, amounts > $1M, first-time vendors).  
4. Head of AP (or delegate G5+ with limit) approves batch.  
5. ApexPay generates instructions; Treasury funds and releases under dual control for wires.  
6. Remittance advices issued; ApexLedger clears `23xxxx`.  
7. Clearing accounts reconciled under `BP-RECN-DAILY` by Reconciliation Lead.

### 14.3 Treasury Interaction

| Step | AP | Treasury (`EMP-600501`) |
|---|---|---|
| ACH batch | Approve proposal | Fund concentration account; release file |
| Wire / SWIFT | Approve + business urgency code | Dual release in ApexTreasury; sanctions already clear |
| SEPA | EU AP team proposal | Local treasury desk release |
| Failure / return | Investigate vendor details | Post return; re-open payable |

Wires above thresholds in `ANB-FIN-MTX-0009` require FinOps/GFC visibility before release.

### 14.4 Example — ACH Batch

Batch `PAY-ACH-20260814-02` includes `INV-9928471103` for `VND-10028441` $450,000. Chen Wei reviews exception dashboard (zero high-risk flags). Colin Devereaux approves batch. Treasury releases. GL: Dr `231000` AP / Cr Cash clearing; then clearing to bank on confirmation.

---

## 15. Sanctions Screening Interlock

1. Vendor screening at onboarding and periodic refresh.  
2. Payment-level screening on instruction creation in ApexPay.  
3. **Interlock:** status Clear required for release; Open/Blocked stops batch line.  
4. Hits managed in ApexServe by Financial Crime — AP does not clear hits.  
5. False positive release only by authorised Financial Crime officers; audit logged.  
6. Record retention aligns with financial crime policy and `RET-FIN-10Y` payment package copy.

---

## 16. Exception Handling and Urgent Payments

### 16.1 Match Exceptions

| Exception | Resolution Path |
|---|---|
| Qty over receipt | Wait for receipt or credit memo |
| Price out of tolerance | PO change order or invoice revise / short-pay |
| Missing receipt | Requestor enters acceptance within 5 business days or invoice parked |
| Wrong vendor | Credit / rebill; do not “redirect” payment |
| Disputed services | Hold flag; business + PRC resolve |

### 16.2 Urgent Payments

Urgent payments are permitted only when:

1. Documented business need (regulatory deadline, critical service continuity, contractual penalty avoidance); and  
2. Invoice validated (or GFC/FinOps accepts provisional with true-up); and  
3. Approvals per `ANB-FIN-MTX-0009` emergency spending / payment rows; and  
4. Beneficiary confirmation current; sanctions Clear; and  
5. Logged in Urgent Payment Register with same-day or next-run regularisation.

**Approvers (operational):** AP Payments Manager prepares; Head of AP approves ≤ $100,000; Head of FinOps ≤ $1,000,000; GFC above — without contradicting enterprise §7.1 single-transaction grade limits for the underlying commitment.

### 16.3 Holds

Head of AP may place vendor or invoice holds for: fraud suspicion, incomplete tax docs, performance dispute, incomplete onboarding, audit request. Release requires documented clearance.

---

## 17. Period Cut-Off and Close Interface

Per `ANB-FIN-SOP-0003`:

- T+1 12:00 ET: no new invoices parked into period without Close Manager override.  
- Received-not-invoiced items accrued (`JE-YYYYMM-######`).  
- GR/IR aged items owned by AP + requestors; material aged GR/IR reported to GFC.  
- Payment runs continue for prior closed payables; they do not reopen locked GL periods incorrectly — posting date follows ApexLedger open period rules.

---

## 18. Process Flows

### 18.1 PO Invoice Happy Path

```
Vendor Active (ApexVendor)
    → PO created/approved (ApexSource)
        → Goods/services received (ApexSource)
            → Invoice INV-########## indexed (ApexLedger)
                → Tax + duplicate checks
                    → Three-way match PASS
                        → Schedule in ACH/SEPA proposal
                            → Sanctions Clear
                                → AP approve batch → ApexPay
                                    → Treasury fund/release → Remittance → Reconcile
```

### 18.2 Bank Detail Change

```
Change request received
    → Independent beneficiary confirmation
        → Four-eyes release in ApexVendor
            → First payment enhanced review
                → Normal runs thereafter
```

### 18.3 Blocked Sanctions Path

```
Payment proposal line
    → Screen HIT/Open
        → ApexServe case
            → Financial Crime decision
                → Clear: resume | Block: cancel/return to AP | Escalate: Legal
```

---

## 19. Decision Tables

### 19.1 Invoice Type Selection

| Situation | Type |
|---|---|
| PO exists and covers supply | `INV-TYPE-PO` |
| Panel counsel monthly fee under engagement letter without classic PO | `INV-TYPE-NONPO` or panel PO per Legal Ops standard |
| Electricity / water | `INV-TYPE-UTILITY` |
| Premises lease invoice | `INV-TYPE-LEASE` |
| Vendor reduces prior invoice | `INV-TYPE-CREDITMEMO` |
| Group entity charges another | `INV-TYPE-INTERCO` |

### 19.2 Rail Selection

| Condition | Rail |
|---|---|
| USD domestic, standard terms | `PAY-ACH` |
| EUR within SEPA zone | `PAY-SEPA` |
| Critical same-day / beneficiary requires wire | `PAY-WIRE` |
| Cross-border non-SEPA | `PAY-SWIFT` via Treasury |

### 19.3 Match Outcome

| Qty | Price | Result |
|---|---|---|
| ≤ receipt, within 0% over | Within ±2% or $100 | Auto-match |
| > receipt | Any | Block |
| ≤ receipt | Outside tolerance | Exception queue |
| No receipt (goods) | Any | Park |

---

## 20. Approval Tables (Procedure-Level)

| Decision | Approver |
|---|---|
| Activate vendor Payable status after confirmation | AP master data four-eyes; PRC Ops as configured |
| Override duplicate hard stop | Head of AP or Head of FinOps |
| Approve match exception short-pay | Requestor G-level per amount + AP |
| Approve Non-PO invoice | Per `ANB-FIN-MTX-0009` |
| Approve ACH/SEPA batch | Head of AP or delegated G5 Payments Manager within limit |
| Approve wire proposal | Head of AP + Treasury dual release; FinOps/GFC per amount |
| Urgent payment ≤ $100k | Head of AP |
| Urgent payment ≤ $1M | Head of FinOps |
| Urgent payment > $1M | GFC (and enterprise grade limits) |
| Release vendor hold (fraud-related) | Head of AP **and** FinOps; Compliance informed |
| Sole-source pay implications | Already constrained at sourcing by CPO/CFO per §9 enterprise matrix |

---

## 21. Control Register (AP / Payments)

| Control ID | Description |
|---|---|
| `CTL-FIN-AP-01` | Vendor Active + verified bank before pay |
| `CTL-FIN-AP-02` | Three-way/two-way match or approved exception |
| `CTL-FIN-AP-03` | Duplicate detection |
| `CTL-FIN-AP-04` | Payment batch approval segregation |
| `CTL-FIN-AP-05` | Sanctions interlock |
| `CTL-FIN-AP-06` | Beneficiary confirmation on bank change |
| `CTL-FIN-AP-07` | Urgent payment register review monthly |
| `CTL-FIN-AP-08` | GR/IR ageing review |

Evidence in ApexDocs / ApexLedger / ApexPay; tested via ApexAudit; retention `RET-AUD-7Y` for test files.

---

## 22. Examples — Integrated Scenarios

### 22.1 Standard Cloud Invoice

`VND-10028441` invoices `INV-9928471103` against `PO-778201`. Match passes. Included in `PAY-ACH` Tuesday run. Posted Dr Cloud expense `720200` $450,000 / Cr AP `231000`. Paid; clearing reconciled by Fatima Al-Hassan.

### 22.2 Fraud Attempt — Bank Change

Fraudulent email requests new account for `VND-10028441`. AP initiates call-back to independently known number; vendor denies request. Change rejected; incident logged; Information Security and Financial Crime notified. No payment diversion.

### 22.3 Intercompany

`INV-TYPE-INTERCO` from `LE-200` to `LE-110` for shared services. Both controllers confirm. Settlement via intercompany netting where elected, or `PAY-SWIFT`/`PAY-SEPA` per treasury policy; eliminations handled at close in `BOOK-CONS-GROUP` under `ANB-FIN-SOP-0003`.

### 22.4 Capex Vendor Payment

Invoice for hardware capitalised to `15xxxx` under `CAP-2026-0142`. PO and asset tagging confirmed; payment via ACH; depreciation begins when placed in service (`790100` via FA run).

---

## 23. Related Documents

### 23.1 Foundation and Governance

| ID | Title |
|---|---|
| Company Profile | Foundation company profile |
| `ANB-ADM-REF-0001` | Enterprise reference / Master Company Profile |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard |
| `ANB-ADM-POL-0001` | Records Retention Policy |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix (§7.1, §9 vendor) |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide |
| `ANB-LEG-REF-0003` | Legal reference index |

### 23.2 Finance Siblings

| ID | Title |
|---|---|
| `ANB-FIN-POL-0001` | Expense Policy |
| `ANB-FIN-POL-0002` | Travel Policy |
| `ANB-FIN-BUD-0005` | Budget FY2026 |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard |
| `ANB-FIN-SOP-0003` | Financial Closing SOP |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy |
| `ANB-FIN-POL-0007` | Corporate Card Policy |
| `ANB-FIN-SOP-0008` | This procedure |
| `ANB-FIN-MTX-0009` | Finance Approval Authority Matrix |

### 23.3 HR Set

| ID | Title |
|---|---|
| `ANB-HRM-HBK-0001` | Employee Handbook |
| `ANB-HRM-POL-0002` | Leave Policy |
| `ANB-HRM-POL-0003` | Remote Work Policy |
| `ANB-HRM-POL-0004` | Code of Conduct |
| `ANB-HRM-POL-0006` | Performance Management Policy |
| `ANB-HRM-POL-0008` | Training and Certification Policy |
| `ANB-HRM-SOP-0007` | Recruitment SOP |
| `ANB-FIN-POL-0002` | Travel Policy |

---

## 24. Review Cycle

Annual review led by AP Payments Manager and Head of AP; re-approval by Head of FinOps. Interim review triggers: payment fraud incident, major ApexPay/ApexLedger release, sanctions programme change, or material audit finding. Next review: **2027-07-22**.

---

## 25. Revision History

| Version | Date | Author | Approver | Summary |
|---|---|---|---|---|
| 0.1 | 2026-06-08 | `EMP-600124` Chen Wei | — | Draft consolidation of AP desk procedures |
| 0.8 | 2026-07-15 | Chen Wei / Colin Devereaux | FinOps review | Added tolerances, sanctions interlock, urgent path |
| 1.0 | 2026-08-01 | `EMP-600124` Chen Wei | `EMP-600102` Marcel Delacroix | Initial in-force publication |

---

## Appendix A — Invoice Validation Checklist

1. Vendor Active – Payable  
2. Entity / company code correct  
3. Invoice number unique  
4. Date logical; not future > 5 days  
5. Currency authorised  
6. PO reference if required  
7. Tax code present  
8. Bank details on invoice do not silently overwrite master  
9. Attachment readable  
10. Duplicate check clear  
11. Sanctions status Clear at payment time  

---

## Appendix B — Payment File Rejection Codes (Operational)

| Code | Meaning | AP Action |
|---|---|---|
| `REJ-BANK-01` | Invalid account | Freeze vendor pay; re-confirm beneficiary |
| `REJ-SANC-01` | Sanctions interlock | Wait Financial Crime |
| `REJ-FUND-01` | Insufficient funding | Treasury reschedule |
| `REJ-DUP-01` | Duplicate instruction | Investigate; do not resubmit blindly |

---

## Appendix C — Segregation Matrix (Minimum)

| Duty | Role A | Role B | Role C |
|---|---|---|---|
| Vendor create | PRC Ops | — | — |
| Bank detail release | AP Officer 1 | AP Officer 2 | — |
| Invoice entry | AP Analyst | — | — |
| Invoice approve (Non-PO) | Business approver | — | — |
| Payment batch approve | Head of AP / delegate | — | — |
| Wire release | Treasury Officer 1 | Treasury Officer 2 | — |

---

## Appendix D — Category-Specific Notes

| Category | Extra Requirement |
|---|---|
| `VCAT-LEGAL` | Engagement approved by Legal; matter number on invoice |
| `VCAT-CLOUD` | Usage report retained for accrual/match |
| `VCAT-DATA` | License period alignment; no automatic renewals without PO |
| `VCAT-BRANCH` | Branch manager acknowledgement for local services > $5,000 |
| `VCAT-HR` | No candidate PII in invoice attachments posted to open AP queues |

---

## Appendix E — Contacts

| Topic | Contact |
|---|---|
| Invoice exceptions | `EMP-600119` Divya Nair |
| Payment runs / urgent | `EMP-600124` Chen Wei |
| Vendor master / holds | `EMP-600112` Colin Devereaux |
| Onboarding | `EMP-600402` Angela Duarte |
| Category | `EMP-600401` Ethan Brookfield |
| Treasury release | `EMP-600501` Nikolai Petrov |
| Tax codes | `EMP-600107` Miriam Rosenthal |
| Close cut-off | `EMP-600122` James Okonkwo |

---

## Appendix F — Worked Example Package (CloudNova August 2026)

| Artefact | Identifier |
|---|---|
| Vendor | `VND-10028441` CloudNova Platforms LLC (`VCAT-CLOUD`) |
| PO | `PO-778201` $5,400,000 annual reservation |
| Service acceptance | ApexSource receipt 2026-08-31 |
| Invoice | `INV-9928471103` $450,000 |
| Tax code | `TAX-US-EXEMPT-SVC` (illustrative; actual per Tax engine) |
| Match result | Pass — qty equal; price variance 0.5% |
| Payment | `PAY-ACH-20260814-02` |
| GL | Dr `720200` / Cr `231000`; clear on bank confirm |
| Close link | If invoice late past T+1 cut-off, accrue via `JE-202608-004821` per `ANB-FIN-SOP-0003` |

This package is the reference training case for AP analysts and is stored in ApexDocs under AP Training → Match & Pay.

---

## Appendix G — Non-PO Justification Codes

| Code | Use When | Extra Approval |
|---|---|---|
| `NPO-LEGAL-PANEL` | Panel counsel per Legal Ops | Legal matter owner |
| `NPO-UTILITY-REG` | Regulated utility without PO habit | Facilities |
| `NPO-LEASE-SCH` | Lease schedule invoice | Corporate Real Estate |
| `NPO-COURT-FEES` | Court / filing fees | Legal |
| `NPO-EMERGENCY` | SEV1 continuity | FinOps / GFC per `ANB-FIN-MTX-0009` |
| `NPO-OTHER` | Rare residual | Head of AP **and** category manager; monthly FinOps review |

Abuse of `NPO-OTHER` is a metrics exception reported to Marcel Delacroix (`EMP-600102`).

---

## Appendix H — Monthly AP Metrics Pack (Contents)

1. Invoices received / posted / paid  
2. Match fail rate by reason  
3. Duplicate blocks and overrides  
4. Urgent payment count and %  
5. Beneficiary confirmation ageing  
6. Sanctions holds ageing  
7. GR/IR > 45 days  
8. Early-pay discount capture rate  
9. Payments by rail (`PAY-ACH` / `PAY-WIRE` / `PAY-SEPA` / `PAY-SWIFT`)  
10. SOX control exceptions  

Prepared by `EMP-600124` Chen Wei; reviewed by `EMP-600112` Colin Devereaux; issued to FinOps and GFC.

---

**End of Document — `ANB-FIN-SOP-0008` v1.0**

*This Procedure is a controlled document. Printed or locally saved copies are uncontrolled. The authoritative version resides in ApexDocs. When in doubt whether an invoice may be paid, hold and escalate — never “pay and fix later.”*
