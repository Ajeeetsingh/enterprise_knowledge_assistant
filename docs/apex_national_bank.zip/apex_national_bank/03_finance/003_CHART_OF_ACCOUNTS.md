# Apex National Bank — Chart of Accounts Standard

## Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-STD-0004` |
| **Document Title** | Apex National Bank — Chart of Accounts Standard |
| **Version** | 4.0 |
| **Status** | Approved — In Force (**Document ID RESERVED** — do not reassign) |
| **Classification** | `C1` Internal |
| **Owner** | Finance Department (FIN) — Financial Control |
| **Document Owner (named)** | `EMP-600101` Gemma Ashworth, Group Financial Controller (G9) |
| **Approver** | `EMP-100002` Priya Raghunathan, Chief Financial Officer (G11) |
| **Author** | `EMP-600109` Rosalind Mbeki, Head of Accounting Policy & Technical Accounting (G8) |
| **Effective Date** | 2026-01-01 |
| **Last Review Date** | 2025-11-14 |
| **Next Review Date** | 2027-11-14 |
| **Review Cycle** | **Biennial** (mandatory interim review on accounting-standard change or legal-entity addition) |
| **Retention Code** | `RET-FIN-10Y` |
| **Taxonomy** | `T5` Finance & Treasury → `T5.1` Financial Control → Chart of Accounts → `STD` |
| **Business Process** | `BP-FIN-COA` Chart of Accounts Governance |
| **Related Processes** | `BP-FIN-CLOSE`, `BP-FIN-JRNL`, `BP-FIN-PLAN`, `BP-FIN-EXP`, `BP-REG-FILE`, `BP-AUD-SOX` |
| **System of Record** | ApexLedger (SAP S/4HANA) — GL master data |
| **Supporting Systems** | ApexPlan, ApexInsight, ApexSource, ApexVendor, ApexRegRep, ApexDocs, ApexServe |
| **Publication Location** | ApexDocs → Finance → Financial Control → Standards |
| **Applies To** | All legal entities, business units, departments, and branches of Apex Financial Group, Inc. |
| **Language** | English (US) — authoritative version |
| **Supersedes** | `ANB-FIN-STD-0004` v3.2 (effective 2024-01-01) |

---

## 1. Purpose

This Standard defines the single enterprise Chart of Accounts (CoA) for Apex Financial Group, Inc. It sets the six-digit natural account structure, account attributes, cost centre and profit centre posting rules, book and period identifiers, governance for create/freeze/reclass, and high-level Call Report / FINREP mapping.

The Group operates **one global chart**. Local statutory and regulatory presentations are produced by mapping, never by parallel charts. Downstream artefacts — Call Report, FR Y-9C, audited statements, Board packs, `ANB-FIN-BUD-0005` variance, SOX key accounts, and tax — all aggregate from this CoA.

**Expense alignment.** Travel, meals, and entertainment **must** use `750100`, `750200`, and `750300`. Sibling policies shall not use legacy ranges such as `611100`.

---

## 2. Scope

### 2.1 In Scope

| Area | Coverage |
|---|---|
| Legal entities | Apex National Bank, N.A.; Apex Financial Group, Inc.; Apex Securities LLC; Apex Asset Management, Inc.; Apex Trust Company, N.A.; Apex National Bank (UK) plc; Apex Bank Europe SE; Apex Global Services Private Limited; Apex Insurance Agency, LLC |
| Business units | CRB, CMB, CIB, WAM, TM |
| Books | `BOOK-USGAAP-ANB`, `BOOK-IFRS-UK`, `BOOK-IFRS-EU`, `BOOK-CONS-GROUP` |
| Periods | `AP-2026-01` … `AP-2026-12`; `CQ-2026-Q1` … `CQ-2026-Q4`; `FY-2026` |
| Master data | Natural accounts, cost centres, profit centres, currencies, intercompany partners, projects, tax codes |
| Subledgers | Loans, deposits, securities, derivatives, fixed assets, AP, AR, expense, payroll, leases |

### 2.2 Out of Scope

| Excluded | Governed By |
|---|---|
| Accounting policy elections (CECL, hedge designation) | Group Accounting Policy Manual |
| Close calendar and journal execution | `ANB-FIN-SOP-0003` |
| Expenditure authority | `ANB-FIN-MTX-0009`; `ANB-ADM-MTX-0001` |
| Budget envelopes | `ANB-FIN-BUD-0005` |
| Expense claim eligibility | `ANB-FIN-POL-0001` |
| CapEx capitalisation criteria | `ANB-FIN-POL-0006` |

### 2.3 Acquisitions

Acquired entities may retain a legacy chart for at most **two** full periods after close under a certified mapping, then must migrate to ApexLedger. Extension requires CFO approval and Audit Committee notice.

---

## 3. Objectives

| # | Objective | Measure |
|---|---|---|
| O1 | One CoA across entities and books | Zero non-conforming production charts |
| O2 | Complete valid accounting string on every posting | ≥ 99.95% pass validation at entry |
| O3 | Unambiguous account use | ≤ 5 misuse findings per quarter |
| O4 | Regulatory mappings complete | 100% Call Report / FINREP lines traceable |
| O5 | Master data change controlled | 100% GL changes have approved change records |
| O6 | Suspense aged within limits | Zero items > 30 days at Hard Close |
| O7 | Management reporting without off-ledger reclass | ≤ 2% of MI from manual adjustment |

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Natural Account** | Six-digit code for economic nature (e.g. `750100` Travel) |
| **Accounting String** | Full segment set on every posting (§5) |
| **Cost Centre** | Expense accountability unit `CC-<DEPT>-###` |
| **Profit Centre** | Revenue accountability unit `PC-<BU>-###` |
| **Book** | Complete ledger under a defined basis (`BOOK-*`) |
| **Control Account** | GL balance that must agree to a subledger |
| **Suspense Account** | Temporary holding account; never a final resting place |
| **SOX Critical** | Account in scope for key SOX controls (`CTL-FIN-*`) |
| **Normal Balance** | Debit (Dr) or Credit (Cr) natural balance |
| **BS / IS** | Balance Sheet or Income Statement classification |

---

## 5. Accounting String

Every posting in ApexLedger carries:

| # | Segment | Format | Example | Source |
|---|---|---|---|---|
| 1 | Legal Entity | `LE-###` | `LE-110` ANB N.A. | Entity master |
| 2 | Book | `BOOK-*` | `BOOK-USGAAP-ANB` | §9 |
| 3 | Cost Centre | `CC-<DEPT>-###` | `CC-FIN-100` | §6 |
| 4 | Natural Account | `######` | `750100` | §8 |
| 5 | Profit Centre | `PC-<BU>-###` | `PC-CRB-001` | §7 |
| 6 | Product (optional) | `PRD-######` | `PRD-RTL-DDA` | Product catalogue |
| 7 | Currency | ISO 4217 | `USD` | §11 |
| 8 | Intercompany Partner | `IC-###` / `IC-000` | `IC-210` | §8.11 |
| 9 | Capital Project | `CAP-2026-####` / `CAP-000000` | `CAP-2026-0210` | `ANB-FIN-POL-0006` |
| 10 | Tax Code | `TX-###` | `TX-100` | §11 |
| 11 | Period | `AP-YYYY-MM` | `AP-2026-03` | §10 |

Postings missing a mandatory segment are rejected at entry. Interface rejects land in suspense `990100` / `990200` (memo range `900000`–`999999`).

---

## 6. Cost Centres

### 6.1 Canonical Cost Centres

| Cost Centre | Name | Dept | Typical GL Posting Focus |
|---|---|---|---|
| `CC-FIN-100` | Financial Control | FIN | Close, CoA, reconciliations |
| `CC-FIN-200` | FP&A | FIN | Planning, allocations |
| `CC-FIN-300` | Financial Operations | FIN | AP, T&E, cards |
| `CC-FIN-400` | Reg Reporting / Capital / SOX / Tax | FIN | ApexRegRep, tax, SOX |
| `CC-RTL-100` | Retail Network Operations | RTL | Branch OpEx |
| `CC-RTL-412` | Southeast Expansion PMO | RTL | Expansion OpEx / CapEx support |
| `CC-CBK-200` | Corporate & Commercial Coverage | CBK | CBK OpEx |
| `CC-ITO-100` | Technology Operations | ITO | Tech run / change OpEx |
| `CC-ISC-100` | Information Security | ISC | Cyber / SOC |
| `CC-HRM-100` | Human Resources | HRM | HR ops / training delivery |
| `CC-CMP-100` | Compliance | CMP | Compliance ops |
| `CC-RSK-100` | Risk Management | RSK | Risk ops (not PCL) |
| `CC-TRY-100` | Treasury | TRY | Treasury ops (not interest expense ownership alone) |
| `CC-ADM-100` | Administration | ADM | Corporate admin / facilities pools |
| `CC-PRC-100` | Procurement | PRC | Procurement ops |
| `CC-MKT-100` | Marketing | MKT | Marketing OpEx |
| `CC-LEG-100` | Legal | LEG | Legal ops / external counsel |
| `CC-IAD-100` | Internal Audit | IAD | Audit ops |
| `CC-CST-100` | Customer Service | CST | Contact centres |

Additional operational cost centres may exist beneath these parents in ApexLedger; they must roll up to a canonical parent for enterprise reporting and for `ANB-FIN-BUD-0005` budget codes.

### 6.2 Cost Centre Rules

1. Every OpEx posting (`700000`–`799999`) requires a valid cost centre.
2. Balance sheet control accounts may use a designated finance CC (`CC-FIN-100`) where organisational CC is not meaningful.
3. Cost Centre Managers are accountable for expense charged to their CC and its budget impact under `ANB-FIN-BUD-0005`.
4. New cost centres require GFC approval and ApexPlan budget code linkage before go-live.

---

## 7. Profit Centres

| Profit Centre | Business Unit | Primary Revenue Accounts |
|---|---|---|
| `PC-CRB-001` | Consumer & Retail Banking | Interest on consumer loans; deposit fees; card fees |
| `PC-CMB-001` | Commercial Banking | C&I interest; treasury management fees |
| `PC-CIB-001` | Corporate & Investment Banking | Markets, DCM/ECM, advisory, corporate lending |
| `PC-WAM-001` | Wealth & Asset Management | Asset management and advice fees |
| `PC-TM-001` | Treasury & Markets | NII from ALM, trading where classified as TM |

Revenue accounts (`400000`–`699999`) require a profit centre. OpEx may carry a profit centre for contribution reporting; absence defaults to `PC-000-000` (unallocated) and is monitored by FP&A.

---

## 8. Unified Natural Account Scheme

| Range | Classification |
|---|---|
| `100000`–`199999` | Assets |
| `200000`–`299999` | Liabilities |
| `300000`–`399999` | Equity |
| `400000`–`499999` | Interest Income |
| `500000`–`599999` | Interest Expense |
| `600000`–`649999` | Noninterest Income (Fee Income) |
| `650000`–`699999` | Other Income / Gains |
| `700000`–`799999` | Operating Expenses |
| `710000`–`719999` | Personnel / Payroll / Benefits |
| `720000`–`729999` | Occupancy & Facilities |
| `730000`–`739999` | Technology & Telecom |
| `740000`–`749999` | Professional Services |
| `750000`–`759999` | Travel, Meals, Entertainment |
| `760000`–`769999` | Marketing & Communications |
| `770000`–`779999` | Training & Development |
| `780000`–`789999` | Compliance, Risk, Audit, Legal external |
| `790000`–`799999` | Other OpEx / Depreciation / Amortisation |
| `800000`–`849999` | Provisions / Credit Losses |
| `850000`–`899999` | Tax Expense |
| `900000`–`999999` | Intercompany / Memo / Off-balance / Suspense |

Account attribute columns used below: **NB** = normal balance; **FS** = BS or IS; **LE** = legal entity applicability (ALL = all consolidating entities unless noted); **SOX** = Y/N; **Recon Owner** = role accountable for reconciliation.

---

### 8.1 Assets (`100000`–`199999`)

| Account | Name | Type | NB | FS | LE | SOX | Recon Owner |
|---|---|---|---|---|---|---|---|
| `100100` | Cash — Head Office Vault | Asset | Dr | BS | ANB | Y | Treasury Ops |
| `100200` | Cash — Branch Vaults | Asset | Dr | BS | ANB | Y | RTL Cash Services |
| `100300` | Cash — ATMs | Asset | Dr | BS | ANB | Y | RTL Cash Services |
| `101100` | Due from Federal Reserve — Reserve Balance | Asset | Dr | BS | ANB | Y | Treasury |
| `101200` | Due from Banks — Demand | Asset | Dr | BS | ALL | Y | Treasury |
| `101300` | Due from Banks — Time | Asset | Dr | BS | ALL | Y | Treasury |
| `110100` | Securities — Trading Debt | Asset | Dr | BS | ALL | Y | Markets Control |
| `110200` | Securities — Trading Equity | Asset | Dr | BS | ALL | Y | Markets Control |
| `111100` | Securities — AFS Debt | Asset | Dr | BS | ALL | Y | Treasury ALM |
| `112100` | Securities — HTM Debt | Asset | Dr | BS | ANB | Y | Treasury ALM |
| `113100` | Securities Valuation Allowance / Fair Value Adj | Asset | Dr/Cr | BS | ALL | Y | Treasury ALM |
| `120100` | Loans — Residential Mortgage | Asset | Dr | BS | ANB | Y | CBK/RTL Credit Ops |
| `120200` | Loans — Home Equity / HELOC | Asset | Dr | BS | ANB | Y | RTL Credit Ops |
| `120300` | Loans — Consumer Instalment | Asset | Dr | BS | ANB | Y | RTL Credit Ops |
| `120400` | Loans — Credit Card | Asset | Dr | BS | ANB | Y | Cards Finance |
| `121100` | Loans — C&I Commercial | Asset | Dr | BS | ANB | Y | CBK Credit Ops |
| `121200` | Loans — Commercial Real Estate | Asset | Dr | BS | ANB | Y | CBK Credit Ops |
| `121300` | Loans — Construction | Asset | Dr | BS | ANB | Y | CBK Credit Ops |
| `122100` | Loans — Corporate / Syndicated | Asset | Dr | BS | ANB | Y | CIB Credit Ops |
| `124100` | Unearned Income / Loan Fees Deferred (contra) | Asset | Cr | BS | ANB | Y | Financial Control |
| `130100` | Allowance for Credit Losses — Loans (contra) | Asset | Cr | BS | ANB | Y | Credit Risk Finance |
| `130200` | Allowance for Credit Losses — HTM Securities | Asset | Cr | BS | ANB | Y | Treasury Finance |
| `140100` | Accrued Interest Receivable — Loans | Asset | Dr | BS | ANB | Y | Financial Control |
| `140200` | Accrued Interest Receivable — Securities | Asset | Dr | BS | ALL | Y | Treasury |
| `141100` | Accounts Receivable — Customers / Fees | Asset | Dr | BS | ALL | N | Fin Ops |
| `142100` | Prepaid Expenses | Asset | Dr | BS | ALL | N | Fin Ops |
| `150100` | Premises — Land | Asset | Dr | BS | ALL | N | Corporate RE |
| `150200` | Premises — Buildings | Asset | Dr | BS | ALL | N | Corporate RE |
| `150400` | Furniture & Equipment — Branches | Asset | Dr | BS | ANB | N | RTL / Corp RE |
| `150500` | IT Hardware — Capitalised | Asset | Dr | BS | ALL | N | ITO Asset Mgmt |
| `151100` | Construction in Progress (CIP) | Asset | Dr | BS | ALL | Y | FP&A CapEx / GFC |
| `151200` | CIP — Core Banking (`CAP-2026-0210`) | Asset | Dr | BS | ANB | Y | ITO / GFC |
| `151300` | CIP — Cyber Platform (`CAP-2026-0088`) | Asset | Dr | BS | ANB | Y | ISC / GFC |
| `151400` | CIP — Branch Expansion (`CAP-2026-0031`) | Asset | Dr | BS | ANB | Y | RTL / GFC |
| `152100` | Accumulated Depreciation — Buildings (contra) | Asset | Cr | BS | ALL | N | Corporate RE |
| `152200` | Accumulated Depreciation — FF&E (contra) | Asset | Cr | BS | ALL | N | Corporate RE |
| `152300` | Accumulated Depreciation — IT Hardware (contra) | Asset | Cr | BS | ALL | N | ITO Asset Mgmt |
| `160100` | Software — Internally Developed Capitalised | Asset | Dr | BS | ALL | Y | ITO / GFC |
| `160200` | Software — Purchased Capitalised | Asset | Dr | BS | ALL | N | ITO Asset Mgmt |
| `160300` | Accumulated Amortisation — Software (contra) | Asset | Cr | BS | ALL | N | ITO Asset Mgmt |
| `161100` | Goodwill | Asset | Dr | BS | ALL | Y | GFC |
| `170100` | Deferred Tax Assets | Asset | Dr | BS | ALL | Y | Tax (`CC-FIN-400`) |
| `180100` | Right-of-Use Assets — Leases | Asset | Dr | BS | ALL | Y | Corporate RE / GFC |
| `190100` | Derivative Assets — Trading | Asset | Dr | BS | ALL | Y | Markets Control |

---

### 8.2 Liabilities (`200000`–`299999`)

| Account | Name | Type | NB | FS | LE | SOX | Recon Owner |
|---|---|---|---|---|---|---|---|
| `200100` | Deposits — Retail Demand / DDA | Liability | Cr | BS | ANB | Y | Deposit Ops |
| `200200` | Deposits — Retail Savings | Liability | Cr | BS | ANB | Y | Deposit Ops |
| `200300` | Deposits — Retail Time / CDs | Liability | Cr | BS | ANB | Y | Deposit Ops |
| `201100` | Deposits — Commercial Demand | Liability | Cr | BS | ANB | Y | CBK Ops |
| `202100` | Deposits — Corporate / Institutional | Liability | Cr | BS | ANB | Y | CIB Ops |
| `204100` | Deposits — Foreign Offices | Liability | Cr | BS | UK/EU | Y | Local Finance |
| `210100` | Federal Funds Purchased | Liability | Cr | BS | ANB | Y | Treasury |
| `210200` | Securities Sold Under Repo | Liability | Cr | BS | ALL | Y | Treasury |
| `211100` | FHLB Advances | Liability | Cr | BS | ANB | Y | Treasury |
| `212100` | Long-Term Debt — Senior | Liability | Cr | BS | AFG/ANB | Y | Treasury / GFC |
| `212200` | Long-Term Debt — Subordinated | Liability | Cr | BS | AFG/ANB | Y | Treasury / GFC |
| `220100` | Trading Liabilities — Short Securities | Liability | Cr | BS | ALL | Y | Markets Control |
| `220200` | Derivative Liabilities — Trading | Liability | Cr | BS | ALL | Y | Markets Control |
| `230100` | Accrued Interest Payable — Deposits | Liability | Cr | BS | ANB | Y | Deposit Accounting |
| `230200` | Accrued Interest Payable — Borrowings | Liability | Cr | BS | ALL | Y | Treasury |
| `231100` | Accounts Payable — Trade Vendors | Liability | Cr | BS | ALL | Y | AP (`CC-FIN-300`) |
| `231200` | Accounts Payable — ApexVendor Clearing | Liability | Cr | BS | ALL | Y | AP |
| `232100` | Accrued Expenses — Compensation | Liability | Cr | BS | ALL | Y | HR Finance / GFC |
| `233100` | Employee Expense Reimbursement Payable | Liability | Cr | BS | ALL | N | Fin Ops |
| `233200` | Corporate Card Payable — Issuer | Liability | Cr | BS | ALL | Y | Fin Ops |
| `234100` | Lease Liabilities | Liability | Cr | BS | ALL | Y | Corporate RE / GFC |
| `240100` | Provision — Litigation | Liability | Cr | BS | ALL | Y | Legal / GFC |
| `240200` | Provision — Operational Remediation | Liability | Cr | BS | ALL | Y | CMP / GFC |
| `250100` | Deferred Tax Liabilities | Liability | Cr | BS | ALL | Y | Tax |
| `260100` | Taxes Payable — Current Income Tax | Liability | Cr | BS | ALL | Y | Tax |
| `260200` | Taxes Payable — Indirect / Sales | Liability | Cr | BS | ALL | N | Tax |

---

### 8.3 Equity (`300000`–`399999`)

| Account | Name | Type | NB | FS | LE | SOX | Recon Owner |
|---|---|---|---|---|---|---|---|
| `300100` | Common Stock | Equity | Cr | BS | AFG | Y | Corporate Secretary / GFC |
| `310100` | Additional Paid-in Capital | Equity | Cr | BS | AFG | Y | GFC |
| `320100` | Retained Earnings | Equity | Cr | BS | ALL | Y | GFC |
| `330100` | AOCI — AFS Unrealised G/L | Equity | Cr/Dr | BS | ALL | Y | Treasury / GFC |
| `330200` | AOCI — Cash Flow Hedges | Equity | Cr/Dr | BS | ALL | Y | Treasury / GFC |
| `330300` | AOCI — Foreign Currency Translation | Equity | Cr/Dr | BS | ALL | Y | GFC |
| `340100` | Treasury Stock (contra) | Equity | Dr | BS | AFG | Y | GFC |

---

### 8.4 Interest Income (`400000`–`499999`)

| Account | Name | Type | NB | FS | LE | SOX | Recon Owner |
|---|---|---|---|---|---|---|---|
| `400100` | Interest Income — Residential Mortgage | Income | Cr | IS | ANB | N | RTL Finance |
| `400300` | Interest Income — Consumer Instalment | Income | Cr | IS | ANB | N | RTL Finance |
| `400400` | Interest Income — Credit Card | Income | Cr | IS | ANB | N | Cards Finance |
| `401100` | Interest Income — C&I | Income | Cr | IS | ANB | N | CBK Finance |
| `401200` | Interest Income — CRE | Income | Cr | IS | ANB | N | CBK Finance |
| `402100` | Interest Income — Corporate / Syndicated | Income | Cr | IS | ANB | N | CIB Finance |
| `403100` | Interest Income — Wealth Lending | Income | Cr | IS | ANB | N | WAM Finance |
| `410100` | Interest Income — Taxable Securities | Income | Cr | IS | ALL | N | Treasury |
| `410200` | Interest Income — Tax-Exempt Securities | Income | Cr | IS | ANB | N | Treasury |
| `420100` | Interest Income — Fed Funds Sold / Reverse Repo | Income | Cr | IS | ALL | N | Treasury |
| `420300` | Interest Income — Other | Income | Cr | IS | ALL | N | Financial Control |

---

### 8.5 Interest Expense (`500000`–`599999`)

| Account | Name | Type | NB | FS | LE | SOX | Recon Owner |
|---|---|---|---|---|---|---|---|
| `500200` | Interest Expense — Retail Savings | Expense | Dr | IS | ANB | N | Deposit Accounting |
| `500300` | Interest Expense — Retail Time | Expense | Dr | IS | ANB | N | Deposit Accounting |
| `501100` | Interest Expense — Commercial Deposits | Expense | Dr | IS | ANB | N | CBK Finance |
| `502100` | Interest Expense — Corporate Deposits | Expense | Dr | IS | ANB | N | CIB Finance |
| `510100` | Interest Expense — Fed Funds / Repo | Expense | Dr | IS | ALL | N | Treasury |
| `510200` | Interest Expense — FHLB Advances | Expense | Dr | IS | ANB | N | Treasury |
| `511100` | Interest Expense — Long-Term Debt | Expense | Dr | IS | AFG/ANB | Y | Treasury / GFC |
| `511200` | Interest Expense — Subordinated Debt | Expense | Dr | IS | AFG/ANB | Y | Treasury / GFC |
| `520200` | Interest Expense — Other Borrowings | Expense | Dr | IS | ALL | N | Treasury |

---

### 8.6 Fee / Noninterest Income (`600000`–`649999`) and Other Income (`650000`–`699999`)

| Account | Name | Type | NB | FS | LE | SOX | Recon Owner |
|---|---|---|---|---|---|---|---|
| `600100` | Fee Income — Deposit Service Charges | Income | Cr | IS | ANB | N | RTL Finance |
| `600300` | Fee Income — Card Interchange (net presentation per policy) | Income | Cr | IS | ANB | N | Cards Finance |
| `610100` | Fee Income — Treasury Management | Income | Cr | IS | ANB | N | CMB/CIB Finance |
| `610200` | Fee Income — Trade Services | Income | Cr | IS | ALL | N | CIB Finance |
| `620100` | Fee Income — Investment Banking / Advisory | Income | Cr | IS | SEC/ANB | Y | CIB Finance |
| `620200` | Fee Income — Underwriting | Income | Cr | IS | SEC | Y | Securities Finance |
| `620300` | Fee Income — Brokerage Commissions | Income | Cr | IS | SEC | N | Securities Finance |
| `630100` | Fee Income — Asset Management | Income | Cr | IS | AAM | Y | WAM Finance |
| `630200` | Fee Income — Financial Advice / Planning | Income | Cr | IS | ANB/AAM | N | WAM Finance |
| `630300` | Fee Income — Trust & Fiduciary | Income | Cr | IS | Trust | Y | Trust Finance |
| `650100` | Other Income — Gains on Sale of Securities | Income | Cr | IS | ALL | Y | Treasury |
| `650200` | Other Income — Gains on Sale of Loans | Income | Cr | IS | ANB | Y | RTL/CBK Finance |
| `660100` | Trading Gains/(Losses) — Debt | Income | Cr/Dr | IS | ALL | Y | Markets Control |
| `660200` | Trading Gains/(Losses) — Equity | Income | Cr/Dr | IS | ALL | Y | Markets Control |
| `660300` | Trading Gains/(Losses) — Derivatives | Income | Cr/Dr | IS | ALL | Y | Markets Control |
| `670100` | FX Gains/(Losses) — Transaction | Income | Cr/Dr | IS | ALL | N | Treasury |

---

### 8.7 Operating Expenses (`700000`–`799999`)

#### Personnel (`710000`–`719999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `710100` | Base Salaries — Domestic | Expense | Dr | IS | Y | Payroll / GFC |
| `710200` | Base Salaries — International | Expense | Dr | IS | Y | Payroll / GFC |
| `711100` | Incentive Compensation — Cash | Expense | Dr | IS | Y | Comp Finance |
| `711200` | Incentive Compensation — Equity Accrual | Expense | Dr | IS | Y | Comp Finance |
| `712100` | Employee Benefits — Medical / Welfare | Expense | Dr | IS | N | HR Finance |
| `712200` | Employee Benefits — Retirement / 401(k) | Expense | Dr | IS | Y | HR Finance |
| `712300` | Payroll Taxes & Social Charges | Expense | Dr | IS | Y | Payroll |
| `713100` | Severance & Restructuring Payroll | Expense | Dr | IS | Y | HR / FP&A |

#### Occupancy (`720000`–`729999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `720100` | Rent — Branches | Expense | Dr | IS | N | Corporate RE |
| `720200` | Rent — Offices / HQ | Expense | Dr | IS | N | Corporate RE |
| `720300` | Rent — Contact Centres / Data Halls | Expense | Dr | IS | N | Corporate RE / ITO |
| `721100` | Utilities — Branches | Expense | Dr | IS | N | RTL Facilities |
| `721200` | Utilities — Corporate | Expense | Dr | IS | N | Corporate RE |
| `722100` | Property Taxes & Assessments | Expense | Dr | IS | N | Corporate RE |
| `723100` | Security Guards & Physical Security | Expense | Dr | IS | N | Corporate Security |
| `724100` | Facilities Management Outsourcing | Expense | Dr | IS | N | ADM / PRC |

#### Technology (`730000`–`739999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `730100` | Cloud Infrastructure — Production | Expense | Dr | IS | N | ITO FinOps |
| `730200` | Software Subscriptions / SaaS | Expense | Dr | IS | N | ITO FinOps |
| `730300` | Telecom — Voice / Data / Network | Expense | Dr | IS | N | ITO |
| `731200` | Market Data & Pricing Feeds | Expense | Dr | IS | N | CIB/TM Finance |
| `732100` | Cybersecurity Tools & SOC Platforms | Expense | Dr | IS | Y | ISC Finance |
| `732200` | Core Banking Run Costs (opex) | Expense | Dr | IS | N | ITO |
| `733100` | IT Disaster Recovery & Resilience OpEx | Expense | Dr | IS | N | ITO |

#### Professional Services (`740000`–`749999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `740100` | Consulting — Strategy / Ops | Expense | Dr | IS | N | Dept / PRC |
| `740200` | Consulting — Technology Integrators (opex) | Expense | Dr | IS | N | ITO |
| `740300` | External Audit Fees (opex portion) | Expense | Dr | IS | Y | GFC |
| `742100` | Recruitment Agency Fees | Expense | Dr | IS | N | HRM |

#### Travel, Meals, Entertainment (`750000`–`759999`) — **canonical for Expense Policy**

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `750100` | Travel — Transportation & Lodging | Expense | Dr | IS | N | Fin Ops T&E |
| `750200` | Meals — Business | Expense | Dr | IS | N | Fin Ops T&E |
| `750300` | Entertainment — Client & Business | Expense | Dr | IS | Y | Fin Ops / Compliance |

#### Marketing (`760000`–`769999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `760100` | Advertising — Media | Expense | Dr | IS | N | MKT |
| `760200` | Digital Marketing & Performance Media | Expense | Dr | IS | N | MKT |
| `760300` | Sponsorships & Brand Partnerships | Expense | Dr | IS | N | MKT |
| `760400` | Customer Remediation / Goodwill (expense) | Expense | Dr | IS | Y | CST / CMP |

#### Training (`770000`–`779999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `770100` | Training — Mandatory Regulatory | Expense | Dr | IS | N | HRM L&D |
| `770200` | Training — Technical / Role-Based | Expense | Dr | IS | N | HRM L&D |
| `770300` | Training — Leadership & External Courses | Expense | Dr | IS | N | HRM L&D |

#### Compliance, Risk, Audit, Legal External (`780000`–`789999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `780100` | External Legal — Litigation & Regulatory | Expense | Dr | IS | Y | Legal |
| `780200` | Regulatory Examination & Assessment Support | Expense | Dr | IS | N | CMP / FIN |
| `780300` | AML / Sanctions Screening Vendors | Expense | Dr | IS | Y | CMP |
| `780400` | Model Validation External | Expense | Dr | IS | N | RSK |
| `780500` | External Audit Co-source / IA Support | Expense | Dr | IS | N | IAD |
| `781100` | Compliance Monitoring Tools (non-`730`) | Expense | Dr | IS | N | CMP |

#### Other OpEx / Depreciation / Amortisation (`790000`–`799999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `790100` | Depreciation — Furniture & Branch FF&E | Expense | Dr | IS | N | Corporate RE |
| `790200` | Depreciation — IT Hardware | Expense | Dr | IS | N | ITO Asset Mgmt |
| `790300` | Amortisation — Software | Expense | Dr | IS | Y | ITO / GFC |
| `790400` | Amortisation — Other Intangibles | Expense | Dr | IS | Y | GFC |
| `791100` | FDIC Insurance Assessments | Expense | Dr | IS | Y | Treasury / FIN |
| `791200` | Other Regulatory Assessments | Expense | Dr | IS | Y | FIN Reg Reporting |
| `792100` | Operational Losses / Charge-offs (non-credit) | Expense | Dr | IS | Y | RSK Ops / GFC |
| `794100` | Miscellaneous Operating Expense | Expense | Dr | IS | N | Fin Ops |
| `795100` | Branch Operating Supplies | Expense | Dr | IS | N | RTL |
| `795200` | Corporate Banking Client Coverage Support | Expense | Dr | IS | N | CBK |
| `795400` | Treasury Operations Expense (non-interest) | Expense | Dr | IS | N | TRY |

---

### 8.8 Provisions / Credit Losses (`800000`–`849999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `800100` | Provision for Credit Losses — Consumer | Expense | Dr | IS | Y | Credit Risk Finance |
| `800200` | Provision for Credit Losses — Mortgage | Expense | Dr | IS | Y | Credit Risk Finance |
| `800300` | Provision for Credit Losses — Commercial | Expense | Dr | IS | Y | Credit Risk Finance |
| `800400` | Provision for Credit Losses — Corporate | Expense | Dr | IS | Y | Credit Risk Finance |
| `820100` | Off-Balance Sheet Credit Provision | Expense | Dr | IS | Y | Credit Risk Finance |

PCL is **never** posted to departmental OpEx ranges. Budget ownership sits with Credit Risk / CFO under the provision plan in `ANB-FIN-BUD-0005`, not with `BUD-FY26-*-OPEX`.

---

### 8.9 Tax Expense (`850000`–`899999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `850100` | Current Tax Expense — Federal / National | Expense | Dr | IS | Y | Tax |
| `850200` | Current Tax Expense — State / Local | Expense | Dr | IS | Y | Tax |
| `860100` | Deferred Tax Expense / (Benefit) | Expense | Dr/Cr | IS | Y | Tax |

---

### 8.10 Intercompany, Memo, Suspense (`900000`–`999999`)

| Account | Name | Type | NB | FS | SOX | Recon Owner |
|---|---|---|---|---|---|---|
| `900100` | Intercompany Receivable — Affiliates | Asset | Dr | BS | Y | Intercompany Hub |
| `900200` | Intercompany Payable — Affiliates | Liability | Cr | BS | Y | Intercompany Hub |
| `901100` | Intercompany Revenue — Service Charges | Income | Cr | IS | Y | Intercompany Hub |
| `901200` | Intercompany Expense — Service Charges | Expense | Dr | IS | Y | Intercompany Hub |
| `910100` | Memo — Funds Transfer Pricing Income | Memo | Cr | IS | N | ALM / FP&A |
| `910200` | Memo — Funds Transfer Pricing Expense | Memo | Dr | IS | N | ALM / FP&A |
| `920100` | Off-Balance — Commitments Notional (memo) | Memo | — | Memo | N | Credit Ops |
| `990100` | GL Suspense — Interface Rejects | Asset/Liab | Dr/Cr | BS | Y | Finance Systems |
| `990200` | GL Suspense — Unmapped Accounts | Asset/Liab | Dr/Cr | BS | Y | GFC |
| `999900` | Error Correction Control | Asset/Liab | Dr/Cr | BS | Y | GFC |

Intercompany accounts eliminate in `BOOK-CONS-GROUP`. FTP memo accounts must net to zero at Group level each period (`ANB-FIN-SOP-0003` checkpoint).

---

## 9. Books / Ledgers

| Book ID | Basis | Primary Use |
|---|---|---|
| `BOOK-USGAAP-ANB` | US GAAP | Primary bank and holding company reporting |
| `BOOK-IFRS-UK` | IFRS as adopted in UK | Apex National Bank (UK) plc statutory |
| `BOOK-IFRS-EU` | IFRS as adopted in EU | Apex Bank Europe SE statutory |
| `BOOK-CONS-GROUP` | Consolidation (US GAAP group view) | Group consolidated statements; IC elimination |

Management ledgers in ApexInsight derive from these books; they do not invent natural accounts.

---

## 10. Accounting Periods

| Period ID | Meaning |
|---|---|
| `AP-2026-01` … `AP-2026-12` | Calendar months January–December 2026 |
| `CQ-2026-Q1` … `CQ-2026-Q4` | Management quarters (aggregates of AP) |
| `FY-2026` | Fiscal year 2026 |

Period status (Open / Soft Close / Hard Close / Locked) is controlled under `ANB-FIN-SOP-0003`. Reopening a Locked period requires **CFO approval and Audit Committee notification**.

---

## 11. Currencies and Tax Codes

| Currency | Use |
|---|---|
| `USD` | Functional currency — ANB N.A., AFG |
| `GBP` | UK subsidiary |
| `EUR` | EU subsidiary |
| `INR` | Apex GSC (India) — local books; USD reporting overlay |
| `SGD` / `HKD` / others | Branch and booking centre as required |

| Tax Code | Meaning |
|---|---|
| `TX-000` | Non-taxable / out of scope |
| `TX-100` | US standard taxable |
| `TX-200` | US tax-exempt securities related |
| `TX-300` | UK VAT recoverable |
| `TX-310` | UK VAT non-recoverable |
| `TX-400` | EU VAT recoverable |
| `TX-500` | India GST input |

---

## 12. Account Attributes and Master Data Governance

### 12.1 Mandatory Attributes on Every Natural Account

Account number; name; description; account type; normal balance; BS/IS; allowed books; allowed legal entities; open item management flag; reconciliation required flag; SOX critical flag; reconciliation owner; default cost centre (optional); product mapping (optional); Call Report map key; FINREP map key; freeze status; effective date; retirement date.

### 12.2 New Account Request

1. Requester (G6+) raises ApexServe ticket **GL Master Data Request** stating economic nature, expected volume/value, why no existing account fits, proposed Call Report/FINREP mapping, and SOX assessment.
2. Accounting Policy (`EMP-600109`) validates definition.
3. Group Financial Controller (`EMP-600101`) approves.
4. Head of Internal Controls & SOX (`EMP-600110`) concurs if SOX critical.
5. Finance Systems configures ApexLedger under segregation of duties (requester ≠ approver ≠ configurator).
6. FP&A links budget mapping if the account is OpEx/CapEx relevant (`ANB-FIN-BUD-0005`).
7. ApexRegRep mapping updated by `EMP-600106` Farhan Siddiqui when regulatory-facing.

SLA: 10 business days standard; 3 business days close-critical.

### 12.3 Freeze / Reclass / Retirement

**Freeze** (no new postings) requires GFC approval; status `FROZEN`. **Reclass** requires journals under `ANB-FIN-SOP-0003`, approval per `ANB-FIN-MTX-0009`, same BS/IS character unless GFC approves restatement-class entries, and `RET-FIN-10Y` evidence. Reclass must not bypass budget control (`ANB-FIN-BUD-0005` §12). **Retirement** after 12 consecutive zero-balance periods; numbers are never reused.

---

## 13. Regulatory Mapping (High Level)

### 13.1 US Call Report / FR Y-9C (illustrative)

| CoA Cluster | Typical Call Report / Y-9C Destination |
|---|---|
| `100100`–`101300` | Cash & balances due from depository institutions |
| `110100`–`113100` | Securities |
| `120100`–`124100`, `130100` | Loans and leases, net of allowance |
| `200100`–`204100` | Deposits |
| `210100`–`212200` | Borrowings & long-term debt |
| `300100`–`350100` | Equity capital |
| `400100`–`420300` / `500100`–`520200` | Interest income / interest expense |
| `600100`–`640100` | Noninterest income |
| `710000`–`795400` | Noninterest expense |
| `800100`–`820100` | Provision for credit losses |
| `850100`–`870100` | Applicable income taxes |

Detailed line-item maps are maintained in ApexRegRep master data owned by `EMP-600106`.

### 13.2 FINREP (UK/EU entities)

| CoA Cluster | FINREP Theme |
|---|---|
| Assets `1xxxxx` | F 01.01 Balance sheet assets |
| Liabilities `2xxxxx` | F 01.02 Balance sheet liabilities |
| Equity `3xxxxx` | Equity |
| NII `4xxxxx`/`5xxxxx` | Interest income/expense |
| Fee income `6xxxxx` | Fee and commission income |
| OpEx `7xxxxx` | Administrative expenses / depreciation |
| PCL `8xxxxx` | Impairment |

Local chart of accounts is **not** created for FINREP; mapping tables bridge `BOOK-IFRS-UK` / `BOOK-IFRS-EU` to FINREP templates.

---

## 14. Controls

| Control ID | Description | Frequency | Owner |
|---|---|---|---|
| `CTL-FIN-COA-01` | Only approved natural accounts accept postings | Continuous | Finance Systems |
| `CTL-FIN-COA-02` | Accounting string validation at entry | Continuous | Finance Systems |
| `CTL-FIN-COA-03` | SOX-critical accounts reconciled per calendar | Monthly | Named recon owners |
| `CTL-FIN-COA-04` | Suspense aged ≤ 30 days at Hard Close | Monthly | GFC |
| `CTL-FIN-COA-05` | GL master changes reconcile to approved tickets | Monthly | `EMP-600110` |
| `CTL-FIN-COA-06` | SoD on GL master maintenance | Quarterly | Finance Systems |
| `CTL-FIN-COA-07` | Regulatory map completeness tested | Quarterly | `EMP-600106` |

---

## 15. Related Documents

| Document ID | Title | Relationship |
|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | Entities, systems, departments |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | Metadata |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy | `T5.1` path |
| `ANB-ADM-STD-0007` | Document Naming and Versioning | ID rules |
| `ANB-ADM-POL-0001` | Records Retention Policy | Retention |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | Authority context |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `BP-FIN-COA` |
| `ANB-HRM-HBK-0001` / `ANB-HRM-POL-0005` / `ANB-HRM-POL-0006` / `ANB-HRM-POL-0008` / `ANB-HRM-SOP-0007` | Key HR governance set | Conduct, performance, training, recruitment coding |
| `ANB-FIN-POL-0001` | Expense Policy | Must use `750100`/`750200`/`750300` |
| `ANB-FIN-POL-0002` | Travel Policy | Travel driving `750100` |
| `ANB-FIN-BUD-0005` | Enterprise Budget FY2026 | Budget codes ↔ CC ↔ GL |
| `ANB-FIN-STD-0004` | This Standard | — |
| `ANB-FIN-SOP-0003` | Financial Closing SOP | Period control, suspense |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy | CIP / capitalisation / `15xxxx` |
| `ANB-FIN-POL-0007` | Corporate Card Policy | Card clearing liabilities |
| `ANB-FIN-SOP-0008` | Vendor Payment Procedure | AP / vendor posting |
| `ANB-FIN-MTX-0009` | Finance Approval Authority Matrix | Journal and master-data authority |

---

## 16. Appendix A — Cost Centre × GL Posting Rules

| Rule ID | Rule |
|---|---|
| R1 | OpEx `700000`–`799999` requires `CC-*` and budget availability check in ApexSource |
| R2 | Branch cash and vault accounts post with `CC-RTL-100` (or child branch CC rolling to it) |
| R3 | Corporate banking coverage OpEx posts to `CC-CBK-200` with `PC-CMB-001` or `PC-CIB-001` |
| R4 | Technology run OpEx posts to `CC-ITO-100`; cybersecurity tools `732100` prefer `CC-ISC-100` |
| R5 | Travel/meals/entertainment `750100`–`750300` post to claimant’s home cost centre |
| R6 | PCL `800000`–`849999` posts centrally; not to RTL/CBK OpEx budgets |
| R7 | Interest income/expense may use Treasury or product CC per ALM rules; profit centre mandatory |
| R8 | CapEx / CIP `151100`–`151400` require `CAP-2026-####` ≠ `CAP-000000` |
| R9 | Intercompany `900100`–`902200` require `IC-###` ≠ `IC-000` |
| R10 | Marketing `760000`–`769999` posts to `CC-MKT-100` unless campaign chargeback approved by FP&A |
| R11 | Training `770000`–`779999` posts to consuming CC; HRM may hold enterprise curriculum in `CC-HRM-100` |
| R12 | External legal `780100` posts to `CC-LEG-100` unless matter-coded to BU with Legal concurrence |
| R13 | Depreciation `790100`–`790300` posts to asset-owner CC or enterprise pool `CC-ADM-100` / `CC-FIN-400` per allocation |
| R14 | FDIC `791100` posts to `CC-TRY-100` or `CC-FIN-400` as designated annually by GFC |
| R15 | Suspense `990100`/`990200` owned by Finance Systems / GFC; aged items escalate per close SOP |

---

## 17. Appendix B — Canonical Entity Register

### B.1 Natural Account Ranges (summary)

See §8. **Listed accounts in this Standard: 185** discrete `######` rows in §8.1–§8.10.

### B.2 Cost Centres

`CC-FIN-100`, `CC-FIN-200`, `CC-FIN-300`, `CC-FIN-400`, `CC-RTL-100`, `CC-RTL-412`, `CC-CBK-200`, `CC-ITO-100`, `CC-ISC-100`, `CC-HRM-100`, `CC-CMP-100`, `CC-RSK-100`, `CC-TRY-100`, `CC-ADM-100`, `CC-PRC-100`, `CC-MKT-100`, `CC-LEG-100`, `CC-IAD-100`, `CC-CST-100`.

### B.3 Profit Centres

`PC-CRB-001`, `PC-CMB-001`, `PC-CIB-001`, `PC-WAM-001`, `PC-TM-001`.

### B.4 Books

`BOOK-USGAAP-ANB`, `BOOK-IFRS-UK`, `BOOK-IFRS-EU`, `BOOK-CONS-GROUP`.

### B.5 Periods

`AP-2026-01` … `AP-2026-12`; `CQ-2026-Q1` … `CQ-2026-Q4`; `FY-2026`.

### B.6 Currencies (core)

`USD`, `GBP`, `EUR`, `INR`, `SGD`, `HKD`.

### B.7 Tax Codes (core)

`TX-000`, `TX-100`, `TX-200`, `TX-300`, `TX-310`, `TX-400`, `TX-500`.

### B.8 Capital Projects (GL-relevant examples)

`CAP-2026-0088`, `CAP-2026-0142`, `CAP-2026-0210`, `CAP-2026-0031`, `CAP-2026-0099`, plus others in `ANB-FIN-BUD-0005` Appendix C.

### B.9 Budget Codes (GL commitment link)

`BUD-FY26-<DEPT>-OPEX`, `BUD-FY26-<DEPT>-CAPEX`, `BUD-FY26-GRP-CAPEX` — full register in `ANB-FIN-BUD-0005`.

---

## 18. Document Control

| Version | Date | Author | Change |
|---|---|---|---|
| 4.0 | 2025-11-14 | `EMP-600109` Rosalind Mbeki | Unified GL scheme; `750100`/`750200`/`750300` travel/meals/entertainment; canonical CC/PC/Book/Period IDs; biennial review confirmation |

**Approval:** Group Financial Controller `EMP-600101` Gemma Ashworth (Document Owner); Chief Financial Officer `EMP-100002` Priya Raghunathan (Approver).

— End of Document `ANB-FIN-STD-0004` —
