# Apex National Bank — Financial Closing Standard Operating Procedure

**Finance SOP | Month-End, Quarter-End, and Year-End Close**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-SOP-0003` |
| **Document Title** | Apex National Bank — Financial Closing Standard Operating Procedure |
| **Version** | 1.0 |
| **Status** | Approved — In Force |
| **Classification** | Confidential (`C2`) |
| **Owner** | Finance Department (FIN) — Financial Control |
| **Document Owner (named)** | `EMP-600101` Gemma Ashworth, Group Financial Controller (G9) |
| **Custodian** | `EMP-600122` James Okonkwo, Close Manager (G5) |
| **Approver** | `EMP-600101` Gemma Ashworth, Group Financial Controller (G9) |
| **Secondary Approvers** | `EMP-100002` Priya Raghunathan, CFO (G11) — year-end attestation pack; `EMP-600110` Teresa Villanueva, Head of Internal Controls & SOX (G8) — ICFR evidence schedule |
| **Author** | `EMP-600122` James Okonkwo, Close Manager (G5) |
| **Created Date** | 2026-06-01 |
| **Effective Date** | 2026-08-01 |
| **Last Review Date** | 2026-07-18 |
| **Next Review Date** | 2027-07-18 |
| **Review Cycle** | Annual (mandatory interim review after any material accounting-standard change, legal-entity addition, or close-calendar redesign) |
| **Retention Code** | `RET-FIN-10Y` (close packs and journals); SOX evidence also under `RET-AUD-7Y` |
| **Taxonomy** | `T5` Finance & Treasury → `T5.1` Financial Control → Period Close → `SOP` |
| **Business Process** | `BP-FIN-CLOSE` Financial Period Close |
| **Related Processes** | `BP-FIN-JRNL`, `BP-RECN-DAILY`, `BP-RECN-SUSP`, `BP-AUD-SOX`, `BP-FIN-PLAN`, `BP-FIN-COA`, `BP-FIN-AP`, `BP-FIN-EXP`, `BP-FIN-CAP`, `BP-FIN-PAY` |
| **System of Record** | ApexLedger (SAP S/4HANA) — primary ledger `BOOK-USGAAP-ANB`; consolidation ledger `BOOK-CONS-GROUP`; ApexInsight (management reporting); ApexRegRep (regulatory packs); ApexDocs (close evidence); ApexAudit (SOX testing) |
| **Publication Location** | ApexDocs → Finance → Financial Control → Procedures |
| **Applies To** | All legal entities consolidated into Apex Financial Group, Inc.; all ledgers feeding `BOOK-CONS-GROUP` |
| **Governing Body** | Disclosure Committee (financial statement pack); Audit Committee (external reporting oversight) |
| **Language** | English (US) — authoritative version |
| **Supersedes** | Reserved ID `ANB-FIN-SOP-0003` Month-End Close Procedure (draft fragments retired 2026-07-31) |
| **Keywords** | month-end close, quarter-end, year-end, journal entry, accrual, reconciliation, trial balance, soft close, hard close, books locked, consolidation, intercompany, ICFR, SOX |

> **Standing.** This SOP expands the reserved Month-End Close Procedure into the Group's single authoritative close operating procedure covering month-end, quarter-end, and year-end. It prescribes *how* the books are closed. Accounting policy elections remain in the Group Accounting Policy Manual. Approval limits for journals and adjustments are operationalised in `ANB-FIN-MTX-0009` and must not contradict `ANB-ADM-MTX-0001` §7.1.

---

## 2. Purpose

A period close is the control event that converts continuous transaction processing into a complete, accurate, and timely set of books. At Apex National Bank, that set of books underpins Call Reports, FR Y-9C filings, SEC disclosures (where applicable at Group level), Board financial packs, regulatory capital ratios, tax computations, and management decisions that move capital.

This procedure exists to:

1. Define a **single close calendar** with named owners, hard cut-offs, and evidence requirements for every close day from T+1 through T+8 (month), with defined extensions for quarter-end and year-end.
2. Enforce **journal quality and approval thresholds** so that no material adjustment enters the ledger without the correct grade of review.
3. Require **reconciliations and suspense clearance** before soft close and hard close gates can open.
4. Produce a **certified trial balance** and financial statement pack that consolidation, Product Control, Tax, and Regulatory Reporting can all consume without rework.
5. Generate **SOX / ICFR evidence** contemporaneously — not reconstructed after the fact.
6. Control the progression from **soft close → hard close → books locked**, so late adjustments are exceptional, approved, and auditable.
7. Drive **consolidation to `BOOK-CONS-GROUP`**, including intercompany eliminations and the disclosure pack for the Disclosure Committee.

---

## 3. Scope

### 3.1 In Scope

| Area | Coverage |
|---|---|
| Period types | Month-end (`AP-2026-MM`), quarter-end, year-end adjustment period |
| Ledgers | `BOOK-USGAAP-ANB` (primary US GAAP), local statutory ledgers mapped from the unified CoA, management ledger views in ApexInsight, consolidation ledger `BOOK-CONS-GROUP` |
| Journal processing | Manual journals, system-generated accruals, automated allocations, FX revaluation, intercompany, late adjustments, reversing entries |
| Reconciliations | Balance-sheet account reconciliations, subledger-to-GL, bank and Nostro, suspense ageing (`BP-RECN-DAILY`, `BP-RECN-SUSP`) |
| Accruals | Expense, revenue (where applicable), interest, bonus, vendor, tax, depreciation (`790100`), capex-in-progress |
| Financial statements | Entity trial balances, consolidating worksheets, Group income statement, balance sheet, equity, selected notes for the Disclosure Committee pack |
| Controls | Close checklist, journal approval, reconciliation certification, suspense thresholds, soft/hard close gates, SOX key controls `CTL-FIN-CLOSE-*` |
| Systems hand-offs | ApexLedger → ApexInsight → ApexRegRep; evidence to ApexDocs; testing artefacts to ApexAudit |

### 3.2 Out of Scope

| Excluded | Governed By |
|---|---|
| Chart of Accounts structure and master-data change | `ANB-FIN-STD-0004` |
| Expense claim rules and corporate card policy | `ANB-FIN-POL-0001`, `ANB-FIN-POL-0007`, `ANB-FIN-POL-0002` |
| Vendor invoice payment execution | `ANB-FIN-SOP-0008` |
| Budget formulation and forecast cycle | `ANB-FIN-BUD-0005`, `ANB-FIN-POL-0006` |
| Credit charge-offs and specific credit provisions | Credit authority in `ANB-ADM-MTX-0001` §8 |
| External audit opinion and PCAOB/PCAOB-equivalent procedures | External auditor engagement letters; Audit Committee |
| Regulatory submission mechanics (Call Report e-file) | Regulatory Reporting playbooks under ApexRegRep |

### 3.3 Legal Entities

All entities in the Legal Entity Register under `ANB-FIN-STD-0004` §4.2 that consolidate into `BOOK-CONS-GROUP`, including `LE-110` Apex National Bank, N.A., securities, advisors, trust, European, UK, Canadian, Latin American, Middle East, and Asia entities. Materiality for close exceptions is assessed at both entity and Group levels.

---

## 4. Objectives

| # | Objective | Measure | Target |
|---|---|---|---|
| O1 | Soft close achieved on calendar | Soft-close gate passed by T+5 18:00 ET (month) | 100% of months |
| O2 | Hard close achieved on calendar | Hard-close / books locked by T+8 18:00 ET (month) | ≥ 11 of 12 months; Q/Y per §8 |
| O3 | Journal quality | Journals rejected for incomplete evidence | ≤ 3% of manual journals |
| O4 | Reconciliation completeness | Balance-sheet accounts certified before soft close | 100% of material accounts |
| O5 | Suspense hygiene | Suspense items > 30 days at hard close | Zero material items |
| O6 | Late adjustment discipline | Post-hard-close adjustments | ≤ 2 per month; zero without GFC approval |
| O7 | SOX evidence contemporaneity | Key control evidence filed same day as control performance | ≥ 98% |
| O8 | Consolidation integrity | Intercompany imbalance after eliminations | $0 at reporting currency (within $1,000 rounding) |
| O9 | Disclosure readiness | Disclosure Committee pack issued | Per §14 calendar |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Accounting Period** | Calendar month identifier `AP-2026-MM` (e.g. `AP-2026-08`); year-end adjustment period `AP-2026-13` |
| **Close Day T+n** | Business day *n* after the last calendar day of the period (T+0 = period-end date) |
| **Soft Close** | Gate at which routine subledger postings stop for the period; only approved close journals and controlled late feeds may post |
| **Hard Close** | Gate at which the entity trial balance is certified; only GFC-approved late adjustments may post |
| **Books Locked** | ApexLedger period status preventing further postings to the period without unlock authorised by GFC |
| **Journal Entry** | Documented posting identified `JE-YYYYMM-######` (e.g. `JE-202608-004821`) |
| **Accrual** | Period-end recognition of an obligation or receivable not yet invoiced or settled |
| **Reconciliation** | Documented comparison of GL balance to subledger, bank statement, or supporting schedule, with explained differences |
| **Suspense** | Temporary holding account pending identification; never a final resting place |
| **Trial Balance** | Complete list of natural account balances for a book/entity at a point in time |
| **Material Account** | Account or combination above the close materiality threshold in Appendix A |
| **ICFR / SOX Key Control** | Control designated in the SOX inventory as relevant to financial statement assertions |
| **Eliminations** | Consolidation entries removing intercompany balances and unrealised intra-group profit |
| **Disclosure Pack** | Curated financial and narrative package for the Disclosure Committee |
| **Preparer / Reviewer** | Distinct individuals; preparer may never be sole reviewer (four-eyes) |
| **Late Adjustment** | Journal proposed after hard close and before or after books locked |

---

## 6. Roles and Responsibilities

| Role | Named Holder | Responsibility |
|---|---|---|
| Chief Financial Officer (G11) | `EMP-100002` Priya Raghunathan | Owns Group financial reporting integrity; approves journals > $50M; signs management representations; chairs escalation of books unlock above GFC |
| Group Financial Controller (G9) | `EMP-600101` Gemma Ashworth | Approver of this SOP; owns close calendar, hard close, books lock/unlock, consolidation certification |
| Close Manager (G5) | `EMP-600122` James Okonkwo | Custodian; runs daily close war-room; maintains checklist in ApexDocs; tracks blockers |
| Reconciliation Lead (G4) | `EMP-600123` Fatima Al-Hassan | Owns reconciliation completion status, ageing of breaks, suspense escalation under `BP-RECN-SUSP` |
| Head of Financial Operations (G8) | `EMP-600102` Marcel Delacroix | Owns AP/AR/expense cut-offs feeding the close; payment calendar coordination with Treasury |
| Head of FP&A (G7) | `EMP-600105` Anneke Visser | Owns management reporting flash and variance commentary from ApexInsight |
| Head of Regulatory Reporting (G7) | `EMP-600106` Farhan Siddiqui | Consumes locked trial balances into ApexRegRep; owns Call Report / FR Y-9C timing interface |
| Head of Product Control (G7) | `EMP-600108` Pieter Janssen | Owns trading P&L substantiation, valuation overlays, and product-control sign-off before soft close for CIB/markets |
| Head of Accounting Policy (G8) | `EMP-600109` Rosalind Mbeki | Owns technical accounting conclusions affecting close journals; disclosure accounting positions |
| Head of Internal Controls & SOX (G8) | `EMP-600110` Teresa Villanueva | Owns `CTL-FIN-CLOSE-*` design, testing schedule, evidence standards in ApexAudit |
| Head of Accounts Payable (G7) | `EMP-600112` Colin Devereaux | Owns AP cut-off, GR/IR clearance contribution, vendor accrual feed |
| Head of Accounts Receivable (G6) | `EMP-600113` Noriko Hayashi | Owns AR cut-off and credit-memo timing |
| Head of Finance Systems (G7) | `EMP-600114` Rahul Bhattacharya | Owns ApexLedger period status, job schedules, close automation, unlock technical execution |
| Payroll Accounting Lead (G6) | `EMP-600115` Bethany Clarke | Owns payroll accrual and true-up journals |
| Head of Tax (G8) | `EMP-600107` Miriam Rosenthal | Owns tax accrual, deferred tax movements, tax provision journals (`TAX-*` codes) |
| Treasury Operations Lead (G6) | `EMP-600501` Nikolai Petrov | Owns cash and Nostro reconciliation inputs; funding and settlement cut-offs with ApexTreasury / ApexPay |
| Chief Audit Executive (G11) | `EMP-100009` Thomas Nakamura | Independent assurance over close controls; may observe war-room without operating it |
| Entity Controllers | Per entity roster | Execute entity close checklist; certify entity trial balance |
| Journal Preparers / Reviewers | Finance staff G3–G9 | Prepare and approve journals per §10 thresholds |

### 6.1 RACI — Period Close

| Activity | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Publish close calendar | Close Manager | GFC | FinOps, Tax, Product Control, Reg Reporting, Treasury | All Finance; Disclosure Committee secretary |
| Execute subledger cut-offs | Process owners (AP, AR, Payroll, FA, Treasury) | Head of FinOps / entity controller | Finance Systems | Close Manager |
| Prepare accruals & journals | Accountants / Product Control | Entity controller | Accounting Policy, Tax | Close Manager |
| Approve journals | Reviewer per §10 | Approver personally | GFC for > $10M | SOX |
| Perform reconciliations | Reconcilers | Reconciliation Lead | Subledger owners | GFC |
| Clear suspense | Process owners | Reconciliation Lead | FinOps | SOX, Internal Audit |
| Soft close gate | Close Manager | GFC | Entity controllers | ApexInsight consumers |
| Consolidation & eliminations | Consolidation team | GFC | Tax, Accounting Policy | FP&A, Reg Reporting |
| Hard close / books lock | Finance Systems (execute) | GFC | Close Manager | CFO, Disclosure Committee |
| Disclosure pack | Accounting Policy + Consolidation | GFC / CFO | Legal, Investor Relations | Disclosure Committee |
| SOX evidence filing | Control performers | Head of Internal Controls & SOX | Close Manager | External Audit |
| Late adjustment / unlock | Requestor | GFC (CFO if > $10M or after external release) | Accounting Policy, SOX | Audit Committee if post-issuance |

---

## 7. Policy and Control Statements

**C1 — Single close.** There is one Group close calendar. Local statutory deadlines do not authorise a parallel undocumented close.

**C2 — No silent postings.** Every manual journal carries preparer, reviewer, business purpose, supporting evidence in ApexDocs, and a natural-account string valid under `ANB-FIN-STD-0004`.

**C3 — Four-eyes.** Preparer and reviewer are distinct individuals. System IDs of the same person under two aliases are prohibited.

**C4 — Threshold obedience.** Journal approval grades in §10 apply. Splitting journals to avoid a threshold is a Code of Conduct violation under `ANB-HRM-POL-0004` and `ANB-ADM-MTX-0001` R-8.

**C5 — Reconciliation before soft close.** Material balance-sheet accounts must be reconciled and certified before the soft-close gate opens. Unreconciled material accounts block soft close unless GFC grants a time-bounded waiver recorded in ApexServe.

**C6 — Suspense not a parking lot.** Items in suspense > 30 days at hard close require GFC sign-off and a remediation plan; items > 60 days escalate to CFO.

**C7 — Soft close is real.** After soft close, only journals on the approved close-journal list and controlled interface late feeds may post. Back-dated operational invoices are forbidden without FinOps and GFC concurrence.

**C8 — Hard close and lock.** After hard close, the period moves to Books Locked. Unlock requires GFC written approval; post-issuance unlock also requires CFO.

**C9 — Contemporaneous SOX evidence.** Evidence for key close controls is filed in ApexDocs / ApexAudit the day the control operates. Reconstruction after quarter-end is a control deficiency.

**C10 — Consolidation integrity.** `BOOK-CONS-GROUP` may not be certified with unresolved intercompany imbalances above Appendix A tolerance.

**C11 — Authority alignment.** Financial authority in this SOP aligns to `ANB-ADM-MTX-0001` §7.1 and is detailed in `ANB-FIN-MTX-0009`. Where conflict appears, the enterprise matrix prevails and this SOP is corrected within five business days.

**C12 — Retention.** Close packs, journals, reconciliations: `RET-FIN-10Y`. Tax provision workpapers: `RET-TAX-10Y`. SOX testing evidence: `RET-AUD-7Y`.

---

## 8. Close Calendar

### 8.1 Month-End Calendar (Standard) — Example Period `AP-2026-08`

| Day | Window (ET) | Tasks | Primary Owner |
|---|---|---|---|
| **T+0** Period-end | 00:00–24:00 | Freeze non-emergency master-data changes; confirm FX rates loaded; Treasury final settlement cut-off with ApexPay/ApexTreasury; AP last regular payment run completes under `BP-FIN-PAY` | `EMP-600114` Rahul Bhattacharya; `EMP-600501` Nikolai Petrov; `EMP-600112` Colin Devereaux |
| **T+1** | 08:00–18:00 | Subledger close: AP invoice park cut-off; AR billing cut-off; payroll results import; fixed-asset depreciation run (`790100`); expense claim period cut-off in ApexLedger Expense; daily bank/Nostro recon (`BP-RECN-DAILY`) | FinOps leads; `EMP-600115` Bethany Clarke; `EMP-600123` Fatima Al-Hassan |
| **T+2** | 08:00–18:00 | Accrual packages drafted (vendor, bonus true-up, interest, facilities, cloud/utilities); Product Control flash P&L; GR/IR ageing review; suspense first sweep | Entity accountants; `EMP-600108` Pieter Janssen; AP/AR |
| **T+3** | 08:00–18:00 | Journal entry wave 1 posted/approved; tax provisional inputs; intercompany confirmations issued; reconciliation progress ≥ 70% material accounts | Journal preparers; `EMP-600107` Miriam Rosenthal; Consolidation |
| **T+4** | 08:00–18:00 | Journal wave 2 (valuation overlays, FX reval, deferrals); reconciliation progress ≥ 90%; suspense second sweep; FP&A flash vs plan in ApexInsight | Product Control; Financial Control; `EMP-600105` Anneke Visser |
| **T+5 Soft Close** | By 18:00 | Soft-close checklist complete; material recon certifications; open suspense aged ≤ policy; GFC soft-close approval; ApexLedger soft-close status set | `EMP-600122` James Okonkwo; `EMP-600101` Gemma Ashworth |
| **T+6** | 08:00–18:00 | Consolidation worksheets; intercompany eliminations; minority interest / equity pickup; entity TB vs consolidation bridge | Consolidation team; GFC |
| **T+7** | 08:00–18:00 | Group analytical review; disclosure note drafts (month: abbreviated); Reg Reporting extract validation in ApexRegRep; SOX control evidence completeness check | Accounting Policy; `EMP-600106` Farhan Siddiqui; `EMP-600110` Teresa Villanueva |
| **T+8 Hard Close / Lock** | By 18:00 | Entity and Group trial balance certification; hard close; books locked; close pack filed in ApexDocs; management flash finalised | GFC; Finance Systems; Close Manager |

### 8.2 Quarter-End Extensions

Quarter-end (`AP-2026-03`, `06`, `09`, `12`) extends the post-soft-close window:

| Day | Incremental Tasks | Owner |
|---|---|---|
| T+5 | Soft close (same gate) | GFC |
| T+6–T+7 | Full consolidating statements; CECL / allowance analytics interface with Credit; lease and CECL disclosure tables | Consolidation; Credit Finance; Accounting Policy |
| T+8–T+9 | Disclosure Committee working pack; Reg Reporting primary submissions dry-run | GFC; Farhan Siddiqui |
| T+10 | Hard close / books locked for quarter (unless CFO authorises T+11 for documented system incident) | GFC |

### 8.3 Year-End Extensions

Year-end (`AP-2026-12` plus `AP-2026-13`):

| Phase | Timing | Tasks |
|---|---|---|
| Soft close | T+5 | Same as month, plus bonus finalisation freeze with HRM/Reward |
| Technical accounting | T+6–T+12 | Subsequent events log; tax provision final (`RET-TAX-10Y` workpapers); pension/actuarial; hedge effectiveness final; legal contingency update with LEG |
| External audit support | Parallel | PBC list fulfilment; sample support from ApexDocs |
| Disclosure Committee | Per Committee calendar | Full annual disclosure pack |
| Hard close / lock | Target T+15 (Group); entity statutory may run longer under local law with bridge reconciliations | GFC / CFO |
| Period 13 | Through audit opinion date as needed | Audit adjustments only, dual-approved per §10 |

### 8.4 Close War-Room

From T+1 through hard close, the Close Manager runs a daily 09:15 ET stand-up (15 minutes) covering: blockers, journals pending approval, recon %, suspense > 15 days, system job failures, and unlock requests. Attendance: Financial Control, FinOps, Product Control (markets weeks), Tax (T+3 onward), Finance Systems, SOX (T+5 and T+8). Minutes logged in ApexDocs close pack.

---

## 9. Procedures — Pre-Close and Cut-Off

### 9.1 Pre-Close (T-5 to T-1)

1. Close Manager publishes the period-specific calendar and checklist instance for `AP-2026-MM` in ApexDocs.
2. Finance Systems confirms ApexLedger period is open, FX rate tables loaded, depreciation calendars active, and close jobs scheduled.
3. AP communicates final invoice receipt dates for period inclusion; invoices after cut-off accrue under §11.
4. Expense claims: employees reminded that claims for the period must be submitted per `ANB-FIN-POL-0001`; unsubmitted material travel accrued by FinOps estimate.
5. Procurement / Capex: assets placed in service reported for capitalisation (`BP-FIN-CAP`, accounts `15xxxx`).
6. Treasury confirms settlement calendars and holiday variants for Nostro cut-off.

### 9.2 Subledger Cut-Off (T+0 / T+1)

| Subledger | Cut-Off Rule | GL Impact |
|---|---|---|
| Accounts Payable | No new AP invoices parked after T+1 12:00 ET for period `AP-2026-MM` without Close Manager override | `23xxxx` AP; expense/asset |
| Accounts Receivable | Billing run final; credit memos after cut-off in next period unless revenue cut-off exception | AR / revenue |
| Expense | Corporate card feed and claims freeze for period coding | `7xxxxx` OpEx including `750100` Travel, `750200` Meals, `750300` Entertainment |
| Fixed Assets | Depreciation posted; CIP transfers completed | `15xxxx`; `790100` |
| Payroll | Payroll journal and accrual true-up | Salary / accrual liability |
| Treasury / Payments | Final ACH/WIRE/SWIFT/SEPA settlements reflected | Cash / clearing |

---

## 10. Journal Entries — Standards and Approval Thresholds

### 10.1 Journal Standards

Every manual journal `JE-YYYYMM-######` must include:

- Header: period, book (`BOOK-USGAAP-ANB` or other), company code, currency, journal type (accrual, reclass, correction, elimination, tax, FX, other)
- Line-level accounting string per `ANB-FIN-STD-0004`
- Business purpose (specific; “month-end accrual” alone is insufficient)
- Supporting calculation or subledger extract in ApexDocs
- Preparer and reviewer electronic approval in ApexLedger workflow
- Reversal instruction (auto-reverse next period / permanent / scheduled)

### 10.2 Approval Thresholds (Absolute Value of Journal, USD Equivalent)

| Threshold (USD) | Minimum Preparer Grade | Minimum Reviewer / Approver | Additional Requirement |
|---|---|---|---|
| < $100,000 | G3+ | G4+ reviewer | Standard evidence |
| $100,000 – < $1,000,000 | G4+ | G6+ | Evidence + analytical reasonableness |
| $1,000,000 – < $10,000,000 | G5+ | G8+ (typically FinOps, Product Control, or Accounting Policy) | GFC notified via close dashboard |
| $10,000,000 – < $50,000,000 | G6+ | G9 GFC (`EMP-600101`) | Written memo in ApexDocs |
| ≥ $50,000,000 | G7+ | CFO (`EMP-100002`) | GFC countersignature; Disclosure Committee informed if P&L or capital impacting |

Thresholds apply to the **absolute value of the largest balancing side**, not the net. Linked journals that are economically one adjustment are aggregated (`ANB-ADM-MTX-0001` R-9).

### 10.3 Special Journal Categories

| Category | Extra Control |
|---|---|
| Intercompany | Both entities must confirm; imbalance blocks consolidation |
| Tax (`TAX-*` codes) | Head of Tax review for provision journals above $1M |
| FX revaluation | System run preferred; manual overlay requires Product Control or GFC |
| Audit adjustment (Period 13) | External auditor alignment logged; GFC + CFO if ≥ $10M |
| Recurring template | Annual re-approval of template logic by account owner |

### 10.4 Example — Accrual Journal

**Journal ID:** `JE-202608-004821`  
**Period:** `AP-2026-08`  
**Book:** `BOOK-USGAAP-ANB`  
**Purpose:** Accrue August cloud infrastructure usage for `VCAT-CLOUD` vendor `VND-10028441` where invoice `INV-9928471103` is expected in September; PO `PO-778201` supports commitment.  
**Preparers:** Entity accountant (G4)  
**Reviewer:** G6 Financial Control  
**Lines (illustrative):** Dr `720200` Cloud Computing Expense $482,600 / Cr `231100` Accrued Expenses $482,600  
**Evidence:** Usage report from ApexSource-linked cloud portal; PO residual; email confirmation of billing cycle.  
**Reversal:** Auto-reverse `AP-2026-09`.

### 10.5 Example — Reclassification

**Journal ID:** `JE-202608-004955`  
**Purpose:** Reclassify travel posted to `750100` that was client-billable entertainment miscode to `750300` for two deals (Policy alignment with `ANB-FIN-POL-0001`).  
**Amount:** $18,440  
**Approver:** G4 reviewer sufficient.

---

## 11. Accruals

### 11.1 Mandatory Accrual Categories

| Category | Owner | Method |
|---|---|---|
| Vendor goods/services received not invoiced | AP / cost centre | PO receipt vs invoice; threshold $5,000 per vendor unless aggregate material |
| Employee expense incurred not claimed | FinOps | Statistical + known trips |
| Payroll and incentives | Payroll Accounting / Reward | Days earned vs paid; bonus plans |
| Interest and fees | Treasury / Product Control | Effective interest / contract |
| Tax current provision step-up | Tax | `TAX-*` computation |
| Depreciation / amortisation true-up | Fixed Assets | System run + manual CIP |
| Legal and contingency (accounting) | Accounting Policy with LEG | ASC 450 / IFRS aligned Group policy |
| Cloud, utilities, leases | FinOps / Corporate Real Estate | Contract schedules |

### 11.2 Accrual Quality Rules

- Accruals below $5,000 may be omitted only if the account's aggregate omitted population is immaterial per Appendix A.
- Manual accruals require the same approval thresholds as §10.
- “Plug to budget” accruals are prohibited. Accruals estimate **obligation incurred**, not budget remaining (`ANB-FIN-BUD-0005` is not an accrual methodology).

---

## 12. Reconciliations and Suspense

### 12.1 Reconciliation Procedure (`BP-RECN-DAILY` / period certification)

1. Reconciler extracts GL balance from ApexLedger for the account and date.
2. Obtains subledger, bank statement, or schedule.
3. Matches; investigates breaks; ages open items.
4. Documents reconciling items with owners and due dates.
5. Certifies in ApexLedger reconciliation module / ApexDocs checklist.
6. Reviewer (minimum one grade above or designated control reviewer) signs off for material accounts.

### 12.2 Suspense Management (`BP-RECN-SUSP`)

| Age | Action |
|---|---|
| 0–7 days | Process owner clears in normal workflow |
| 8–15 days | Reconciliation Lead escalates to process owner’s G6 |
| 16–30 days | Escalation to Head of FinOps or entity controller; daily war-room item |
| > 30 days at hard close | GFC waiver + remediation plan required |
| > 60 days | CFO notification; ORC risk event consideration |

Suspense accounts are never used to hold known P&L items across a hard close without GFC approval.

### 12.3 Example — Suspense Clearance

On T+4 for `AP-2026-08`, reconciliation identifies $126,500 in unapplied cash suspense related to wire `PAY-WIRE-884201`. Treasury Operations (`EMP-600501`) matches to customer pending advice; AR posts application journal `JE-202608-005102` before soft close.

---

## 13. Soft Close, Hard Close, and Books Locked

### 13.1 Soft Close Gate Criteria

All must be true (or waived in ApexServe by GFC):

1. Subledger cut-offs confirmed.  
2. ≥ 100% of material account reconciliations certified (or waived).  
3. Suspense > 30 days = zero material, or waived.  
4. Product Control sign-off for markets entities.  
5. Journal queue for wave 1–2 cleared or explicitly deferred to consolidation-only list.  
6. Close Manager checklist status “Soft Close Ready”.  

**GFC approval** sets ApexLedger soft-close status. Operational AP/AR entry for the period stops.

### 13.2 Hard Close Gate Criteria

1. Soft close complete.  
2. Consolidation eliminations posted and IC imbalance within tolerance.  
3. Group analytical review complete; unexplained variances resolved or disclosed to GFC.  
4. Tax provision step for the period posted (month: roll-forward; quarter/year: expanded).  
5. SOX key control evidence complete for the period’s close controls.  
6. Entity controllers’ trial balance certificates filed.  

**GFC approval** → Finance Systems sets **Books Locked**.

### 13.3 Unlock Protocol

| Scenario | Approver | Evidence |
|---|---|---|
| Pre-issuance error, < $10M | GFC | Unlock ticket; correcting `JE-`; re-lock same day |
| Pre-issuance, ≥ $10M | GFC + CFO | Memo; Disclosure Committee secretary informed |
| Post-external issuance / regulatory filing | CFO + notification to Audit Committee Chair | Restatement assessment with Accounting Policy |
| System failure preventing lock on calendar day | GFC | Incident record; catch-up plan |

---

## 14. Trial Balance, Consolidation, and Disclosure Pack

### 14.1 Trial Balance Certification

Each entity controller certifies: completeness of journals, reconciliation status, suspense representation, and that the TB in `BOOK-USGAAP-ANB` (or local book mapped to Group CoA) is fairly stated for close purposes. Certificates stored under `RET-FIN-10Y`.

### 14.2 Consolidation to `BOOK-CONS-GROUP`

1. Load entity TBs.  
2. Align accounting policies / reporting currency translation.  
3. Post elimination journals (income statement and balance sheet).  
4. Validate intercompany matrix = $0 (± $1,000).  
5. Compute NCI, equity consolidation, and investment elimination.  
6. Produce consolidating worksheet for the close pack.  

### 14.3 Intercompany Eliminations — Example

Entities `LE-110` and `LE-200` record reciprocal service fees. Elimination `JE-202608-006200` in `BOOK-CONS-GROUP` removes revenue and expense $2,450,000 and related AR/AP, after both entity controllers confirm balances in the intercompany portal.

### 14.4 Disclosure Committee Pack

Month-end: abbreviated pack (TB bridge, top variances, subsequent events check, regulatory capital flash pointer).  
Quarter / year: full pack — primary statements, selected notes, legal contingency update, subsequent events, representation status, open audit items. Pack issued via ApexDocs; Classification C2.

---

## 15. SOX / ICFR Evidence (`BP-AUD-SOX`)

| Control ID | Control Description | Evidence | Performer | Reviewer |
|---|---|---|---|---|
| `CTL-FIN-CLOSE-01` | Close calendar published and followed | Calendar + daily tracker | Close Manager | GFC |
| `CTL-FIN-CLOSE-02` | Journal approval at threshold | ApexLedger workflow audit | Preparer/Approver | SOX testing |
| `CTL-FIN-CLOSE-03` | Material BS recon certification | Signed recon | Reconciler | Reconciliation Lead |
| `CTL-FIN-CLOSE-04` | Soft close approval | Gate checklist | Close Manager | GFC |
| `CTL-FIN-CLOSE-05` | Hard close / lock | Period status log | Finance Systems | GFC |
| `CTL-FIN-CLOSE-06` | Intercompany elimination completeness | IC matrix | Consolidation | GFC |
| `CTL-FIN-CLOSE-07` | Suspense ageing review | Ageing report + actions | Reconciliation Lead | Head of FinOps |
| `CTL-FIN-CLOSE-08` | Management review of TB / results | Analytical review pack | FP&A / Controllership | GFC or CFO (Q/Y) |

Evidence retention: `RET-AUD-7Y` in ApexAudit; operational copies in close pack `RET-FIN-10Y`.

---

## 16. Process Flows

### 16.1 Month-End Close Flow

```
T-5..T-1 Pre-Close prep
    → T+0/T+1 Subledger cut-offs & system jobs
        → T+2..T+4 Accruals, journals, reconciliations, suspense sweeps
            → T+5 SOFT CLOSE GATE (GFC)
                → T+6..T+7 Consolidation, analytics, reg extract QA
                    → T+8 HARD CLOSE + BOOKS LOCKED (GFC)
                        → ApexInsight final flash / ApexRegRep consume
                            → Disclosure pack (abbrev.) / SOX evidence complete
```

### 16.2 Late Adjustment Flow

```
Requestor drafts JE + memo
    → Close Manager impact assessment
        → Approver per §10 (+ unlock approver per §13.3)
            → Finance Systems unlock (if locked)
                → Post JE → Re-perform affected recon
                    → Re-lock → Update close pack & notify consumers
```

### 16.3 Consolidation Flow

```
Entity TB certificates
    → Load BOOK-CONS-GROUP
        → Translation
            → IC matching & eliminations
                → Group analytics
                    → Certify Group TB
                        → Disclosure / Reg Reporting hand-off
```

---

## 17. Decision Tables

### 17.1 Period Type Routing

| Question | Month | Quarter | Year |
|---|---|---|---|
| Soft close day | T+5 | T+5 | T+5 |
| Hard close target | T+8 | T+10 | T+15 (Group) |
| Full disclosure pack | Abbreviated | Yes | Yes |
| External audit PBC intensity | Low | Medium | High |
| Period 13 use | No | No | Yes |

### 17.2 Soft Close Blockers

| Condition | Block Soft Close? | Waiver Authority |
|---|---|---|
| Material recon incomplete | Yes | GFC ≤ 2 business days |
| Suspense > 30 days material | Yes | GFC with plan |
| Product Control unsigned (markets) | Yes | GFC + Head of Product Control joint |
| Single non-material recon pending | No — track to T+6 | Close Manager |
| ApexLedger job failure | Yes | GFC after Finance Systems ETA |

### 17.3 Journal Type Routing

| Journal Type | System Path | Typical Approver Band |
|---|---|---|
| Standard accrual | ApexLedger JE workflow | §10 table |
| Allocation cycle | Automated assessment CO | FinOps G6+ exception only |
| Elimination | Consolidation ledger workflow | Consolidation lead + GFC for > $10M |
| Tax provision | Tax → Controllership | Tax G8 + §10 |
| Correction of error | Controllership | Escalate one level above original; GFC if prior period |

---

## 18. Approval Tables (Close-Specific)

| Decision | Authority |
|---|---|
| Publish / amend close calendar mid-period | GFC |
| Soft close approval | GFC |
| Hard close / books lock | GFC |
| Unlock < $10M impact | GFC |
| Unlock ≥ $10M or post-issuance | CFO (+ Audit Committee Chair notify if post-issuance) |
| Waive material recon at soft close | GFC |
| Suspend reconciliation programme | CFO **and** CRO per `ANB-ADM-MTX-0001` §10.3 |
| Accept IC imbalance above $1,000 | GFC (must clear before external filing) |
| Defer disclosure note to next pack | GFC with Disclosure Committee secretary |

Journal money thresholds: §10 and `ANB-FIN-MTX-0009`.

---

## 19. Examples — End-to-End

### 19.1 Clean August Close

Period `AP-2026-08`. Close Manager `EMP-600122` opens checklist. T+1 depreciation posts $41.2M to `790100`. T+3 journal `JE-202608-004821` accrues cloud $482,600. T+4 Fatima Al-Hassan (`EMP-600123`) reports 96% material recon complete; two waivers not required. T+5 Gemma Ashworth approves soft close. T+7 eliminations clear. T+8 books locked at 16:42 ET. SOX evidence `CTL-FIN-CLOSE-01`–`08` complete. Abbreviated disclosure pack issued C2.

### 19.2 Blocked Soft Close — Suspense

T+5 suspense shows $2.1M unreconciled item aged 34 days in payments clearing. Soft close blocked. Nikolai Petrov and Colin Devereaux clear $1.85M the same evening via `JE-202608-005440`; residual $250k waived by GFC to T+6 with named owner. Soft close recorded 21:10 ET with waiver in ApexServe. Hard close still achieved T+8.

### 19.3 Post-Lock Adjustment

On T+9, Tax identifies $6.2M deferred tax correction. Unlock approved by GFC (`JE-202609-000018` posted into still-open adjustment path or unlock of `AP-2026-08` per memo). CFO informed (amount < $10M). Books re-locked; ApexRegRep extract refreshed; Disclosure Committee secretary notified.

---

## 20. Systems and Interfaces

| System | Close Role |
|---|---|
| **ApexLedger** | GL, journals, period status, subledgers, reconciliations |
| **ApexPlan** | Budget/forecast reference for analytics (not accrual basis) |
| **ApexInsight** | Management flash, variance, cost centre views |
| **ApexSource** | Procurement receipt signals for GR/IR and accruals |
| **ApexVendor** | Vendor master validation for AP accruals |
| **ApexServe** | Waivers, unlock tickets, exception workflow |
| **ApexDocs** | Close pack, evidence, memos |
| **ApexRegRep** | Regulatory reporting consumption of locked data |
| **ApexPay / ApexTreasury** | Settlement cut-off, cash/Nostro evidence |
| **ApexCore** | Product/customer reference where revenue cut-off needs it |
| **ApexAudit** | SOX testing and ICFR evidence repository |

---

## 21. Related Documents

### 21.1 Foundation and Enterprise Governance

| ID | Title |
|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile / Enterprise Reference |
| Company Profile | `docs/apex_national_bank/00_foundation/COMPANY_PROFILE.md` |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard |
| `ANB-ADM-POL-0001` | Records Retention Policy |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix (parent; §7.1 financial authority) |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide |
| `ANB-LEG-REF-0003` | Legal / regulatory reference index |
| `ANB-ADM-REF-0001` | Enterprise committee and governance linkages |

### 21.2 Finance Sibling Set

| ID | Title |
|---|---|
| `ANB-FIN-POL-0001` | Expense Policy |
| `ANB-FIN-POL-0002` | Travel Policy |
| `ANB-FIN-BUD-0005` | Budget FY2026 |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard |
| `ANB-FIN-SOP-0003` | This procedure — Financial Closing SOP |
| `ANB-FIN-POL-0006` | Capital Expenditure Policy |
| `ANB-FIN-POL-0007` | Corporate Card Policy |
| `ANB-FIN-SOP-0008` | Vendor Payment Procedure |
| `ANB-FIN-MTX-0009` | Finance Approval Authority Matrix |

### 21.3 HR Set (by ID)

| ID | Title |
|---|---|
| `ANB-HRM-HBK-0001` | Employee Handbook |
| `ANB-HRM-POL-0002` | Leave Policy |
| `ANB-HRM-POL-0003` | Remote Work Policy |
| `ANB-HRM-POL-0004` | Code of Conduct |
| `ANB-HRM-POL-0006` | Performance Management Policy |
| `ANB-HRM-POL-0008` | Training and Certification Policy |
| `ANB-HRM-SOP-0007` | Recruitment SOP |
| `ANB-FIN-POL-0002` | Travel Policy (finance-owned; HR-adjacent obligations) |

---

## 22. Review Cycle

| Trigger | Action |
|---|---|
| Annual | Full review by Close Manager; re-approval by GFC |
| New legal entity | Interim close playbook within 30 days |
| Accounting standard change | Accounting Policy + GFC interim update |
| Material system change (ApexLedger release) | Finance Systems + Close Manager update job runbooks |
| Repeated hard-close miss | Root-cause review within 10 business days; ORC notification if control failure |

Next scheduled review: **2027-07-18**.

---

## 23. Revision History

| Version | Date | Author | Approver | Summary |
|---|---|---|---|---|
| 0.1 | 2026-06-01 | `EMP-600122` James Okonkwo | — | Draft expansion of reserved month-end procedure |
| 0.9 | 2026-07-10 | Close Manager | GFC (review) | Added Q/Y calendars, unlock protocol, SOX map |
| 1.0 | 2026-08-01 | `EMP-600122` James Okonkwo | `EMP-600101` Gemma Ashworth | Initial in-force publication covering month, quarter, and year-end close |

---

## Appendix A — Materiality and Tolerances (Close Operations)

| Item | Threshold |
|---|---|
| Material balance-sheet account (entity) | Greater of $1,000,000 or 0.5% of entity equity (close ops threshold — not audit materiality) |
| Intercompany imbalance tolerance at certification | $1,000 reporting currency |
| Accrual omission per vendor line | $5,000 if aggregate population immaterial |
| Suspense “material” item | $100,000 or qualitatively significant |
| Rounding in consolidation | As above |

External audit materiality is set by the external auditor and may differ; Finance uses Appendix A for **operational close gates only**.

---

## Appendix B — Close Checklist Skeleton (Month)

1. Calendar published  
2. FX rates loaded  
3. Subledger cut-offs confirmed (AP, AR, FA, Payroll, Expense, Treasury)  
4. Depreciation posted  
5. Accrual inventory complete  
6. Journals wave 1–2 approved  
7. Material recon 100%  
8. Suspense ageing compliant  
9. Product Control sign-off (if applicable)  
10. Soft close approved  
11. Eliminations posted  
12. Group analytics complete  
13. Reg extract QA  
14. SOX evidence complete  
15. Hard close / books locked  
16. Close pack filed  

Instance IDs follow `CLOSE-AP-2026-MM-ANB`.

---

## Appendix C — Journal Evidence Minimum Set

| Evidence Type | Required For |
|---|---|
| System report / extract | System-supported accruals |
| Counterparty confirmation | Intercompany, material third-party accruals |
| Contract / PO reference (`PO-########`) | Vendor accruals |
| Calculation workbook (locked PDF + source) | Estimates, bonuses, tax |
| Accounting Policy memo | Judgemental technical entries |
| Waiver ticket (`ApexServe`) | Any soft/hard close waiver |

---

## Appendix D — Control Failure Escalation

| Failure | Escalate To | Time |
|---|---|---|
| Missed soft close without waiver | GFC → CFO | Same day |
| Books locked late | GFC; ORC if > 1 business day | Next morning |
| SOX evidence missing at T+8 | Head of Internal Controls & SOX → CAE notify if key control | 24 hours |
| Unauthorised posting into locked period | GFC, SOX, CAE | Immediate |

---

## Appendix E — Named Contacts (Finance Close)

| Topic | Contact |
|---|---|
| Calendar / war-room | `EMP-600122` James Okonkwo |
| Reconciliations / suspense | `EMP-600123` Fatima Al-Hassan |
| Soft/hard close approval | `EMP-600101` Gemma Ashworth |
| Systems / lock | `EMP-600114` Rahul Bhattacharya |
| SOX evidence | `EMP-600110` Teresa Villanueva |
| Tax journals | `EMP-600107` Miriam Rosenthal |
| Payments cut-off | `EMP-600112` Colin Devereaux / `EMP-600124` Chen Wei |
| Treasury cash | `EMP-600501` Nikolai Petrov |

---

**End of Document — `ANB-FIN-SOP-0003` v1.0**

*This Procedure is a controlled document. Printed or locally saved copies are uncontrolled. The authoritative version resides in ApexDocs. Period status in ApexLedger is the system of truth for soft close, hard close, and books locked.*
