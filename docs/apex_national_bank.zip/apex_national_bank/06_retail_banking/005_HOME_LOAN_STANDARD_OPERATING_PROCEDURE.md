# Apex National Bank — Home Loan Standard Operating Procedure

**SOP | Mortgage Application, Verification, Valuation, Approval, Disbursement, and Servicing Handoff**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-SOP-0005` |
| **Document Title** | Home Loan Standard Operating Procedure |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Mortgage Operations |
| **Custodian** | Rachel Kim, Head of Mortgage (G8) — `EMP-300108` |
| **Approver** | Gregory Lin, Head of Consumer & Retail Banking (G10) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.2` → Mortgages → `SOP` |
| **Business Process** | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-CRD-DOC`, `BP-CRD-APPR`, `BP-SRV-BILL` |
| **System of Record** | ApexOrigin · ApexCredit · ApexCore · ApexKYC · ApexDocs · Apex360 |
| **Parent Policy** | `ANB-RTL-POL-0003` |
| **Related Documents** | `ANB-RTL-FRM-0002`, `ANB-CBK-POL-0001`, `ANB-RSK-FRM-0001` |

---

## 2. Purpose

This SOP translates `ANB-RTL-POL-0003` into step-by-step mortgage (home loan) operations from first contact through post-disbursement servicing board, ensuring TRID timelines, appraisal independence, credit authority, and clean handoff to Loan Servicing (`EMP-300115`).

---

## 3. Scope

All US residential mortgage originations (purchase, rate-term refi, cash-out, construction-to-permanent, FHA/VA, jumbo). HELOC draw setup included where originated on ApexOrigin. India home loans follow local addendum.

Identifiers: `MTG-########`, `HLN-########`, `APP-##########`, `CUS-########`.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **TRID** | TILA-RESPA Integrated Disclosure — Loan Estimate / Closing Disclosure |
| **CTC** | Clear to Close |
| **CD** | Closing Disclosure |
| **AMC** | Appraisal Management Company |
| **Conditions** | Prior-to-docs / prior-to-funding requirements in ApexOrigin |

---

## 5. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| Mortgage Loan Officer / Personal Banker | Intake; `ANB-RTL-FRM-0002`; intent to proceed |
| Mortgage Processor | Document collection; TRID clock management |
| Underwriter (Credit) | Credit decision; conditions |
| Closer / Funder | Docs; disbursement; MERS / recording |
| Appraiser / AMC | Independent valuation |
| Head of Mortgage (`EMP-300108`) | SLA; quality; escalations |
| Credit Risk (`EMP-400201` team) | Referrals; exceptions |
| KYC Ops (`EMP-400112`) | CIP/CDD blockers |
| Loan Servicing (`EMP-300115`) | Boarding checklist |

---

## 6. Application Workflow

```
Day 0 — Application
  ├─ Create MTG-######## / APP-########## in ApexOrigin
  ├─ Link CUS-########; launch/refresh KYC-########
  ├─ Pull credit (permissible purpose)
  ├─ Issue Loan Estimate within TRID timing
  └─ Intent to proceed recorded

Verification (parallel)
  ├─ Income / employment
  ├─ Assets / down payment source (AML-sensitive)
  ├─ Property — title order; HOI; flood
  └─ Sanctions / PEP / adverse media (ApexKYC)

Valuation
  ├─ Order appraisal via AMC (no LO value influence)
  └─ Review SSR / appraisal checklist

Underwriting
  ├─ AUS + manual UW as required
  ├─ Assign CRR-####; decision Approve / Suspend / Deny
  └─ Conditions issued

Pre-Close
  ├─ CD timing; final conditions cleared → CTC
  ├─ Closing package; wet/eClose
  └─ Funding authorization

Disbursement
  ├─ Wire / settlement; book HLN-########
  └─ Post-funding QC sample

Servicing handoff
  └─ Board ApexCore; welcome; escrow setup
```

**SLA targets:** LE same day / next day; UW decision 48–72 hours file-complete; CTC to close per contract.

---

## 7. Verification Standards

| Item | Pass Criteria |
|---|---|
| Identity | CIP complete; ID not expired |
| Income | Documented and stable; overlaps reconciled |
| Down payment | Sourced; gift letter if gift; no unexplained cash (`ANB-CMP-POL-0001`) |
| Liabilities | All debts in DTI; authorized-user treated per policy |
| Occupancy | Affidavit; fraud red flags reviewed |
| Insurance | Hazard binder; flood if required |

Third-party funding or complex gifts → Financial Crime consult before CTC.

---

## 8. Property Valuation

| Rule | Detail |
|---|---|
| Independence | Production staff may not select appraiser or discuss value |
| Transfer | Appraisal transfers accepted if AIR-compliant |
| Desktop / hybrid | Only where product and investor allow |
| Re-inspection | Required if CTC delayed past appraisal validity |
| Challenge | Reconsideration of value process — documented; no pressure |

Valuation stored in ApexDocs under `MTG-########` folder per naming standard.

---

## 9. Credit Approval

Follow `ANB-RTL-POL-0003` §10 and `ANB-ADM-REF-0001` §5.4.

| Outcome | Action |
|---|---|
| Approve | Conditions list; rate lock rules |
| Suspend | Missing docs — clock management |
| Deny | Adverse action; HMDA action code |
| Exception | `BP-CRD-EXC` package; Risk concurrence |

Jumbo and investment property: manual UW mandatory; no full auto-decision.

---

## 10. Documentation and Closing

1. Prior-to-docs conditions cleared  
2. Generate closing package (eClose where eligible)  
3. Issue CD within TRID tolerance  
4. Confirm wire instructions verbally (callback fraud control)  
5. Notary / settlement agent per state  
6. Execute security instrument; perfect lien  
7. Fund; book `HLN-########` / `ACC-##########`  

**Wire fraud control:** Dual verification of beneficiary details; never rely solely on email.

---

## 11. Disbursement and Post-Disbursement

| Step | Owner | Evidence |
|---|---|---|
| Funding figures balanced | Funder | ApexOrigin funding screen |
| Investor / warehouse delivery | Capital Markets Ops | Delivery checklist |
| Trailing docs | Post-Closer | 30/60/90 chase |
| QC audit sample | Mortgage QC | ApexAudit linkage |
| Servicing board | `EMP-300115` team | Boarding ticket `SRQ-` |
| First payment notice | Servicing | Customer disclosure |

Post-disbursement servicing: payments, escrow analysis, PMI cancellation requests, payoff quotes — ApexCore / Apex360.

---

## 12. Decision Trees

### 12.1 Down Payment Source

```
Source of funds
        │
        ├─ Seasoned Apex deposits? ──► Accept
        ├─ Documented sale of assets? ──► Accept
        ├─ Gift from relative — letter + donor trail? ──► Accept
        ├─ Large cash unexplained? ──► HOLD — FC / SAR path
        └─ Third-party business funding opaque? ──► Escalate CMP/RSK
```

### 12.2 Appraisal Issue

```
Appraisal received
        │
        ├─ Value supports LTV? ──YES──► Continue
        ├─ Value short — customer brings cash / restructure?
        ├─ Material deficiency — reorder / ROV
        └─ Suspected influence — escalate Compliance / Audit
```

---

## 13. Escalation Paths

| Issue | Escalate To | Timeline |
|---|---|---|
| KYC / sanctions blocker | `EMP-400112` / Sanctions | Same day |
| Fraud suspicion | `EMP-400106` Fraud | Immediate |
| Credit exception | `EMP-400201` | Before CTC |
| TRID cure / tolerance cure | Mortgage Ops Manager | Before consummation |
| Customer complaint | `CMP-########` via `ANB-RTL-MAN-0004` | Per CST SLA |
| Servicing boarding fail | `EMP-300115` | 24 hours |

---

## 14. Examples

**Purchase path:** `MTG-202605-2210` for `CUS-03115590`; appraisal supports; CTC day 28; fund `HLN-202605-0099`; boarded; payment due schedule generated.

**Cash-out refi hold:** Large recent cash deposit USD 45,000 unexplained. Processor opens `SRQ-`; Financial Crime reviews; customer provides business-sale docs; cleared; file proceeds.

---

## 15. Risk and Compliance Controls

| Control | Reference |
|---|---|
| ATR/QM | `ANB-RTL-POL-0003` |
| Fair lending | HMDA; Pricing monitoring |
| Appraisal independence | AIR / Reg Z |
| BSA — source of funds | `ANB-CMP-POL-0001` |
| Model use | `ANB-RSK-POL-0004` |
| Credit rating | `ANB-RSK-FRM-0001` `CRR-` |

---

## 16. Related Documents

`ANB-RTL-POL-0003` · `ANB-RTL-FRM-0002` · `ANB-RTL-POL-0004` · `ANB-RTL-MAN-0004` · `ANB-CBK-POL-0001` · `ANB-CBK-TPL-0003` · `ANB-CMP-POL-0002` · `ANB-RSK-STMT-0001` · `ANB-RSK-FRM-0001` · `ANB-ADM-STD-0007` · `ANB-HRM-POL-0008`

---

## 17. Review Cycle / Revision History

Annual; TRID or investor guide changes within 30 days.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | R. Kim | Initial home loan SOP |

---

## Appendix A — Processor Checklist (File Complete)

- [ ] `MTG-` / `APP-` created; LE issued  
- [ ] Intent to proceed  
- [ ] `KYC-` clear; `SCR-` / `PEP-` attached  
- [ ] Income / asset docs indexed in ApexDocs  
- [ ] Appraisal ordered / received  
- [ ] Title / HOI / flood  
- [ ] AUS findings addressed  
- [ ] CD issued; tolerances managed  
- [ ] Funding figures balanced  
- [ ] Servicing boarding `SRQ-` opened  

---

**End of Document** — `ANB-RTL-SOP-0005` v1.0
