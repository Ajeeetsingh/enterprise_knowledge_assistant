# Apex National Bank — Branch Operations Manual

**Operations Manual | Opening, Closing, Teller, Vault, Security, and Escalation**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-MAN-0003` |
| **Document Title** | Branch Operations Manual |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Branch Network |
| **Custodian** | Patricia Nwankwo, Head of Retail Operations (G8) — `EMP-300101` |
| **Approver** | Gregory Lin, Head of Consumer & Retail Banking (G10) — `EMP-100014` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.3` Branch & Channel Operations → `MAN` |
| **Business Process** | `BP-BRN-OPEN`, `BP-BRN-CASH`, `BP-BRN-SDB`, `BP-ONB-ACCT`, `BP-DEP-MAINT` |
| **System of Record** | ApexTeller · ApexBranch · ApexCore · ApexAccess · ApexServe · Apex360 |
| **Related Documents** | `ANB-RTL-SOP-0006`, `ANB-RTL-GDL-0003`, `ANB-RTL-MAN-0004`, `ANB-CMP-SOP-0007` |

> **Note.** Reserved ID `ANB-RTL-MAN-0003` per `ANB-ADM-REF-0001` §15. Company Profile §4.3 historically referenced `ANB-RTL-SOP-0004` for this manual; **`ANB-RTL-MAN-0003` is authoritative**.

---

## 2. Purpose

This Manual is the operating standard for 1,842 retail branches (Flagship, Community, Express, In-Store). It defines opening and closing controls, teller operations, vault discipline, cash limits, customer servicing, physical security, and escalation so that every `BRN-####` / `SIT-####` runs to one control framework.

---

## 3. Scope

All US retail branches and international full-service retail branches. In-Store formats follow the same cash and opening controls with staffing overlays. Contact centre operations are governed by `ANB-RTL-MAN-0004` / CST procedures.

Canonical retail entities: `ANB-RTL-GDL-0001` Appendix A.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Branch Operating ID** | `BRN-####` — maps to workplace site `SIT-####` |
| **Dual control** | Two authorised employees jointly perform a control |
| **ApexBranch** | Branch workforce, queue, and schedule module integrated with ApexTeller |
| **Time-lock** | Vault timer preventing immediate reopen after close |
| **All-clear** | Opening signal that premises are safe to enter |

---

## 5. Roles and Responsibilities

| Role | Example | Responsibility |
|---|---|---|
| Regional Retail Director | `EMP-300102` Victor Salazar | Region performance; surprise cash audits |
| Branch Manager | `EMP-300103` / `EMP-300107` (`BRN-0412`) | Daily control environment |
| Assistant Branch Manager | G4 | Opening/closing alternate; approvals |
| Personal Banker | `EMP-300105` | Sales, onboarding, complex servicing |
| Teller | `EMP-300106` / `TEL-####` | Cash transactions; balancing |
| Cash Services Manager | `EMP-300113` Helen Cho | CIT, vault policy, shortages |
| Compliance Branch Monitoring | `EMP-400104` | CTR quality; mystery shop themes |
| Op Risk — Retail | `EMP-400203` | RCSA; loss events |
| Physical Security / ADM | ApexAccess | Badging; alarm response |

---

## 6. Branch Opening (`BP-BRN-OPEN`)

```
Pre-open (outside)
  ├─ Two employees present (never solo open)
  ├─ Visual premises check; all-clear procedure
  ├─ Disarm alarm via ApexAccess protocol
  └─ Enter; CCTV verify

Open vault / ATM (if on-site)
  ├─ Dual control VAULT-####
  ├─ Remove CBX-#### for assigned TEL-
  └─ ApexTeller sign-on; buy cash from vault

Floor ready
  ├─ Queue system live (QTK-)
  ├─ Opening checklist in ApexBranch signed
  └─ Doors open at published time
```

**BRN-OP-1.** Solo opening is prohibited. Violation is a Code of Conduct matter (`ANB-HRM-POL-0004`).

**BRN-OP-2.** Late open > 15 minutes → Regional notification + customer comms script.

---

## 7. Branch Closing

```
Lobby close at published time (customers inside may finish)
  ├─ Door control; no new entries
  ├─ Teller balance each CBX-####
  ├─ Sell cash to vault; dual control
  ├─ ATM settle if branch-managed (see ATM Guide)
  ├─ Secure SDB area; courier logs
  ├─ ApexTeller / ApexBranch close checklist
  ├─ Arm alarm; dual exit
  └─ Time-lock engaged
```

Differences and overages: log `REV-` / ApexServe incident if above threshold (`ANB-RTL-SOP-0006`).

---

## 8. Teller Operations

| Activity | Standard |
|---|---|
| Authentication | Photo ID for non-card; card+PIN / biometric where enabled |
| Cash in / out | ApexTeller; `TXN-##########`; `RCP-########` |
| Cheque deposit | Image; endorsement review |
| Large cash | Dual control per cash procedure |
| CTR prompt | System hard-stop > USD 10,000 aggregate |
| Refusals | Never process if CIP incomplete for new customer |

**Teller drawer limits (illustrative):** working cash USD 8,000–15,000 by format; excess sold to vault intraday.

---

## 9. Vault Operations

| Control | Requirement |
|---|---|
| Access | Dual custody; ApexAccess badge + combination split |
| Inventory | Denomination straps; sealed bags; CIT receipts |
| Intraday | Dual control for all vault opens |
| Surprise verification | Regional / Cash Services — unannounced |
| Vault ID | `VAULT-####` matching `BRN-####` |

Safe deposit (`SDB-####`): dual control access; deceased / court order protocols with Legal; `BP-BRN-SDB`.

---

## 10. Cash Limits

| Limit Type | Amount (USD) | Authority |
|---|---|---|
| Teller continuous authority | 5,000 per customer withdrawal | `TEL-` |
| Branch Manager approval | 5,001–25,000 | G5 |
| Advance notice + Cash Services | > 25,000 | `EMP-300113` path |
| Vault overnight max | Per branch cash schedule | Regional + Cash Services |
| CIT shipment | Dual control; sealed | Approved carrier |

---

## 11. Customer Servicing

| Standard | Target |
|---|---|
| Greeting / queue token | Within 1 minute of entry |
| Wait time (Flagship/Community) | ≤ 10 minutes average (`RTL-KPI-018`) |
| Complex product | Warm handoff to Personal Banker |
| Vulnerable customer | Private space; no upsell pressure (`ANB-RTL-MAN-0004`) |
| Complaint intake | Log `CMP-########`; do not promise SAR outcomes |

Products serviced: savings/checking guides; debit `DBC-`; cards; mortgage intake referral; personal loans per policy.

---

## 12. Security

| Theme | Control |
|---|---|
| Robbery / skimming | Silent alarm; compliance with training; no heroics |
| CCTV | Retention per ISC/ADM standard; available to investigations |
| Tailgating | Challenge unknown persons in secure zone |
| Device | No personal USB on ApexTeller |
| Insider | Dual control; mandatory consecutive absence for cash roles (`ANB-HRM-POL-0002`) |
| Cyber at branch | Report to `EMP-500201` / ApexServe Sev path |

Scenario linkage: `SCN-2026-BRN-001` branch unavailability — activate BCP `ANB-RSK-POL-0007`.

---

## 13. Escalation Paths

| Situation | Escalate To | Timeline |
|---|---|---|
| Cash shortage > USD 200 | Branch Manager → Cash Services | Same day |
| Suspected structuring / SAR | `EMP-400104` / Investigations | Same business day |
| Robbery / threat | Law enforcement + Regional + ISC | Immediate |
| System outage ApexCore/Teller | ApexServe Sev1; ITO `EMP-500101` | Immediate |
| Media at branch | Regional + MKT + Legal | Immediate |
| Employee misconduct | HR BP `EMP-200201` + Manager | Same day |

---

## 14. Approval Authorities (Branch)

| Decision | Approver |
|---|---|
| Fee waiver ≤ USD 50 | Teller / PB within daily cap |
| Fee waiver ≤ USD 250 | Branch Manager |
| Account maintenance exceptions | Branch Manager |
| Unsecured loan ≤ USD 50,000 (scoreband) | Branch Manager |
| Large cash payout | Per §10 |
| BCP invocation (site) | Site Incident Manager → COO path |

---

## 15. Examples

**Opening — `BRN-0412`:** Managers `EMP-300103`/`EMP-300107` and Teller `EMP-300106` execute dual open; `VAULT-0412` dual; drawers `CBX-0412-01..03` issued; doors 09:00.

**Escalation — structuring:** Four cash deposits observed; teller escalates per AML Policy example; CTR + ApexGuard path.

---

## 16. Related Documents

`ANB-RTL-SOP-0006` · `ANB-RTL-GDL-0001` · `ANB-RTL-GDL-0002` · `ANB-RTL-GDL-0003` · `ANB-RTL-MAN-0004` · `ANB-RTL-POL-0001` · `ANB-CMP-POL-0001` · `ANB-CMP-SOP-0007` · `ANB-RSK-POL-0005` · `ANB-RSK-POL-0007` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0004` · `ANB-HRM-HBK-0001` · `ANB-ADM-REF-0001` · `ANB-IAD` branch cash audits

---

## 17. Review Cycle / Revision History

Annual; post-robbery or material audit finding within 30 days.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | P. Nwankwo | Initial published Branch Operations Manual |

---

## Appendix A — Daily Control Checklist

- [ ] Dual open / all-clear  
- [ ] Vault dual access logged  
- [ ] Teller buy/sell recorded  
- [ ] CTR candidates reviewed  
- [ ] Queue / NPS device live  
- [ ] Dual close; alarm armed  
- [ ] Differences logged  

## Appendix B — Branch Format Overlay

| Format | SDB | Full Platform | Notes |
|---|---|---|---|
| Flagship | Yes | Yes | Advisory suites |
| Community | Optional | Yes | Standard |
| Express | No | Assisted ST | Reduced vault |
| In-Store | No | Limited | Host rules + Bank controls |

---

**End of Document** — `ANB-RTL-MAN-0003` v1.0
