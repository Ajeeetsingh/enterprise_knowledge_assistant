# Apex National Bank — Savings Account Guide

**Product Guide | Consumer Savings Variants, Interest, Fees, Lifecycle, and Dormancy**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-GDL-0001` |
| **Document Title** | Savings Account Guide |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Deposit Products |
| **Custodian** | Patricia Nwankwo, Head of Retail Operations (G8) — `EMP-300101` |
| **Approver** | Gregory Lin, Head of Consumer & Retail Banking (G10) — `EMP-100014` |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Retention** | `RET-POL-10Y` |
| **Taxonomy** | `T3` → `T3.1` Deposit Products → `GDL` |
| **Business Process** | `BP-ONB-ACCT`, `BP-DEP-MAINT`, `BP-DEP-DORM`, `BP-DEP-FEE` |
| **System of Record** | ApexCore · ApexKYC · ApexTeller · ApexMobile · Apex360 |
| **Related Documents** | See §14 |

> **Authority.** This Guide operationalises savings products under `ANB-RTL-POL-0001` Retail Account Opening Policy and the product catalogue in `ANB-ADM-REF-0001` §3. Canonical retail entities for the entire `06_retail_banking/` domain are defined in Appendix A.

---

## 2. Purpose

Savings accounts are the foundation of the Bank’s Consumer & Retail Banking (`CRB`) deposit franchise — 24.1 million retail customers and CASA funding for the balance sheet. This Guide defines product variants, eligibility, interest calculation, fees, KYC linkage, dormancy/escheatment, and closure so that branch, digital, and contact-centre staff operate one consistent product model.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| All Apex consumer savings products booked on ApexCore | Brokered CDs and wholesale deposits (TRY) |
| US retail and India retail savings (local addenda) | Commercial money-market for corporates (CBK) |
| Joint, minor, and trust-linked savings | Apex Wealth discretionary portfolios (WAM) |
| Interest, fees, dormancy, closure | Tax advice (customer obtains own counsel) |

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Savings Account Record** | Product instance `SAV-########` linked to core account `ACC-##########` and customer `CUS-########` |
| **CASA** | Current Account / Savings Account balances used in retail funding metrics |
| **APY** | Annual Percentage Yield disclosed under Reg DD (Truth in Savings) |
| **Dormant** | No customer-initiated activity for 12 months (US) — `BP-DEP-DORM` |
| **Escheat** | Transfer of unclaimed funds to state per unclaimed property law |
| **Primary Relationship** | Flagship deposit relationship driving relationship pricing |

Entity formats: Appendix A.

---

## 5. Roles and Responsibilities

| Role | Employee / Function | Responsibility |
|---|---|---|
| Head of Consumer & Retail Banking | `EMP-100014` Gregory Lin | Product strategy; Guide approval |
| Head of Retail Operations | `EMP-300101` Patricia Nwankwo | Custodian; operating standards |
| Regional Retail Director — Southeast | `EMP-300102` Victor Salazar | Branch network execution |
| Branch Manager — `BRN-0412` / `SIT-0412` | `EMP-300103` Amara Okoye / `EMP-300107` Dara Ekwueme | Local KYC/sales quality |
| Personal Banker / Teller | `EMP-300105`, `EMP-300106` | Onboarding and servicing |
| Compliance Officer — Retail | `EMP-400103` Priyanka Iyer | Fair advertising; Reg DD |
| Branch Network Monitoring | `EMP-400104` Oluwaseun Bakare | Cash/CTR linkage |
| Finance Manager — CRB | `EMP-600116` Olumide Fashola | Product P&L; fee MI |

---

## 6. Product Variants

| Product Code | Name | Min Opening | Min Balance (fee waiver) | Target Segment |
|---|---|---|---|---|
| `SAV-STD` | Apex Everyday Savings | USD 25 | USD 300 | Mass retail |
| `SAV-PLUS` | Apex Advantage Savings | USD 100 | USD 1,500 | Mass affluent |
| `SAV-YTH` | Apex Youth Savings (age 13–17) | USD 10 | None | Youth with adult co-owner |
| `SAV-HSA` | Apex HSA Savings | USD 0 | None | Eligible HSA participants |
| `SAV-IND` | Apex India Savings (INR) | INR 500 | INR 1,000 | India resident retail |

Each instance receives `SAV-########` and books to ApexCore `ACC-##########`. Debit card where eligible: `DBC-########` via ApexCards / ApexPay.

---

## 7. Eligibility

| Criterion | Standard | Youth | India |
|---|---|---|---|
| Age | 18+ | 13–17 + adult joint | Per RBI / local |
| CIP / KYC | Complete `KYC-########` per `ANB-CMP-POL-0002` | Adult + minor ID | Local KYC |
| Risk rating | Not `CR-P` | Same | Same |
| Sanctions / PEP | Clear `SCR-` / `PEP-` | Same | Same |
| Residency | US person or eligible NRA | US | India resident |

**Decision tree — open / decline:**

```
Application received (branch / ApexMobile / ApexOnline)
        │
        ├─ CIP incomplete? ──► HOLD — complete ApexKYC
        ├─ Sanctions true hit? ──► DECLINE (CR-P)
        ├─ Age < 13 (US)? ──► DECLINE / UTMA path
        ├─ Existing SAV-STD only customer wants PLUS? ──► Upgrade path
        └─ Else ──► OPEN SAV-########; issue DBC- if requested
```

---

## 8. Interest Calculation

| Element | Rule |
|---|---|
| Method | Daily balance method; compounded monthly; credited monthly |
| Rate setting | Treasury FTP + product margin; published rate sheet in ApexDocs |
| Disclosure | Reg DD APY on opening and on change (21-day advance if adverse) |
| Variable rates | May change at Bank’s discretion with required notice |
| Accrual start | Day of first deposit (funds availability per Reg CC) |

**Illustrative FY2026 standard rates (published separately; not contractual):** `SAV-STD` APY 0.45%; `SAV-PLUS` APY 1.85% (relationship tier). Actual rates maintained by Deposit Pricing Committee under TRY/RTL.

---

## 9. Fees

| Fee | Amount (USD) | Waiver |
|---|---|---|
| Monthly maintenance — Everyday | 5.00 | Balance ≥ 300 or age < 18 or military |
| Monthly maintenance — Advantage | 0.00 | Relationship product |
| Excessive withdrawal (Reg D legacy monitoring — informational) | Soft alert after 6/month | Not a hard fee post-Reg D repeal; monitor for fraud |
| Outgoing domestic wire | 25.00 | Premier relationship waiver |
| Paper statement | 3.00 | eStatement enrolled |
| Early account closure (< 180 days) | 25.00 | Hardship exception — Branch Manager |

Fee waivers recorded as `SRQ-########`; authority per `ANB-ADM-MTX-0001` and `BP-DEP-FEE`.

---

## 10. Account Lifecycle

```
Prospect → CIP/KYC → Open SAV-######## / ACC-##########
        → Fund (cash TXN- / ACH / transfer)
        → Activate DBC-######## (optional)
        → Ongoing: deposits, withdrawals, SI, digital
        → Trigger events: KYC refresh, address change, adverse media
        → Dormant (12 months) → Reactivation or escheat path
        → Closure → final interest; zero balance; retain RET-CUS-7Y
```

### 10.1 KYC and Ongoing Due Diligence

- Opening requires `KYC-########` and `CDD-########` (or `EDD-` if `CR-H`) per `ANB-CMP-GDL-0007` / `ANB-CMP-SOP-0006`.
- Periodic refresh: `CR-L` 36 months; `CR-M` 24 months; `CR-H` 12 months.
- Material activity inconsistent with expected profile → escalate ApexGuard / Financial Crime.

### 10.2 Standing Instructions and Transfers

Standing instructions (`SI`) and ApexPay transfers (ACH, Zelle, India NEFT/IMPS/UPI where licensed) maintained in ApexCore. Changes require authenticated channel (branch with ID, ApexMobile MFA, or authenticated contact centre).

---

## 11. Dormancy and Escheatment (`BP-DEP-DORM`)

| Stage | Timing | Action |
|---|---|---|
| Inactive warning | Month 9 without customer-initiated activity | Notice via Apex360 preferred channel |
| Dormant flag | Month 12 | Restrict online transfers; interest continues |
| Reactivation | Customer presents ID / MFA | Branch or digital; `SRQ-########` |
| Escheat notice | Per state dormancy period (typically 3–5 years) | Legal + Operations |
| Remittance to state | Per jurisdiction calendar | ApexVault evidence |

**Example:** `CUS-04928311` / `SAV-202401-8841` / `ACC-8871200456` dormant 14 months. Customer visits `BRN-0412`; Teller `TEL-0412` (`EMP-300106`) verifies ID; reactivation `SRQ-202608-1144`; cash deposit `TXN-2026081800441` / `RCP-202608-5521`.

---

## 12. Closure

| Path | Requirements |
|---|---|
| Customer-initiated | Zero or transfer balance; destroy/hotlist `DBC-`; final statement |
| Bank-initiated (fraud / AML) | Compliance/Risk hold; no tipping off if SAR path |
| Estate | Death certificate; executor authority; Legal checklist |

Closure reason codes stored on `SAV-########`. Re-open within 90 days requires Branch Manager approval if prior AML exit.

---

## 13. Risk and Compliance Controls

| Control | Link |
|---|---|
| CIP before booking | `CTL-CMP-001`, `ANB-CMP-POL-0002` |
| CTR on cash > USD 10,000 | `ANB-CMP-SOP-0007` |
| Structuring escalation | `RULE-AML-0101` / ApexGuard |
| Fair advertising of APY | Reg DD — `EMP-400103` |
| Operational loss on misposting | `ANB-RSK-POL-0005` / `REV-` |
| Model for relationship pricing (if scored) | `ANB-RSK-POL-0004` |

---

## 14. Related Documents

| ID | Title |
|---|---|
| `ANB-RTL-POL-0001` | Retail Account Opening Policy |
| `ANB-RTL-GDL-0002` | Checking Account Guide |
| `ANB-RTL-MAN-0003` | Branch Operations Manual |
| `ANB-RTL-SOP-0006` | Cash Handling Procedure |
| `ANB-RTL-MAN-0004` | Customer Service Manual |
| `ANB-CMP-POL-0001` / `0002` | AML / KYC Policies |
| `ANB-CMP-SOP-0007` | CTR Procedure |
| `ANB-RSK-POL-0001` / `0005` | ERM / Operational Risk |
| `ANB-ADM-REF-0001` | Master Company Profile |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard |
| `ANB-HRM-POL-0008` | Training — deposit product modules |
| `ANB-FIN-STD-0004` | Chart of Accounts — deposit GL |

---

## 15. Review Cycle

Annual review by Head of Retail Operations; interim update within 30 days of Reg DD or deposit-rate methodology change. Next review: **2027-07-31**.

---

## 16. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 1.0 | 2026-07-31 | P. Nwankwo | Initial published savings guide | G. Lin |

---

## 17. Appendices

### Appendix A — Canonical Retail Entity Register

**Authoritative for all documents in `06_retail_banking/` and downstream customer-case domains.**

#### A.1 Customer and Product Accounts

| Entity | Format | Example | System |
|---|---|---|---|
| Customer | `CUS-########` | `CUS-04928311` | ApexCore, ApexKYC |
| Customer Profile | `CRP-########` | `CRP-04928311` | ApexKYC |
| Core Account | `ACC-##########` | `ACC-8871200456` | ApexCore |
| Savings Account | `SAV-########` | `SAV-202401-8841` | ApexCore |
| Checking Account | `CHK-########` | `CHK-202402-1102` | ApexCore |
| Personal Loan | `PLN-########` | `PLN-202603-0441` | ApexCore, ApexOrigin |
| Home Loan / Mortgage Facility | `HLN-########` | `HLN-202605-0099` | ApexCore, ApexCredit |
| Mortgage Application | `MTG-########` | `MTG-202605-2210` | ApexOrigin |
| Loan Application (generic) | `APP-##########` | Per metadata standard | ApexOrigin |

#### A.2 Branch, Staff, and Cash

| Entity | Format | Example | Notes |
|---|---|---|---|
| Branch Operating ID | `BRN-####` | `BRN-0412` | Maps 1:1 to site `SIT-0412` |
| Site / Location | `SIT-####` | `SIT-0412` | ApexWorkplace (authoritative location) |
| Teller ID | `TEL-####` | `TEL-0412` | ApexTeller entitlement |
| Branch Vault | `VAULT-####` | `VAULT-0412` | Dual control |
| Cash Box | `CBX-####` | `CBX-0412-03` | Teller drawer |
| ATM | `ATM-####` | `ATM-0412` | ApexATM |
| ATM Cassette | `CAS-####` | `CAS-0412-A` | Replenishment |
| Safe Deposit Box | `SDB-####` | `SDB-0412-118` | Flagship/Community |

#### A.3 Cards, Transactions, Service

| Entity | Format | Example |
|---|---|---|
| Debit Card | `DBC-########` | `DBC-202402-7781` |
| Credit Card | `CRC-########` | `CRC-202511-3344` |
| Transaction | `TXN-##########` | `TXN-2026081800441` |
| Receipt | `RCP-########` | `RCP-202608-5521` |
| Service Request | `SRQ-########` | `SRQ-202608-1144` |
| Customer Complaint | `CMP-########` | `CMP-202608-0088` |
| Queue Token | `QTK-########` | `QTK-20260818-0144` |
| Retail KPI | `RTL-KPI-###` | `RTL-KPI-012` |

> **Note.** `CMP-########` denotes a **customer complaint** case ID in Apex360 / ApexServe. It is distinct from the Compliance department code `CMP` and from compliance document IDs `ANB-CMP-*`.

#### A.4 Extended Retail Personnel (Domain Register)

| Employee ID | Name | Grade | Role |
|---|---|---|---|
| `EMP-100014` | Gregory Lin | G10 | Head of Consumer & Retail Banking |
| `EMP-300101` | Patricia Nwankwo | G8 | Head of Retail Operations |
| `EMP-300102` | Victor Salazar | G7 | Regional Retail Director — Southeast |
| `EMP-300103` | Amara Okoye | G5 | Branch Manager — `BRN-0412` |
| `EMP-300104` | Brendan Kelly | G5 | Branch Manager — `BRN-0873` / `SIT-0873` |
| `EMP-300105` | Lucia Marchetti | G2 | Personal Banker |
| `EMP-300106` | Jamal Robertson | G1 | Teller (`TEL-0412`) |
| `EMP-300107` | Dara Ekwueme | G5 | Branch Manager — `BRN-0412` (2026 appointment) |
| `EMP-300108` | Rachel Kim | G8 | Head of Mortgage |
| `EMP-300109` | Omar Haddad | G8 | Head of Consumer Lending |
| `EMP-300110` | Sofia Alvarez | G8 | Head of Cards |
| `EMP-300111` | Priya Menon | G8 | Head of Digital Banking |
| `EMP-300112` | Marcus Webb | G6 | ATM Operations Manager |
| `EMP-300113` | Helen Cho | G6 | Cash Services Manager |
| `EMP-300114` | Andre Fontaine | G8 | Head of Collections |
| `EMP-300115` | Naomi Okonkwo | G8 | Head of Loan Servicing |
| `EMP-300201` | Katarina Novak | G8 | Head of Contact Centre Operations |
| `EMP-300202` | Michael Thornton | G6 | Customer Service Manager — Disputes & Complaints |

### Appendix B — Interest Accrual Example

Customer `CUS-03115590` holds `SAV-202608-0156` / `ACC-1029384756`. Average daily balance USD 4,200 for August 2026 at APY 0.45% → monthly interest credit ≈ USD 1.58 posted as `TXN-2026090100008` on 2026-09-01.

---

**End of Document** — `ANB-RTL-GDL-0001` v1.0 · C2 · Effective 2026-08-01
