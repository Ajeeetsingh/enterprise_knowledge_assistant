# Apex National Bank — ATM Operations Guide

**Operations Guide | Replenishment, Monitoring, Incidents, Reconciliation, Maintenance, and Fraud**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-GDL-0003` |
| **Document Title** | ATM Operations Guide |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — ATM Channel |
| **Custodian** | Marcus Webb, ATM Operations Manager (G6) — `EMP-300112` |
| **Approver** | Patricia Nwankwo, Head of Retail Operations (G8) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.3` → ATM Channel → `GDL` |
| **Business Process** | `BP-BRN-CASH`, `BP-CARD-ISS`, `BP-FRD-DET`, `BP-ITSM-INC` |
| **System of Record** | ApexATM · ApexPay · ApexTeller · ApexMonitor · ApexServe · ApexShield |
| **Related Documents** | `ANB-RTL-MAN-0003`, `ANB-RTL-SOP-0006`, `ANB-RSK-POL-0007`, `ANB-ISC-SOP-0003` |

---

## 2. Purpose

Apex National Bank operates approximately 4,600 ATMs. This Guide defines cash replenishment, availability monitoring, incident handling, cassette reconciliation, preventive maintenance, and fraud response so that `CBS-00000001` (retail payments & account servicing) impact tolerances are protected and customers receive reliable self-service access.

---

## 3. Scope

Bank-owned and branded ATMs (`ATM-####`); ITMs where deployed; surcharge-free partner network oversight (commercial terms by PRC). Cryptocurrency kiosks are out of scope.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **ATM ID** | `ATM-####` — unique device in ApexATM CMDB |
| **Cassette** | `CAS-####` — denomination canister |
| **FLM / SLM** | First-line / second-line maintenance |
| **EMV / NFC** | Chip and contactless acceptance |
| **Skimming** | Illegal card-data capture device |
| **Uptime** | % of scheduled hours in service — `RTL-KPI-024` |

---

## 5. Roles and Responsibilities

| Role | Employee / Party | Responsibility |
|---|---|---|
| ATM Operations Manager | `EMP-300112` Marcus Webb | Network performance; vendor SLAs |
| Cash Services | `EMP-300113` | Cassette cash; CIT coordination |
| Branch Manager | Local `BRN-` | Lobby ATM dual control loads |
| Head of Cards | `EMP-300110` | Card/ATM dispute nexus |
| Head of Fraud | `EMP-400106` | Skimming / cash trapping response |
| ITO / ApexMonitor | `EMP-500103` service path | Device health; Sev incidents |
| ISC Cyber Defence | `EMP-500201` | Compromised device forensics |
| CIT / FLM vendor | Approved `VEN-*` | Replenish; hardware |

---

## 6. Cash Replenishment

### 6.1 Forecast and Schedule

ApexATM cash forecasting uses withdrawal history + seasonality (payroll Fridays, holidays). Rank A ATMs (Flagship / high volume) replenished more frequently.

### 6.2 Branch-Loaded ATM

```
Dual control team
  ├─ Open ATM safe per procedure
  ├─ Remove CAS-####; seal integrity check
  ├─ Count residual vs ApexATM expected
  ├─ Insert replenished cassettes; dual sign
  ├─ Test dispense (supervisor)
  └─ Update ApexATM + ApexTeller cash position
```

### 6.3 CIT-Loaded ATM

Sealed cassettes prepared under dual control at cash centre; CIT swap; electronic confirmation in ApexATM; residual returned under seal.

**ATM-CASH-1.** Cassette keys and combinations split-custody.

**ATM-CASH-2.** Never pre-stage unsealed cash in vehicles overnight.

---

## 7. Monitoring

| Signal | Source | Response SLA |
|---|---|---|
| Out of cash | ApexATM | Replenish prioritisation < 4h Rank A |
| Hardware fault | ApexMonitor | FLM dispatch < 4h Rank A |
| Comms down | ApexMonitor | Telecom / ITO < 2h |
| Skimming alert / camera AI | ApexShield / vendor | Fraud + ISC immediate |
| Abnormal dispense / zero | ApexATM | Suspend device; investigate |

Target network uptime: **≥ 98.5%** (`RTL-KPI-024`); Rank A **≥ 99.0%**.

---

## 8. Incident Handling

```
Alert / customer report
        │
        ├─ Create ApexServe INC-######## (link ATM-####)
        ├─ Severity: Sev1 if CBS impact wide / fraud device
        │
        ├─ Cash / hardware ──► FLM / Cash Services
        ├─ Suspected skimming ──► Fraud + ISC; take ATM out of service
        ├─ Card/PIN compromise pattern ──► Cards hotlist rules
        └─ Physical attack / ram raid ──► Police + Regional + BC
```

Customer claims: Reg E path via CST / Cards (`ANB-CST-SOP-0001`, `BP-CARD-DISP`).

---

## 9. Reconciliation

| Cycle | Activity |
|---|---|
| Daily | Electronic totals ApexATM vs switch (ApexPay) |
| Per replenishment | Cassette residual vs system |
| Weekly | Suspense aged items |
| Monthly | GL proof with Finance `EMP-600116` |

Unresolved dispense/reject differences > USD 100 aged > 5 days → Cash Services escalation; potential `REV-`.

---

## 10. Preventive Maintenance

| Task | Frequency |
|---|---|
| FLM clean / journal / fascia check | Per vendor SLA (typically monthly) |
| SLM / module service | Quarterly or OEM |
| Camera / lighting check | Monthly |
| EMV kernel / security patches | ITO change calendar `ANB-ITO-SOP-0003` |
| Penetration / skimming physical exam | Quarterly Rank A; sample others |

---

## 11. Fraud Response

| Threat | Immediate Actions |
|---|---|
| Skimming / shimming | Out of service; preserve device; Fraud/ISC forensics |
| Cash trapping / empty envelope | CCTV; claim hold; pattern analytics |
| Card trapping | Capture device; assist customer; hotlist if needed |
| Shoulder surfing / distraction | Staff training; mirror/camera placement |
| Logical compromise | Isolate network; `ANB-ISC-SOP-0003`; possible `SCN-2026-CYB-001` linkage |

**ATM-FRD-1.** Do not alert suspects that surveillance review is underway if tipping would harm investigation (coordinate Legal/Fraud).

---

## 12. Decision Tree — Out of Service

```
ATM fault
        │
        ├─ Cash only? ──► Replenish path; keep online if hardware OK
        ├─ Fraud device suspected? ──► Immediate OOS + Fraud
        ├─ Network down > 30 min Rank A? ──► Sev escalate ITO
        └─ Recurring failure same ATM? ──► Replace / major SLM
```

---

## 13. Examples

**Replenishment:** `ATM-0412` at `BRN-0412` hits cash threshold; CIT loads `CAS-0412-A/B`; residual USD 8,440 matches ApexATM; online 14 minutes later.

**Skimming:** Customer reports odd fascia at `ATM-0873`. Branch Manager takes OOS; Fraud finds overlay; `INC-202608-4412`; cards in exposure window monitored; `CMP-` complaints tracked for service recovery.

---

## 14. Risk and Compliance Controls

| Control | Reference |
|---|---|
| Dual control cash | `ANB-RTL-SOP-0006` |
| PCI / card data | ISC standards |
| Availability / resilience | `ANB-RSK-POL-0007`, `CBS-00000001` |
| Fraud loss | `ANB-RSK-POL-0005`, Fraud programme |
| Vendor FLM/CIT | `ANB-RSK-FRM-0002` |

---

## 15. Related Documents

`ANB-RTL-MAN-0003` · `ANB-RTL-SOP-0006` · `ANB-RTL-GDL-0002` · `ANB-RTL-MAN-0004` · `ANB-RTL-RPT-FY26-0001` · `ANB-ISC-SOP-0003` · `ANB-RSK-POL-0007` · `ANB-ITO-PLN-0002` · `ANB-CMP-POL-0001` · `ANB-CST-SOP-0001`

---

## 16. Review Cycle / Revision History

Annual; after material fraud wave within 20 days.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | M. Webb | Initial ATM operations guide |

---

## Appendix A — Rank A ATM Criteria

High withdrawal volume; Flagship lobby; airports/transit; no alternate ATM < 0.25 miles; regulatory/accessibility critical sites.

---

**End of Document** — `ANB-RTL-GDL-0003` v1.0
