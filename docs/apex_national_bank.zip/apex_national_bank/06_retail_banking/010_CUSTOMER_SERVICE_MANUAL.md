# Apex National Bank — Customer Service Manual

**Operations Manual | Interactions, Complaints, Escalation, Vulnerable Customers, and Service Recovery**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-MAN-0004` |
| **Document Title** | Customer Service Manual |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) with Customer Support (CST) |
| **Custodian** | Katarina Novak, Head of Contact Centre Operations (G8) — `EMP-300201` |
| **Secondary Custodian** | Patricia Nwankwo, Head of Retail Operations (G8) — `EMP-300101` |
| **Approver** | Gregory Lin (`EMP-100014`) and Marcus Adeyemi, Head of Customer Support (G9) — `EMP-100020` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.5` Customer Experience → `MAN` |
| **Business Process** | `BP-CST-AUTH`, `BP-CST-CMPL`, `BP-CST-CORR`, `BP-CARD-DISP`, `BP-DEP-MAINT` |
| **System of Record** | Apex360 · ApexServe · ApexVoice · ApexCore · ApexTeller · ApexMobile |
| **Related Documents** | `ANB-CST-SOP-0001`, `ANB-RTL-MAN-0003`, `ANB-CMP-POL-0001`, `ANB-HRM-POL-0004` |

---

## 2. Purpose

Service quality is a conduct and franchise asset. This Manual sets standards for customer interactions across branch, contact centre, and digital assist channels — including authentication, complaint handling (`CMP-########`), escalation, vulnerable-customer care, and service recovery — aligned with fair treatment expectations and `ANB-CST-SOP-0001`.

---

## 3. Scope

All retail customer-facing employees (RTL and CST), contractors in contact centres, and branch staff. Wholesale / CIB coverage models are out of scope. Financial crime tipping-off prohibitions always override transparency instincts (`ANB-CMP-SOP-0004`).

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Complaint** | Expression of dissatisfaction requiring response — logged `CMP-########` |
| **Service Request** | Fulfilment request without dissatisfaction — `SRQ-########` |
| **Vulnerable customer** | Customer with resilience/capability limitations needing adjusted care |
| **Service recovery** | Actions to restore trust after failure — may include goodwill |
| **ASA** | Average Speed of Answer |
| **FCR** | First Contact Resolution |

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Head of Customer Support | `EMP-100020` Marcus Adeyemi | CST strategy |
| Head of Contact Centre | `EMP-300201` Katarina Novak | Manual custodian; phone/chat |
| Disputes & Complaints Manager | `EMP-300202` Michael Thornton | `CMP-` quality; root cause |
| Head of Retail Operations | `EMP-300101` | Branch service standards |
| Branch Manager | `EMP-300103` / others | Floor coaching; local recovery |
| Compliance Retail | `EMP-400103` | Conduct / UDAAP oversight |
| HR BP — Retail/CST | `EMP-200201` Fiona Gallagher | Conduct consequences |

---

## 6. Service Standards

| Standard | Target |
|---|---|
| Branch greeting | Within 60 seconds |
| Branch wait | ≤ 10 minutes average (`RTL-KPI-018`) |
| Contact centre ASA | ≤ 60 seconds |
| Chat first response | ≤ 45 seconds |
| Complaint acknowledgment | Within 2 business days |
| Complaint resolution | Within 8 calendar days average (`RTL-KPI-023`) |
| Identity authentication | 100% before account data / transactions |

**Brand behaviours:** Clear · Courteous · Competent · Confidential · Correct — no product pressure on distressed customers.

---

## 7. Customer Interactions

### 7.1 Authentication (`BP-CST-AUTH`)

| Channel | Method |
|---|---|
| Branch | Photo ID; card+PIN; biometric where enrolled |
| Phone | Knowledge-based + OTP / voice biometrics per ISC standard |
| Chat / secure message | ApexMobile / Online session MFA |
| High-risk change (address, payee, wire) | Step-up authentication mandatory |

Failed auth → no data; offer branch visit or callback after verification.

### 7.2 Branch Etiquette

- Queue token `QTK-########`; visible wait management  
- Private desk for vulnerable / complex / bereavement  
- No discussion of other customers  
- Name badge visible (`ANB-HRM-HBK-0001`)  
- Warm handoff with summary — customer should not repeat story  

### 7.3 Call / Chat Handling

```
Connect → Authenticate → Confirm reason → Resolve or log SRQ-/CMP-
        → Summarize actions → Offer digital self-serve tip → Close code
```

**Prohibited:** Guaranteeing loan approval; advising tax/legal outcomes; disclosing SAR/investigation status; arguing with customers.

---

## 8. Complaint Handling

Aligns with `ANB-CST-SOP-0001` and process `BP-CST-CMPL`.

```
Dissatisfaction expressed (any channel)
        │
        ├─ Log CMP-######## in Apex360 same day
        ├─ Severity: Standard / Sensitive / Executive
        ├─ Acknowledge (template + personalisation)
        ├─ Investigate (systems TXN-/RCP-/voice)
        ├─ Outcome: Uphold / Partially uphold / Not uphold
        ├─ Communicate remedy; goodwill if appropriate
        └─ Root cause tag → MI (RTL-KPI-021..023)
```

| Severity | Examples | Escalation |
|---|---|---|
| Standard | Fee dispute, wait time | CST / Branch Manager |
| Sensitive | Vulnerable customer; alleged discrimination; legal threat | `EMP-300202` + Compliance |
| Executive | CEO letter; regulator; media | Head of CST + Legal + MKT |

**Goodwill credits:** Within grade limits (`ANB-ADM-MTX-0001`); larger amounts Branch Manager / CST Manager.

---

## 9. Escalation Paths

| Situation | Escalate To | Timeline |
|---|---|---|
| Suspected fraud on account | Fraud `EMP-400106` | Immediate |
| AML / unusual activity | Do **not** tip off; Compliance / ApexGuard path | Same day |
| Discrimination allegation | Compliance + HR | Same day |
| Legal / summons | Legal `EMP-100006` path | Immediate |
| Data breach concern | ISC `EMP-500201` | Immediate |
| Mortgage / loan credit decision dispute | Credit / Mortgage Ops — not “re-underwrite on call” | 2 days |
| Threats of violence | Security + terminate call/visit safely | Immediate |

---

## 10. Vulnerable Customers

| Indicator | Adjusted Care |
|---|---|
| Cognitive / age-related difficulty | Slower pace; written summary; trusted third party with authority |
| Bereavement | Empathy script; hold collections outreach per policy |
| Financial abuse suspicion | Private conversation; escalate Fraud/Legal — do not confront alleged abuser |
| Language barrier | Interpreter service; do not use minors as interpreters for complex credit |
| Digital exclusion | Complete in branch; no forced app-only |

Document vulnerability flag in Apex360 with minimum necessary data (privacy — `REG-AML-008` / GLBA).

---

## 11. Service Recovery

| Failure | Recovery Toolkit |
|---|---|
| Long wait | Apology; expedite; manager intercept |
| Error fee | Reverse if Bank error; explain if customer-driven |
| Card not received | Tracker; expedite `DBC-`/`CRC-`; temporary limits advice |
| ATM down / skim claim | Empathy; Reg E claim path; `ATM-####` reference |
| Mortgage delay | Status transparency; supervisor callback same day |

**Recovery ≠ admission of legal liability** — Legal-approved language for Sensitive/Executive cases.

---

## 12. Decision Tree — Complaint vs Request

```
Customer contact
        │
        ├─ Wants something done, not unhappy? ──► SRQ-########
        ├─ Expresses dissatisfaction? ──► CMP-########
        ├─ Both (e.g. late card + angry)? ──► CMP- primary; SRQ- linked
        └─ Regulatory / fair lending language? ──► Sensitive CMP- + Compliance
```

---

## 13. Approval Authorities — Goodwill / Fee

| Amount | Approver |
|---|---|
| ≤ USD 50 | Frontline (within daily cap) |
| ≤ USD 250 | Branch Manager / CST Team Lead |
| ≤ USD 1,000 | Regional / `EMP-300202` |
| > USD 1,000 | Head of CST or Head of Retail Ops |

---

## 14. Examples

**Branch recovery:** Customer at `BRN-0412` waits 22 minutes (`QTK-20260818-0144`). Manager apologises; completes account maintenance; waives USD 12 monthly fee for one month; CSAT survey sent.

**Complaint — overdraft:** `CUS-04928311` files `CMP-202608-0088` on OD fees. Investigation shows Reg E opt-in valid; partial goodwill USD 35 as service recovery; education on linked savings ODP; root cause tagged for MI.

**No tipping off:** Customer asks if “the bank filed a report on me.” Staff uses approved script — cannot confirm or deny SAR; offers normal account servicing; alerts Compliance if persistent.

---

## 15. Risk and Compliance Controls

| Theme | Control |
|---|---|
| Conduct / UDAAP | Call monitoring; complaint themes to FCC/BPR |
| Privacy | Minimum necessary; no shoulder-screen |
| AML confidentiality | `ANB-CMP-SOP-0004` |
| Discrimination | Fair lending escalation |
| Training | `ANB-HRM-POL-0008` service + AML modules |
| Recording | ApexVoice retention per policy |

---

## 16. Related Documents

| ID | Title |
|---|---|
| `ANB-CST-SOP-0001` | Complaint Handling Procedure |
| `ANB-RTL-MAN-0003` | Branch Operations Manual |
| `ANB-RTL-GDL-0001` / `0002` | Savings / Checking Guides |
| `ANB-RTL-GDL-0003` | ATM Operations Guide |
| `ANB-RTL-RPT-FY26-0001` | Retail KPI Report |
| `ANB-RTL-POL-0003` / `0004` | Mortgage / Personal Loan Policies |
| `ANB-CMP-POL-0001` / `0002` | AML / KYC |
| `ANB-CMP-SOP-0004` | SAR Procedure |
| `ANB-RSK-POL-0005` | Operational Risk |
| `ANB-HRM-POL-0004` | Code of Conduct |
| `ANB-HRM-HBK-0001` | Employee Handbook |
| `ANB-ADM-REF-0001` | Company Profile |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix |

---

## 17. Review Cycle / Revision History

Annual; CFPB complaint theme spikes trigger interim update within 45 days.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | K. Novak / P. Nwankwo | Initial Customer Service Manual |

---

## Appendix A — Frontline Phrase Bank (Extract)

| Situation | Say |
|---|---|
| Wait | “Thank you for your patience — I’ll help you next.” |
| Fee | “I can explain the fee and check whether a waiver applies.” |
| SAR ask | “I’m not able to discuss investigative matters; I can help with your account needs.” |
| Vulnerable | “We can take this step by step — would a quieter desk help?” |

## Appendix B — Complaint File Minimum Contents

- [ ] `CMP-########`  
- [ ] `CUS-########`  
- [ ] Channel / date / verbatim issue  
- [ ] Auth method  
- [ ] Investigation notes / `TXN-` refs  
- [ ] Outcome and customer communication  
- [ ] Root cause / product tag  
- [ ] Goodwill amount / approver if any  

---

**End of Document** — `ANB-RTL-MAN-0004` v1.0 · C2 · Effective 2026-08-01
