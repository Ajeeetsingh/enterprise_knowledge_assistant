# Apex National Bank — Retail Banking KPI Report

**Management Report | FY2026 Monthly Retail Performance — July 2026**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-RPT-FY26-0001` |
| **Document Title** | Retail Banking KPI Report — July 2026 |
| **Version** | 1.0 |
| **Report Period** | 2026-07-01 to 2026-07-31 |
| **Owner** | Retail Banking (RTL) — Performance MI |
| **Custodian** | Patricia Nwankwo, Head of Retail Operations (G8) — `EMP-300101` |
| **Approver** | Gregory Lin, Head of Consumer & Retail Banking (G10) — `EMP-100014` |
| **Classification** | Confidential (C2) |
| **Effective / Publish Date** | 2026-08-08 |
| **Review Cycle** | Monthly issuance; framework annual |
| **Taxonomy** | `T3` → `T3.4` Retail Performance MI → `RPT` |
| **System of Record** | ApexInsight · ApexCore · Apex360 · ApexATM · ApexOrigin · ApexBranch |
| **Related Documents** | `ANB-RTL-MAN-0003`, `ANB-FIN-BUD-0005`, `ANB-RSK-STMT-0001`, `ANB-CMP-GDL-0008` |

---

## 2. Purpose

This Report provides ExCo, CRB leadership, and Regional Directors with a single monthly view of branch performance, product sales, deposits, loan growth, CASA, experience (NPS/CSAT/wait time), digital adoption, ATM uptime, complaints, and cross-sell — using canonical KPI IDs `RTL-KPI-###`.

---

## 3. Scope

Consumer & Retail Banking US network (1,842 branches; ~4,600 ATMs) plus digital retail. International retail shown only as memorandum items. Figures are **management information** (not audited financial statements); Finance alignment via `EMP-600116` Olumide Fashola.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **CASA** | Checking + Savings balances |
| **NPS** | Net Promoter Score — promoters % − detractors % |
| **CSAT** | Post-interaction satisfaction (1–5 → % ≥ 4) |
| **Cross-sell ratio** | Average products per active retail household |
| **Digital adoption** | % active customers with ApexMobile login in 90 days |

---

## 5. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| Head of CRB (`EMP-100014`) | Accountability for targets |
| Head of Retail Operations (`EMP-300101`) | Report integrity; branch KPIs |
| Regional Directors (e.g. `EMP-300102`) | Region commentary / actions |
| Finance Manager CRB (`EMP-600116`) | Balance / P&L reconciliation |
| Head of Digital (`EMP-300111`) | Digital KPIs |
| ATM Ops (`EMP-300112`) | Uptime |
| CST (`EMP-300201` / `EMP-300202`) | Complaint / CSAT inputs |
| Compliance Testing (`EMP-400107`) | Conduct KPI challenge as needed |

---

## 6. Executive Summary — July 2026

| Theme | Result | vs Plan | vs Prior Month |
|---|---|---|---|
| Deposit balances (retail) | USD 312.4B | +0.8% | +0.4% |
| CASA mix | 54.2% of retail deposits | +0.3 pp | +0.1 pp |
| Consumer loan originations | USD 4.82B | −1.2% | +3.1% |
| Mortgage originations | USD 2.16B | −4.0% (rate environment) | −2.2% |
| Network NPS | 41 | +1 vs plan 40 | +2 |
| ATM uptime | 98.7% | vs target 98.5% | +0.1 pp |
| Branch avg wait | 8.4 min | vs target ≤ 10 | −0.6 min |
| Complaints per 10k customers | 3.8 | vs target ≤ 4.5 | −0.2 |

**Management narrative:** Southeast (`EMP-300102`) led deposit growth; mortgage soft on rates; digital adoption hit plan; one Rank A ATM skimming cluster in Midwest drove temporary uptime dip (now remediated — see `ANB-RTL-GDL-0003`).

---

## 7. Scorecard — Canonical KPIs

| KPI ID | Metric | July 2026 | Target | Status |
|---|---|---|---|---|
| `RTL-KPI-001` | Retail deposit EOP balances (USD B) | 312.4 | 310.0 | Green |
| `RTL-KPI-002` | CASA % of retail deposits | 54.2% | 53.5% | Green |
| `RTL-KPI-003` | Net new checking accounts (`CHK-`) (000s) | 186 | 175 | Green |
| `RTL-KPI-004` | Net new savings accounts (`SAV-`) (000s) | 142 | 150 | Amber |
| `RTL-KPI-005` | Personal loan bookings (`PLN-`) (USD M) | 980 | 1,000 | Amber |
| `RTL-KPI-006` | Mortgage fundings (`HLN-`) (USD M) | 2,160 | 2,250 | Amber |
| `RTL-KPI-007` | HELOC / HEL outstandings (USD B) | 18.4 | 18.2 | Green |
| `RTL-KPI-008` | Debit cards active (`DBC-`) (M) | 19.6 | 19.4 | Green |
| `RTL-KPI-009` | Credit cards new (`CRC-`) (000s) | 88 | 90 | Amber |
| `RTL-KPI-010` | Branch sales appointments kept % | 91% | 90% | Green |
| `RTL-KPI-011` | Cross-sell ratio (products / HH) | 2.84 | 2.80 | Green |
| `RTL-KPI-012` | Primary relationship households (M) | 11.2 | 11.0 | Green |
| `RTL-KPI-013` | Digital adoption (90-day Mobile) | 68.5% | 68.0% | Green |
| `RTL-KPI-014` | Digital deposit % of total deposit txns | 61% | 60% | Green |
| `RTL-KPI-015` | Zelle / P2P active users (M) | 8.9 | 8.7 | Green |
| `RTL-KPI-016` | Network NPS | 41 | 40 | Green |
| `RTL-KPI-017` | Branch CSAT (% ≥ 4) | 86% | 85% | Green |
| `RTL-KPI-018` | Avg branch wait time (min) | 8.4 | ≤ 10 | Green |
| `RTL-KPI-019` | Contact centre ASA (sec) | 42 | ≤ 60 | Green |
| `RTL-KPI-020` | First contact resolution % | 78% | 75% | Green |
| `RTL-KPI-021` | Complaints opened (`CMP-`) | 9,140 | — | Monitor |
| `RTL-KPI-022` | Complaints / 10k customers | 3.8 | ≤ 4.5 | Green |
| `RTL-KPI-023` | Complaint avg resolution days | 6.2 | ≤ 8 | Green |
| `RTL-KPI-024` | ATM uptime % | 98.7% | ≥ 98.5% | Green |
| `RTL-KPI-025` | Rank A ATM uptime % | 99.1% | ≥ 99.0% | Green |
| `RTL-KPI-026` | Cash difference incidents > USD 200 | 37 | ≤ 40 | Green |
| `RTL-KPI-027` | CTR filing quality error rate | 0.28% | ≤ 0.50% | Green |
| `RTL-KPI-028` | KYC refresh SLA adherence | 97.6% | ≥ 98.0% | Amber |
| `RTL-KPI-029` | Early delinquency 30+ DPD consumer | 1.12% | ≤ 1.20% | Green |
| `RTL-KPI-030` | Mandatory training completion — branch | 99.4% | 100% | Amber |

---

## 8. Branch Performance — Regional Snapshot

| Region | Branches | Deposit Growth MoM | NPS | Wait (min) | Flagged Branches |
|---|---|---|---|---|---|
| Northeast | 486 | +0.3% | 39 | 9.1 | 12 |
| Southeast | 402 | +0.7% | 44 | 7.6 | 6 |
| Midwest | 358 | +0.2% | 40 | 8.8 | 9 |
| Southwest | 291 | +0.5% | 42 | 8.0 | 5 |
| West | 243 | +0.4% | 41 | 8.5 | 7 |

**Illustrative branch leaders:**

| Branch | ID | Deposit MoM | Wait | Notes |
|---|---|---|---|---|
| Charlotte Uptown Flagship | `BRN-0412` / `SIT-0412` | +1.1% | 7.2 | Strong PB pipeline (`EMP-300105`) |
| Chicago Loop Community | `BRN-0873` / `SIT-0873` | +0.2% | 11.4 | Wait amber — staffing action |

---

## 9. Product Sales and Loan Growth

| Product | July Units / Volume | FY26 YTD | Commentary |
|---|---|---|---|
| Essential / Relationship checking | 186k net new | 1.21M | Ahead of plan |
| Everyday / Advantage savings | 142k net new | 0.98M | Rate competition |
| Personal loans | USD 980M | USD 6.4B | Mix shift to lower risk tiers |
| Mortgages funded | USD 2.16B | USD 14.9B | Refinance weak; purchase resilient |
| Cards — new credit | 88k | 590k | Near plan |

Credit quality: consumer 30+ DPD `RTL-KPI-029` within appetite; mortgage delinquency monitored with Credit Risk (`EMP-400201`).

---

## 10. Experience, Digital, ATM, Complaints

### 10.1 Experience

| Channel | NPS | CSAT |
|---|---|---|
| Branch | 43 | 86% |
| Contact centre | 38 | 84% |
| ApexMobile | 47 | 89% |

### 10.2 Top Complaint Themes (`CMP-########`)

| Theme | Share | Owner |
|---|---|---|
| Fee / overdraft | 22% | Deposit Products / `ANB-RTL-GDL-0002` |
| Card / ATM dispute | 18% | Cards / ATM Ops |
| Wait time / service | 14% | Branch Network |
| Mortgage timeline | 11% | Mortgage Ops |
| Digital access | 9% | Digital Banking |

### 10.3 ATM

Uptime 98.7%; Midwest skimming cluster: 14 ATMs OOS peak day 2026-07-18; restored within 36 hours; Fraud closed field investigation.

---

## 11. Risk, Compliance, and Control Overlay

| Indicator | Result | Link |
|---|---|---|
| CTR quality | 0.28% error | `ANB-CMP-SOP-0007` |
| KYC refresh SLA | 97.6% (amber) | `ANB-CMP-POL-0002` |
| Cash differences > USD 200 | 37 | `ANB-RTL-SOP-0006` |
| Op loss retail (July) | USD 2.1M | `ANB-RSK-POL-0005` |
| Training gaps | 0.6% branch overdue | `ANB-HRM-POL-0008` |

Amber KYC SLA: concentrated in West — KYC Ops surge support agreed with `EMP-400112`.

---

## 12. Decision Tree — KPI Escalation

```
KPI status
        │
        ├─ Green ──► Monitor
        ├─ Amber 2 consecutive months ──► Regional action plan
        ├─ Red any month ──► Head of Retail Ops + CRB Head briefing
        └─ Conduct / AML KPI red ──► CCO path same week
```

---

## 13. Action Register (Extract)

| Action | Owner | Due |
|---|---|---|
| Chicago Loop wait time staffing | `EMP-300104` | 2026-08-31 |
| West KYC refresh backlog | `EMP-400112` + Regional | 2026-08-22 |
| Savings acquisition campaign | `EMP-300111` + MKT | 2026-09-15 |
| ATM anti-skimming retrofit Rank A Midwest | `EMP-300112` | 2026-09-30 |

---

## 14. Related Documents

`ANB-RTL-MAN-0003` · `ANB-RTL-GDL-0001` · `ANB-RTL-GDL-0002` · `ANB-RTL-GDL-0003` · `ANB-RTL-POL-0003` · `ANB-RTL-POL-0004` · `ANB-RTL-MAN-0004` · `ANB-FIN-BUD-0005` · `ANB-RSK-STMT-0001` · `ANB-CMP-GDL-0008` · `ANB-HRM-POL-0006` · `ANB-ADM-REF-0001`

---

## 15. Review Cycle / Revision History

Issued monthly by T+6 business days. Framework review annually.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-08-08 | P. Nwankwo | July 2026 monthly KPI report |

---

## Appendix A — Data Sources

| KPI Group | Source |
|---|---|
| Balances / CASA | ApexCore → ApexInsight |
| Originations | ApexOrigin |
| NPS / CSAT | Apex360 surveys |
| Wait time | ApexBranch queue |
| ATM uptime | ApexATM / ApexMonitor |
| Complaints | Apex360 / ApexServe `CMP-` |
| CTR quality | ApexRegRep / CMP QA |

## Appendix B — Heat Map (Regions × Experience)

| Region | NPS | Wait | Complaints |
|---|---|---|---|
| Northeast | Amber | Amber | Green |
| Southeast | Green | Green | Green |
| Midwest | Green | Amber | Amber (ATM) |
| Southwest | Green | Green | Green |
| West | Green | Green | Amber (KYC) |

---

**End of Document** — `ANB-RTL-RPT-FY26-0001` v1.0 · July 2026
