# Apex National Bank — Checking Account Guide

**Product Guide | Personal and Business Checking, Overdraft, Cheques, and Daily Operations**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-GDL-0002` |
| **Document Title** | Checking Account Guide |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Deposit Products |
| **Custodian** | Patricia Nwankwo, Head of Retail Operations (G8) — `EMP-300101` |
| **Approver** | Gregory Lin, Head of Consumer & Retail Banking (G10) — `EMP-100014` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.1` Deposit Products → `GDL` |
| **Business Process** | `BP-ONB-ACCT`, `BP-DEP-MAINT`, `BP-DEP-FEE`, `BP-CARD-ISS`, `BP-BRN-CASH` |
| **System of Record** | ApexCore · ApexTeller · ApexPay · ApexCards · ApexMobile · Apex360 |
| **Related Documents** | `ANB-RTL-GDL-0001`, `ANB-RTL-POL-0001`, `ANB-RTL-MAN-0003`, `ANB-CMP-POL-0002` |

---

## 2. Purpose

Checking (current) accounts are the primary transactional relationship for retail and small-business customers. This Guide defines personal and business checking variants, minimum balances, overdraft programmes, cheque operations, fees, and day-to-day servicing standards across branch, ATM, and digital channels.

---

## 3. Scope

Personal checking, joint checking, Apex Student Checking, Apex Small Business Checking (revenue < USD 10M), and India Current Accounts where licensed. Corporate cash management (CBK) is out of scope.

Canonical entities: Appendix A of `ANB-RTL-GDL-0001`.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Checking Account Record** | `CHK-########` linked to `ACC-##########` and `CUS-########` |
| **ODP** | Overdraft Protection — linked savings or LOC |
| **ODLOC** | Apex Overdraft Line of Credit — revolving unsecured line |
| **NSF** | Non-sufficient funds |
| **Reg E / Reg CC** | Electronic fund transfers / funds availability |
| **Cheque / Check** | Negotiable instrument processed via ApexPay / image cash letter |

---

## 5. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| Head of Retail Operations (`EMP-300101`) | Product operations; Guide custodian |
| Head of Cards (`EMP-300110`) | Debit issuance `DBC-########`; dispute handoff |
| Head of Digital Banking (`EMP-300111`) | ApexMobile / ApexOnline entitlements |
| Branch Manager (`EMP-300103` / `EMP-300107`) | Local exceptions; cash / cheque quality |
| Teller (`EMP-300106` / `TEL-####`) | Deposits, withdrawals, cheque intake |
| Contact Centre (`EMP-300201`) | Authenticated servicing; stop payments |
| Compliance Retail (`EMP-400103`) | UDAAP, Reg DD/E, overdraft practice review |
| Risk — Retail Op Risk (`EMP-400203`) | Loss events; RCSA for deposit processes |

---

## 6. Product Variants

| Code | Name | Min Opening | Monthly Fee | Fee Waiver |
|---|---|---|---|---|
| `CHK-ESS` | Apex Essential Checking | USD 25 | USD 12 | Direct deposit ≥ USD 500/mo or age 17–24 |
| `CHK-REL` | Apex Relationship Checking | USD 100 | USD 0 | Combined deposit/invest ≥ USD 5,000 |
| `CHK-STU` | Apex Student Checking | USD 0 | USD 0 | Valid student status to age 24 |
| `CHK-SMB` | Apex Business Checking | USD 100 | USD 15 | Average balance ≥ USD 5,000 |
| `CHK-IND` | Apex India Current (INR) | INR 5,000 | Per schedule | Balance / salary credit |

Each books as `CHK-########` + `ACC-##########`. Debit card `DBC-########` standard on personal products.

---

## 7. Minimum Balances and Relationship Pricing

| Product | Avoid Fee / Earn Benefits |
|---|---|
| Essential | Direct deposit OR age waiver OR military |
| Relationship | Combined CASA + Apex Wealth ≥ USD 5,000 |
| Business | Combined deposit ≥ USD 5,000 OR ≥ 20 ApexPay ACH credits/mo |

Balances calculated on average daily ledger balance in ApexCore. MI owned by `EMP-600116`.

---

## 8. Overdraft

### 8.1 Programmes

| Programme | Description | Credit Link |
|---|---|---|
| Linked Savings Transfer | Auto-transfer from `SAV-` | Fee USD 10 per transfer day |
| ODLOC | Apex Overdraft Line of Credit | Subject to `ANB-RTL-POL-0004` / credit decision |
| Discretionary OD (ATM/POS) | Opt-in Reg E for ATM and one-time debit | Per-item fee USD 35; max 4/day |

**Policy statements:**

- **CHK-OD-1.** No Reg E ATM/POS overdraft fees without affirmative opt-in.
- **CHK-OD-2.** Continuous OD > 35 days → restrict and collections referral (`EMP-300114`).
- **CHK-OD-3.** ODLOC underwriting uses `MDL-202402-0018` / consumer scorecards per `ANB-RSK-POL-0004`.

### 8.2 Decision Tree — Overdraft Presentment

```
Item presented (cheque / ACH / debit)
        │
        ├─ Sufficient available balance? ──► Pay
        ├─ Linked SAV funds available? ──► Transfer + fee
        ├─ ODLOC available? ──► Draw + interest
        ├─ Reg E opt-in ATM/POS? ──► Discretionary pay + fee (limits)
        └─ Else ──► Return NSF / decline; notice per Reg E/DD
```

---

## 9. Cheques and Instruments

| Activity | Standard |
|---|---|
| Chequebook order | ApexOnline / branch; first book free on Relationship |
| Deposit | Image capture ApexMobile or ApexTeller; Reg CC availability |
| Stop payment | Authenticated request; fee USD 30; `SRQ-########` |
| Demand draft / cashier’s cheque | Branch issuance; dual control > USD 5,000 |
| Stale-dated | > 6 months — supervisor review before pay |

India: multi-city cheques and local clearing per India addendum; NEFT/RTGS/IMPS/UPI preferred for payments.

---

## 10. Fees (Personal — Illustrative Schedule)

| Fee | USD |
|---|---|
| Monthly maintenance (Essential, unwaved) | 12.00 |
| NSF / returned item | 35.00 |
| Discretionary OD (opt-in) | 35.00 |
| Stop payment | 30.00 |
| Cashier’s cheque | 10.00 |
| Domestic wire out | 25.00 |
| Expedited debit card | 20.00 |

Business fee schedule published separately; cash deposit fees may apply above soft limits for SMB.

---

## 11. Daily Operations Workflow

```
Customer arrives / digital session
        │
        ├─ Authenticate (ID / MFA / card+PIN)
        ├─ Queue token QTK-######## (branch)
        │
        ├─ Deposit cash/cheque ──► ApexTeller; TXN-; RCP-; CTR check
        ├─ Withdrawal ──► Limits; large cash dual control
        ├─ Cheque issue / stop ──► ApexCore
        ├─ Card activate / replace ──► ApexCards
        ├─ ACH / Zelle / wire / India rails ──► ApexPay
        └─ Maintenance (address, SI) ──► Apex360 + ApexCore
```

**Branch cash withdrawal limits (teller):** USD 5,000 standard; USD 5,001–25,000 Branch Manager; above USD 25,000 Cash Services + notice (`ANB-RTL-SOP-0006`).

---

## 12. Risk and Compliance Controls

| Control | Reference |
|---|---|
| CIP / BO for SMB | `ANB-CMP-POL-0002`, FinCEN BO |
| CTR / structuring | `ANB-CMP-SOP-0007`, `ANB-CMP-POL-0001` |
| Sanctions screening on wires | `ANB-CMP-SOP-0005` |
| Overdraft UDAAP testing | `ANB-CMP-GDL-0008` |
| Fraud / mule indicators | `RULE-AML-0401`; Head of Fraud `EMP-400106` |
| Op risk cash differences | `ANB-RSK-POL-0005` |

---

## 13. Examples

**Example 1 — Digital open:** `CUS-03115590` opens `CHK-202608-0156` via ApexMobile; `KYC-202608-0156` complete; `DBC-202608-0156` issued; first direct deposit expected; Essential fee waived on DD.

**Example 2 — Branch cash + CTR:** `CUS-04928311` deposits USD 12,400 cash to `CHK-202402-1102` at `BRN-0412`. Teller `TEL-0412` captures conductor data; `CTR-202607-004821` path per CTR SOP; receipt `RCP-202607-4412`.

---

## 14. Related Documents

`ANB-RTL-GDL-0001` · `ANB-RTL-POL-0001` · `ANB-RTL-POL-0004` · `ANB-RTL-MAN-0003` · `ANB-RTL-SOP-0006` · `ANB-RTL-GDL-0003` · `ANB-RTL-MAN-0004` · `ANB-CMP-POL-0001` · `ANB-CMP-POL-0002` · `ANB-RSK-FRM-0001` · `ANB-CST-SOP-0001` · `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001`

---

## 15. Review Cycle / Revision History

Annual review; next **2027-07-31**.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | P. Nwankwo | Initial checking guide |

---

## Appendix A — Funds Availability (Reg CC Summary)

| Deposit Type | Availability |
|---|---|
| Cash | Next business day |
| US Treasury cheque | Next business day |
| Local cheque (case-by-case image) | Next business day first USD 225; remainder per schedule |
| New account (first 30 days) | Extended holds permitted with notice |

---

**End of Document** — `ANB-RTL-GDL-0002` v1.0
