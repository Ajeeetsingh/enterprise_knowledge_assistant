# Apex National Bank — Cash Handling Procedure

**Standard Operating Procedure | Receipts, Payments, Dual Control, Counterfeit, Balancing, and Transport**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-SOP-0006` |
| **Document Title** | Cash Handling Procedure |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Cash Services |
| **Custodian** | Helen Cho, Cash Services Manager (G6) — `EMP-300113` |
| **Approver** | Patricia Nwankwo, Head of Retail Operations (G8) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.3` → Cash Operations → `SOP` |
| **Business Process** | `BP-BRN-CASH`, `BP-BRN-OPEN`, `BP-AML-CTR` |
| **System of Record** | ApexTeller · ApexCore · ApexServe · ApexBranch |
| **Related Documents** | `ANB-RTL-MAN-0003`, `ANB-CMP-SOP-0007`, `ANB-RSK-POL-0005` |

---

## 2. Purpose

Cash is high-risk inventory. This Procedure defines end-to-end controls for receiving, paying, securing, balancing, verifying, and transporting currency and coin so that losses, counterfeit intake, and BSA reporting failures are prevented and auditable.

---

## 3. Scope

All branch cash, vault cash, ATM cassettes prepared in-branch, and CIT movements. Vault cash accounting interfaces to Finance (`CC-RTL-*`). India cash operations follow local currency addendum with same dual-control principles.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Cash Box** | `CBX-####` — teller drawer inventory |
| **Vault** | `VAULT-####` — branch reserve under dual control |
| **Difference** | Over / short vs ApexTeller expected |
| **CIT** | Cash-in-transit vendor (Tier 1 — `ANB-RSK-FRM-0002`) |
| **Counterfeit** | Suspected non-genuine note — Secret Service / local protocol |
| **Strapped cash** | Banded currency with teller stamp / system strap ID |

---

## 5. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| Teller (`TEL-####`) | Accurate count; counterfeit screening; balance drawer |
| Branch Manager | Dual control; difference investigation; approvals |
| Cash Services (`EMP-300113`) | Policy; CIT; surprise verification programme |
| Regional Director (`EMP-300102`) | Escalation; chronic difference branches |
| Compliance (`EMP-400104`) | CTR aggregation; structuring themes |
| Op Risk (`EMP-400203`) | Loss recording `REV-########` |
| CIT vendor | Secure transport; sealed bag integrity |

---

## 6. Cash Receipts (Deposits)

```
Customer presents cash
        │
        ├─ Authenticate customer / conductor
        ├─ Count in view of customer (where safe)
        ├─ Screen notes (UV/magnetic/pen per denomination rules)
        ├─ ApexTeller post → TXN-########## → RCP-########
        ├─ CTR / aggregation check (ANB-CMP-SOP-0007)
        └─ Strap / place in CBX-; sell excess to vault intraday
```

**CASH-1.** Never leave unsecured cash unattended.

**CASH-2.** Conductor ID captured when conductor ≠ account holder (CTR-relevant).

---

## 7. Cash Payments (Withdrawals / Cashier’s Cheques Cash-Out)

| Step | Control |
|---|---|
| Verify available balance | ApexTeller / ApexCore |
| Authenticate | ID standards; large amount enhanced |
| Authority | Limits per `ANB-RTL-MAN-0003` §10 |
| Dual control | Required ≥ USD 10,000 payout or per local schedule |
| Dispense | Count twice; customer acknowledgment |
| Receipt | `RCP-########` mandatory |

---

## 8. Dual Control Matrix

| Activity | Dual Control Required |
|---|---|
| Vault open / close | Yes |
| Vault buy/sell | Yes |
| ATM cassette load (branch) | Yes |
| Cashier’s cheque / DD > USD 5,000 | Yes |
| Customer cash out > USD 10,000 | Yes |
| CIT bag preparation | Yes |
| Combination / key custody change | Yes + ApexAccess update |

Solo custody of vault keys **and** combination by one person is prohibited.

---

## 9. Counterfeit Detection

1. Train annually (`ANB-HRM-POL-0008` cash module).  
2. Suspect note: do not return to presenter if confiscation protocol applies; issue receipt.  
3. Stamp / isolate per Secret Service guidance; notify Branch Manager.  
4. Log ApexServe incident; notify Cash Services.  
5. Do not accuse customer of criminality at window — professional script.  

Genuine replacement only per legal guidance — typically no.

---

## 10. Cash Balancing

| When | Action |
|---|---|
| Intraday | Balance on suspicious difference or limit breach |
| End of day | Mandatory full `CBX-` balance before vault sell |
| Vault | Dual count vs ApexTeller vault position |
| ATM | Per `ANB-RTL-GDL-0003` |

**Difference thresholds:**

| Amount | Action |
|---|---|
| ≤ USD 20 | Log; teller explanation; trend monitor |
| USD 20.01–200 | Manager review same day |
| > USD 200 | Cash Services + potential `REV-`; HR if pattern |
| > USD 1,000 | Regional + Op Risk + consider investigation |

Charge-off / GL: Finance mapping `ANB-FIN-STD-0004`; operational loss `ANB-RSK-POL-0005`.

---

## 11. Surprise Verification

| Element | Standard |
|---|---|
| Frequency | Each branch ≥ 2× per year unannounced |
| Performer | Regional ops, Cash Services, or Internal Audit |
| Scope | Random `CBX-`, vault straps, ATM cassette seals |
| Failure | Immediate recount; access suspension if integrity doubt |
| Evidence | ApexServe + ApexDocs; `RET-AUD-7Y` |

Mandatory consecutive absence for sensitive cash roles supports detection of concealment (`ANB-HRM-POL-0002`).

---

## 12. Cash Transport (CIT)

```
Prepare shipment
  ├─ Dual count and seal bag
  ├─ Manifest in ApexTeller / CIT portal
  ├─ Vendor ID verified on arrival
  ├─ CCTV coverage of handoff
  └─ Receipt retained RCP-/CIT reference
```

**CASH-T-1.** Only approved CIT vendors (`VEN-*` Tier 1).

**CASH-T-2.** No employee personal vehicle for vault cash.

**CASH-T-3.** Robbery in transit — vendor + Bank incident protocol; do not resist.

---

## 13. Decision Tree — Difference

```
Drawer does not balance
        │
        ├─ Recount currency and cheques
        ├─ Review TXN- log for miskeys
        ├─ Still off ≤ USD 20? ──► Log and close
        ├─ Still off > USD 20? ──► Manager recount
        └─ Suspect theft / fraud? ──► Freeze access; escalate HR/Investigations
```

---

## 14. Examples

**Balanced day — `BRN-0412`:** Teller `TEL-0412` ends with zero difference; sells USD 6,200 to `VAULT-0412` under dual control with `EMP-300103`.

**CTR-linked deposit:** Cash USD 12,400 to `CHK-202402-1102`; procedure + CTR SOP executed; no teller discretion to split tickets to avoid CTR.

**Shortage:** `CBX-0873-02` short USD 350 at `BRN-0873`. Manager recount confirms; ApexServe case; Cash Services reviews CCTV; teller placed on supervised cash pending outcome.

---

## 15. Risk and Compliance Controls

| Control | Reference |
|---|---|
| CTR / structuring | `ANB-CMP-SOP-0007`, `ANB-CMP-POL-0001` |
| Dual control | `CTL` in RCSA `BP-BRN-CASH` |
| Op loss | `REV-########`, `RAM-0008` |
| Vendor CIT | `ANB-RSK-FRM-0002` |
| Audit | `EMP-400301` retail branch cash audits |

---

## 16. Related Documents

`ANB-RTL-MAN-0003` · `ANB-RTL-GDL-0003` · `ANB-RTL-GDL-0002` · `ANB-CMP-SOP-0007` · `ANB-RSK-POL-0005` · `ANB-RSK-POL-0001` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0004` · `ANB-FIN-STD-0004` · `ANB-ADM-REF-0001`

---

## 17. Review Cycle / Revision History

Annual; after any theft > USD 5,000 within 15 days.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | H. Cho | Initial cash handling procedure |

---

## Appendix A — Teller End-of-Day Pack

- [ ] All `TXN-` committed  
- [ ] Cheques imaged / batched  
- [ ] Cash counted to system  
- [ ] Differences documented  
- [ ] Vault sell dual-signed  
- [ ] Drawer locked; keys secured  

---

**End of Document** — `ANB-RTL-SOP-0006` v1.0
