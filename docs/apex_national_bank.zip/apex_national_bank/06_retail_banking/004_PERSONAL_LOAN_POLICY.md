# Apex National Bank — Personal Loan Policy

**Enterprise Policy | Unsecured Consumer Lending — Eligibility, Scoring, Approval, and Collections**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-POL-0004` |
| **Document Title** | Personal Loan Policy |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Consumer Lending |
| **Custodian** | Omar Haddad, Head of Consumer Lending (G8) — `EMP-300109` |
| **Approver** | Gregory Lin (`EMP-100014`) with Head of Credit Risk concurrence (`EMP-400201`) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.2` Lending Products → Consumer Loans → `POL` |
| **Business Process** | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-CRD-APPR`, `BP-COLL-EARLY`, `BP-COLL-LATE` |
| **System of Record** | ApexOrigin · ApexCore · ApexModel · ApexCredit · ApexReach |
| **Related Documents** | `ANB-RSK-FRM-0001`, `ANB-RSK-POL-0004`, `ANB-CBK-POL-0001`, `ANB-RTL-POL-0003` |

---

## 2. Purpose

Apex Personal Loans (USD 2,000–100,000; 12–84 months fixed rate) and related unsecured products (including ODLOC) must be originated with consistent ability-to-repay assessment, model-governed scoring, clear approval authorities, and disciplined collections — within consumer unsecured credit authority in `ANB-ADM-REF-0001` §5.4.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| Apex Personal Loan instalment | Auto loans (separate product SOP) |
| ODLOC linked to checking | Mortgage / HELOC (`ANB-RTL-POL-0003`) |
| Student refinance (consumer) | Commercial / SMB term loans (CBK) |

Facility ID: `PLN-########` booked to ApexCore; application `APP-##########`.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Personal Loan** | Unsecured instalment credit `PLN-########` |
| **Scorecard** | `MDL-202402-0018` and consumer unsecured models in ApexModel |
| **Adverse action** | Decline or counteroffer — FCRA/Reg B notice |
| **Exception** | Approval outside standard policy — `BP-CRD-EXC` |
| **Early-stage collections** | 1–29 DPD — `BP-COLL-EARLY` |
| **Late-stage collections** | 30+ DPD — `BP-COLL-LATE` |

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Head of Consumer Lending | `EMP-300109` Omar Haddad | Policy; channel quality |
| Head of Credit Risk | `EMP-400201` Lars Henriksson | Credit standards; overrides |
| Head of Model Risk | `EMP-400204` Kenji Okada | Scorecard validation |
| Head of Collections | `EMP-300114` Andre Fontaine | Collections strategy; agencies |
| Branch / Digital | PB / ApexMobile | Application intake; disclosures |
| Compliance Retail | `EMP-400103` | Fair lending; UDAAP; SCRA |
| Finance — CRB | `EMP-600116` | Product P&L; provision interface |

---

## 6. Eligibility

| Criterion | Standard |
|---|---|
| Age | 18+ (or state majority) |
| Identity / KYC | Complete `KYC-########`; not `CR-P` |
| Income | Verifiable; sufficient residual after DTI |
| Credit score | Typically ≥ 660 for standard pricing; 620–659 thicker file / lower amount |
| Citizenship | US person or documented eligible resident |
| Existing exposure | Apex unsecured aggregate limits apply |
| Bankruptcy | Seasoning overlays (typically 4 years Ch.7 / 2 years Ch.13 discharge) |

**India personal loans:** local product addendum; bureau + income per India regulations.

---

## 7. Income Assessment

| Income Type | Evidence |
|---|---|
| Salary / wages | Paystubs ≤ 30 days; VOE if needed |
| Self-employed | 2 years tax returns; YTD P&L |
| Fixed income | Award letters; 1099s |
| Rental | Leases + tax schedule |

DTI policy max **40%** standard for unsecured; **45%** with compensating factors (liquidity, Apex relationship tenure ≥ 24 months).

---

## 8. Credit Scoring and Decisioning

```
APP-########## submitted
        │
        ├─ Hard bureau pull (permissible purpose)
        ├─ Scorecard MDL-* + policy rules engine
        │
        ├─ AUTO-APPROVE ≤ USD 25,000 (authority matrix)
        ├─ REFER — manual underwriter
        └─ DECLINE — adverse action notice ≤ 30 days (target 7)
```

**PLN-SCR-1.** No production use of unvalidated models (`ANB-RSK-POL-0004`).

**PLN-SCR-2.** Adverse action reasons specific and FCRA-compliant.

**PLN-SCR-3.** Pricing based on risk-based schedule; fair lending monitored quarterly.

---

## 9. Approval Authorities

| Amount | Approver |
|---|---|
| ≤ USD 25,000 scorecard approve | Automated ApexOrigin |
| ≤ USD 50,000 | Branch Manager (G5) — within scoreband |
| ≤ USD 150,000 | Credit Manager (G6) |
| ≤ USD 250,000 | Senior Credit Officer (G7) |
| Policy exception | One level up + Credit Risk concurrence |
| ODLOC ≤ USD 5,000 | Automated / Branch Manager per matrix |

---

## 10. Exceptions

| Exception Type | Documentation | Approver |
|---|---|---|
| Score below floor | Compensating factors memo | Credit Manager+ |
| DTI 40–45% | Residual income proof | Credit Manager |
| Recent thin file | Alternate data / relationship | Senior Credit Officer |
| Counteroffer amount cut | Customer acceptance recorded | System + UW |

All exceptions tagged in ApexOrigin for fair lending and audit sampling (`EMP-400301`).

---

## 11. Disclosures and Booking

- TILA / Reg Z disclosures before consummation
- Ability-to-repay attestation in file
- Book `PLN-########` / `ACC-` in ApexCore; funds via ApexPay ACH or credit to `CHK-`
- Right of rescission N/A for unsecured non-HELOC

---

## 12. Collections

| Stage | DPD | Actions |
|---|---|---|
| Friendly reminder | 1–15 | SMS/email ApexReach; CSR call |
| Early collections | 16–29 | Agent outreach; payment arrangements |
| Late collections | 30–89 | Formal demand; hardship review |
| Charge-off eval | 120 (policy) | Accounting per FIN CECL; recovery continues |
| Agency / legal | Post charge-off | Approved agencies only — TPRM `ANB-RSK-FRM-0002` |

**PLN-COL-1.** FDCPA / Reg F and TCPA compliance mandatory.

**PLN-COL-2.** SCRA / MLA protections verified before adverse action.

**PLN-COL-3.** Bankruptcy — cease collection; Legal protocol.

---

## 13. Risk and Compliance Controls

| Theme | Control |
|---|---|
| Credit appetite | Unsecured growth within portfolio limits; NPL `RAM-0005` |
| Model drift | `BP-MDL-MON`; PSI alerts |
| Fraud | Synthetic ID; first-party fraud — `EMP-400106` |
| AML | Loan proceeds structuring; mule use — ApexGuard |
| UDAAP | Fee and collections practice testing |

---

## 14. Examples

**Approve:** `CUS-04928311` requests USD 18,000 / 60 months; FICO 701; DTI 32%; Apex checking 3 years. Auto-approve `PLN-202603-0441`; funds to `CHK-202402-1102`.

**Decline / counter:** Score 628; DTI 44%; requested USD 40,000. Counteroffer USD 12,000 / 36 months; customer declines; adverse action sent; `APP-` closed.

---

## 15. Related Documents

`ANB-RTL-POL-0003` · `ANB-RTL-GDL-0002` · `ANB-RTL-MAN-0004` · `ANB-RSK-FRM-0001` · `ANB-RSK-POL-0004` · `ANB-RSK-STMT-0001` · `ANB-CMP-POL-0001` · `ANB-CBK-POL-0001` · `ANB-ADM-REF-0001` · `ANB-FIN-SOP-0003` · `ANB-CST-SOP-0001`

---

## 16. Review Cycle / Revision History

Annual; rate sheet may update monthly without full policy reissue.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | O. Haddad | Initial personal loan policy |

---

## Appendix A — Decision Tree — Exceptions

```
Policy rule fail
        │
        ├─ Safety & soundness issue (fraud, CR-P)? ──► DECLINE — no exception
        ├─ Compensating factors documented? ──NO──► DECLINE / counter
        └─ YES ──► Route per §10; record BP-CRD-EXC
```

---

**End of Document** — `ANB-RTL-POL-0004` v1.0
