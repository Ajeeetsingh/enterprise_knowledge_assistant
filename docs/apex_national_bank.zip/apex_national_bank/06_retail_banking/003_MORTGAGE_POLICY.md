# Apex National Bank — Mortgage Policy

**Enterprise Policy | Residential Mortgage Eligibility, Underwriting, LTV, and Servicing**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-POL-0003` |
| **Document Title** | Mortgage Policy |
| **Version** | 1.0 |
| **Owner** | Retail Banking (RTL) — Mortgage |
| **Custodian** | Rachel Kim, Head of Mortgage (G8) — `EMP-300108` |
| **Approver** | Gregory Lin (`EMP-100014`) with CRO concurrence (`EMP-100004`) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Taxonomy** | `T3` → `T3.2` Lending Products → Mortgages → `POL` |
| **Business Process** | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-CRD-APPR`, `BP-SRV-BILL`, `BP-SRV-MOD` |
| **System of Record** | ApexOrigin · ApexCredit · ApexCore · ApexModel · ApexDocs |
| **Related Documents** | `ANB-RTL-FRM-0002`, `ANB-RTL-SOP-0005`, `ANB-CBK-POL-0001`, `ANB-RSK-FRM-0001` |

---

## 2. Purpose

This Policy sets enterprise standards for originating, underwriting, approving, and servicing residential mortgages so that growth remains within Board risk appetite (`RAM` metrics; max LTV 90% with MI / 80% without; min FICO 620 standard per `ANB-RSK-STMT-0001`) while delivering fair, compliant outcomes for customers.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| Apex Fixed, ARM, Jumbo, FHA/VA, Construction-to-Permanent, Investment Property (1–4) | Commercial CRE (CBK) |
| Portfolio and agency-eligible originations | Securities trading of MBS (TRY) |
| HELOC / Home Equity Loan (second lien standards) | Unsecured personal loans (`ANB-RTL-POL-0004`) |

Applications: `MTG-########` / `APP-##########`; facilities: `HLN-########`.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **LTV / CLTV** | Loan-to-value / combined LTV including subordinate liens |
| **MI** | Mortgage insurance — required when LTV > 80% on conventional |
| **DTI** | Debt-to-income ratio (front-end / back-end) |
| **ATR / QM** | Ability-to-Repay / Qualified Mortgage under CFPB rules |
| **HMDA** | Home Mortgage Disclosure Act reporting |
| **CRR** | Credit risk rating on facility — `CRR-####` per `ANB-RSK-FRM-0001` |

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Head of Mortgage | `EMP-300108` Rachel Kim | Policy custodian; production quality |
| Head of Credit Risk | `EMP-400201` Lars Henriksson | Underwriting standards; overrides |
| Head of Loan Servicing | `EMP-300115` Naomi Okonkwo | Billing, escrow, default servicing |
| Head of Special Assets | `EMP-400209` Elaine Morrison | Mods / foreclosure escalation |
| CRO | `EMP-100004` Helena Brandt | Appetite; GrCC / BRC path |
| Compliance — Retail | `EMP-400103` Priyanka Iyer | Fair lending; HMDA; UDAAP |
| Mortgage Loan Officer / PB | Branch / retail channel | Application intake `ANB-RTL-FRM-0002` |

---

## 6. Policy Statements

**MTG-1.** No mortgage commitment without complete application (`MTG-########`), CIP/KYC, and credit decision in ApexOrigin.

**MTG-2.** Maximum LTV **90%** with approved MI; **80%** without MI — aligned to `ANB-RSK-STMT-0001`. Investment property max LTV **75%** (1-unit) / **70%** (2–4).

**MTG-3.** Minimum representative credit score **620** for standard conventional; overlays may raise floors by product/channel.

**MTG-4.** ATR assessment mandatory; QM or documented ATR non-QM with Risk approval.

**MTG-5.** Credit authority follows `ANB-ADM-REF-0001` §5.4 and `ANB-CBK-POL-0001`: automated ≤ USD 500,000 conforming; Regional CC ≤ USD 15M; GrCC above.

**MTG-6.** Appraisal / valuation independence — no value influence by production staff.

**MTG-7.** Fair lending: no discouragement or discriminatory pricing; exceptions logged and monitored.

**MTG-8.** Servicing complies with RESPA/Reg X, TILA/Reg Z, and CFPB servicing rules.

---

## 7. Eligibility

| Factor | Primary Residence Conventional | Investment |
|---|---|---|
| Citizenship / residency | US citizen / PR / eligible foreign national with overlays | Same + stronger reserves |
| Credit score | ≥ 620 (≥ 680 jumbo preferred) | ≥ 680 |
| DTI (back-end) | ≤ 43% QM; ≤ 50% exception path | ≤ 40% |
| Reserves | 2 months PITIA typical | 6–12 months |
| KYC / risk rating | Not `CR-P`; EDD if `CR-H` / PEP | Same |
| Property | 1–4 residential; eligible condo/warrantable | 1–4 non-owner |

---

## 8. Underwriting and Credit Assessment

### 8.1 Data Sources

ApexOrigin pulls bureau, income (VOE/VOI, tax transcripts), assets, ApexKYC status, and scorecard `MDL-202402-0018` (retail PD) where applicable. Facility rating `CRR-####` assigned at approval.

### 8.2 LTV / MI Matrix

| LTV | MI Required | Max DTI (std) |
|---|---|---|
| ≤ 80% | No | 43% |
| 80.01–90% | Yes | 43% |
| > 90% | **Prohibited** (policy) | — |

### 8.3 Documentation

| Document | Requirement |
|---|---|
| Application | `ANB-RTL-FRM-0002` in ApexOrigin |
| ID / CIP | Linked `KYC-########` |
| Income | Paystubs, W-2, tax returns as applicable |
| Assets | Statements ≤ 60 days |
| Purchase contract / title | Current |
| Appraisal | Independent AMC; interior for purchase/refi cash-out |
| Insurance / flood | Binding before funding |

---

## 9. Risk Controls

| Control | Detail |
|---|---|
| Appetite | `RAM-0005` NPL; retail mortgage moderate growth |
| Concentration | Geographic and product MI via ApexCredit |
| Model risk | Scorecards validated `ANB-RSK-POL-0004` |
| Fraud | Occupancy misrep, income fraud — Fraud + Investigations |
| AML | Source of down payment; third-party funding `RULE-AML-0402` |
| Climate / flood | Flood zone determination mandatory |

---

## 10. Approval Authorities

| Exposure | Approver |
|---|---|
| ≤ USD 500,000 conforming, scorecard pass | Automated ApexOrigin |
| ≤ USD 1,500,000 | Credit Manager (G6) |
| ≤ USD 5,000,000 | Senior Credit Officer (G7) |
| ≤ USD 15,000,000 | Regional Credit Committee |
| > USD 15,000,000 | Group Credit Committee (`EMP-100004` chair) |
| Policy exception (LTV/DTI/score) | One level above standard + Risk concurrence |

---

## 11. Servicing

| Activity | Owner | System |
|---|---|---|
| Billing / escrow | `EMP-300115` | ApexCore |
| Customer inquiries | CST / Mortgage Servicing | Apex360 |
| Forbearance / mod | Special Assets + Servicing | ApexOrigin / ApexCredit |
| Agency reporting | Servicing Ops | Investor portals |
| Default / foreclosure | Special Assets `EMP-400209` | ApexCredit |

Portfolio loans serviced in-house; agency-sold loans per sub-servicing agreements (`ANB-RSK-FRM-0002` vendor oversight).

---

## 12. Operational Workflow (Summary)

```
MTG-######## intake → KYC/CIP → Credit pull → AUS / underwriter
        → Appraisal → Conditions → Clear to close
        → Closing docs → Disbursement HLN-######## / ACC-
        → Servicing board → Ongoing escrow / HMDA close
```

Detailed steps: `ANB-RTL-SOP-0005`.

---

## 13. Examples

**Example:** `CUS-03115590` purchase USD 520,000; loan USD 416,000 (80% LTV); FICO 742; DTI 36%. `MTG-202605-2210` auto-approved; `HLN-202605-0099` boarded; first payment schedule in ApexCore.

**Exception:** LTV 87% with MI; DTI 46%. Credit Manager approves with compensating factors (reserves 6 months; residual income); logged exception in ApexOrigin; fair lending sample pool.

---

## 14. Related Documents

`ANB-RTL-SOP-0005` · `ANB-RTL-FRM-0002` · `ANB-RTL-POL-0004` · `ANB-CBK-POL-0001` · `ANB-CBK-TPL-0003` · `ANB-RSK-STMT-0001` · `ANB-RSK-FRM-0001` · `ANB-RSK-POL-0004` · `ANB-CMP-POL-0001` · `ANB-CMP-POL-0002` · `ANB-ADM-MTX-0001` · `ANB-ADM-REF-0001` · `ANB-HRM-POL-0008`

---

## 15. Review Cycle / Revision History

Annual with Credit Risk; interim on CFPB/QM or FHFA limit changes within 45 days.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | R. Kim | Initial mortgage policy |

---

## Appendix A — Product × Max LTV

| Product | Max LTV |
|---|---|
| Fixed / ARM conforming primary | 90% w/ MI; 80% w/o |
| Jumbo primary | 80% (85% limited exception) |
| FHA | Per FHA handbook (Bank overlays apply) |
| VA | Per VA; Bank residual income overlays |
| Investment 1-unit | 75% |
| HELOC CLTV | 85% |

---

**End of Document** — `ANB-RTL-POL-0003` v1.0
