# Apex National Bank — Trade Finance Manual

**Operations Manual | Documentary Credits, Guarantees, Collections, Compliance, and Fraud**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-MAN-0001` |
| **Document Title** | Trade Finance Manual |
| **Version** | 1.0 |
| **Owner** | Corporate Banking (CBK) — Trade Finance |
| **Custodian** | Thomas Reinhardt, Head of Trade Finance (G8) — `EMP-300306` |
| **Approver** | Alicia Moreau, Head of Commercial Banking (G10) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-TRD-LC`, `BP-TRD-SCF`, `BP-SAN-SCRN`, `BP-CRD-APPR` |
| **System of Record** | ApexTrade · ApexCredit · ApexPay · ApexKYC · ApexWatch |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-CMP-SOP-0005`, `ANB-CMP-POL-0001`, `ANB-RSK-FRM-0001` |

---

## 2. Purpose

Trade finance enables import/export clients to move goods under controlled payment and risk terms. This Manual sets standards for letters of credit, standby LCs, bank guarantees, import/export finance, collections, Incoterms handling, SWIFT messaging, trade sanctions compliance, dual-use goods, shipping documents, and fraud indicators.

---

## 3. Scope

All documentary and guarantee products on ApexTrade for CMB/CIB clients with approved trade lines under `FAC-########`. Supply-chain finance programmes (`BP-TRD-SCF`) included at programme level.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **LC** | Documentary letter of credit — `LC-########` |
| **SBLC** | Standby letter of credit |
| **BG** | Bank guarantee / demand guarantee — `BG-########` |
| **UCP 600** | ICC Uniform Customs for documentary credits |
| **URDG 758** | ICC rules for demand guarantees |
| **MT700** | SWIFT issue of a documentary credit |
| **Trade transaction** | `TRD-########` umbrella in ApexTrade |

---

## 5. Roles

| Role | Employee | Responsibility |
|---|---|---|
| Head of Trade Finance | `EMP-300306` | Manual; product risk |
| Trade Operations | Trade Ops team | Document examination; SWIFT |
| RM | Client coverage | Facility utilisation; client KYC |
| Credit Risk | `EMP-400201` team | Trade line approval |
| Sanctions | `EMP-400105` Catherine O'Brien | Screening / holds |
| Compliance FC | `EMP-400101` | TBML patterns |

---

## 6. Letters of Credit

### 6.1 Issuance Workflow

```
Client application (ApexTrade)
        │
        ├─ Verify trade line availability on FAC-
        ├─ Sanctions screen parties, vessels, ports, goods (SCR-)
        ├─ Dual-use / restricted goods check
        ├─ Price / collateral / cash margin as required
        ├─ Draft LC terms; client approval
        ├─ Issue MT700 (and MT701 continuations)
        └─ Assign LC-########; link TRD-########
```

### 6.2 Examination

Documents examined under UCP 600 for discrepancy. Pay / refuse within UCP timelines. Discrepant presentations: client waiver or refusal.

### 6.3 Products

| Product | Use |
|---|---|
| Import LC | Apex as issuing bank |
| Export LC advise / confirm | Apex as advising / confirming |
| Transferable / back-to-back | Restricted — specialist approval |
| Revolving LC | Within facility sublimit |

---

## 7. Standby LC and Bank Guarantees

| Instrument | Typical Purpose | Rules |
|---|---|---|
| Performance SBLC | Contract performance | ISP98 / UCP as stated |
| Financial SBLC | Payment support | Credit intensive |
| Advance payment BG | Mobilisation funds | URDG 758 |
| Bid / tender BG | Tender security | Short tenor |
| Customs / tax BG | Regulatory | Local form |

`BG-########` booked against guarantee sublimit; same sanctions controls as LC.

---

## 8. Import and Export Finance

| Product | Description |
|---|---|
| Import loan | Finance LC maturity / collection |
| Export negotiation / discount | Purchase of export bills |
| Receivables finance | Approved buyer programmes |
| Supply chain finance | Anchor buyer payables `BP-TRD-SCF` |

Tenor typically ≤ 180 days; longer requires Credit approval.

---

## 9. Bills Collection

Clean and documentary collections under URC 522. Apex acts as remitting or collecting bank. No payment undertaking unless separately confirmed/financed.

---

## 10. Incoterms

Staff must understand risk transfer points (FOB, CIF, DAP, DDP, etc.). LC goods description and Incoterm must align with insurance requirements (e.g., CIF requires insurance docs).

---

## 11. SWIFT MT700 (Core Fields)

| Tag | Content |
|---|---|
| 40A | Form of credit |
| 31D | Date and place of expiry |
| 50 | Applicant |
| 59 | Beneficiary |
| 32B | Currency / amount |
| 41a | Available with / by |
| 43P / 43T | Partial / transhipment |
| 44E / 44F / 44B | Ports / place |
| 45A | Description of goods |
| 46A | Documents required |
| 47A | Additional conditions |
| 71B | Charges |
| 49 | Confirmation instructions |

Amendments via MT707. Never issue free-format substitutes for controlled MT700 without Trade Ops dual control.

---

## 12. Trade Compliance and Sanctions

| Control | Standard |
|---|---|
| Party screening | Applicant, beneficiary, banks, vessels, dual parties — `ANB-CMP-SOP-0005` |
| Country | Prohibited / high-risk jurisdictions blocked |
| Goods | Dual-use, military, luxury to sanctioned destinations |
| Vessel / AIS | Maritime red flags (`SCN` sanctions evasion typology) |
| TBML | Over/under invoicing; phantom shipment — `RULE-AML-0301` |
| True hit | Do not tip off; escalate `BP-SAN-ESC` |

**No LC issuance** on Compliance hold.

---

## 13. Dual-Use Goods

Goods on commerce control lists require export licence evidence where applicable. Trade Ops checklist; Compliance consult for uncertain ECCN/HS codes. Decline if licence cannot be evidenced and risk remains.

---

## 14. Shipping Documents (Typical LC Set)

- Commercial invoice  
- Bill of lading / AWB / multimodal transport doc  
- Packing list  
- Certificate of origin  
- Insurance (if CIF/CIP)  
- Inspection certificate (if required)  
- Other as 46A  

Examine for consistency of goods, quantity, dates, consignees, and alterations.

---

## 15. Fraud Indicators

| Indicator | Response |
|---|---|
| Beneficiary newly formed / thin file | Enhanced DD; possible decline |
| Price vs market outlier | TBML review |
| Soft CL / unusual urgency | Verify authenticity via RMA / authenticated SWIFT only |
| Duplicate B/L / freight forwarder fraud | Hold; verify carrier |
| Third-party LC with no commercial logic | Escalate Credit + FC |
| Document photocopy quality / manipulation | Refuse; investigate |

Example: Export LC advise for unknown beneficiary — verify with issuing bank via SWIFT; do not rely on email PDF alone.

---

## 16. Examples

**Import LC — Meridian:** `LC-202607-4412` / `TRD-202607-8841` for specialty chemicals; applicant `CORP-10000001`; screened clear; issued MT700; documents compliant; paid at sight.

**Guarantee — Summit Health:** `BG-202608-1102` performance guarantee USD 5M under `FAC-10057844` sublimit; URDG 758.

---

## 17. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-SOP-0001` · `ANB-CBK-GDL-0001` · `ANB-CMP-SOP-0005` · `ANB-CMP-POL-0001` · `ANB-CMP-MAN-0001` · `ANB-RSK-POL-0001` · `ANB-ITO-PLN-0002` (SWIFT DR) · `ANB-TRY-MAN-0001`

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | T. Reinhardt | Initial trade finance manual |

---

## Appendix A — Pre-Issuance Checklist

- [ ] Trade line available on `FAC-`  
- [ ] All parties screened (`SCR-`)  
- [ ] Goods / dual-use cleared  
- [ ] Incoterms / insurance coherent  
- [ ] Pricing / margin / cash collateral booked  
- [ ] Client authorised signatory  
- [ ] MT700 dual-authorised  

---

**End of Document** — `ANB-CBK-MAN-0001` v1.0
