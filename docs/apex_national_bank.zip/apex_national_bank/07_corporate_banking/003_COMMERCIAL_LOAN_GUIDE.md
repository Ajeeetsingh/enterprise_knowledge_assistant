# Apex National Bank — Commercial Loan Guide

**Product Guide | Commercial Loan Lifecycle from Origination through Workout and Closure**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-GDL-0001` |
| **Document Title** | Commercial Loan Guide |
| **Version** | 1.0 |
| **Owner** | Corporate Banking (CBK) — Commercial Banking |
| **Custodian** | Alicia Moreau, Head of Commercial Banking (G10) — `EMP-100015` |
| **Approver** | Lars Henriksson, Head of Credit Risk (G9) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-SRV-BOOK`, `BP-CORP-COV`, `BP-COLL-LATE` |
| **System of Record** | ApexOrigin · ApexCredit · ApexCore · Apex360 |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-CBK-SOP-0001`, `ANB-CBK-POL-0002`, `ANB-CBK-TPL-0003` |

---

## 2. Purpose

This Guide is the operating reference for Relationship Managers and Credit Analysts managing commercial loans (typically client revenue USD 10M–500M): lifecycle stages, required documents, financial analysis, collateral, risk grading, pricing, approval, disbursement, monitoring, default, workout, and closure.

---

## 3. Scope

Commercial term loans, RCFs, ABL, equipment finance, owner-occupied CRE, and SBA overlays. Large corporate / syndicate nuances in `ANB-CBK-POL-0001` and `ANB-CBK-GDL-0003`. Trade instruments: `ANB-CBK-MAN-0001`.

Canonical borrowers: Appendix A of `ANB-CBK-POL-0001`.

---

## 4. Loan Lifecycle

```
Prospect → Onboarding (ANB-CBK-SOP-0002)
        → Credit application APP-
        → Analysis / Memo / Grading CRR-
        → Approval (SOP-0001)
        → Documentation & Collateral COL-
        → Disbursement FAC- live
        → Monitoring / Covenants COV-
        → Renewal / Amendment
        → (Default) → Workout / Exit
        → Closure / Release
```

---

## 5. Required Documents

| Package | Contents |
|---|---|
| Identity / KYB | Formation docs; BO certification; signatory list — `ANB-CBK-GDL-0002` |
| Financials `FIN-########` | 3 years audited or reviewed statements; interim YTD; AR aging if ABL |
| Projections | 12–36 month forecast for term / acquisition |
| Debt schedule | All third-party debt |
| Collateral | Appraisals; UCC searches; insurance binders |
| Legal | Authority (board resolution); landlord waivers if needed |
| Tax | EIN confirmation; good standing |

**Example — Cascade Logistics `CORP-10000003`:** `FIN-10040118-FY25` audited; ABL borrowing base certificate monthly.

---

## 6. Financial Statement Analysis

| Area | Focus |
|---|---|
| Income | Revenue quality; EBITDA adjustments; margin trend |
| Balance sheet | Leverage; liquidity; working capital cycle |
| Cash flow | CFO vs net income; free cash flow; debt service |
| Quality | Audit opinion; related-party; contingent liabilities |

Minimum standards by segment in Credit Underwriting Standards annex (ApexDocs); analyst completes `ANB-CBK-TPL-0003` sections.

**Meridian FY2025 extract (`FIN-10028441-FY25`):** Revenue USD 412M; EBITDA USD 48M; Total Debt USD 95M; Debt/EBITDA 2.0x; Interest cover 5.1x.

---

## 7. Collateral

Eligible types, haircuts, valuation: `ANB-CBK-POL-0002`. Commercial loans typically take:

- All-assets GSA (`COL-########-GSA`)
- Specific RE mortgage for OOCRE
- Equipment liens
- Owner / sponsor guarantees (unlimited or limited)

Perfection before first draw (`CTL-CRD-004`).

---

## 8. Credit Scoring and Risk Grading

| Tool | Use |
|---|---|
| Commercial rating model `MDL-202403-0022` | Financial + qualitative → master scale |
| Obligor grade | `CRR-0001`–`CRR-0008` (`ANB-RSK-FRM-0001`) |
| Facility grade | May notch for security / subordination |
| Overrides | Documented; Risk approval |

Watchlist if migrate to `CRR-0004`+.

---

## 9. Pricing

SOFR + margin by grade and RAROC; commitment fee on undrawn; unused line fee. FTP applied (`ANB-TRY-MAN-0001`). Exceptions via credit approval path.

---

## 10. Approval and Disbursement

Follow `ANB-CBK-SOP-0001`. Conditions precedent typical:

1. Executed facility agreement  
2. Perfected security  
3. KYC clear  
4. Insurance  
5. No MAC / default  
6. Initial borrowing base (ABL)  

Funds to operating account `ACC-##########` or third-party per purpose letter.

---

## 11. Monitoring

| Activity | Frequency |
|---|---|
| Financial reporting | Quarterly / monthly if watch |
| Covenant test | Per `COV-` schedule |
| Site visit | Annual (`CRR-0001`–`0003`); semi-annual watch |
| Borrowing base | Monthly ABL |
| Insurance / taxes | Calendar in ApexCredit |
| Early warning | Revenue −20% YoY; covenant headroom < 10%; key customer loss |

---

## 12. Default Handling

| Event | Action |
|---|---|
| Technical default | Notice; cure period; waiver assessment |
| Payment default | Demand; freeze further draws; Special Assets notify |
| Cross-default | Legal + Credit Risk |
| Fraud / AML | Compliance investigations; possible SAR — no tip-off |

Default notices through Legal templates; RM does not freelance legal threats.

---

## 13. Workout

Owned by Special Assets `EMP-400209` with RM support:

- Forbearance / amendment  
- Additional collateral  
- Partial sale / restructuring  
- Enforcement / foreclosure  
- Charge-off coordination with FIN CECL (`MDL-202401-0044`)

Example path: Northwind Energy `CORP-10000004` at `CRR-0004` — heightened monitoring; leverage waiver request routed GrCC.

---

## 14. Closure

| Step | Action |
|---|---|
| Payoff quote | ApexCredit / Loan Ops |
| Final payment | ApexPay |
| Release | UCC termination; mortgage satisfaction |
| Guarantee release | Per docs |
| Facility status | Closed on `FAC-`; retain `RET-AML-5Y` / credit file retention |

---

## 15. Decision Tree — New Money vs Decline

```
Commercial request
        │
        ├─ Prohibited industry / CR-P? ──► Decline
        ├─ Cash flow insufficient even with collateral? ──► Decline / reduce
        ├─ Within authority & appetite? ──► SOP-0001 path
        └─ Watchlist / CRR-0005+ existing? ──► Special Assets consult before new money
```

---

## 16. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-SOP-0001` · `ANB-CBK-POL-0002` · `ANB-CBK-TPL-0003` · `ANB-CBK-GDL-0002` · `ANB-CBK-GDL-0003` · `ANB-RSK-FRM-0001` · `ANB-RSK-STMT-0001` · `ANB-CMP-POL-0002` · `ANB-TRY-MAN-0001` · `ANB-FIN-SOP-0003`

---

## 17. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | A. Moreau | Initial commercial loan guide |

---

## Appendix A — Illustrative Facility Snapshot

| Field | Cascade Logistics `FAC-10040118` |
|---|---|
| Type | ABL revolving |
| Limit | USD 45M |
| Borrowing base | 85% eligible AR + 50% eligible inventory |
| CRR | `CRR-0003` |
| Collateral | `COL-10040118-GSA`, `COL-10040118-AR` |
| Covenant | Fixed charge ≥ 1.15x (`COV-10040118-01`) |
| RM | `EMP-300301` |

---

**End of Document** — `ANB-CBK-GDL-0001` v1.0
