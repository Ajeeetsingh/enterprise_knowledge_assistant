# Apex National Bank — Corporate Account Opening Guide

**Product Guide | Corporate Deposit Onboarding, UBO, KYB, Signatories, and Tax**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-GDL-0002` |
| **Document Title** | Corporate Account Opening Guide |
| **Version** | 1.0 |
| **Owner** | Corporate Banking (CBK) — Transaction Banking / Onboarding |
| **Custodian** | Rajiv Mehta, Head of Transaction Banking (G8) — `EMP-300308` |
| **Approver** | Alicia Moreau (`EMP-100015`) with CCO concurrence path |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-ONB-CORP`, `BP-ONB-CIP`, `BP-ONB-KYC`, `BP-ONB-EDD`, `BP-CORP-CASH` |
| **System of Record** | ApexKYC · ApexCore · Apex360 · ApexDocs |
| **Related Documents** | `ANB-CMP-POL-0002`, `ANB-CBK-SOP-0002`, `ANB-CMP-SOP-0006`, `ANB-RTL-POL-0001` |

---

## 2. Purpose

Corporate operating, deposit, and cash-management accounts require legal-entity identification, beneficial ownership, authority evidence, and tax documentation before ApexCore booking. This Guide standardises KYB/CIP for legal entities so Transaction Banking, RMs, and KYC Operations open accounts consistently with `ANB-CMP-POL-0002`.

---

## 3. Scope

Legal entity customers: corporations, LLCs, partnerships, trusts (commercial), associations. Correspondent banks follow EDD path (`ANB-CMP-SOP-0006`). Consumer accounts: Retail guides.

Identifiers: `CORP-########` + `CUS-########` + deposit `ACC-##########` / `CHK-` product wrappers where used.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **KYB** | Know Your Business — entity due diligence |
| **UBO / BO** | Ultimate beneficial owner — ≥ 25% equity or control |
| **Control person** | Individual with significant management responsibility |
| **Board resolution** | Authorises account opening and signatories |
| **Authorized signatory** | Person empowered to bind the entity on the account |

---

## 5. Roles

| Role | Responsibility |
|---|---|
| RM | Sponsor; collect package; attest relationship purpose |
| Client Onboarding / KYC Ops (`EMP-400112`) | Verification; ApexKYC record |
| Transaction Banking (`EMP-300308`) | Product setup; cash management |
| Compliance | EDD / PEP / high-risk industry |
| Legal | Complex authority / trust documents |

---

## 6. Corporate Onboarding Package

| Document | Requirement |
|---|---|
| Formation / good standing | Certificate of incorporation / formation; good standing ≤ 90 days where available |
| Operating agreement / bylaws | Evidence of authority |
| Board / members resolution | Account opening; signatory list; product powers |
| BO certification | FinCEN CDD form or equivalent (`ANB-CMP-FRM-0003` path) |
| Control person ID | CIP for control person + all BO ≥ 25% |
| Signatory IDs | Government photo ID each signatory |
| Tax | W-9 or W-8 series; EIN/TIN |
| Financials (credit clients) | Per credit path; optional for deposit-only low risk |
| Proof of address | Registered and principal place of business |

---

## 7. UBO Verification

```
Entity ownership tree
        │
        ├─ Identify all ≥ 25% owners (direct/indirect)
        ├─ Drill through holding companies to natural persons
        ├─ Identify one control person (CEO/CFO/equivalent)
        ├─ CIP verify each natural person
        ├─ Screen SCR- / PEP- each
        └─ If opaque after reasonable drill-down ──► Decline / EDD
```

Layered structures (e.g. Harborpoint `CUS-06291004` / `CORP-10000007`) trigger `EDD-` per `ANB-CMP-SOP-0006`.

---

## 8. KYB and Corporate KYC

| Element | Standard |
|---|---|
| Legal name / trade names | Match formation docs |
| Registration number | State / country ID |
| NAICS / business description | Documented |
| Purpose of account | Operating / payroll / escrow — specific |
| Expected activity | Volumes; geographies; cash intensity |
| Risk rating | `CR-L` / `CR-M` / `CR-H` / `CR-P` |
| Record | `KYC-########` + `CDD-` / `EDD-` |

Screening mandatory before account live (`CTL-CMP-001` / `010`).

---

## 9. Board Resolution and Signatories

Resolution must:

1. Name Apex National Bank  
2. Authorise account types  
3. List signatories and signing rules (sole / dual)  
4. Authorise online banking administrators  
5. Be certified by corporate secretary / equivalent  

Changes to signatories: new resolution or certified update; ApexCore maintenance `SRQ-` / call-back verification.

---

## 10. Tax Documents

| Form | When |
|---|---|
| W-9 | US persons |
| W-8BEN-E / W-8IMY etc. | Foreign entities |
| FATCA / CRS self-cert | Per entity type |
| Sales tax / exemption | If applicable to services |

Missing tax forms → withhold per FIN/Tax (`EMP-600107`) guidance; account may be restricted.

---

## 11. Account Opening Workflow

```
RM submits package → ApexKYC case
        → CIP/BO/screening
        → Risk rate
        → EDD if needed
        → Approve KYC
        → Create CORP-/CUS- if new
        → Book ACC- in ApexCore
        → Entitlements Apex Business Online / ApexPay
        → Welcome / mandate confirmation
```

Full orchestration: `ANB-CBK-SOP-0002`.

---

## 12. Decision Tree

```
Corporate application
        │
        ├─ Sanctions / CR-P? ──► Decline
        ├─ BO incomplete? ──► Pend — no account
        ├─ High-risk industry / PEP? ──► EDD path
        ├─ Complex trust / offshore? ──► EDD + Legal
        └─ Standard SMB/corporate transparent ──► Standard CDD open
```

---

## 13. Examples

**Vertex Cloud `CORP-10000005`:** Delaware C-Corp; BO two founders 40%/35% + VC fund <25% each LP look-through documented; resolution dual signature; `CHK` operating + ApexPay; `KYC-202604-51233` `CR-M`.

**Helix Pharma `CORP-10000002`:** Operating + controlled disbursement; EDD not required; trade line separate under `FAC-10031902`.

---

## 14. Risk and Compliance Controls

| Control | Reference |
|---|---|
| CIP / BO | `ANB-CMP-POL-0002`, `REG-AML-001/002` |
| Sanctions | `ANB-CMP-SOP-0005` |
| EDD | `ANB-CMP-SOP-0006` |
| Expected vs actual | TM / refresh triggers |
| Signatory fraud | Callback on mandate change |

---

## 15. Related Documents

`ANB-CBK-SOP-0002` · `ANB-CBK-POL-0001` · `ANB-CMP-POL-0002` · `ANB-CMP-GDL-0007` · `ANB-CMP-SOP-0006` · `ANB-CMP-FRM-0003` · `ANB-RTL-GDL-0002` · `ANB-ADM-STD-0005` · `ANB-RSK-POL-0001`

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | R. Mehta | Initial corporate account opening guide |

---

## Appendix A — Package Checklist

- [ ] Formation + good standing  
- [ ] Resolution  
- [ ] BO form + IDs  
- [ ] Control person ID  
- [ ] Signatory IDs  
- [ ] W-9 / W-8  
- [ ] Expected activity  
- [ ] Screening clear  
- [ ] `KYC-` approved  

---

**End of Document** — `ANB-CBK-GDL-0002` v1.0
