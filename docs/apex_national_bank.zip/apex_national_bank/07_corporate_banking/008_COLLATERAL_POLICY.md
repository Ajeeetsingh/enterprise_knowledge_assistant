# Apex National Bank — Collateral Policy

**Enterprise Policy | Eligible Collateral, Haircuts, Valuation, Monitoring, Release, and Substitution**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-POL-0002` |
| **Document Title** | Collateral Policy |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) — Credit Risk with Credit Administration |
| **Custodian** | Amélie Fontaine, Head of Credit Administration (G8) — `EMP-300307` |
| **Approver** | Lars Henriksson, Head of Credit Risk (G9) — `EMP-400201` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-CRD-DOC`, `BP-SRV-BOOK`, `BP-SRV-PAY`, `BP-CORP-COV` |
| **System of Record** | ApexCredit · ApexDocs · ApexLegal |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-CBK-CTR-0002`, `ANB-RSK-FRM-0001` |

---

## 2. Purpose

Collateral reduces loss given default but does not replace cash-flow underwriting. This Policy defines eligible collateral, indicative haircuts, valuation standards, perfection, monitoring, release, and substitution for commercial and corporate facilities (`COL-########`).

---

## 3. Scope

Security for facilities under `ANB-CBK-POL-0001`. Retail mortgage collateral standards remain in `ANB-RTL-POL-0003`. Margin collateral for markets/treasury counterparties follows Treasury/Credit annexes.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Collateral record** | `COL-########` in ApexCredit |
| **Haircut** | Percentage reduction from market/appraised value to lending value |
| **Perfection** | Legal steps to establish priority (UCC, mortgage, control, possession) |
| **Substitution** | Replacement of collateral with equal or better quality |
| **Release** | Discharge of Bank’s security interest |

---

## 5. Eligible Collateral

| Category | Eligible | Typically Ineligible |
|---|---|---|
| Cash / deposits at Apex | Yes — control agreement | Uncontrolled third-party cash |
| Listed investment-grade securities | Yes | Concentrated volatile single names without limit |
| Commercial real estate | Yes — appraisal standards | Special-use without exit path (case-by-case) |
| Residential 1–4 (commercial purpose) | Restricted | Owner primary residence for large C&I (policy preference against) |
| Accounts receivable | Yes — eligibility criteria | Affiliate / >90 day / disputed / government without overlays |
| Inventory | Yes — raw/finished eligible | Obsolete / consignment without control |
| Equipment | Yes | Specialized with no secondary market (deep haircut / decline) |
| Guarantees | Support — not primary collateral | Circular / inadequate capacity guarantors |
| Shares (private) | Restricted — pledge + controls | Unregistered thinly valued stock as sole support |
| Intellectual property | Rare — specialist valuation | Unsupported brand-only |

---

## 6. Indicative Haircuts

Aligned with `ANB-RSK-FRM-0001` §7:

| Collateral | Haircut (indicative) | Revaluation |
|---|---|---|
| Cash / Apex deposits | 0–5% | Daily |
| Listed IG securities | 15–30% | Daily / weekly |
| Owner-occupied CRE | 20–35% | Annual (external > USD 10M) |
| Investment CRE | 25–40% | Annual / more if watch |
| Eligible AR | 40–60% (advance rate inverse) | Monthly BB |
| Inventory | 50–70% | Monthly BB |
| Equipment | 30–50% | Annual |
| Private company shares | 50–80% or decline | Event-driven |

Product-specific advance rates (ABL) supersede where tighter.

---

## 7. Valuation Standards

| Type | Standard |
|---|---|
| CRE | FIRREA-conformant appraisal; independence; AMC where required |
| Equipment | Desk or field appraisal by approved valuer |
| Securities | Mark-to-market from approved data feeds |
| AR / Inventory | Borrowing base certificate + field exam (periodic) |
| Guarantor | Personal financial statement / corporate analysis |

Appraisal influence by RM production staff is prohibited (same independence principle as mortgages).

---

## 8. Perfection and Documentation

| Collateral | Perfection |
|---|---|
| Personal property | UCC-1 filing; search prior liens |
| Deposit accounts | Control agreement |
| Securities | Control / possession |
| CRE | Recorded mortgage / deed of trust; title policy |
| Guarantees | Executed guarantee; capacity opinion if needed |

Docs stored under `FAC-` in ApexDocs; template security schedules align with `ANB-CBK-CTR-0002`.

**COL-1.** No first draw against required security until perfected (`CTL-CRD-004`).

---

## 9. Monitoring

| Activity | Frequency |
|---|---|
| Insurance confirmation | Annual / binder tracking |
| Tax / HOA status (CRE) | Per calendar |
| UCC continuation | Pre-lapse |
| Borrowing base | Monthly ABL |
| Appraisal refresh | On renewal; or if `CRR-0004`+ |
| Site inspection | Per credit grade |
| Concentration in collateral pool | Ongoing |

Impairment of collateral value → restructure lending value; possible margin call / paydown.

---

## 10. Release

| Scenario | Approver |
|---|---|
| Full payoff | Loan Ops + Credit Admin checklist |
| Partial release — LTV remains in policy | Authority equivalent to original credit (or SCO minimum) |
| Partial release — increases risk | Same as new money for exposure |
| Release of guarantee | Credit Risk + Legal |

Release documents dual-controlled; UCC-3 termination timely after payoff.

---

## 11. Substitution

Substitution permitted if:

1. New collateral eligible and perfected  
2. Lending value ≥ released value (or shortfall cured by paydown)  
3. Documented amendment  
4. Approved at required authority  

Like-kind inventory turnover under ABL is operational, not a formal substitution, if within BB eligibility rules.

---

## 12. Decision Tree — Accept Collateral

```
Proposed security
        │
        ├─ Ineligible type? ──► Reject
        ├─ Valuation stale / conflicted? ──► New valuation
        ├─ Prior liens priming Bank? ──► Intercreditor / decline
        ├─ Insurance inadequate? ──► Condition precedent
        └─ Else ──► Accept with policy haircut; perfect before draw
```

---

## 13. Examples

**Meridian:** `COL-10028441-GSA` all-assets; `COL-10028441-RE` plant appraised USD 62M; 30% haircut → lending value USD 43.4M; supports RCF alongside cash flow.

**Cascade ABL:** `COL-10040118-AR` / inventory; eligibility excludes affiliate receivables; field exam annually.

**Release:** Summit Health pays down term loan tranche; partial equipment release approved by SCO after LTV re-check on remaining `FAC-10057844`.

---

## 14. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-SOP-0001` · `ANB-CBK-GDL-0001` · `ANB-CBK-CTR-0002` · `ANB-CBK-TPL-0003` · `ANB-RSK-FRM-0001` · `ANB-RSK-STMT-0001` · `ANB-LEG` security opinions practice · `ANB-ADM-POL-0001`

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | A. Fontaine | Initial collateral policy |

---

## Appendix A — Collateral Record Minimum Fields (`COL-########`)

Facility ID; type; description; location; valuation amount/date/source; haircut; lending value; perfection type/date/filing numbers; insurance; monitoring frequency; status (held / released / substituted).

---

**End of Document** — `ANB-CBK-POL-0002` v1.0
