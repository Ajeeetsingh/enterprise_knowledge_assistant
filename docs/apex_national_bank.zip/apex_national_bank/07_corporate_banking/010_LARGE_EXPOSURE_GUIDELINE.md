# Apex National Bank — Large Exposure Guideline

**Compliance Guideline | Single-Name, Connected Counterparties, Concentration, Stress, and Escalation**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-GDL-0003` |
| **Document Title** | Large Exposure Guideline |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) — Credit Risk / Portfolio Management |
| **Custodian** | Sophia Brandt, Head of Portfolio Management (G8) — `EMP-300309` |
| **Approver** | Lars Henriksson, Head of Credit Risk (G9); Helena Brandt, CRO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-CRD-APPR`, `BP-CORP-COV`, `BP-RSK-STRESS`, `BP-RSK-APP` |
| **System of Record** | ApexCredit · ApexRisk · ApexInsight |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-RSK-STMT-0001`, `ANB-RSK-FRM-0001`, `ANB-LEG-REF-0003` |

---

## 2. Purpose

Large and concentrated exposures threaten capital and earnings in stress. This Guideline defines single-borrower and connected-counterparty aggregation, industry and country limits, stress testing, Board reporting, early warning indicators, and escalation — implementing `RAM-0006` / `RAM-0007` and regulatory large exposure expectations.

---

## 3. Scope

All credit and credit-equivalent exposures: loans, RCFs (drawn + undrawn with CCF), trade contingents (`LC-`/`BG-`), derivatives counterparty (CEM/SA-CCR as applicable), securities financing. Intraday payment exposures governed with Treasury. Retail granular portfolios excluded except where single-name > threshold.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Single borrower** | Legal entity obligor `CORP-` / `CUS-` |
| **Connected counterparties** | Group of clients linked by control or economic interdependence — aggregated |
| **Large exposure** | Exposure ≥ 10% of Tier 1 capital (internal reporting threshold; regulatory definitions applied in ApexCredit LE module) |
| **Limit ID** | `LMT-########` — obligor or group limit |
| **EWI** | Early warning indicator |

---

## 5. Single Borrower Limits

| Limit | Value | Reference |
|---|---|---|
| Soft internal management | 10% of capital — enhanced reporting | Portfolio Mgmt |
| Board appetite | ≤ 15% of capital (`RAM-0007`) | `ANB-RSK-STMT-0001` |
| Tolerance | ≤ 20% with BRC approval | Appetite |
| Hard stop | Decline new money that would breach without BRC | ApexCredit block |

Measurement: total exposure at default methodology in ApexCredit; include unused commitments with regulatory CCF.

**Example:** Northwind Energy group (`CORP-10000004`) monitored daily; RCF USD 200M + trade contingencies vs capital — utilisation reported in GrCC pack.

---

## 6. Connected Counterparties

Aggregate when:

- Control relationship (≥ 50% voting or dominant influence)  
- Common guarantor material to repayment  
- Economic dependence (e.g. >50% revenue to single counterparty)  
- Cross-default / single funding centre  

Group hierarchy maintained in ApexCredit. Harborpoint Holdings (`CORP-10000007` / `CUS-06291004`) and subsidiaries aggregated for LE.

RM must disclose known connections in credit memo (`ANB-CBK-TPL-0003` §2).

---

## 7. Industry Concentration

| Industry | Internal Cap | Notes |
|---|---|---|
| CRE (income-producing) | `RAM-0006` CRE/capital ≤ 300% | Constrained appetite |
| Energy | ≤ 8% of credit portfolio | Includes Northwind book |
| Healthcare | Soft 10% | Summit Health monitored |
| Technology | Soft 10% | Vertex Cloud |
| Manufacturing | Soft 12% | Meridian |
| Logistics / transport | Soft 8% | Cascade |

Breach → no new material origination without GrCC/BRC plan.

---

## 8. Country Limits

Country limit grid (ApexCredit) set by Credit Risk with Compliance geopolitical input. High-risk / FATF-listed jurisdictions: zero or EDD-only; sanctioned jurisdictions: prohibited. Cross-border trade exposure attributed by counterparty and goods destination.

---

## 9. Stress Testing

| Scenario | Application |
|---|---|
| `SCN-2026-CRD-001` | CRE price shock — LE migration |
| Sector energy shock | Northwind + suppliers |
| Top-20 name stress | Simultaneous downgrade two notches |
| Liquidity-linked | Large RCF draw + deposit outflow (`SCN-2026-LIQ-001`) |

Results to GrCC / BRC with capital impact (`BP-RSK-STRESS`; `EMP-400205` / `EMP-600111`).

---

## 10. Board and Committee Reporting

| Report | Forum | Frequency |
|---|---|---|
| Top 20 exposures | GrCC | Monthly |
| Large exposure ≥ 10% capital | GrCC + BRC summary | Monthly / Quarterly |
| Industry / country heat map | GrCC | Monthly |
| Appetite `RAM-0006/0007` | BRC | Quarterly |
| Watchlist LE names | GrCC | Monthly |

Minutes retained per `ANB-LEG-REF-0003`.

---

## 11. Early Warning Indicators

| EWI ID | Indicator | Amber | Red |
|---|---|---|---|
| `EWI-LE-01` | Single name / capital | > 12% | > 15% |
| `EWI-LE-02` | Connected group / capital | > 12% | > 15% |
| `EWI-LE-03` | Industry vs soft cap | > 90% cap | > 100% |
| `EWI-LE-04` | Top name downgrade to `CRR-0004` | Any Top 20 | Top 10 to `CRR-0005` |
| `EWI-LE-05` | Undrawn commitment > USD 100M high utilisation spike | > 80% util | > 95% util sudden |
| `EWI-LE-06` | Covenant headroom | < 15% | Breach |

Dashboard: ApexInsight — Large Exposure tile; owned by `EMP-300309`.

---

## 12. Escalation

```
EWI amber
        │
        ├─ Portfolio Mgmt action plan within 5 business days
        │
EWI red / RAM breach
        │
        ├─ Notify Head of Credit Risk + CRO same day
        ├─ Freeze new money to name/industry as directed
        ├─ GrCC extraordinary item
        └─ BRC if RAM-0007 breached or sustained > 5 days
```

| Situation | Escalate To | Timeline |
|---|---|---|
| Proposed deal breaches LE | Stop — BRC path only | Before commitment |
| Data quality break in aggregation | Credit Admin + ITO | 24 hours |
| Regulatory LE reporting error | FIN Regulatory Reporting `EMP-600106` + Risk | Immediate |

---

## 13. Operational Controls

| Control | Detail |
|---|---|
| Pre-deal check | ApexOrigin hard warning vs `LMT-` / LE capacity |
| Daily batch | ApexCredit LE recalculation |
| Manual overrides | CRO approval only; time-bound |
| Model / CCF changes | `ANB-RSK-POL-0004` governance |

---

## 14. Examples

**Within limits:** Meridian `LMT-10028441` USD 75M — well below single-name appetite; industry manufacturing within soft cap.

**Watch:** Northwind `FAC-10045520` USD 200M + contingencies; `CRR-0004`; `EWI-LE-04` amber; monthly GrCC deep dive; no upsize without BRC-ready pack.

**Connected:** Two logistics affiliates under Cascade parent — exposures summed before Regional CC approval of incremental ABL.

---

## 15. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-SOP-0001` · `ANB-CBK-TPL-0003` · `ANB-CBK-GDL-0001` · `ANB-RSK-STMT-0001` · `ANB-RSK-FRM-0001` · `ANB-RSK-POL-0001` · `ANB-TRY-MAN-0001` · `ANB-LEG-REF-0003` · `ANB-FIN` capital/LE reporting · `ANB-CMP-POL-0001`

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | S. Brandt | Initial large exposure guideline |

---

## Appendix A — Pre-Commitment LE Checklist

- [ ] Obligor + connected group identified  
- [ ] ApexCredit group exposure current  
- [ ] Post-deal % of capital computed  
- [ ] Industry / country caps checked  
- [ ] `LMT-` headroom confirmed  
- [ ] If ≥ 10% capital — GrCC/BRC materials prepared  
- [ ] EWIs updated post-booking  

## Appendix B — Heat Map (Illustrative July 2026)

| Dimension | Status |
|---|---|
| Max single name | Green (11.2% peak) |
| CRE / capital | Amber (near `RAM-0006` management trigger) |
| Energy industry | Amber |
| Country — high risk | Green (within tight caps) |

---

**End of Document** — `ANB-CBK-GDL-0003` v1.0
