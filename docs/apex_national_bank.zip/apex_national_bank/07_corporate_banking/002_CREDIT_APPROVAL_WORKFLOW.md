# Apex National Bank — Credit Approval Workflow

**Standard Operating Procedure | End-to-End Corporate Credit Gates from RM Intake to Renewal**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-SOP-0001` |
| **Document Title** | Credit Approval Workflow |
| **Version** | 1.0 |
| **Owner** | Corporate Banking (CBK) — Credit Administration |
| **Custodian** | Amélie Fontaine, Head of Credit Administration (G8) — `EMP-300307` |
| **Approver** | Lars Henriksson, Head of Credit Risk (G9) — `EMP-400201` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-CRD-APPR`, `BP-CRD-DOC`, `BP-SRV-BOOK`, `BP-CORP-COV` |
| **System of Record** | ApexOrigin · ApexCredit · ApexKYC · ApexLegal · ApexDocs · ApexCore |
| **Parent Policy** | `ANB-CBK-POL-0001` |
| **Related Documents** | `ANB-CBK-TPL-0003`, `ANB-CBK-CTR-0002`, `ANB-LEG-REF-0003` |

---

## 2. Purpose

This SOP defines every approval gate for commercial and corporate credit — from Relationship Manager origination through Credit Committee, documentation, disbursement, monitoring, and renewal — so that no facility is booked without required Risk, Legal, and Compliance clearances.

---

## 3. Scope

All facilities under `ANB-CBK-POL-0001`. Retail mortgages follow `ANB-RTL-SOP-0005`. Trade instrument issuance follows `ANB-CBK-MAN-0001` with credit capacity from an approved `FAC-`.

---

## 4. End-to-End Workflow

```
1  Relationship Manager          APP- / FAC- draft in ApexOrigin
2  Credit Analyst                Credit Memorandum (ANB-CBK-TPL-0003)
3  Risk Review                   Independent UW / CRR- assignment
4  Legal                         Term sheet / docs feasibility
5  Compliance                    KYC/KYB/EDD/sanctions gate
6  Credit Committee              Regional CC or GrCC / BRC
7  Documentation                 ANB-CBK-CTR-0002 + security
8  Disbursement                  Conditions precedent → ApexCore book
9  Monitoring                    Covenants COV-; portfolio
10 Renewal                       Annual / trigger review
```

---

## 5. Gate-by-Gate Detail

### Gate 1 — Relationship Manager

| Item | Standard |
|---|---|
| Owner | RM (e.g. `EMP-300301` Henry Bakshi) |
| Actions | Client need assessment; indicative term sheet; create `APP-##########` / draft `FAC-########`; attach `CORP-` / `CUS-` |
| Exit criteria | Complete intake checklist; no prohibited industry without escalate |
| System | ApexOrigin, Apex360 |

### Gate 2 — Credit Analyst

| Item | Standard |
|---|---|
| Owner | Credit Analyst (e.g. `EMP-300302` Naomi Castellanos) |
| Actions | Financial analysis `FIN-########`; industry; collateral; draft memo per `ANB-CBK-TPL-0003` |
| Exit criteria | Memo complete; recommendation Approve / Decline / Approve with conditions |
| SLA | 5–10 business days file-complete |

### Gate 3 — Risk Review

| Item | Standard |
|---|---|
| Owner | Credit Risk UW under `EMP-400201` |
| Actions | Challenge assumptions; assign/confirm `CRR-####`; RWA / capital view; model use check (`ANB-RSK-POL-0004`) |
| Exit criteria | Risk concurrence or objection recorded; exposure vs `LMT-` / `RAM-0007` |
| Hard stop | Risk objection at committee level blocks approval |

### Gate 4 — Legal

| Item | Standard |
|---|---|
| Owner | Banking Legal (LEG) |
| Actions | Structure legality; security perfection path; intercreditor; opinion needs |
| Exit criteria | Legal OK to structure / known issues listed as conditions |
| Template | `ANB-CBK-CTR-0002` Master Loan Agreement |

### Gate 5 — Compliance

| Item | Standard |
|---|---|
| Owner | KYC Ops / Financial Crime / Retail-Corporate Compliance |
| Actions | `KYC-` / BO / `EDD-` if required; `SCR-` / `PEP-`; adverse media; trade dual-use if TF |
| Exit criteria | Status Clear or Conditional; **block if `CR-P`** |
| References | `ANB-CMP-POL-0002`, `ANB-CMP-SOP-0006`, `ANB-CBK-SOP-0002` |

### Gate 6 — Credit Committee

| Exposure | Forum | Chair |
|---|---|---|
| ≤ Regional limit | Regional Credit Committee | Regional Credit Officer |
| ≤ USD 500M commercial | GrCC | `EMP-100004` CRO |
| > USD 500M | BRC | Hugo Bertrand |

| Item | Standard |
|---|---|
| Materials | Credit memo; Risk opinion; Compliance status; Legal issues list |
| Voting | Majority **and** Risk affirmative (`ANB-LEG-REF-0003`) |
| Output | Minutes `MINS_GRCC_*` / Regional; decision on `FAC-` |
| Conditions | Precedent / subsequent logged in ApexOrigin |

### Gate 7 — Documentation

| Item | Standard |
|---|---|
| Owner | Credit Administration `EMP-300307` + Legal |
| Actions | Execute loan/security docs; UCC / mortgage recording; guarantees; opinions |
| Collateral | Perfect `COL-########` per `ANB-CBK-POL-0002` |
| Exit criteria | Docs complete; conditions precedent checklist signed |

### Gate 8 — Disbursement

| Item | Standard |
|---|---|
| Owner | Loan Operations / Transaction Banking |
| Actions | Verify CP; book ApexCore; set `LMT-` in ApexCredit; fund via ApexPay |
| Process | `BP-SRV-BOOK` |
| Hard stops | Incomplete KYC; unperfected required security; sanctions hold |

### Gate 9 — Monitoring

| Item | Standard |
|---|---|
| Owner | RM + Portfolio Management `EMP-300309` |
| Actions | Covenant tests `COV-` (`BP-CORP-COV`); financials; site visits; early warning |
| Triggers | Breach → waiver path (`ANB-CBK-POL-0001` §12) or Special Assets |
| Risk rating | Re-rate on material change (`ANB-RSK-FRM-0001`) |

### Gate 10 — Renewal

| Item | Standard |
|---|---|
| Timing | Per review frequency by `CRR-` |
| Actions | Updated memo; refreshed KYC; collateral revaluation; committee if material change |
| Outcome | Renew / amend / reduce / exit |

---

## 6. Decision Tree — Routing

```
Facility request
        │
        ├─ KYC/sanctions CR-P? ──► STOP — decline
        ├─ ≤ Credit Manager authority + standard? ──► Dual approval path
        ├─ ≤ USD 50M commercial? ──► Regional CC
        ├─ ≤ USD 500M? ──► GrCC
        └─ > USD 500M or related party ──► BRC
```

---

## 7. SLA Summary

| Gate | Target |
|---|---|
| RM intake complete | 3 business days |
| Analyst memo | 10 business days |
| Risk review | 5 business days |
| Committee (scheduled) | Next weekly GrCC / Regional |
| Docs post-approval | 15–30 business days (complexity) |
| First draw post-CP | 2 business days |

---

## 8. Example — Meridian RCF Approval

1. RM `EMP-300301` opens `APP-202606120044` for `CORP-10000001`.  
2. Analyst `EMP-300302` completes memo; recommends Approve `FAC-10028441` USD 75M.  
3. Risk assigns `CRR-0003`; within Regional/GrCC path.  
4. Legal confirms GSA + RE mortgage path `COL-10028441-*`.  
5. Compliance: `KYC` current; BO complete.  
6. GrCC approves 2026-06-12 with leverage covenant `COV-10028441-01`.  
7. Docs executed; UCC filed.  
8. Initial draw USD 12M via ApexPay; limit `LMT-10028441` live.  
9. Quarterly covenant testing in ApexCredit.  
10. Annual renewal scheduled 2027-06.

---

## 9. Escalation

| Issue | Escalate | Timeline |
|---|---|---|
| Risk / Business deadlock | CRO binding for Risk objection path | Before booking |
| Compliance hold | Head of Financial Crime / CCO | Same day |
| CP not met at funding | Credit Admin — no waiver by Ops alone | Block draw |
| Post-booking covenant breach | Portfolio Mgmt → Credit Risk → Special Assets | 5 business days |

---

## 10. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-TPL-0003` · `ANB-CBK-CTR-0002` · `ANB-CBK-POL-0002` · `ANB-CBK-SOP-0002` · `ANB-CBK-GDL-0003` · `ANB-RSK-FRM-0001` · `ANB-CMP-POL-0002` · `ANB-LEG-REF-0003` · `ANB-ADM-MTX-0001`

---

## 11. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | A. Fontaine | Initial credit approval workflow SOP |

---

## Appendix A — Gate Checklist (Compressed)

- [ ] `APP-` / `FAC-` created  
- [ ] Memo per TPL-0003  
- [ ] `CRR-` assigned; Risk opinion  
- [ ] Legal structure OK  
- [ ] KYC/EDD/sanctions Clear  
- [ ] Committee minutes  
- [ ] Docs + perfection  
- [ ] CP satisfied  
- [ ] Booked + `LMT-` live  
- [ ] Monitoring diary set  

---

**End of Document** — `ANB-CBK-SOP-0001` v1.0
