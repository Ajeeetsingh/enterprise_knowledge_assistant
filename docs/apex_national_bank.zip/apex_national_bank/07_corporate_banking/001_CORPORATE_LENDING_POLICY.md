# Apex National Bank — Corporate Lending Policy

**Enterprise Policy | Loan Approval, Credit Products, Authority, Covenants, and Portfolio Standards**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-POL-0001` |
| **Document Title** | Corporate Lending Policy (Loan Approval Policy) |
| **Version** | 1.0 |
| **Owner** | Corporate Banking (CBK) with Risk (RSK) |
| **Custodian** | Lars Henriksson, Head of Credit Risk (G9) — `EMP-400201` |
| **Approver** | Helena Brandt, CRO (G11) — `EMP-100004`; Alicia Moreau, Head of Commercial Banking (G10) — `EMP-100015` |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Retention** | `RET-POL-10Y` |
| **Taxonomy** | `T2` → `T2.1` Credit Risk → Credit Authority → `POL` |
| **Business Process** | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-CRD-APPR`, `BP-CRD-DOC`, `BP-CRD-EXC`, `BP-CORP-COV` |
| **System of Record** | ApexOrigin · ApexCredit · ApexRisk · ApexDocs |
| **Related Documents** | See §16 |

> **Authority.** This Policy is the reserved Loan Approval Policy (`ANB-ADM-REF-0001` §15 #31). It governs commercial and corporate credit decisions jointly with `ANB-RSK-FRM-0001` and Board appetite in `ANB-RSK-STMT-0001`. Canonical corporate entities for `07_corporate_banking/` are defined in Appendix A.

---

## 2. Purpose

Corporate and commercial lending is a primary earnings engine for CMB and CIB. This Policy states the Bank’s lending philosophy, eligible products, exposure and pricing standards, credit authority, industry and ESG restrictions, covenant and waiver rules, and review frequency — so Relationship Managers, Credit Analysts, Risk, Legal, Compliance, and credit committees operate to one standard.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| Commercial lending (revenue USD 10M–500M) | Retail consumer / mortgage (`ANB-RTL-POL-0003` / `0004`) |
| Corporate banking (revenue > USD 500M), FI, public sector | Securities underwriting (ASL) |
| Bilateral, club, and syndicated facilities | Pure market risk trading book limits (`ANB-TRY-POL-0001`) |
| Trade loans, project finance, ABL, CRE commercial | Vendor credit to the Bank as borrower |

---

## 4. Lending Philosophy

**CBK-1.** Credit is extended only where repayment capacity is demonstrated from cash flow, with collateral as secondary support — never the sole basis for approval (except structured ABL within policy).

**CBK-2.** Risk appetite governs growth: moderate for C&I and SMB; **constrained** for CRE income-producing; **low** for leveraged finance (`ANB-RSK-STMT-0001` §7).

**CBK-3.** Independent Risk vote is mandatory at GrCC and Regional Credit Committees (`ANB-LEG-REF-0003` §7.9). Business majority cannot override Risk objection.

**CBK-4.** No facility is committed without current KYC/KYB (`ANB-CMP-POL-0002`) and sanctions clear (`ANB-CMP-SOP-0005`).

**CBK-5.** Related-party and insider credit follow Reg O / Bank policy — enhanced review; no self-approval (`ANB-HRM-HBK-0001`).

---

## 5. Corporate Credit Products

| Product | Description | Typical Tenor | Booking |
|---|---|---|---|
| Revolving Credit Facility (RCF) | Working capital; borrowing base optional | 1–5 years | `FAC-########` |
| Working Capital Line | Seasonal / ABL against AR/inventory | ≤ 3 years | `FAC-` |
| Term Loan A / B | Amortising or bullet acquisition / capex | 3–7 years | `FAC-` |
| Bridge Facility | Short-term pending take-out | ≤ 12 months | `FAC-` |
| Syndicated / Club | Multi-bank; Apex as agent or participant | Per deal | `FAC-` + syndicate ID |
| Trade Loan / Import-Export | Linked to `TRD-` / `LC-` | ≤ 180 days typical | `FAC-` |
| Project Finance | Limited-recourse; DSCR-driven | Long-term | `FAC-` |
| CRE Acquisition / Construction / Permanent | Income property / OO | Per CRE grid | `FAC-` |
| Equipment Finance / Lease | Secured by equipment `COL-` | ≤ useful life | `FAC-` |
| SBA 7(a) / 504 | US government-guaranteed overlay | Per SBA | `FAC-` |

Each facility links to corporate customer `CORP-########` / `CUS-########`, limits `LMT-########`, collateral `COL-########`, covenants `COV-########`.

---

## 6. Exposure Limits

| Limit Type | Metric | Reference |
|---|---|---|
| Single-name | ≤ 15% of capital (`RAM-0007`); tolerance 20% with BRC | `ANB-RSK-STMT-0001`, `ANB-CBK-GDL-0003` |
| CRE / capital | ≤ 300% (`RAM-0006`) | Appetite |
| Industry — Energy | ≤ 8% of credit portfolio | `ANB-RSK-FRM-0001` |
| Leveraged loan notional | ≤ USD 12B | GrCC |
| Country | Country limit grid in ApexCredit | Head of Credit Risk |
| Connected counterparties | Aggregated per large exposure rules | `ANB-CBK-GDL-0003` |

Internal limit IDs: `LMT-########` on ApexCredit obligor groups.

---

## 7. Pricing

| Element | Standard |
|---|---|
| Base | SOFR (or agreed index) + margin |
| Margin | Risk-based by `CRR-####` and RAROC hurdle |
| FTP | Charged per `BP-TRY-FTP` / `ANB-TRY-POL-0001` |
| Fees | Commitment, utilisation, agency, amendment — schedule in credit memo |
| Floor | No negative interest; contractual floor where used |
| Exceptions | Documented in ApexOrigin; one-level-up approval |

Illustrative: Meridian Advanced Materials (`CORP-10000001`) RCF priced SOFR + 225 bps at `CRR-0003`.

---

## 8. Credit Authority

Per `ANB-ADM-REF-0001` §5.4 and GrCC charter:

| Authority | Commercial / Corporate | Mortgage (ref) |
|---|---|---|
| Credit Manager (G6) | ≤ USD 1,000,000 | ≤ USD 1,500,000 |
| Senior Credit Officer (G7) | ≤ USD 10,000,000 | ≤ USD 5,000,000 |
| Regional Credit Committee | ≤ USD 50,000,000 | ≤ USD 15,000,000 |
| Group Credit Committee | ≤ USD 500,000,000 | > USD 15,000,000 |
| Board Risk Committee | > USD 500,000,000 | — |

**Risk affirmative vote required** at Regional CC and GrCC. Workflow detail: `ANB-CBK-SOP-0001`.

---

## 9. Industry Restrictions

| Industry | Stance |
|---|---|
| Arms / munitions (non-sovereign) | Prohibited without ExCo + Compliance exception |
| Adult entertainment | Prohibited |
| Pure cryptocurrency mining / unlicensed VASP | Prohibited / EDD decline path |
| Tobacco manufacturing | Restricted — GrCC minimum |
| Thermal coal expansion | Restricted — ESG overlay §10 |
| Gaming (licensed) | Restricted — Compliance + GrCC |
| Embargoed jurisdictions | Prohibited (`CR-P`) |

---

## 10. ESG Restrictions

| Theme | Requirement |
|---|---|
| Thermal coal | No new project finance for coal-fired generation expansion |
| Arctic oil exploration | Restricted — Escalation to CRO |
| Deforestation-linked agri | Enhanced DD; decline if unresolved |
| Equator Principles (project finance) | Apply where EP-applicable |
| Climate physical risk (CRE/energy) | Documented in credit memo for material exposures |

ESG findings recorded in ApexOrigin credit package; material issues escalate to GrCC.

---

## 11. Covenant Policy

| Covenant Type | Typical Use |
|---|---|
| Financial — Leverage (Debt/EBITDA) | Term / RCF |
| Financial — Interest coverage | Term / RCF |
| Financial — Current ratio / Fixed charge | ABL / WC |
| Financial — DSCR | Project / CRE |
| Affirmative | Insurance, reporting, KYC refresh |
| Negative | Liens, distributions, debt incurrence |
| Informative | Rating downgrade notice |

Covenant IDs: `COV-########` in ApexCredit (`BP-CORP-COV`). Testing frequency: quarterly for most; monthly if `CRR-0004`+.

---

## 12. Waiver Policy

| Waiver | Approver |
|---|---|
| Technical / one-time immaterial | Senior Credit Officer |
| Financial covenant soft breach with cure | Regional CC or GrCC per exposure |
| Material amendment (tenor, amount, security release) | Same authority as new money |
| Repeated waivers (>2 in 12 months) | Escalate one level; Special Assets notified |

Waivers logged on `FAC-########`; never oral-only.

---

## 13. Credit Review Frequency

| `CRR` | Review |
|---|---|
| `CRR-0001`–`0003` | Annual full review + interim financials |
| `CRR-0004`–`0005` | Quarterly |
| `CRR-0006`–`0008` | Monthly; Special Assets (`EMP-400209`) |
| Material trigger | Immediate (covenant breach, loss event, adverse media, SAR) |

---

## 14. Roles (Summary)

| Role | Employee | Responsibility |
|---|---|---|
| Head of Commercial Banking | `EMP-100015` Alicia Moreau | CMB franchise |
| Group Treasurer | `EMP-100018` David Chen | FTP / liquidity interface |
| Head of Credit Risk | `EMP-400201` Lars Henriksson | Policy custodian; UW standards |
| CRO | `EMP-100004` Helena Brandt | GrCC chair; BRC |
| RM — Midwest | `EMP-300301` Henry Bakshi | Client coverage |
| Senior Credit Analyst | `EMP-300302` Naomi Castellanos | Credit memos |
| Special Assets | `EMP-400209` Elaine Morrison | Workout |
| CCO / FC | `EMP-100005` / `EMP-400101` | KYC/EDD blockers |

---

## 15. Examples

**Approved — Meridian:** `FAC-10028441` USD 75M RCF; `CRR-0003`; GrCC 2026-06-12; covenants `COV-10028441-01` (max leverage 3.5x); collateral `COL-10028441-RE` + GSA.

**Restricted industry decline:** Unlicensed VASP applicant — Compliance `CR-P` path; no credit memo to GrCC.

---

## 16. Related Documents

| ID | Title |
|---|---|
| `ANB-CBK-SOP-0001` | Credit Approval Workflow |
| `ANB-CBK-GDL-0001` | Commercial Loan Guide |
| `ANB-CBK-MAN-0001` | Trade Finance Manual |
| `ANB-CBK-GDL-0002` | Corporate Account Opening Guide |
| `ANB-CBK-TPL-0003` | Credit Memorandum Template |
| `ANB-CBK-POL-0002` | Collateral Policy |
| `ANB-CBK-SOP-0002` | Corporate Client Onboarding |
| `ANB-CBK-GDL-0003` | Large Exposure Guideline |
| `ANB-CBK-CTR-0002` | Master Loan Agreement Template |
| `ANB-TRY-MAN-0001` | Treasury Operations Manual |
| `ANB-RSK-POL-0001` / `STMT-0001` / `FRM-0001` | ERM / Appetite / Credit Framework |
| `ANB-CMP-POL-0001` / `0002` / `SOP-0006` | AML / KYC / EDD |
| `ANB-LEG-REF-0003` | Committee Charter — GrCC |
| `ANB-ADM-REF-0001` / `MTX-0001` | Profile / Authority Matrix |

---

## 17. Review Cycle / Revision History

Annual with GrCC recommendation to BRC for material changes.

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | L. Henriksson | Initial published corporate lending / loan approval policy |

---

## 18. Appendices

### Appendix A — Canonical Corporate Banking Entity Register

**Authoritative for `07_corporate_banking/` and credit-file domains.**

#### A.1 Parties and Facilities

| Entity | Format | Example | System |
|---|---|---|---|
| Corporate Customer | `CORP-########` | `CORP-10000001` | Apex360, ApexKYC |
| Customer (enterprise) | `CUS-########` | `CUS-10028441` | ApexCore (same legal entity) |
| Facility | `FAC-########` | `FAC-10028441` | ApexCredit, ApexOrigin |
| Application | `APP-##########` | `APP-202606120044` | ApexOrigin |
| Limit | `LMT-########` | `LMT-10028441` | ApexCredit |
| Collateral | `COL-########` | `COL-10028441-RE` | ApexCredit |
| Covenant | `COV-########` | `COV-10028441-01` | ApexCredit |
| Financial Package | `FIN-########` | `FIN-10028441-FY25` | ApexDocs |
| Credit Memo | Uses `ANB-CBK-TPL-0003` instance | Linked to `FAC-` | ApexOrigin |

#### A.2 Trade and Treasury

| Entity | Format | Example |
|---|---|---|
| Trade Transaction | `TRD-########` | `TRD-202607-8841` |
| Letter of Credit | `LC-########` | `LC-202607-4412` |
| Bank Guarantee | `BG-########` | `BG-202608-1102` |
| FX Deal | `FX-########` | `FX-20260815-0099` |

#### A.3 Canonical Corporate Borrowers (FY2026 Book)

| CORP / CUS | Legal Name | Industry | RM | CRR | Flagship Facility |
|---|---|---|---|---|---|
| `CORP-10000001` / `CUS-10028441` | Meridian Advanced Materials Inc. | Manufacturing | `EMP-300301` | `CRR-0003` | `FAC-10028441` USD 75M RCF |
| `CORP-10000002` / `CUS-10031902` | Helix Pharma Sciences LLC | Pharmaceuticals | `EMP-300303` | `CRR-0002` | `FAC-10031902` USD 120M Term + RCF |
| `CORP-10000003` / `CUS-10040118` | Cascade Logistics Holdings Inc. | Logistics | `EMP-300301` | `CRR-0003` | `FAC-10040118` USD 45M ABL |
| `CORP-10000004` / `CUS-10045520` | Northwind Energy Partners LLC | Energy | `EMP-300304` | `CRR-0004` | `FAC-10045520` USD 200M RCF |
| `CORP-10000005` / `CUS-10051233` | Vertex Cloud Systems Inc. | Technology | `EMP-300305` | `CRR-0002` | `FAC-10051233` USD 60M RCF |
| `CORP-10000006` / `CUS-10057844` | Summit Health Networks Inc. | Healthcare | `EMP-300303` | `CRR-0003` | `FAC-10057844` USD 90M Term |
| `CORP-10000007` / `CUS-06291004` | Harborpoint Holdings LLC | Diversified holding | `EMP-300304` | `CRR-0003` | Prior EDD `EDD-202608-0012` |

#### A.4 Extended Corporate / Treasury Personnel

| Employee ID | Name | Grade | Role |
|---|---|---|---|
| `EMP-100015` | Alicia Moreau | G10 | Head of Commercial Banking |
| `EMP-100018` | David Chen | G10 | Group Treasurer |
| `EMP-300301` | Henry Bakshi | G6 | RM — Commercial Banking Midwest |
| `EMP-300302` | Naomi Castellanos | G3 | Senior Credit Analyst |
| `EMP-300303` | Priya Desai | G6 | RM — Healthcare & Life Sciences |
| `EMP-300304` | James Okafor | G7 | Sector Head — Energy & Industrials |
| `EMP-300305` | Elena Vasquez | G6 | RM — Technology |
| `EMP-300306` | Thomas Reinhardt | G8 | Head of Trade Finance |
| `EMP-300307` | Amélie Fontaine | G8 | Head of Credit Administration |
| `EMP-300308` | Rajiv Mehta | G8 | Head of Transaction Banking |
| `EMP-300309` | Sophia Brandt | G8 | Head of Portfolio Management |
| `EMP-600501` | Nikolai Petrov | G6 | Treasury Operations Lead |
| `EMP-400201` | Lars Henriksson | G9 | Head of Credit Risk |
| `EMP-400209` | Elaine Morrison | G8 | Head of Special Assets |
| `EMP-400206` | Patrick O'Malley | G9 | Head of Market & Liquidity Risk |

---

**End of Document** — `ANB-CBK-POL-0001` v1.0 · C2 · Effective 2026-08-01
