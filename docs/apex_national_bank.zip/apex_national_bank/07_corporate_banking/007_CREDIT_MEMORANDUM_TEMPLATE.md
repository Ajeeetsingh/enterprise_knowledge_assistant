# Apex National Bank — Credit Memorandum Template

**Controlled Template | Credit Analyst Package for Commercial and Corporate Approvals**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-TPL-0003` |
| **Document Title** | Credit Memorandum Template |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) — Credit Risk / Corporate Banking |
| **Custodian** | Lars Henriksson, Head of Credit Risk (G9) — `EMP-400201` |
| **Approver** | Helena Brandt, CRO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Biennial |
| **Taxonomy** | `T2` → `T2.1` → Credit Authority → `TPL` |
| **Business Process** | `BP-CRD-UW`, `BP-CRD-APPR` |
| **System of Record** | ApexOrigin (memo instances) · ApexDocs |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-CBK-SOP-0001`, `ANB-RSK-FRM-0001` |

> **Usage.** Analysts complete every section below in ApexOrigin. Incomplete memos cannot be submitted to Regional CC or GrCC. Filename pattern per `ANB-ADM-STD-0007`: `CBKL_FAC-<id>_CreditMemorandum_<YYYYMMDD>_C2.pdf`.

---

## 2. Purpose

Provide a single, committee-ready analytical structure for credit decisions — executive summary through recommendation and decision capture — reusable across commercial and corporate facilities.

---

## 3. Template Body (Complete for Each Transaction)

---

### MEMORANDUM HEADER

| Field | Value |
|---|---|
| Facility ID | `FAC-________` |
| Application ID | `APP-__________` |
| Corporate ID | `CORP-________` / `CUS-________` |
| Date | YYYY-MM-DD |
| RM | Name / `EMP-` |
| Analyst | Name / `EMP-` |
| Request type | New / Increase / Renewal / Amendment / Waiver |
| Amount / Type | USD ___ / RCF · Term · ABL · Other |
| Proposed grade | `CRR-____` |
| Committee | Regional CC / GrCC / BRC / Delegated |

---

### 1. Executive Summary

*State in ≤ 400 words: who the borrower is; what is requested; key financial metrics; primary risks; mitigants; recommendation (Approve / Approve with conditions / Decline).*

**Illustrative (Meridian):** Request approval of USD 75M three-year SOFR RCF for Meridian Advanced Materials Inc. (`CORP-10000001`). Debt/EBITDA 2.0x; interest cover 5.1x; `CRR-0003`. Collateral: GSA + owner-occupied plant mortgage. Recommend **Approve** with max leverage 3.5x covenant.

---

### 2. Borrower

| Item | Detail |
|---|---|
| Legal name | |
| CORP / CUS | |
| Jurisdiction / formation | |
| NAICS / industry | |
| Ownership / UBO summary | |
| Year founded | |
| Management | |
| Relationship since | |
| Existing Apex products | Deposits `ACC-` · Trade · FX · Cards |
| KYC / risk rating | `KYC-` · `CR-L/M/H` · last refresh |
| Connected parties | Group / guarantors / `LMT-` aggregation |

---

### 3. Financial Analysis

Attach `FIN-________`. Complete:

| Metric | FY-2 | FY-1 | FY LTM | Trend |
|---|---|---|---|---|
| Revenue | | | | |
| EBITDA | | | | |
| Net income | | | | |
| Total debt | | | | |
| Cash | | | | |
| Debt / EBITDA | | | | |
| Interest coverage | | | | |
| Current ratio | | | | |
| CFO | | | | |

**Quality of earnings / adjustments:**  

**Working capital / cash conversion:**  

**Auditor / opinion:**  

---

### 4. Industry Analysis

| Item | Detail |
|---|---|
| Industry outlook | |
| Competitive position | |
| Cyclicality / regulation | |
| ESG factors | Per `ANB-CBK-POL-0001` §10 |
| Bank portfolio concentration | vs industry caps |

---

### 5. Collateral

| COL ID | Type | Value | Haircut | Advance | Perfection status |
|---|---|---|---|---|---|
| `COL-` | | | | | |

**Guarantees:**  

**Valuation date / appraiser:** per `ANB-CBK-POL-0002`  

---

### 6. Risk

| Risk | Description | Mitigant | Residual |
|---|---|---|---|
| Business | | | |
| Financial | | | |
| Structure | | | |
| Collateral | | | |
| Compliance / FC | | | |
| ESG / climate | | | |

**Early warning indicators to monitor:**  

**Stress case (`SCN-2026-CRD-001` or sector):**  

---

### 7. Cash Flow

| Item | Base case | Downside |
|---|---|---|
| Free cash flow | | |
| Debt service | | |
| Minimum cash | | |
| Sources & uses (if acquisition) | | |

**Ability to repay narrative:**  

---

### 8. Covenants

| COV ID | Covenant | Threshold | Test frequency |
|---|---|---|---|
| `COV-` | Max Debt/EBITDA | | Quarterly |
| `COV-` | Min Interest coverage | | Quarterly |
| `COV-` | Other | | |

**Reporting covenants:**  

---

### 9. Repayment

| Item | Detail |
|---|---|
| Primary source | Operating cash flow / refinance / asset sale |
| Secondary source | Collateral / sponsor support |
| Amortisation | |
| Maturity | |
| Clean-down (if RCF) | |

---

### 10. Pricing

| Component | Term |
|---|---|
| Index | SOFR / other |
| Margin | bps |
| Commitment fee | |
| Other fees | |
| FTP-aware RAROC | % vs hurdle |
| Comparable deals | |

---

### 11. Recommendation

| Item | Detail |
|---|---|
| Recommendation | Approve / Approve with conditions / Decline |
| Conditions precedent | |
| Conditions subsequent | |
| Proposed `CRR-` | |
| Authority required | |

**Analyst signature / date:**  

**RM acknowledgment / date:**  

---

### 12. Risk Opinion

| Item | Detail |
|---|---|
| Risk reviewer | `EMP-` |
| Concurrence | Yes / Yes with conditions / Object |
| Commentary | |
| Final `CRR-` | |

---

### 13. Compliance Confirmation

| Item | Status |
|---|---|
| KYC / BO | Clear / Conditional / Block |
| Sanctions | Clear / Hold |
| EDD (if any) | `EDD-` ref |
| Comments | |

---

### 14. Committee Decision

| Item | Detail |
|---|---|
| Forum / date | |
| Decision | Approved / Approved with conditions / Declined / Deferred |
| Votes / Risk affirmative | |
| Conditions imposed | |
| Minute reference | `MINS_GRCC_*` / Regional |
| Limit ID booked | `LMT-` |

**Chair / secretary sign-off:**  

---

## 4. Worked Example Header — Meridian Advanced Materials

| Field | Value |
|---|---|
| Facility | `FAC-10028441` |
| Application | `APP-202606120044` |
| Borrower | Meridian Advanced Materials Inc. — `CORP-10000001` / `CUS-10028441` |
| RM | Henry Bakshi `EMP-300301` |
| Analyst | Naomi Castellanos `EMP-300302` |
| Request | New USD 75M RCF, 3 years |
| Grade | `CRR-0003` |
| Committee | GrCC 2026-06-12 — **Approved** |
| Covenants | `COV-10028441-01` Debt/EBITDA ≤ 3.5x; `COV-10028441-02` Interest cover ≥ 3.0x |
| Collateral | `COL-10028441-GSA`; `COL-10028441-RE` (plant appraisal USD 62M) |
| Financials | `FIN-10028441-FY25` |
| Limit | `LMT-10028441` |

---

## 5. Quality Standards

**TPL-1.** No empty mandatory sections for GrCC packages.  
**TPL-2.** Connected exposure must reconcile to ApexCredit group view.  
**TPL-3.** Model outputs cited with `MDL-` IDs when used.  
**TPL-4.** Fair presentation — no omission of known adverse facts.  
**TPL-5.** Retention with credit file `RET-RSK-7Y` / loan file standards.

---

## 6. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-SOP-0001` · `ANB-CBK-POL-0002` · `ANB-CBK-GDL-0001` · `ANB-CBK-GDL-0003` · `ANB-CBK-CTR-0002` · `ANB-RSK-FRM-0001` · `ANB-RSK-POL-0004` · `ANB-CMP-POL-0002` · `ANB-ADM-STD-0007`

---

## 7. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | L. Henriksson | Initial controlled credit memorandum template |

---

## Appendix A — Submission Checklist

- [ ] Header complete  
- [ ] Sections 1–11 complete  
- [ ] Risk opinion §12  
- [ ] Compliance §13  
- [ ] Exhibits: financials, org chart, appraisal, BO  
- [ ] ApexOrigin workflow advanced to Committee  

---

**End of Document** — `ANB-CBK-TPL-0003` v1.0
