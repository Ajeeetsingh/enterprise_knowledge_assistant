# Apex National Bank — Treasury Operations Manual

**Operations Manual | Liquidity, FX, Money Markets, ALM, FTP, Limits, and Daily Reporting**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-TRY-MAN-0001` |
| **Document Title** | Treasury Operations Manual |
| **Version** | 1.0 |
| **Owner** | Treasury (TRY) |
| **Custodian** | Nikolai Petrov, Treasury Operations Lead (G6) — `EMP-600501` |
| **Approver** | David Chen, Group Treasurer (G10) — `EMP-100018` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-TRY-LIQ`, `BP-TRY-FUND`, `BP-TRY-FTP`, `BP-TRY-INV`, `BP-MKT-FX`, `BP-PAY-NOST` |
| **System of Record** | ApexTreasury · ApexRisk · ApexPay · ApexLedger · ApexInsight |
| **Parent Policies** | `ANB-TRY-POL-0001`, `ANB-TRY-PLN-0002` |
| **Related Documents** | `ANB-RSK-STMT-0001`, `ANB-LEG-REF-0003` (ALCO), `ANB-CBK-POL-0001` |

---

## 2. Purpose

Treasury safeguards the Bank’s liquidity, funding, structural market risk, and funds transfer pricing, and executes client and proprietary FX/money-market activity within Board and ALCO limits. This Manual is the operational companion to `ANB-TRY-POL-0001` and Contingency Funding Plan `ANB-TRY-PLN-0002`.

---

## 3. Scope

Group Treasury and Markets desk operations for Apex National Bank, N.A. and designated affiliates. Securities underwriting (ASL) excluded. Credit approval for client facilities remains CBK/RSK.

---

## 4. Roles

| Role | Employee | Responsibility |
|---|---|---|
| Group Treasurer | `EMP-100018` David Chen | ALCO member; funding strategy |
| Head of Market & Liquidity Risk | `EMP-400206` Patrick O'Malley | Independent limit monitoring |
| Treasury Operations Lead | `EMP-600501` Nikolai Petrov | Settlements; nostro; daily pack |
| CFO | `EMP-100002` Priya Raghunathan | ALCO Chair |
| CRO | `EMP-100004` | Appetite veto on ALCO per charter |

---

## 5. Liquidity Management (`BP-TRY-LIQ`)

| Metric | Appetite (`ANB-RSK-STMT-0001`) | Ops Cadence |
|---|---|---|
| LCR | ≥ 120% (`RAM-0003`) | Intraday / daily |
| NSFR | ≥ 115% (`RAM-0004`) | Daily / weekly |
| Survival horizon | ≥ 30 days severe stress | Weekly |
| Intraday buffer | ≥ USD 8B | Continuous |

**Daily:** ApexTreasury liquidity dashboard; FR 2052a inputs; escalate if LCR < 115% to ALCO (`SCN-2026-LIQ-001` playbook).

Cash forecasting: 13-week rolling forecast; business line inputs via ApexInsight; variance explained T+1.

---

## 6. Cash Forecasting

| Horizon | Owner | Output |
|---|---|---|
| Intraday | Payments + Treasury Ops | Nostro projections (`BP-PAY-NOST`) |
| 1–5 days | Liquidity desk | Funding gap / surplus |
| 6–13 weeks | Balance sheet management | Wholesale issuance plan |
| Structural | ALM | FTP and investment strategy |

Corporate client large draws (e.g. Meridian `FAC-10028441`) notified to Treasury when > USD 25M same-day.

---

## 7. FX Operations (`BP-MKT-FX`)

| Activity | Standard |
|---|---|
| Client FX | Spot / forward / swap via ApexTreasury; credit line check |
| Deal ID | `FX-########` |
| Settlement | CLS where eligible; otherwise bilateral with nostro control |
| Conduct | FX Global Code; surveillance ApexWatch |
| Limits | Desk VaR / stop-loss / tenor — ApexRisk |

Sanctions screening on counterparties and payment messages (`ANB-CMP-SOP-0005`).

---

## 8. Money Markets and Funding (`BP-TRY-FUND`)

- Interbank deposits / loans  
- Commercial paper / CD issuance  
- Repo / reverse repo against HQLA  
- FHLB / central bank facilities as contingent  

Execution within Board funding plan; dealer mandates; dual control on settlement instructions.

---

## 9. Investment Portfolio (`BP-TRY-INV`)

| Bucket | Instruments | Purpose |
|---|---|---|
| HQLA | Treasuries, agency, high-quality | LCR |
| Investment | Munis, MBS (policy limits) | Yield within risk |
| Restricted | Per Investment Policy Statement |

Mark-to-market / ACL accounting interface ApexLedger; Finance close `ANB-FIN-SOP-0003`.

---

## 10. Interest Rate Risk and ALM

| Measure | Monitoring |
|---|---|
| NII sensitivity | ±100 / ±200 bps |
| EVE | Parallel and non-parallel shocks |
| Gap analysis | Repricing buckets |
| Basis / option risk | Mortgage pipeline / deposits |

Limits approved by ALCO; breaches to `EMP-400206` then ALCO/BRC per appetite.

---

## 11. Funds Transfer Pricing (`BP-TRY-FTP`)

FTP curve published per ALCO methodology. Corporate loan pricing in credit memos must show FTP-aware RAROC. Curve changes communicated to CBK/RTL product teams; effective dates versioned in ApexTreasury.

---

## 12. Treasury Limits

| Limit Class | Example | System |
|---|---|---|
| Liquidity | LCR, NSFR, survival | ApexTreasury / ApexRisk |
| Market | VaR, DV01, FX delta | ApexRisk |
| Credit (counterparties) | Bank lines | ApexCredit |
| Issuer | Single name securities | ApexTreasury |
| Operational | Settlement fails | Ops MI |

Breach: desk notify Market Risk same day; ratification path per `ANB-ADM-MTX-0001` / ALCO.

---

## 13. Daily Reporting Pack

| Report | Audience | Time (ET) |
|---|---|---|
| Opening liquidity | Treasurer / Liquidity desk | 08:00 |
| Intraday alert | Ops / Risk | Continuous |
| Closing positions / P&L | Markets / Product Control | 18:30 |
| LCR flash | ALCO distribution | 17:00 |
| Settlement fails | Ops + ITO | 19:00 |
| Limit breach log | Market Risk | EOD |

Monthly ALCO pack: funding, IRRBB, investments, FTP, contingency indicators (`ANB-LEG-REF-0003` §7.8).

---

## 14. Contingency Funding

Invocation of `ANB-TRY-PLN-0002` on ALCO stress declaration. Triggers include wholesale freeze (`SCN-2026-LIQ-001`), deposit flight, LCR breach. Actions: HQLA monetisation, FHLB, issuance halt, lending slowdown coordination with CRO/CBK.

---

## 15. Examples

**FX:** `FX-20260815-0099` — Vertex Cloud (`CORP-10000005`) hedges EUR payables; credit checked against `FAC-10051233` ancillary FX sublimit; settled CLS.

**Liquidity:** Large Cascade ABL draw USD 30M same-day — Treasury Ops adjusts nostro; LCR remains 124%.

---

## 16. Related Documents

`ANB-TRY-POL-0001` · `ANB-TRY-PLN-0002` · `ANB-RSK-STMT-0001` · `ANB-RSK-POL-0001` · `ANB-CBK-POL-0001` · `ANB-FIN-SOP-0003` · `ANB-CMP-SOP-0005` · `ANB-ITO-PLN-0002` · `ANB-LEG-REF-0003`

---

## 17. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | N. Petrov | Initial treasury operations manual |

---

## Appendix A — Intraday Control Checklist

- [ ] Prior-day fails cleared or escalated  
- [ ] FX rates loaded  
- [ ] Nostro opening confirmed  
- [ ] Large corporate draw notices reviewed  
- [ ] LCR flash vs `RAM-0003`  
- [ ] Limit dashboard green / exceptions logged  

---

**End of Document** — `ANB-TRY-MAN-0001` v1.0
