# Apex National Bank — Corporate Client Onboarding

**Standard Operating Procedure | RM-Led Onboarding through Product Activation**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-SOP-0002` |
| **Document Title** | Corporate Client Onboarding |
| **Version** | 1.0 |
| **Owner** | Corporate Banking (CBK) |
| **Custodian** | Rajiv Mehta, Head of Transaction Banking (G8) — `EMP-300308` |
| **Approver** | Alicia Moreau, Head of Commercial Banking (G10) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-ONB-CORP`, `BP-ONB-KYC`, `BP-ONB-EDD`, `BP-CORP-REL`, `BP-CRD-APPR` |
| **System of Record** | Apex360 · ApexKYC · ApexOrigin · ApexCredit · ApexCore · ApexTrade · ApexTreasury |
| **Related Documents** | `ANB-CBK-GDL-0002`, `ANB-CMP-POL-0002`, `ANB-CBK-SOP-0001`, `ANB-CMP-SOP-0006` |

---

## 2. Purpose

Corporate client onboarding is a cross-functional programme: Relationship Management, KYB/KYC, EDD, Compliance, Credit Risk, Treasury, Operations, and Legal must clear sequential gates before accounts and facilities are activated. This SOP sequences those gates end-to-end.

---

## 3. Scope

New legal-entity relationships in CMB/CIB and material expansions (new credit + cash management). Consumer onboarding excluded. Correspondents require FCC-level EDD.

---

## 4. End-to-End Workflow

```
1  RM Onboarding Initiation          Apex360 opportunity / CORP- draft
2  KYB Package Collection            ANB-CBK-GDL-0002 checklist
3  KYC / CIP / BO / Screening        ApexKYC → KYC- / SCR- / PEP-
4  EDD (if triggered)                ANB-CMP-SOP-0006 → EDD-
5  Compliance Clearance              Clear / Conditional / Block
6  Risk (credit appetite screen)     Early industry / concentration view
7  Treasury (if FX / complex cash)   Limits / FTP awareness
8  Operations                        Core ready / entitlements design
9  Legal                             Resolutions / special structures
10 Account Opening                   ACC- live
11 Facility Creation                 FAC- via ANB-CBK-SOP-0001 (parallel/serial)
12 Product Activation                ApexPay / ApexTrade / FX / cards
```

Credit may run **in parallel** after KYC Clear for speed, but **no disbursement** before Gates 5 and 10–11 complete.

---

## 5. Gate Detail

### Gate 1 — RM Onboarding

| Owner | RM (e.g. `EMP-300301`, `EMP-300303`, `EMP-300305`) |
|---|---|
| Actions | Client discovery; expected products; create Apex360; draft `CORP-########` |
| Exit | Sponsoring RM attested; no prohibited industry without escalate |

### Gate 2 — KYB Package

Collect documents per `ANB-CBK-GDL-0002`. Incomplete packages not submitted to KYC Ops.

### Gate 3 — KYC / Screening

| Owner | KYC Operations `EMP-400112` |
|---|---|
| Output | `KYC-########`, `CDD-########`, `SCR-########`, `PEP-########` |
| Rating | `CR-L` / `CR-M` / `CR-H` / `CR-P` |

### Gate 4 — EDD

Triggers: PEP, high-risk geography, MSB/VASP adjacency, layered ownership, correspondent, material adverse media, `CR-H`. Owner: Financial Crime; approvals per `ANB-CMP-SOP-0006`.

### Gate 5 — Compliance Clearance

Hard stop on Block/`CR-P`. Conditional clearance lists monitoring requirements.

### Gate 6 — Risk Screen

Portfolio Management / Credit Risk checks industry caps, country limits, early single-name aggregation (`ANB-CBK-GDL-0003`). Not a substitute for full credit approval.

### Gate 7 — Treasury

Required if client needs FX lines, notional cash pooling, or complex liquidity products. Desk confirms operational readiness; credit ancillary limits via `FAC-` later.

### Gate 8 — Operations

Account numbering; statement; digital admin design; payment channels; dual administration for Apex Business Online.

### Gate 9 — Legal

Complex holding structures, regulated entities, cross-border branching, non-standard resolutions.

### Gate 10 — Account Opening

Book `CUS-` / `ACC-` in ApexCore; mandates loaded; welcome pack.

### Gate 11 — Facility Creation

Execute `ANB-CBK-SOP-0001` for `FAC-########` / `LMT-########`. Trade sublimits for ApexTrade; FX sublimits for ApexTreasury.

### Gate 12 — Product Activation

| Product | System | Dependency |
|---|---|---|
| ACH / wires | ApexPay | Account + entitlements |
| LCs / guarantees | ApexTrade | Trade line on `FAC-` |
| FX | ApexTreasury | FX limit |
| Cards commercial | ApexCards / ApexPay | Credit if charge card |
| Escrow | Apex Trust path | Legal docs |

---

## 6. Decision Tree

```
New corporate client
        │
        ├─ CR-P / sanctions true hit? ──► Decline — stop all products
        ├─ EDD required? ──► Complete EDD before account live
        ├─ Deposit only, CR-L/M? ──► Gates 1–5, 8–10, 12 (skip credit)
        └─ Credit requested? ──► Parallel SOP-0001 after KYC Clear; activate post CP
```

---

## 7. SLA

| Stage | Target |
|---|---|
| RM package complete | 10 business days from kickoff |
| KYC standard | 5 business days complete file |
| EDD | 15–20 business days |
| Account book post-Clear | 2 business days |
| First credit committee | Per `ANB-CBK-SOP-0001` SLA |

---

## 8. Examples

**Full franchise — Helix Pharma `CORP-10000002`:** RM `EMP-300303` → KYC Clear `CR-M` → operating accounts → GrCC credit `FAC-10031902` → trade + FX activated.

**EDD path — Harborpoint `CORP-10000007` / `CUS-06291004`:** Layered ownership → `EDD-202608-0012` → conditional monitoring → limited deposit products until EDD approved.

**Deposit-only SMB:** Cascade subsidiary operating account — Gates 1–5, 8–10, 12; credit ABL later via separate `APP-`.

---

## 9. Escalation

| Issue | Escalate | Timeline |
|---|---|---|
| BO opacity | Financial Crime / Head of KYC Ops | 48 hours |
| RM pressure to skip KYC | CCO / Code of Conduct | Immediate |
| Cross-border booking conflict | Regulatory Affairs `EMP-400108` | 3 days |
| Operational entitlement fraud risk | ISC + Transaction Banking | Same day |

---

## 10. Related Documents

`ANB-CBK-GDL-0002` · `ANB-CBK-SOP-0001` · `ANB-CBK-POL-0001` · `ANB-CBK-MAN-0001` · `ANB-TRY-MAN-0001` · `ANB-CMP-POL-0002` · `ANB-CMP-SOP-0005` · `ANB-CMP-SOP-0006` · `ANB-RSK-FRM-0001` · `ANB-HRM-POL-0004`

---

## 11. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | R. Mehta | Initial corporate client onboarding SOP |

---

## Appendix A — Activation Checklist

- [ ] `CORP-` / `CUS-` created  
- [ ] `KYC-` Clear (or EDD approved)  
- [ ] Compliance gate passed  
- [ ] Accounts booked  
- [ ] Mandates / dual admin  
- [ ] `FAC-` / `LMT-` if credit  
- [ ] Trade / FX / Pay products tested  
- [ ] RM welcome call documented in Apex360  

---

**End of Document** — `ANB-CBK-SOP-0002` v1.0
