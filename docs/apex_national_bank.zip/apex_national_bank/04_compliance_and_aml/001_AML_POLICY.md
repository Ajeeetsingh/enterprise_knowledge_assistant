# Apex National Bank — Anti-Money Laundering Policy

**Enterprise Policy | BSA/AML Programme Governance, Risk-Based Controls, and Financial Crime Prevention**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-POL-0001` |
| **Document Title** | Apex National Bank — Anti-Money Laundering Policy |
| **Version** | 1.0 |
| **Owner** | Compliance Department (CMP) — Financial Crime |
| **Custodian** | Adeline Mercier, Head of Financial Crime (G9) — `EMP-400101` |
| **Approver** | Samuel A. Okonkwo, Chief Compliance Officer (G11) — `EMP-100005` |
| **Ratified By** | Board Public Responsibility & Compliance Committee |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Created Date** | 2026-07-02 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-28 |
| **Review Cycle** | Annual (next review 2027-07-28) |
| **Supersedes** | None — initial published programme policy |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T6` Compliance & Financial Crime → `T6.1` AML/BSA → Programme Governance → `POL` |
| **Business Process** | `BP-AML-TM`, `BP-AML-INV`, `BP-AML-SAR`, `BP-AML-CTR`, `BP-AML-RISK` |
| **Governing Body** | Financial Crime Committee (FCC); Board Public Responsibility & Compliance Committee |
| **System of Record** | ApexDocs (this policy) · ApexGuard (monitoring and cases) · ApexKYC (customer risk) |
| **Keywords** | AML, BSA, FinCEN, FATF, risk-based approach, transaction monitoring, SAR, CTR, sanctions, financial crime |
| **Related Documents** | See §20 |

> **Authority.** This Policy is the apex instrument of the Bank's Bank Secrecy Act / Anti-Money Laundering (`BSA/AML`) programme. It implements the AML scope in `ANB-ADM-REF-0001` §6 and §7.7. Subordinate procedures must not weaken obligations stated here.

---

## 2. Purpose

Money laundering and terrorist financing exploit the banking system by converting illicit proceeds into apparently legitimate funds. Apex National Bank is a `$58.2B` revenue institution operating in nineteen jurisdictions with approximately 41 million transactions per day through ApexCore. The AML programme exists so that every customer relationship, every payment, and every account is assessed, monitored, and — where necessary — reported under a single, risk-based, auditable framework.

This Policy:

1. Establishes **programme governance** and the three lines of defence for financial crime.
2. Mandates a **risk-based approach** (RBA) across customer, product, channel, and geography dimensions.
3. Defines the **control framework** — CDD, monitoring, sanctions, reporting, training, and independent testing.
4. Sets **customer risk rating methodology** and escalation thresholds.
5. Assigns **roles and accountability** from the Board to the branch teller.
6. Introduces the **canonical compliance entity register** used across all financial crime documents.

---

## 3. Scope

### 3.1 Applies To

| Population / Activity | Coverage |
|---|---|
| All legal entities | Apex National Bank, N.A.; Apex Financial Group, Inc.; Apex National Bank (UK) plc; Apex Bank Europe SE; Apex Securities LLC; Apex Asset Management, Inc.; Apex Trust Company, N.A.; Apex Global Services; Apex Insurance Agency, LLC |
| All customer types | Retail, small business, commercial, corporate, institutional, correspondent, trust, wealth, and broker-dealer relationships |
| All products and channels | Deposits, lending, cards, payments (ApexPay), trade finance (ApexTrade), digital (ApexMobile/ApexOnline), branch, and securities where Apex Securities LLC is involved |
| All employees and contractors | Mandatory training; speak-up obligations; no tipping-off |
| Third parties acting for the Bank | Correspondent banks, introducers, payment agents — flow-down required |

### 3.2 Regulatory Framework (Reference)

The programme is designed to satisfy, among others:

| Regime | Application |
|---|---|
| **USA — BSA / FinCEN** | CIP, CDD, CTR (`31 CFR 1010.311`), SAR (`31 CFR 1020.320`), beneficial ownership (`31 CFR 1010.230`), record retention |
| **USA — OFAC** | SDN and sectoral sanctions; blocking and rejection; reporting |
| **USA — OCC / FFIEC** | BSA/AML examination expectations; `FFIEC BSA/AML Examination Manual` |
| **FATF Recommendations** | RBA; Recommendations 10, 11, 20, 22 (PEPs, record-keeping, reporting, DNFBP alignment) |
| **UK — MLR / FCA** | Apex National Bank (UK) plc — customer due diligence, SAR (NCA), financial sanctions |
| **EU — AMLD6 / local transposition** | Apex Bank Europe SE |
| **GDPR / GLBA** | Privacy interaction with CDD and SAR confidentiality — see §12 |

Local addenda are maintained by the Head of Regulatory Affairs (`EMP-400108`) as child documents.

### 3.3 Out of Scope

| Excluded | Governed By |
|---|---|
| Credit underwriting standards | `ANB-CBK-POL-0001`; Risk (RSK) |
| Market abuse surveillance detail | `ANB-CMP-POL-0006`; ApexWatch |
| Fraud loss recognition and provisioning | Fraud programme; Finance (FIN) |
| Vendor third-party onboarding | `ANB-PRC-POL-0002` with CMP overlay |

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | No customer onboarded without CDD commensurate with risk | 100% of live `CUS-` records with valid `KYC-` and `CR-*` rating |
| O-2 | Transaction monitoring operates without material gaps | ≥ 99.5% of in-scope transactions screened within SLA |
| O-3 | Regulatory reporting timeliness | 100% CTR/SAR filed within statutory deadlines |
| O-4 | Sanctions compliance | Zero confirmed payments to sanctioned parties |
| O-5 | Independent testing | Annual independent review with no material programme weakness unremediated > 90 days |
| O-6 | Culture and training | 100% role-based AML training completion; Ethics Line financial-crime themes reviewed quarterly |
| O-7 | Exam readiness | Zero repeat BSA/AML examination findings on the same control in consecutive cycles |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **AML Programme** | The written framework comprising this Policy and all subordinate standards, procedures, and manuals in `04_compliance_and_aml/` |
| **BSA** | Bank Secrecy Act (USA), as amended, including the USA PATRIOT Act provisions |
| **CDD** | Customer Due Diligence — understanding the customer and the nature of the relationship |
| **EDD** | Enhanced Due Diligence — additional measures for higher-risk relationships |
| **CIP** | Customer Identification Program — verifying identity at onboarding |
| **Beneficial Owner (BO)** | Any individual owning ≥ 25% or exercising control over a legal entity customer |
| **PEP** | Politically Exposed Person — domestic, foreign, or international organisation PEP per `ANB-CMP-POL-0002` |
| **SAR** | Suspicious Activity Report filed with FinCEN (or equivalent) — identifier `SAR-########` |
| **CTR** | Currency Transaction Report for cash transactions > USD 10,000 — identifier `CTR-########` |
| **ML/TF** | Money laundering / terrorist financing |
| **RBA** | Risk-Based Approach — controls calibrated to assessed risk |
| **Transaction Monitoring (TM)** | Automated and manual review of activity for unusual patterns — `BP-AML-TM` |
| **Tipping Off** | Disclosing that a SAR has been filed or an investigation is underway — prohibited |
| **5130 Account** | FinCEN-designated account for SAR filings (operational detail in `ANB-CMP-SOP-0004`) |

Entity identifiers (`CUS-`, `KYC-`, `AML-CASE-`, etc.) are defined in Appendix A.

---

## 6. Roles and Responsibilities

### 6.1 Three Lines of Defence — Financial Crime

| Line | Who | Accountability |
|---|---|---|
| **First** | Business lines (RTL, CBK, TRY, WAM, CST), branch staff, relationship managers | Know your customer; escalate red flags; complete CDD data; never bypass controls |
| **Second** | Compliance (CMP) — Financial Crime, Sanctions, Fraud, Regulatory Affairs | Programme design, monitoring, investigation, filing, training, advisory |
| **Third** | Internal Audit (IAD) | Independent assurance to the Board Audit Committee |

Business management may not override a Compliance hold, downgrade a risk rating, or close an `AML-CASE-` without Financial Crime approval.

### 6.2 Key Roles

| Role | Name / ID | Responsibility |
|---|---|---|
| **Board Public Responsibility & Compliance Committee** | Chaired by Marisol Reyes | Oversight of conduct and compliance; receives annual AML effectiveness report |
| **Financial Crime Committee (FCC)** | Chaired by CCO `EMP-100005` | Typologies, emerging risks, resource, escalation of material cases |
| **Chief Compliance Officer (G11)** | `EMP-100005` Samuel A. Okonkwo | Accountable executive; regulatory interface; programme adequacy attestation |
| **Head of Financial Crime (G9)** | `EMP-400101` Adeline Mercier | Custodian of this Policy; TM, investigation, SAR/CTR quality, FCC secretariat |
| **BSA Officer (G8)** | `EMP-400102` Robert Kinsella | SAR/CTR filing authority; FinCEN correspondence; 314(a) and 314(b) coordination |
| **Head of Sanctions (G8)** | `EMP-400105` Catherine O'Brien | Sanctions programme; `BP-SAN-SCRN`, `BP-SAN-ESC`; OFAC reporting |
| **Head of Fraud (G8)** | `EMP-400106` Daniel Okoro | Fraud typologies; coordination with AML on mule accounts and APP fraud |
| **Head of Compliance Testing (G8)** | `EMP-400107` Isabelle Fontaine | Monitoring and testing programme per `ANB-CMP-GDL-0008` |
| **Head of Regulatory Affairs (G8)** | `EMP-400108` James Whitfield | Regulatory change; examination management; `BP-REG-EXAM` |
| **Head of KYC Operations (G7)** | `EMP-400112` Meilin Zhang | Onboarding and refresh operations in ApexKYC |
| **AML Investigations Manager (G7)** | `EMP-400109` Trevor Walsh | Investigation quality; `INV-AML-` assignment; case closure |
| **Compliance Officer — Retail** | `EMP-400103` Priyanka Iyer | First-line liaison; branch escalation; retail typologies |
| **Compliance Officer — Branch Monitoring** | `EMP-400104` Oluwaseun Bakare | Branch cash and CTR quality; `SIT-0412` and network |
| **Head of Regulatory Reporting (FIN)** | `EMP-600106` Farhan Siddiqui | Call Report and FR Y-9C; coordinates with CMP on BSA data feeds |
| **Chief Risk Officer** | `EMP-100004` Helena Brandt | Enterprise risk appetite; ML/TF risk in ERM |
| **General Counsel** | `EMP-100006` Margaret Sullivan | Legal privilege; subpoenas; SAR confidentiality |

### 6.3 First-Line Obligations

Every employee who touches a customer or a transaction must:

1. Complete mandatory AML training (`ANB-HRM-POL-0008` E-2, E-3, E-4, E-8).
2. Verify identity and collect CDD per role authority — never "just open the account."
3. Escalate unusual activity through ApexServe or ApexGuard — never investigate alone.
4. Never disclose SAR filing or investigation status to the customer or unauthorised colleagues.
5. Cooperate with Financial Crime and Internal Audit requests within stated timelines.

---

## 7. Policy Statements

**AML-1. Risk-based approach.** Controls are proportionate to assessed risk. Low-risk customers receive standard CDD and rule-based monitoring; high-risk customers receive EDD and enhanced monitoring. **Prohibited** relationships are not onboarded regardless of revenue opportunity.

**AML-2. No anonymous accounts.** The Bank does not maintain anonymous accounts, numbered accounts without CIP, or accounts where the beneficial owner is knowingly concealed.

**AML-3. Correspondent banking.** Correspondent relationships require enhanced due diligence, payable-through account prohibitions unless exception-approved by FCC, and ongoing monitoring per `ANB-CMP-SOP-0006` EDD section for correspondent banks.

**AML-4. Politically exposed persons.** PEP relationships require EDD, senior management approval, and enhanced ongoing monitoring — never standard CDD alone.

**AML-5. Shell companies and bearer shares.** Legal entity customers with opaque structures, nominee directors, or bearer share arrangements require EDD and may be declined where BO cannot be verified.

**AML-6. Record retention.** AML/BSA records are retained minimum **five years** from account closure or filing date (`RET-AML-5Y` / `ANB-ADM-POL-0001` §9.2). SAR-related material is **C3 Restricted** indefinitely while investigation may reopen.

**AML-7. SAR confidentiality.** SAR filing and existence are confidential. Access is role-restricted in ApexGuard. Disclosure to the subject or tipping off is a federal offence and terminable misconduct.

**AML-8. No business override.** Revenue, relationship, or executive pressure does not override a Compliance decline, hold, or SAR filing decision. Retaliation against reporters is gross misconduct (`ANB-HRM-POL-0004` §12).

**AML-9. Independent testing.** The programme is tested annually by Internal Audit and/or an independent third party, with results reported to the Board Audit Committee and FCC.

**AML-10. Training.** All employees receive annual AML training; investigators, onboarding staff, and branch cash handlers receive additional role-based modules.

---

## 8. Customer Risk Rating Methodology

### 8.1 Risk Dimensions

| Dimension | Factors |
|---|---|
| **Customer** | PEP status, adverse media, industry (MSB, cash-intensive, crypto), legal structure complexity, BO transparency |
| **Product** | Correspondent banking, trade finance, private banking, cross-border wires, prepaid cards |
| **Channel** | Non-face-to-face digital onboarding, third-party introducers, agent banking |
| **Geography** | FATF high-risk / increased monitoring jurisdictions; OFAC comprehensively sanctioned countries |

### 8.2 Rating Scale

| Code | Label | Definition | CDD Tier | Review Frequency |
|---|---|---|---|---|
| `CR-L` | Low | Transparent retail or small business; domestic; standard products | Standard CDD | 36 months |
| `CR-M` | Medium | Moderate complexity; some cross-border; non-PEP commercial | Standard CDD | 24 months |
| `CR-H` | High | PEP (non-prohibited), high-risk geography, MSB, complex structure, correspondent | EDD | 12 months |
| `CR-P` | Prohibited | Sanctions match; unable to verify BO; designated shell pattern; TF nexus | **No relationship** | N/A |

Ratings are stored on `CRP-########` and drive ApexKYC refresh schedules and ApexGuard rule sets.

### 8.3 Re-rating Triggers

Immediate re-rating review required on: material adverse media; sanctions hit; STR/SAR from another institution; change of BO or control; significant change in activity inconsistent with profile; law enforcement enquiry; internal investigation substantiation; geographic relocation to high-risk jurisdiction.

Process: `BP-AML-RISK` — owner `EMP-400101`.

---

## 9. AML Control Framework

| # | Control Domain | Primary Process | System | Key Control ID |
|---|---|---|---|---|
| 1 | Customer identification | `BP-ONB-CIP` | ApexKYC | `CTL-CMP-001` |
| 2 | Customer due diligence | `BP-ONB-KYC` | ApexKYC | `CTL-CMP-002` |
| 3 | Enhanced due diligence | `BP-ONB-EDD` | ApexKYC | `CTL-CMP-003` |
| 4 | Sanctions screening | `BP-SAN-SCRN` | ApexKYC, ApexGuard, ApexPay | `CTL-CMP-010` |
| 5 | Transaction monitoring | `BP-AML-TM` | ApexGuard | `CTL-CMP-020` |
| 6 | CTR filing | `BP-AML-CTR` | ApexCore, ApexRegRep | `CTL-CMP-030` |
| 7 | SAR investigation and filing | `BP-AML-SAR` | ApexGuard, ApexRegRep | `CTL-CMP-031` |
| 8 | Financial crime investigation | `BP-AML-INV` | ApexGuard | `CTL-CMP-040` |
| 9 | Ongoing monitoring / refresh | `BP-AML-RISK` | ApexKYC | `CTL-CMP-050` |
| 10 | Training and attestation | `BP-HR-TRN` | ApexLearn | `CTL-CMP-060` |
| 11 | Compliance testing | `BP-REG-MON` | ApexAudit | `CTL-CMP-070` |
| 12 | Regulatory reporting data | `BP-REG-FILE` | ApexRegRep | `CTL-CMP-080` |

Control testing evidence is retained `RET-AUD-7Y`.

---

## 10. Operational Workflow — Programme Lifecycle

```
GOVERNANCE                    OPERATIONS                         REPORTING
     │                              │                                  │
Board PRCC ──► FCC ──► CCO ──► Head of Financial Crime                 │
     │              │                    │                              │
     │              │         ┌──────────┼──────────┐                   │
     │              │         ▼          ▼          ▼                   │
     │              │      Onboarding   TM Alerts   Sanctions             │
     │              │      (ApexKYC)   (ApexGuard) (ApexWatch)           │
     │              │         │          │          │                   │
     │              │         └──────────┼──────────┘                   │
     │              │                    ▼                              │
     │              │              AML-CASE- / INV-AML-                 │
     │              │                    │                              │
     │              │         ┌──────────┼──────────┐                   │
     │              │         ▼          ▼          ▼                   │
     │              │        CTR       SAR      Exit/Restrict           │
     │              │     (FinCEN)  (FinCEN)   (ApexCore)               │
     │              │                    │                              │
     └──────── Annual Effectiveness ◄───┴──► Internal Audit / Exam      │
```

---

## 11. Decision Trees

### 11.1 Unusual Activity Detected

```
Unusual activity observed (any channel)
        │
        ├─ Employee observation ──► Escalate to Compliance / create ApexServe case
        │
        ├─ TM alert (ALT-########) ──► Analyst disposition in ApexGuard
        │       │
        │       ├─ False positive ──► Close with rationale; may tune RULE-AML-####
        │       ├─ Inconclusive ──► Open AML-CASE-########; assign investigator
        │       └─ Substantiated concern ──► INV-AML-########; consider SAR-########
        │
        └─ Sanctions hit (SCR-########) ──► BP-SAN-ESC; block/reject; do not tip off
```

### 11.2 Customer Risk at Onboarding

```
New customer application
        │
        ├─ Sanctions / prohibited geography ──► DECLINE (CR-P)
        ├─ PEP / high-risk industry / complex structure ──► EDD-######## required
        ├─ Standard retail / transparent SMB ──► CDD-########; CR-L or CR-M
        └─ Correspondent / MSB / trust ──► EDD + FCC notification if material
```

---

## 12. Risk Indicators and Typologies

The Bank maintains a living typology library in ApexDocs, reviewed quarterly by FCC. Core patterns:

| Typology | Indicators | Typical Rules |
|---|---|---|
| **Structuring** | Multiple cash deposits just below USD 10,000; same-day multi-branch | `RULE-AML-0101` |
| **Smurfing** | Multiple third parties depositing to one account | `RULE-AML-0102` |
| **Layering** | Rapid movement through accounts; no economic purpose | `RULE-AML-0201` |
| **Integration** | Sudden legitimate-appearing investments after opaque inflows | `RULE-AML-0202` |
| **Trade-based ML** | Over/under invoicing; round-tripping goods | `RULE-AML-0301` |
| **Shell companies** | No physical presence; nominee directors; bearer instruments | Onboarding decline |
| **BO concealment** | Refusal to provide BO; inconsistent filings | `CTL-CMP-003` fail |
| **Mule accounts** | Dormant account reactivation; rapid in/out; young account holder | `RULE-AML-0401` |
| **Third-party funding** | Unrelated third parties funding loan or account | `RULE-AML-0402` |
| **High-risk jurisdictions** | Wires to/from FATF black/grey list without business rationale | `RULE-AML-0501` |
| **Sanctions evasion** | Triangulation; non-SDN intermediaries; maritime AIS gaps | `BP-SAN-ESC` |
| **Terrorist financing** | Small structured donations; charity front; conflict zone nexus | `RULE-AML-0601` |
| **Fraud ↔ AML nexus** | APP fraud proceeds; romance scam deposits | Coordination with `EMP-400106` |
| **Dormant reactivation** | Long-dormant account sudden high activity | `RULE-AML-0701` |
| **Crypto exposure** | MSB / VASP flows without licence verification | EDD + enhanced TM |
| **Unusual cash** | CTR aggregation; vault visits inconsistent with profile | Branch escalation |

---

## 13. Escalation Paths

| Situation | Escalate To | Timeline |
|---|---|---|
| Potential SAR (any amount) | AML Investigations Manager `EMP-400109` | Same business day |
| Confirmed sanctions match on customer | Head of Sanctions `EMP-400105` | Within 1 hour |
| PEP identified post-onboarding | Head of Financial Crime `EMP-400101` | Within 1 business day |
| Law enforcement enquiry | BSA Officer + General Counsel | Immediate |
| Media / reputational AML event | CCO + Group CEO notification | Same day |
| Programme control failure | FCC + Board Audit Committee | 5 business days for report |
| Cross-border regulatory conflict | Head of Regulatory Affairs `EMP-400108` | 3 business days |

---

## 14. Approval Workflow

| Decision | Approver | Second Approver |
|---|---|---|
| Policy Major version | Head of Financial Crime (G9) | CCO (G11) → Board PRCC |
| Customer `CR-H` onboarding | Head of KYC Operations (G7) | Head of Financial Crime (G9) |
| PEP relationship (non-prohibited) | Head of Financial Crime (G9) | CCO (G11) for foreign PEP |
| Correspondent bank onboarding | CCO (G11) | FCC recommendation |
| Decline / exit for AML reasons | Head of Financial Crime (G9) | BSA Officer notified |
| SAR filing | BSA Officer (G8) | Head of Financial Crime (G9) review |
| No-SAR closure of substantiated investigation | AML Investigations Manager (G7) | BSA Officer concurrence |
| TM rule deactivation | Head of Financial Crime (G9) | Head of Compliance Testing (G8) |
| Sanctions false-positive model change | Head of Sanctions (G8) | CCO (G11) |

---

## 15. Examples

### 15.1 Structuring — Branch Escalation

`EMP-300106` Jamal Robertson (Teller, `SIT-0412`) observes a customer making four cash deposits of USD 9,500 on consecutive days to the same account `ACC-8871200456` (`CUS-04928311`). He escalates through ApexServe to `EMP-400104` Oluwaseun Bakare. CTR aggregation review confirms reportable activity; `CTR-202607-004821` is filed. TM opens `ALT-20260718-0044`; case `AML-CASE-20260718-0091` is opened. Investigation `INV-AML-20260720-0033` substantiates structuring; `SAR-202607-004412` is filed by `EMP-400102` Robert Kinsella. Customer relationship restricted pending exit review.

### 15.2 Correspondent EDD

A Caribbean correspondent bank applies for a nostro relationship. Onboarding triggers `EDD-202608-0012`: BO verification, AML programme questionnaire, onsite visit waiver with enhanced documentary review, FCC briefing. `CR-H` assigned. `PEP-202608-0012` identifies a board member as domestic PEP. CCO approves with conditions: USD 5M per-day wire cap and quarterly refresh. Documented in `CRP-06291004`.

---

## 16. Related Documents

### 16.1 Compliance Domain

| ID | Title | File |
|---|---|---|
| `ANB-CMP-POL-0002` | KYC Policy | `002_KYC_POLICY.md` |
| `ANB-CMP-GDL-0007` | Customer Due Diligence Guideline | `003_CUSTOMER_DUE_DILIGENCE_GUIDELINE.md` |
| `ANB-CMP-SOP-0006` | Enhanced Due Diligence Procedure | `004_ENHANCED_DUE_DILIGENCE_PROCEDURE.md` |
| `ANB-CMP-SOP-0005` | Sanctions Screening SOP | `005_SANCTIONS_SCREENING_STANDARD_OPERATING_PROCEDURE.md` |
| `ANB-CMP-POL-0005` | Sanctions & OFAC Screening Policy | *(parent policy for SOP-0005)* |
| `ANB-CMP-SOP-0007` | Currency Transaction Report Procedure | `006_CURRENCY_TRANSACTION_REPORT_PROCEDURE.md` |
| `ANB-CMP-SOP-0004` | Suspicious Activity Report Procedure | `007_SUSPICIOUS_ACTIVITY_REPORT_PROCEDURE.md` |
| `ANB-CMP-GDL-0008` | Compliance Monitoring Guide | `008_COMPLIANCE_MONITORING_GUIDE.md` |
| `ANB-CMP-SOP-0009` | Regulatory Reporting SOP | `009_REGULATORY_REPORTING_STANDARD_OPERATING_PROCEDURE.md` |
| `ANB-CMP-MAN-0001` | Financial Crime Investigation Manual | `010_FINANCIAL_CRIME_INVESTIGATION_MANUAL.md` |
| `ANB-CMP-FRM-0003` | Customer KYC Form | *(planned)* |
| `ANB-CMP-POL-0006` | Compliance Policy | *(planned — regulatory change & monitoring)* |

### 16.2 Foundation, Governance, HR, Finance

| ID | Title |
|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy |
| `ANB-ADM-STD-0007` | Document Naming Standard |
| `ANB-ADM-POL-0001` | Records Retention Policy |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter |
| `ANB-HRM-POL-0004` | Code of Conduct |
| `ANB-HRM-POL-0008` | Training & Certification Policy |
| `ANB-RTL-POL-0001` | Retail Account Opening Policy |
| `ANB-FIN-SOP-0003` | Financial Closing SOP |
| `ANB-FIN-STD-0004` | Chart of Accounts Standard |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy |

---

## 17. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full programme review; Board PRCC attestation | Head of Financial Crime | By 31 July |
| FATF / FinCEN rule change | Gap assessment and policy update | Head of Regulatory Affairs | 60 days |
| Material examination finding | Remediation plan to FCC | CCO | 30 days |
| Typology emergence | Rule and training update | Head of Financial Crime | 45 days |
| Significant enforcement action (peer) | Thematic review | FCC | 90 days |

Next scheduled review: **2027-07-28**.

---

## 18. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-07-02 | Head of Financial Crime | Initial draft from `ANB-ADM-REF-0001` §6 AML scope | — |
| 0.5 | 2026-07-15 | Head of Financial Crime | Risk rating methodology and typology library | — |
| 0.8 | 2026-07-22 | Head of Financial Crime | Control framework aligned to `ANB-ADM-GDL-0001` BP-AML-* | — |
| 1.0 | 2026-07-28 | Head of Financial Crime | First published version | S. A. Okonkwo / Board PRCC |

---

## 19. Appendices

### Appendix A — Canonical Compliance Entity Register

**Authoritative for all documents in `04_compliance_and_aml/` and downstream domains.** New identifiers are allocated by KYC Operations (`EMP-400112`) or Financial Crime case management — never invented in narrative text.

#### A.1 Customer and Profile Identifiers

| Entity | Format | Example | System | Retention |
|---|---|---|---|---|
| Customer | `CUS-########` | `CUS-04928311` | ApexCore, ApexKYC | `RET-CUS-7Y` |
| Customer Profile | `CRP-########` | `CRP-04928311` | ApexKYC | `RET-AML-5Y` |
| Account | `ACC-##########` | `ACC-8871200456` | ApexCore | `RET-CUS-7Y` |

#### A.2 Due Diligence Records

| Entity | Format | Example | Retention |
|---|---|---|---|
| KYC Record | `KYC-########` | `KYC-20260419-0044` | `RET-AML-5Y` |
| CDD Review | `CDD-########` | `CDD-20260701-0088` | `RET-AML-5Y` |
| EDD Review | `EDD-########` | `EDD-202608-0012` | `RET-AML-5Y` |
| PEP Assessment | `PEP-########` | `PEP-202608-0012` | `RET-AML-5Y` |

#### A.3 Screening and Watchlist

| Entity | Format | Example | Retention |
|---|---|---|---|
| Sanctions Screening Record | `SCR-########` | `SCR-20260722-0033` | `RET-AML-5Y` |
| Watchlist Record | `WL-########` | `WL-OFAC-SDN-12844` | `RET-AML-5Y` |

#### A.4 Cases, Alerts, Investigations

| Entity | Format | Example | Retention |
|---|---|---|---|
| TM Alert | `ALT-########` | `ALT-20260718-0044` | `RET-AML-5Y` |
| AML Case | `AML-CASE-########` | `AML-CASE-20260718-0091` | `RET-AML-5Y` (C3 if SAR) |
| Investigation | `INV-AML-########` | `INV-AML-20260720-0033` | `RET-AML-5Y` (C3 if SAR) |
| Monitoring Rule | `RULE-AML-####` | `RULE-AML-0101` | `RET-POL-10Y` |

#### A.5 Regulatory Reports

| Entity | Format | Example | Retention |
|---|---|---|---|
| CTR Report | `CTR-########` | `CTR-202607-004821` | `RET-AML-5Y` |
| SAR Report | `SAR-########` | `SAR-202607-004412` | `RET-AML-5Y` (C3) |

#### A.6 Governance Objects

| Entity | Format | Example |
|---|---|---|
| Regulatory Obligation | `REG-AML-###` | `REG-AML-001` (BSA CIP) |
| Compliance Control | `CTL-CMP-###` | `CTL-CMP-031` |
| Customer Risk Rating | `CR-L` / `CR-M` / `CR-H` / `CR-P` | `CR-H` |

#### A.7 Case Status Codes

| Code | Meaning |
|---|---|
| `ST-NEW` | Newly opened; unassigned |
| `ST-ASSIGNED` | Assigned to analyst/investigator |
| `ST-PEND-INFO` | Pending internal or external information |
| `ST-PEND-MLRO` | Pending BSA Officer / MLRO decision |
| `ST-SAR-FILED` | SAR filed; post-filing monitoring |
| `ST-NO-SAR` | Closed without SAR — documented rationale |
| `ST-ESC-LEGAL` | Escalated to Legal |
| `ST-ESC-LAW` | Law enforcement liaison |
| `ST-CLOSED` | Closed — all actions complete |
| `ST-REOPEN` | Reopened on new information |

#### A.8 Regulatory Obligations Register (Extract)

| ID | Obligation | Driver |
|---|---|---|
| `REG-AML-001` | Customer Identification Program | BSA / 31 CFR 1020.220 |
| `REG-AML-002` | Customer Due Diligence & BO | 31 CFR 1010.230 |
| `REG-AML-003` | Currency Transaction Reports | 31 CFR 1010.311 |
| `REG-AML-004` | Suspicious Activity Reports | 31 CFR 1020.320 |
| `REG-AML-005` | OFAC Sanctions Compliance | 31 CFR Part 501 |
| `REG-AML-006` | Record Retention (BSA) | 31 CFR 1010.430 |
| `REG-AML-007` | PEP and EDD (UK MLR) | UK MLR 2017 Reg 33–35 |
| `REG-AML-008` | GDPR Art. 6 lawful basis for CDD | EU/UK GDPR |

#### A.9 Compliance Personnel Register (Extended)

| Employee ID | Name | Grade | Role | Location |
|---|---|---|---|---|
| `EMP-100005` | Samuel A. Okonkwo | G11 | Chief Compliance Officer | New York |
| `EMP-400101` | Adeline Mercier | G9 | Head of Financial Crime | New York |
| `EMP-400102` | Robert Kinsella | G8 | BSA Officer | New York |
| `EMP-400103` | Priyanka Iyer | G6 | Compliance Officer — Retail Banking | Charlotte |
| `EMP-400104` | Oluwaseun Bakare | G5 | Compliance Officer — Branch Monitoring | Charlotte |
| `EMP-400105` | Catherine O'Brien | G8 | Head of Sanctions | New York |
| `EMP-400106` | Daniel Okoro | G8 | Head of Fraud | New York |
| `EMP-400107` | Isabelle Fontaine | G8 | Head of Compliance Testing | London |
| `EMP-400108` | James Whitfield | G8 | Head of Regulatory Affairs | New York |
| `EMP-400109` | Trevor Walsh | G7 | AML Investigations Manager | New York |
| `EMP-400110` | Elena Vasquez-Kim | G6 | Senior AML Investigator | New York |
| `EMP-400111` | Marcus Lindholm | G4 | Financial Crime Analyst | Charlotte |
| `EMP-400112` | Meilin Zhang | G7 | Head of KYC Operations | New York |
| `EMP-400113` | Aisha Mensah | G4 | Sanctions Screening Analyst | New York |
| `EMP-400114` | Ryan O'Connell | G3 | CTR Quality Analyst | Charlotte |
| `EMP-400115` | Sofia Petrov | G6 | Regulatory Reporting Manager — CMP | New York |

Filename examples per `ANB-ADM-STD-0007`: `AMLC_AML-CASE-20260718-0091_InvestigationSummary_20260725_C3.pdf`.

---

**End of Document**

`ANB-CMP-POL-0001` · Version 1.0 · Classification: Confidential (C2) · Owner: Compliance (CMP) · Approver: Samuel A. Okonkwo, Chief Compliance Officer · Effective 2026-08-01

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
