# Apex National Bank — Enhanced Due Diligence Procedure

**Standard Operating Procedure | High-Risk Customers, PEPs, and Source of Wealth/Funds**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-SOP-0006` |
| **Document Title** | Enhanced Due Diligence Procedure |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Financial Crime |
| **Custodian** | Adeline Mercier, Head of Financial Crime (G9) — `EMP-400101` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C3) — PEP and investigation-adjacent data |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-ONB-EDD`, `BP-AML-RISK` |
| **System of Record** | ApexKYC · ApexGuard · ApexDocs |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-POL-0002`, `ANB-CMP-GDL-0007`, `ANB-CMP-MAN-0001` |

---

## 2. Purpose

Enhanced Due Diligence (EDD) applies measures beyond standard CDD to manage elevated money laundering, terrorist financing, corruption, and sanctions evasion risk. This Procedure defines triggers, information requirements, approval workflow, ongoing monitoring, and documentation for `EDD-########` records.

---

## 3. Scope

Mandatory for: `CR-H` customers; all PEPs (domestic, foreign, international organisation); correspondent banks; MSBs and VASPs; complex legal structures; high-risk jurisdictions; material adverse media; relationships referred from TM or law enforcement.

---

## 4. EDD Triggers

| # | Trigger | Auto-Route |
|---|---|---|
| T-1 | Risk score ≥ 51 | ApexKYC workflow |
| T-2 | PEP match on `PEP-########` | ApexKYC |
| T-3 | Correspondent banking application | Manual — KYC Ops |
| T-4 | MSB / crypto / casino / arms dealer NAICS | Manual |
| T-5 | Layered ownership (> 2 tiers opaque) | KYC Analyst |
| T-6 | FATF high-risk country nexus | Screening |
| T-7 | Material adverse media | Analyst / TM |
| T-8 | Substantiated TM concern pre-SAR | `EMP-400109` |
| T-9 | Post-SAR continuation (rare) | FCC + CCO |
| T-10 | Correspondent / payable-through request | FCC |

---

## 5. EDD Information Requirements

### 5.1 All EDD Relationships

| Requirement | Detail |
|---|---|
| Source of wealth (SOW) | Documented origin of total wealth — employment, inheritance, business sale, etc. |
| Source of funds (SOF) | Origin of funds for the relationship / specific transaction |
| Purpose | Detailed business rationale |
| Expected activity | Quantified — wire volumes, countries, cash % |
| Site visit or equivalent | Physical or enhanced remote for corporate/correspondent |
| Senior management approval | Per §8 |
| Enhanced monitoring plan | ApexGuard rule set `RULE-AML-EDD-*` |
| Refresh | 12 months maximum |

### 5.2 PEP-Specific

| Requirement | Detail |
|---|---|
| PEP classification | Domestic / foreign / IO — `PEP-########` |
| Role and country | Position, term, family links |
| SOW/SOF | Mandatory — independent verification where possible |
| Approval | Head of Financial Crime; foreign PEP → CCO |
| Enhanced TM | All transactions reviewed for 12 months or relationship life |
| Relatives and close associates (RCA) | Identified and screened |

### 5.3 Correspondent Banking

| Requirement | Detail |
|---|---|
| Wolfsberg questionnaire | Completed and verified |
| Licensing and supervision | Home regulator confirmation |
| AML programme assessment | Rated satisfactory or above |
| Sanctions programme | Confirmed |
| FCC briefing | Mandatory |
| Payable-through accounts | Prohibited unless CCO exception |

---

## 6. Operational Workflow

```
EDD trigger identified
        │
        ├─ Assign EDD Owner (G5+ KYC or FC analyst)
        ├─ Create EDD-######## linked to CRP-########
        ├─ Collect SOW/SOF documentation
        ├─ Independent verification (public records, corporate registries, RM interview)
        ├─ Adverse media deep dive
        ├─ Draft EDD report in ApexKYC
        │
        ├─ PEP / correspondent / MSB ──► Senior approval chain (§8)
        │
        ├─ APPROVE ──► Set CR-H; monitoring plan; 12-month refresh
        ├─ APPROVE WITH CONDITIONS ──► Limits, products restricted, documented
        └─ DECLINE ──► No relationship; record in ApexKYC
```

---

## 7. Ongoing Monitoring

| Measure | Detail |
|---|---|
| TM rule set | `RULE-AML-EDD-001` — lower thresholds, all wires reviewed |
| Manual review | Quarterly activity review by FC analyst for PEP/correspondent |
| Trigger re-EDD | Any SAR consideration, BO change, or adverse media |
| Relationship Manager | Monthly attestation for commercial PEP relationships |

---

## 8. Approval Workflow

| Relationship Type | Approver | Second Approver |
|---|---|---|
| `CR-H` non-PEP commercial | Head of KYC Operations (G7) | Head of Financial Crime (G9) |
| Domestic PEP | Head of Financial Crime (G9) | BSA Officer notified |
| Foreign PEP | CCO (G11) | FCC noting |
| Correspondent bank | CCO (G11) | FCC recommendation minuted |
| MSB / VASP | Head of Financial Crime (G9) | CCO if > USD 1M expected activity |
| Post-SAR continuation | CCO (G11) | General Counsel |

---

## 9. Decision Tables

| Finding | Decision |
|---|---|
| SOW verified; low residual risk | Approve EDD; `CR-H` |
| SOW unverified; customer cooperative | Conditional — limits until verified |
| SOW refusal | Decline |
| PEP — foreign head of state | Decline unless FCC exception |
| Correspondent — weak AML programme | Decline |
| Adverse media — financial crime nexus | Decline or exit |
| Layered structure — BO still opaque | Decline |

---

## 10. Examples

### 10.1 Foreign PEP — Private Banking

`CUS-06291004` identified as foreign PEP (former minister). `EDD-202608-0012` opened. SOW: declared business interests + public salary history; verified via corporate registry and independent database. `PEP-202608-0012` documents role. CCO approves private banking relationship with USD 2M AUM cap and quarterly FC review. `RULE-AML-EDD-001` assigned.

### 10.2 Correspondent Decline

Caribbean bank applicant cannot provide independent AML audit. Wolfsberg incomplete. FCC recommends decline. `EDD-202609-0020` closed as declined; no account opened.

---

## 11. Escalation

| Event | Escalate To | Timeline |
|---|---|---|
| PEP not previously identified on existing customer | Head of Financial Crime | 24 hours |
| SOW inconsistency with public data | AML Investigations | 48 hours |
| Correspondent downstream concern | FCC | 5 days |
| EDD approval disagreement | CCO binding decision | 10 days |

---

## 12. Related Documents

`ANB-CMP-POL-0001` · `ANB-CMP-POL-0002` · `ANB-CMP-GDL-0007` · `ANB-CMP-SOP-0005` · `ANB-CMP-MAN-0001` · `ANB-HRM-POL-0004` · `ANB-LEG-REF-0003` (FCC)

---

## 13. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | A. Mercier | Initial EDD procedure |

---

## Appendix A — EDD Document Checklist

SOW statement (customer signed); SOF for initial funding; 3 years tax returns or audited FS (commercial); corporate registry extract (< 6 months); BO diagram; PEP declaration; site visit report or remote equivalent; screening printouts (`SCR-`, `PEP-`); approver signatures; monitoring plan; next refresh date.

---

**End of Document** — `ANB-CMP-SOP-0006` v1.0 · C3
