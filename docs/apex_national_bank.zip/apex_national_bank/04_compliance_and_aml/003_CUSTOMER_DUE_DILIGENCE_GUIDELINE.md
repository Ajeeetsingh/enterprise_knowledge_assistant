# Apex National Bank — Customer Due Diligence Guideline

**Compliance Guideline | Standard CDD, Risk Scoring, and Documentation Standards**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-GDL-0007` |
| **Document Title** | Customer Due Diligence Guideline |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Financial Crime |
| **Custodian** | Adeline Mercier, Head of Financial Crime (G9) — `EMP-400101` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-ONB-KYC`, `BP-AML-RISK` |
| **System of Record** | ApexKYC |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-POL-0002`, `ANB-CMP-SOP-0006` |

---

## 2. Purpose

This Guideline operationalises standard Customer Due Diligence for relationships that do not require Enhanced Due Diligence. It defines customer classification, the risk scoring model, required documentation, review frequencies, and quality standards for `CDD-########` records.

---

## 3. Scope

Applies to all `CR-L` and `CR-M` customers at onboarding and refresh. `CR-H`, PEP, correspondent, MSB, and complex trust relationships are routed to `ANB-CMP-SOP-0006` EDD.

---

## 4. Customer Classification

| Class | Code | Description | Examples |
|---|---|---|---|
| **Retail — Individual** | `CLS-RET-IND` | Natural person consumer | Checking, savings, mortgage |
| **Retail — Joint** | `CLS-RET-JNT` | Two or more natural persons | Joint account |
| **Small Business** | `CLS-SMB` | Privately held, < USD 50M revenue | SMB operating account |
| **Commercial** | `CLS-COM` | Middle-market corporate | Cash management, term loan |
| **Institutional** | `CLS-INS` | Fund, pension, insurance | Custody, treasury |
| **Correspondent** | `CLS-COR` | Financial institution | Nostro/vostro — **EDD mandatory** |
| **Wealth / Private** | `CLS-WAM` | HNW private banking | May trigger EDD by AUM/geography |

---

## 5. Risk Scoring Model

### 5.1 Score Components (0–100)

| Factor | Weight | Low (0) | Medium (1) | High (2) |
|---|---|---|---|---|
| Customer type | 15% | Retail individual | SMB | MSB/correspondent/shell-prone |
| Geography | 25% | US/UK/EU low-risk | Non-FATF grey adjacent | FATF high-risk / sanctioned |
| Product | 20% | Deposit only | Lending | Trade finance, wires, private banking |
| Channel | 10% | Branch face-to-face | RM-introduced | Digital-only, introducer |
| PEP / adverse media | 20% | Clear | Adverse media (non-material) | PEP or material adverse media |
| Activity profile | 10% | Consistent with stated purpose | Moderate deviation | Opaque / inconsistent |

### 5.2 Score to Rating Mapping

| Score | Rating | CDD Path |
|---|---|---|
| 0–25 | `CR-L` | Standard CDD — this Guideline |
| 26–50 | `CR-M` | Standard CDD — this Guideline |
| 51–75 | `CR-H` | **Route to EDD** |
| 76+ or prohibited factor | `CR-P` | **Decline** |

Prohibited factors (automatic `CR-P`): confirmed sanctions match; inability to identify BO; bearer shares; comprehensively sanctioned jurisdiction nexus without licence.

---

## 6. Standard CDD Requirements

### 6.1 Information to Obtain

| Element | All Customers | Legal Entity Additional |
|---|---|---|
| Purpose and intended nature of relationship | ✓ | Business description, NAICS/SIC |
| Expected activity — volume and type | ✓ | Expected wire countries, cash intensity |
| Source of funds (onboarding) | ✓ if material deposit | ✓ |
| Source of wealth | — | ✓ if `CR-M` upper band |
| BO identification | N/A | ✓ per `ANB-CMP-POL-0002` |
| Screening results | `SCR-`, `PEP-` | ✓ |
| RM / branch attestation | ✓ | ✓ |

### 6.2 Required Documentation Matrix

| Class | Identity | Address | BO | Financial | Other |
|---|---|---|---|---|---|
| `CLS-RET-IND` | Photo ID | ≤ 90 days | — | — | SSN verification |
| `CLS-RET-JNT` | Both parties ID | Both | — | — | — |
| `CLS-SMB` | ID + formation | Business address | BO form | 2 years tax return or FS (if credit) | Operating agreement |
| `CLS-COM` | Signatory ID | Registered + ops | BO form | Audited FS or RM credit file | Board resolution |

Documents stored in ApexKYC; classified C2 minimum; C3 if investigation-linked.

---

## 7. Operational Workflow — CDD Review

```
Trigger: onboarding or periodic refresh
        │
        ├─ Pull CRP-######## and existing KYC-########
        ├─ Verify CIP elements current
        ├─ Run SCR-######## and PEP-######## (World-Check via ApexKYC)
        ├─ Calculate risk score → CR-L / CR-M / CR-H
        │
        ├─ CR-H ──► Refer EDD-######## (stop standard CDD)
        │
        └─ CR-L / CR-M
                ├─ Complete CDD questionnaire in ApexKYC
                ├─ Document expected vs actual (if refresh)
                ├─ KYC Analyst QA
                ├─ Create CDD-######## with status ST-CLOSED
                └─ Set next_refresh_date on CRP-########
```

---

## 8. Review Frequencies

| Rating | Months | Owner | QA Sample |
|---|---|---|---|
| `CR-L` | 36 | KYC Operations | 5% annual |
| `CR-M` | 24 | KYC Operations | 10% annual |
| Post-SAR (no exit) | 6 | Financial Crime | 100% plan |

---

## 9. Decision Trees

### 9.1 Standard vs Enhanced

```
Risk score calculated
        │
        ├─ PEP identified? ──YES──► EDD (no exception)
        ├─ Correspondent? ──YES──► EDD
        ├─ MSB/VASP? ──YES──► EDD
        ├─ Score ≥ 51? ──YES──► EDD
        └─ Else ──► Standard CDD under this Guideline
```

### 9.2 Refresh Outcome

```
Periodic refresh
        │
        ├─ Information current; activity consistent ──► Reaffirm CR-*; new CDD-########
        ├─ Activity deviation ──► Re-rate; possible EDD
        ├─ Adverse media ──► Escalate Financial Crime
        └─ Unable to contact / docs expired ──► Restrict account; escalate exit
```

---

## 10. Quality Assurance

| Control | Frequency | Owner |
|---|---|---|
| `CTL-CMP-002` — CDD completeness | Monthly | KYC Operations |
| Independent sample review | Quarterly | `EMP-400107` Compliance Testing |
| ApexKYC field validation rules | Continuous | `EMP-400114` Ryan O'Connell (CTR/KYC QA) |

Deficiency rate > 3% triggers remedial training and rule tightening.

---

## 11. Examples

**Example 1 — `CLS-RET-IND`:** `CUS-04928311` scores 18 → `CR-L`. `CDD-20260701-0088` documents expected payroll deposits USD 4–6k/month. Approved by KYC Analyst. Next refresh 2029-07.

**Example 2 — Score borderline:** SMB scores 48 → `CR-M`. Additional documentation: 2-year tax return requested. `CDD-202608-0099` approved. 24-month refresh.

---

## 12. Related Documents

Full compliance domain cross-reference per `ANB-CMP-POL-0001` §16. Primary siblings: `ANB-CMP-POL-0002`, `ANB-CMP-SOP-0006`, `ANB-RTL-POL-0001`, `ANB-ADM-STD-0005`.

---

## 13. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | A. Mercier | Initial guideline; scoring model v1 |

---

## Appendix A — CDD Checklist (Analyst)

- [ ] `CUS-` and `CRP-` created/updated
- [ ] CIP elements verified and not expired
- [ ] `SCR-` and `PEP-` run and attached
- [ ] Risk score calculated and rating assigned
- [ ] If `CR-H` → EDD referral (do not complete standard CDD)
- [ ] Expected activity documented
- [ ] BO form on file (if entity)
- [ ] Approver recorded
- [ ] `CDD-########` created with next refresh date
- [ ] Customer notified of CDD obligations (where required)

---

**End of Document** — `ANB-CMP-GDL-0007` v1.0
