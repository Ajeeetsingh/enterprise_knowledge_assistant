# Apex National Bank — Currency Transaction Report Procedure

**Standard Operating Procedure | Cash Reporting, Aggregation, and FinCEN Filing**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-SOP-0007` |
| **Document Title** | Currency Transaction Report Procedure |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Financial Crime |
| **Custodian** | Robert Kinsella, BSA Officer (G8) — `EMP-400102` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-AML-CTR` |
| **System of Record** | ApexCore · ApexRegRep · ApexGuard |
| **Regulatory Obligation** | `REG-AML-003` — 31 CFR 1010.311 |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-SOP-0004`, `ANB-RTL-POL-0001` |

---

## 2. Purpose

The Bank must report currency transactions exceeding USD 10,000 in aggregate per business day, and certain other reportable transactions, to FinCEN via Currency Transaction Reports (CTRs). This Procedure defines identification, aggregation, filing workflow, quality assurance, and regulatory timelines for `CTR-########` records.

---

## 3. Scope

| In Scope | Detail |
|---|---|
| Cash in / cash out | USD and foreign currency converted to USD equivalent |
| Branches | All `SIT-####` locations including `SIT-0412` Charlotte network |
| Night deposit / ATM | Branch-attributable cash |
| Multiple transactions | Same customer, same business day aggregation |
| Exemptions | Phase II exempt persons — list maintained by BSA Officer |

| Out of Scope | Detail |
|---|---|
| Monetary instruments only (no cash) | May trigger other reporting |
| Virtual currency | Separate programme — MSB rules |

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Reportable Transaction** | Cash in or out > USD 10,000 in one transaction OR aggregated same-day |
| **Aggregation** | Multiple cash transactions same customer same business day |
| **CTR** | FinCen Form 112 — identifier `CTR-########` |
| **Exempt Person** | Bank, government, listed public company — limited exemption per 31 CFR 1020.315 |
| **Conductor** | Person physically conducting transaction if different from account holder |

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| BSA Officer | `EMP-400102` Robert Kinsella | Filing authority; FinCEN correspondence; exemptions |
| CTR Quality Analyst | `EMP-400114` Ryan O'Connell | QA sampling; field validation |
| Branch Monitoring | `EMP-400104` Oluwaseun Bakare | Branch escalation; teller training liaison |
| Tellers / CSRs | First line | CTR data capture; conductor ID |
| Head of Financial Crime | `EMP-400101` | Programme oversight; TM linkage |
| Regulatory Reporting (CMP) | `EMP-400115` Sofia Petrov | ApexRegRep submission calendar |

---

## 6. Reporting Thresholds and Rules

### 6.1 Mandatory CTR

| Condition | Action |
|---|---|
| Single cash transaction > USD 10,000 | File CTR |
| Multiple cash transactions same day, same customer, aggregate > USD 10,000 | File CTR — aggregated |
| Cash purchase of monetary instruments > USD 3,000 (multiple) | Consider aggregation with cash |
| Suspicious activity + reportable cash | File **both** CTR and SAR — SAR does not eliminate CTR |

### 6.2 Currency Conversion

Foreign currency converted at ApexCore daily rate at transaction time. Document rate used on CTR.

### 6.3 Structuring Nexus

If activity appears structured to avoid CTR, file CTR **and** escalate for SAR consideration (`RULE-AML-0101`). Do not advise customer of filing.

---

## 7. Operational Workflow

```
Cash transaction at branch / ATM (ApexCore)
        │
        ├─ System flags if > USD 10,000 or aggregation threshold
        ├─ Teller captures: conductor ID if different from customer
        ├─ Auto-create CTR draft in ApexRegRep
        │
        ├─ End of business day ──► Aggregation batch job
        ├─ Merge same-day CUS- transactions
        │
        ├─ QA review (EMP-400114) — sample 100% for first 30 days new teller
        ├─ BSA Officer sign-off (batch or individual per policy)
        │
        ├─ Assign CTR-######## (e.g. CTR-202607-004821)
        ├─ Submit to FinCEN BSA E-Filing via ApexRegRep
        │
        └─ Store acknowledgement; link to CUS- / ACC- records
```

---

## 8. Regulatory Timelines

| Milestone | Deadline |
|---|---|
| Transaction date | Day 0 |
| CTR preparation complete | T+1 business day |
| FinCEN submission | **T+15 calendar days** (statutory) — Bank target **T+5 business days** |
| QA completion | Before submission |
| Retention | `RET-AML-5Y` from filing date |

Late filing: escalate to BSA Officer and Head of Regulatory Affairs; incident logged in compliance issue tracker.

---

## 9. Quality Assurance

| QA Element | Standard | Owner |
|---|---|---|
| Field completeness | 100% mandatory FinCEN fields | CTR QA |
| TIN validation | SSN/EIN format and mismatch review | Automated + sample |
| Aggregation accuracy | Zero missed same-day aggregates | Daily batch reconciliation |
| Duplicate CTR | Zero duplicate filings same transaction | System control |
| Sample review | 10% monthly random + 100% of amended CTRs | `EMP-400114` |
| Branch error rate | < 0.5% critical field error | Branch Monitoring |

**Control:** `CTL-CMP-030` — CTR timeliness and accuracy.

---

## 10. Exemptions

Phase II exempt person list maintained by BSA Officer; reviewed annually. Exemption does **not** apply to suspicious activity. Document exemption ID on internal record; FinCEN exemption registration current.

---

## 11. Escalation

| Event | Escalate To | Action |
|---|---|---|
| Missed aggregation | BSA Officer | Retrospective CTR within 24 hours |
| System outage > 4 hours | Head of Financial Crime + IT | Manual logging; backfill |
| Customer inquiry about CTR | Branch manager — **do not confirm filing** | Standard script |
| Structuring pattern | AML Investigations | `AML-CASE-` + SAR review |

---

## 12. Examples

### 12.1 Aggregation — Structuring Case (from AML Policy)

`CUS-04928311` / `ACC-8871200456`: four deposits of USD 9,500 over four days. Days 1–4 individually below threshold; day 3 aggregation with prior same-day activity triggers review. Combined activity on 2026-07-18 exceeds USD 10,000 — `CTR-202607-004821` filed. Linked TM alert `ALT-20260718-0044`.

### 12.2 Conductor Identification

Customer sends employee to deposit USD 12,000 cash. Teller captures conductor name, ID type, number, and address on CTR Part III.

---

## 13. Related Documents

`ANB-CMP-POL-0001` · `ANB-CMP-SOP-0004` · `ANB-CMP-SOP-0009` · `ANB-RTL-POL-0001` · `ANB-FIN-SOP-0003` · `ANB-HRM-POL-0008` (branch cash module)

---

## 14. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | R. Kinsella | Initial CTR procedure |

---

## Appendix A — CTR Data Fields (Critical)

Financial institution TIN; customer name and address; SSN/EIN/TIN; account number; transaction date; cash in/out amounts; transaction type codes; conductor if applicable; branch location (`SIT-####`).

## Appendix B — Decision Tree

```
Cash transaction
        │
        ├─ Exempt person with valid exemption? ──YES──► No CTR (still monitor for SAR)
        ├─ Single txn > USD 10,000? ──YES──► CTR
        ├─ Same-day aggregate > USD 10,000? ──YES──► CTR (aggregated)
        └─ Else ──► No CTR; retain transaction record
```

---

**End of Document** — `ANB-CMP-SOP-0007` v1.0
