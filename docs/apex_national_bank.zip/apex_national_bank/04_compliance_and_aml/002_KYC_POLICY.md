# Apex National Bank — Know Your Customer Policy

**Enterprise Policy | Customer Identification, Beneficial Ownership, and Lifecycle Due Diligence**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-POL-0002` |
| **Document Title** | Apex National Bank — Know Your Customer (KYC) Policy |
| **Version** | 1.0 |
| **Owner** | Compliance Department (CMP) — Financial Crime / KYC Operations |
| **Custodian** | Meilin Zhang, Head of KYC Operations (G7) — `EMP-400112` |
| **Approver** | Samuel A. Okonkwo, Chief Compliance Officer (G11) — `EMP-100005` |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Retention** | `RET-POL-10Y` |
| **Taxonomy** | `T6` → `T6.2` KYC/CDD → `POL` |
| **Business Process** | `BP-ONB-CIP`, `BP-ONB-KYC`, `BP-ONB-EDD`, `BP-AML-RISK` |
| **System of Record** | ApexKYC · ApexCore · ApexDocs |
| **Related Documents** | `ANB-CMP-POL-0001` · `ANB-CMP-GDL-0007` · `ANB-CMP-SOP-0006` · `ANB-RTL-POL-0001` · `ANB-CMP-FRM-0003` |

---

## 2. Purpose

KYC is the foundation of the AML programme. Without verified identity, understood beneficial ownership, and a defensible risk rating, transaction monitoring is noise and regulatory reporting is unreliable.

This Policy defines how Apex National Bank identifies customers, verifies identity, establishes beneficial ownership, assigns risk ratings, and maintains relationships through periodic review and trigger-based refresh — across all channels and entities.

---

## 3. Scope

Applies to all new customer relationships, material changes to existing relationships, and periodic refresh. Covers natural persons, legal entities, trusts, partnerships, correspondent banks, and wealth/fiduciary structures.

**Out of scope:** Employee screening (`ANB-HRM-SOP-0007`); vendor onboarding (`ANB-PRC-POL-0002` with CMP overlay).

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | No account opened without completed CIP | 100% `KYC-` records complete before ApexCore booking |
| O-2 | Beneficial ownership captured for all legal entities | 100% BO certification or equivalent |
| O-3 | Risk rating current | ≥ 98% of `CRP-` within refresh SLA |
| O-4 | Trigger events actioned | 100% triggers reviewed within 5 business days |
| O-5 | Data quality | ≥ 99% mandatory fields populated in ApexKYC |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **CIP** | Customer Identification Program — name, DOB/incorporation, address, ID verification |
| **CDD** | Customer Due Diligence — purpose of relationship, expected activity, risk assessment |
| **BO** | Beneficial Owner — ≥ 25% ownership or control of legal entity |
| **Control Person** | Single individual with significant responsibility to control/manage entity |
| **Certifying Person** | Individual authorised to certify BO on FinCEN Form (legal entity customers) |
| **NRA** | Non-Resident Alien — enhanced tax and CDD considerations |
| **Refresh** | Periodic or trigger-driven update of `KYC-` / `CDD-` records |

Entity formats: Appendix A of `ANB-CMP-POL-0001`.

---

## 6. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| CCO | `EMP-100005` | Policy owner; regulatory attestation |
| Head of KYC Operations | `EMP-400112` Meilin Zhang | Operations, ApexKYC, data quality, refresh calendar |
| Head of Financial Crime | `EMP-400101` Adeline Mercier | Risk methodology; EDD standards; escalations |
| BSA Officer | `EMP-400102` Robert Kinsella | BO rule interpretation; FinCEN alignment |
| Retail Compliance | `EMP-400103` Priyanka Iyer | Branch and digital retail onboarding oversight |
| KYC Analysts (G3–G4) | KYC Operations team | Document verification, screening, data entry |
| Relationship Managers (G6+) | CBK/RTL/WAM | Customer information accuracy; EDD cooperation |
| Head of Sanctions | `EMP-400105` Catherine O'Brien | Screening policy alignment |

---

## 7. Policy Statements

**KYC-1.** No customer account is opened, and no material product is activated, until CIP and CDD appropriate to the customer type are complete and approved in ApexKYC.

**KYC-2.** The Bank identifies and verifies the identity of **all** beneficial owners of legal entity customers meeting the 25% threshold, plus one control person, using the FinCEN beneficial ownership form or equivalent (`ANB-CMP-FRM-0003`).

**KYC-3.** Non-face-to-face onboarding requires enhanced identity verification (e.g. document + biometric, or in-person verification within 30 days for high-value digital accounts per `ANB-RTL-POL-0001`).

**KYC-4.** Politically Exposed Persons require EDD under `ANB-CMP-SOP-0006` — never standard CDD alone.

**KYC-5.** Customer information must remain accurate. Material changes must be reported by the customer and are trigger events for refresh.

**KYC-6.** The Bank may not maintain anonymous or numbered accounts without CIP.

**KYC-7.** Reliance on third-party CDD is permitted only under written reliance agreements meeting FFIEC/OCC standards, with annual due diligence on the third party.

**KYC-8.** GDPR/privacy: CDD data is processed on lawful bases documented in the Privacy Policy; SAR-related data is segregated with restricted access.

**KYC-9.** Declined customers are recorded in ApexKYC with reason; re-application requires Head of KYC Operations approval.

**KYC-10.** All KYC records are retained `RET-AML-5Y` minimum after relationship end.

---

## 8. Customer Identification Program (CIP)

### 8.1 Natural Persons

| Element | Requirement | Verification |
|---|---|---|
| Legal name | Full legal name | Government photo ID or digital equivalent |
| Date of birth | Full DOB | ID document |
| Address | Residential address | Utility bill, bank statement, or ID (< 90 days) |
| Tax identifier | SSN/ITIN or foreign equivalent | IRS verification or documentary |
| Identification number | ID number and expiry | Document scan in ApexKYC |

**Acceptable ID:** Passport, driver's licence, state ID, military ID (US); equivalent for non-US per jurisdiction annex.

### 8.2 Legal Entities

| Element | Requirement |
|---|---|
| Legal name and trade names | Certificate of incorporation / formation |
| Address | Registered and principal place of business |
| Registration number | State/country registration |
| BO identification | FinCEN BO form — all ≥ 25% owners and one control person |
| Purpose of account | Documented business purpose |
| Expected activity | Volume, products, geographies |

### 8.3 Trusts and Fiduciary

Trust deed or equivalent; identify settlor, trustees, beneficiaries (named or class), and protectors where applicable. EDD default for private trust structures with cross-border nexus.

---

## 9. Beneficial Ownership

| Rule | Detail |
|---|---|
| Threshold | 25% equity ownership — aggregate indirect ownership through chains |
| Control person | At least one individual with significant management control — even if no 25% owner |
| Exemptions | Publicly traded US companies listed on major exchanges; registered investment companies — per FinCEN rule |
| Certification | Certifying person signs BO certification; refreshed on change or at CDD refresh |
| Reliance | Third-party reliance only with approved agent and annual review |
| Ongoing | Change in BO is a **trigger event** — refresh within 10 business days |

---

## 10. Onboarding Workflow

```
Application (ApexOrigin / ApexKYC / branch)
        │
        ├─ Create CUS-######## (pending) and CRP-########
        ├─ CIP verification (documents + ApexKYC checks)
        ├─ Sanctions / PEP / adverse media (SCR-########, PEP-########)
        ├─ Risk scoring → CR-L / CR-M / CR-H / CR-P
        │
        ├─ CR-P ──► DECLINE
        ├─ CR-H / PEP ──► EDD-######## (ANB-CMP-SOP-0006)
        └─ CR-L / CR-M ──► CDD-######## (ANB-CMP-GDL-0007)
                │
                ├─ Approve in ApexKYC
                ├─ Create KYC-######## master record
                └─ Book account in ApexCore (ApexID triggers if employee-related)
```

**Service levels:** Retail digital — decision within 2 business days; commercial — 5 business days; correspondent — 20 business days.

---

## 11. Periodic Review and Trigger Events

### 11.1 Periodic Refresh

| Risk Rating | Frequency | Owner |
|---|---|---|
| `CR-L` | 36 months | KYC Operations |
| `CR-M` | 24 months | KYC Operations |
| `CR-H` | 12 months | KYC Operations + Financial Crime QA |

Refresh includes: updated BO certification, sanctions/PEP rescreen, activity vs expected profile, risk rating reaffirmation or change.

### 11.2 Trigger Events (Non-Exhaustive)

| Trigger | Action | SLA |
|---|---|---|
| Change of BO or control | Full BO refresh | 10 business days |
| Change of address / legal form | CIP element update | 10 business days |
| Adverse media (material) | Re-rating review | 5 business days |
| TM alert linked to customer | Case review; possible EDD | 5 business days |
| SAR filed on customer | Enhanced monitoring plan | Immediate |
| Significant activity deviation | Re-rating | 10 business days |
| Law enforcement request | Legal + Financial Crime | Immediate |
| Customer request for high-risk product | EDD if not already performed | Before product activation |

---

## 12. Decision Tables

### 12.1 Onboarding Decision

| Profile | CDD Path | Approver |
|---|---|---|
| US retail checking, face-to-face | Standard CDD | KYC Analyst + system rules |
| US retail, digital | Standard CDD + enhanced ID | KYC Analyst |
| SMB / commercial | Standard CDD | KYC Analyst + RM attestation |
| Legal entity, transparent | CDD + BO form | KYC Team Lead (G5+) |
| PEP (domestic) | EDD | Head of KYC Operations |
| PEP (foreign) | EDD | Head of Financial Crime + CCO |
| Correspondent bank | EDD + FCC | CCO |
| MSB / VASP | EDD | Head of Financial Crime |
| Trust (complex) | EDD | Head of Financial Crime |
| Sanctions near-match unresolved | Decline | Head of Sanctions |

### 12.2 Risk Rating Override

| Request | Approver |
|---|---|
| Downgrade CR-H to CR-M | Head of Financial Crime — **rare; documented exception only** |
| Upgrade any rating | KYC Team Lead |
| Assign CR-P (prohibited) | Automatic — no override |

---

## 13. Examples

### 13.1 Retail Digital Onboarding — `CUS-03115590`

Customer applies via ApexMobile for a checking account. ApexKYC creates `KYC-202608-0156`. Document verification passes; `SCR-202608-0156` clear; `PEP-202608-0156` negative; assigned `CR-L`. `CDD-202608-0156` completed with expected activity: payroll deposits, debit card use. Account `ACC-1029384756` booked. Refresh due 2029-08.

### 13.2 Legal Entity — Beneficial Ownership Gap

A Delaware LLC applies for a commercial account. BO form lists one 100% owner — a second LLC. Enhanced BO drill-down required: ultimate natural person BO identified as `CUS-06291004`. `EDD-202609-0044` triggered due to layered structure. `CR-M` assigned with 24-month refresh.

---

## 14. Related Documents

| ID | Title |
|---|---|
| `ANB-CMP-POL-0001` | AML Policy — entity register Appendix A |
| `ANB-CMP-GDL-0007` | CDD Guideline |
| `ANB-CMP-SOP-0006` | EDD Procedure |
| `ANB-CMP-SOP-0005` | Sanctions Screening SOP |
| `ANB-CMP-FRM-0003` | Customer KYC Form |
| `ANB-RTL-POL-0001` | Retail Account Opening Policy |
| `ANB-CBK-POL-0001` | Loan Approval Policy |
| `ANB-ADM-STD-0005` | Metadata Standard — `CUS-` format |
| `ANB-HRM-POL-0008` | Training — KYC certification |
| `ANB-PRC-POL-0002` | Third-Party Risk — introducer due diligence |

---

## 15. Review Cycle

Annual review by Head of KYC Operations with Head of Financial Crime; CCO approval. Interim update on FinCEN CDD rule or BO rule amendments within 60 days.

---

## 16. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 1.0 | 2026-07-28 | M. Zhang | Initial published policy | S. Okonkwo |

---

## 17. Appendices

### Appendix A — KYC Record Minimum Fields (`KYC-########`)

Customer ID, legal name, DOB/incorporation date, tax ID, addresses, ID document references, BO structure (if entity), `CR-*` rating, screening references (`SCR-`, `PEP-`), approver, effective date, next refresh date, linked `CDD-` / `EDD-` IDs.

### Appendix B — Document Retention per Customer Type

| Customer Type | Minimum Documents |
|---|---|
| Natural person retail | ID, proof of address, signature card |
| Legal entity | Formation docs, BO certification, signatory authority, expected activity profile |
| Correspondent | AML programme questionnaire, licensing, Wolfsberg, onsite/remote assessment |
| Trust | Trust deed, trustee IDs, beneficiary schedule |

---

**End of Document** — `ANB-CMP-POL-0002` v1.0 · C2 · Effective 2026-08-01
