# Apex National Bank — Regulatory Reporting Standard Operating Procedure

**Standard Operating Procedure | BSA/AML Regulatory Reporting Calendar, Validation, and Submission**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-SOP-0009` |
| **Document Title** | Regulatory Reporting Standard Operating Procedure |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Regulatory Reporting |
| **Custodian** | Sofia Petrov, Regulatory Reporting Manager — CMP (G6) — `EMP-400115` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-REG-FILE`, `BP-AML-CTR`, `BP-AML-SAR` |
| **System of Record** | ApexRegRep · ApexGuard · ApexCore |
| **Related Documents** | `ANB-CMP-SOP-0004`, `ANB-CMP-SOP-0007`, `ANB-FIN-SOP-0003` |

---

## 2. Purpose

Financial crime regulatory reporting requires accurate, timely submission to FinCEN and other authorities. This SOP defines the reporting calendar, data validation, submission controls, exception management, and coordination between Compliance and Finance for BSA-related filings and cross-domain regulatory data.

---

## 3. Scope

| Report Type | System | Primary Owner |
|---|---|---|
| CTR (FinCEN 112) | ApexRegRep | BSA Officer (`EMP-400102`) |
| SAR (FinCEN 111) | ApexRegRep | BSA Officer |
| OFAC blocking / rejection reports | ApexWatch / manual | Head of Sanctions (`EMP-400105`) |
| 314(a) searches | ApexGuard | BSA Officer |
| UK SAR (NCA) — UK plc | ApexRegRep UK module | UK MLRO delegate |
| EU goAML — Europe SE | Local procedure addendum | `EMP-400108` |
| BSA statistical data to FIN Call Report | ApexRegRep → ApexLedger | `EMP-600106` Farhan Siddiqui |

---

## 4. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Regulatory Reporting Manager — CMP | `EMP-400115` Sofia Petrov | Calendar; submission ops; validation rules |
| BSA Officer | `EMP-400102` Robert Kinsella | CTR/SAR sign-off; FinCEN correspondence |
| Head of Regulatory Affairs | `EMP-400108` James Whitfield | Regulatory change; exam coordination |
| Head of Regulatory Reporting — FIN | `EMP-600106` Farhan Siddiqui | Call Report / Y-9C BSA data reconciliation |
| Head of Sanctions | `EMP-400105` | OFAC reports |
| IT — ApexRegRep | Technology (TEC) | System availability; release management |

---

## 5. Regulatory Reporting Calendar (US — Core)

| Report | Frequency | Statutory Deadline | Bank Target | Owner |
|---|---|---|---|---|
| CTR | Per transaction | T+15 calendar days | T+5 business days | BSA Officer |
| SAR | Per suspicion | T+30 calendar days | T+20 calendar days | BSA Officer |
| Continuing SAR | 90-day review | T+30 from review | T+20 | BSA Officer |
| OFAC blocking report | Per event | 10 business days | T+5 | Head of Sanctions |
| 314(a) FinCEN query | Per request | 14 days | T+10 | BSA Officer |
| BSA data to Call Report | Quarterly | FFIEC filing date | T-5 business days before FIN file | FIN + CMP |

Calendar maintained in ApexRegRep; exported to FCC pack monthly.

---

## 6. Data Validation

### 6.1 Pre-Submission Validation Rules

| Rule ID | Check | Error Action |
|---|---|---|
| `VAL-REG-001` | TIN format valid | Block submit |
| `VAL-REG-002` | Mandatory FinCEN fields populated | Block submit |
| `VAL-REG-003` | No duplicate CTR same txn | Block submit |
| `VAL-REG-004` | SAR narrative ≥ 500 characters | Warning; manager review |
| `VAL-REG-005` | Amount fields reconcile to ApexCore | Block submit |
| `VAL-REG-006` | Customer status not merged/deceased mismatch | Manual review |
| `VAL-REG-007` | Filing institution TIN correct | Block submit |

### 6.2 Two-Person Control

| Step | Performer | Reviewer |
|---|---|---|
| CTR batch preparation | CTR QA (`EMP-400114`) | BSA Officer |
| SAR narrative finalisation | Investigator | BSA Officer + Head of Financial Crime |
| OFAC report | Sanctions Analyst | Head of Sanctions |
| Call Report BSA extract | `EMP-400115` | `EMP-600106` |

5130 credentials: dual custody; access reviewed quarterly.

---

## 7. Submission Controls

```
Report ready in ApexRegRep
        │
        ├─ Automated validation (VAL-REG-*)
        ├─ Manual QA checklist
        ├─ Approver electronic sign-off
        │
        ├─ Submit to FinCEN BSA E-Filing / OFAC portal / NCA
        ├─ Capture acknowledgement ID
        ├─ Assign regulatory ID (CTR-######## / SAR-########)
        │
        └─ Archive PDF + XML; link to CUS- / AML-CASE- / INV-AML-
```

**Control:** `CTL-CMP-080` — regulatory reporting accuracy and timeliness.

Post-submission: no amendment without BSA Officer approval; amendment logged with reason.

---

## 8. Exception Management

| Exception Type | Response |
|---|---|
| Missed deadline | Critical issue; `ISS-CMP-`; CCO notification; voluntary late filing with explanation if permitted |
| FinCEN rejection | Fix within 24 hours; resubmit |
| System outage | Manual FinCEN portal fallback; IT incident ticket |
| Data mismatch FIN vs CMP | `EMP-400115` + `EMP-600106` reconciliation within 3 days |
| Cross-border dual filing | Head of Regulatory Affairs determines lead jurisdiction |

---

## 9. Privacy and GDPR Interaction

SAR and CTR data contain personal data. Transfers to FinCEN/US authorities documented under `REG-AML-008`. UK/EU filings follow local lawful basis schedules. No personal data in non-secure email.

---

## 10. Examples

**Example 1 — CTR Batch:** End of day 2026-07-18 — 847 CTR drafts aggregated. Validation passes except 2 TIN mismatches — corrected. `EMP-400114` QA complete. BSA Officer approves batch. 844 `CTR-202607-#####` submitted; acknowledgements archived.

**Example 2 — SAR Submission:** `SAR-202607-004412` linked to `INV-AML-20260720-0033`. Validation `VAL-REG-004` warning — narrative expanded. Dual approval. FinCEN acknowledgement within 20 days of detection.

**Example 3 — FIN Coordination:** Q2 Call Report — BSA monetary instrument data reconciled between ApexRegRep and `ANB-FIN-STD-0004` GL accounts by `EMP-600106` and `EMP-400115` before FFIEC submission.

---

## 11. Escalation

| Event | Escalate To | Timeline |
|---|---|---|
| Submission failure | BSA Officer + IT | 1 hour |
| Statutory deadline at T-3 | Head of Financial Crime | Same day |
| Material data error post-file | CCO + General Counsel | 24 hours |
| Regulatory enquiry on filing | Head of Regulatory Affairs | Immediate |

---

## 12. Related Documents

`ANB-CMP-POL-0001` · `ANB-CMP-SOP-0004` · `ANB-CMP-SOP-0007` · `ANB-CMP-GDL-0008` · `ANB-FIN-SOP-0003` · `ANB-FIN-STD-0004` · `ANB-ADM-POL-0001`

---

## 13. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | S. Petrov | Initial regulatory reporting SOP |

---

## Appendix A — Pre-Submission Checklist (SAR)

- [ ] Linked `AML-CASE-` / `INV-AML-` complete
- [ ] Typology coded
- [ ] All relevant accounts included
- [ ] Prior SAR reference if continuing
- [ ] No tipping-off in narrative
- [ ] BSA Officer approval recorded
- [ ] Acknowledgement slot reserved for `SAR-########`

## Appendix B — Regulatory Obligation Map

| ID | Obligation |
|---|---|
| `REG-AML-003` | CTR |
| `REG-AML-004` | SAR |
| `REG-AML-005` | OFAC reporting |
| `REG-AML-006` | Record retention post-filing |

---

**End of Document** — `ANB-CMP-SOP-0009` v1.0
