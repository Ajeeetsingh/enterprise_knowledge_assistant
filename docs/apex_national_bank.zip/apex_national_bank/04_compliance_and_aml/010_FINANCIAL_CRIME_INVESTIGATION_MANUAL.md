# Apex National Bank — Financial Crime Investigation Manual

**Investigation Manual | Lifecycle, Evidence, Interviews, Documentation, and Closure**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-MAN-0001` |
| **Document Title** | Financial Crime Investigation Manual |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — AML Investigations |
| **Custodian** | Trevor Walsh, AML Investigations Manager (G7) — `EMP-400109` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C3) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-AML-INV`, `BP-AML-SAR` |
| **System of Record** | ApexGuard · ApexDocs |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-SOP-0004`, `ANB-CMP-SOP-0005` |

---

## 2. Purpose

This Manual is the operational reference for AML and financial crime investigators conducting case work from alert referral through closure. It defines the investigation lifecycle, evidence handling, interview guidance, case documentation standards, root cause analysis, and lessons learned — supporting defensible SAR and no-SAR decisions.

---

## 3. Scope

Applies to all `AML-CASE-########` and `INV-AML-########` work performed by Financial Crime Investigations and designated senior analysts. Fraud investigations (`EMP-400106`) coordinate on typology overlap but maintain separate case IDs unless merged by manager approval.

---

## 4. Investigation Lifecycle

```
INTAKE
  │  Sources: ALT-########, ApexServe referral, 314(a), LE subpoena,
  │           sanctions escalation, employee report, counterparty SAR notice
  │
  ├─ Create AML-CASE-######## (ST-NEW)
  ├─ Assign investigator within 4 business hours (ST-ASSIGNED)
  │
PLANNING
  ├─ Scope: customer CUS- / accounts ACC- / period / typology hypothesis
  ├─ Investigation plan in ApexGuard (objectives, sources, timeline)
  │
EVIDENCE GATHERING
  ├─ Internal: ApexCore transactions, CDD KYC-/CDD-/EDD-, prior cases
  ├─ External: corporate registries, adverse media, counterparty banks (314(b))
  ├─ Open INV-AML-######## when complexity warrants separate workbook
  │
ANALYSIS
  ├─ Apply typology indicators (AML Policy §12)
  ├─ Document innocent explanation testing
  │
DECISION
  ├─ SAR recommendation ──► ST-PEND-MLRO (ANB-CMP-SOP-0004)
  ├─ No-SAR ──► ST-NO-SAR with dual approval
  ├─ Law enforcement ──► ST-ESC-LAW
  └─ Account action: restrict / exit (no tipping off)
  │
CLOSURE
  ├─ ST-CLOSED or ST-SAR-FILED
  ├─ Root cause analysis (if control failure)
  └─ Lessons learned to FCC if thematic
```

**Target durations:** Standard case 30 days; complex (correspondent, TBML, multi-jurisdiction) 60 days; TF/sanctions 15 days decision gate.

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| AML Investigations Manager | `EMP-400109` Trevor Walsh | Assignment; quality; closure approval |
| Senior AML Investigator | `EMP-400110` Elena Vasquez-Kim | Complex cases; mentor |
| Financial Crime Analyst | `EMP-400111` Marcus Lindholm | Alert triage; standard investigations |
| BSA Officer | `EMP-400102` Robert Kinsella | SAR filing; LE liaison |
| Head of Financial Crime | `EMP-400101` Adeline Mercier | Resource; FCC escalations |
| General Counsel | `EMP-100006` Margaret Sullivan | Privilege; subpoenas |
| Relationship Managers | Business lines | **Do not** interview customer on suspicion |

---

## 6. Evidence Handling

### 6.1 Principles

| Principle | Requirement |
|---|---|
| Integrity | No alteration of source records; screenshots timestamped |
| Provenance | Document source system and extraction date |
| Classification | C3 for SAR workpapers; access restricted |
| Retention | `RET-AML-5Y`; SAR material indefinite while reopen possible |
| Chain of custody | External documents logged in case file index |

### 6.2 Evidence Types

| Type | Source | Storage |
|---|---|---|
| Transaction records | ApexCore | ApexGuard attach + reference ID |
| CDD package | ApexKYC | Link `KYC-`, `CDD-`, `EDD-` |
| Screening | ApexWatch | `SCR-`, `PEP-` |
| Communications | Internal email (not customer) | ApexDocs case folder |
| External OSINT | Licensed databases | PDF export with search parameters |
| LE materials | Subpoena / 314(b) | Legal custody |

### 6.3 Prohibited Actions

- Do not interview the customer or third parties about suspicious activity without Legal approval
- Do not notify customer of SAR consideration (tipping off)
- Do not delete alerts or cases to manage backlog
- Do not run ad-hoc SQL against production without data governance approval

---

## 7. Interview Guidance

### 7.1 Internal Interviews

| Subject | When | Conducted By |
|---|---|---|
| Branch teller / CSR | Cash or referral cases | Investigator |
| Relationship Manager | Commercial activity context | Investigator — **no accusatory framing** |
| Operations staff | Wire processing anomalies | Investigator |

Document: date, participants, questions, answers (factual). Store in case file C2 unless SAR — then C3.

### 7.2 Customer / External Interviews

**Default: do not conduct** without General Counsel written approval. If approved (e.g. exit interview unrelated to SAR disclosure):

- Use approved script — no reference to investigation or SAR
- Two bank staff present
- No recording without consent where required by law

### 7.3 Law Enforcement

All LE contact through BSA Officer + General Counsel. Document contact reference in `ST-ESC-LAW` cases without compromising ongoing investigation.

---

## 8. Case Documentation Standards

### 8.1 Minimum Case File Contents

| Section | Content |
|---|---|
| Executive summary | 1 page — customer, allegation, outcome |
| Customer profile | `CUS-`, `CRP-`, `CR-*`, products, RM |
| Alert / referral | `ALT-` or ticket ID; rule `RULE-AML-####` |
| Timeline | Chronological facts |
| Transaction analysis | Tables; counterparty analysis |
| Typology assessment | Structured / layering / mule / etc. |
| Innocent explanation | Tested and rejected or accepted |
| CDD review | Adequacy of onboarding |
| Conclusion | SAR / no-SAR / escalate |
| Approvals | Sign-off chain |

### 8.2 Naming Convention

Per `ANB-ADM-STD-0007`: `AMLC_AML-CASE-20260718-0091_InvestigationSummary_20260725_C3.pdf`

---

## 9. Typology Investigation Playbooks (Summary)

| Typology | Key Steps | Related Rules |
|---|---|---|
| **Structuring** | CTR history; branch pattern; conductor analysis | `RULE-AML-0101` |
| **Smurfing** | Multiple depositors; common beneficiary | `RULE-AML-0102` |
| **Layering** | Velocity; pass-through; unrelated counterparties | `RULE-AML-0201` |
| **Mule accounts** | Dormant reactivation; young holder; remote deposit | `RULE-AML-0401` |
| **TBML** | Invoice vs shipment value; related party trade | `RULE-AML-0301` |
| **Sanctions evasion** | Triangulation; non-SDN intermediaries | `BP-SAN-ESC` |
| **Crypto exposure** | VASP flows; blockchain analytics if licensed | EDD + specialist consult |
| **PEP corruption** | SOW vs activity; public salary benchmarks | `PEP-` review |

Full playbooks in ApexDocs typology library — FCC quarterly update.

---

## 10. Root Cause Analysis

Required when investigation reveals **control failure**:

| RCA Element | Question |
|---|---|
| What happened | Factual finding |
| Why | People / process / system / external |
| Control gap | Which `CTL-CMP-` failed |
| Impact | Customers affected; reporting impact |
| Remediation | Owner; `ISS-CMP-` link |
| Retest date | Compliance Testing |

Example: missed EDD on layered LLC — root cause: KYC analyst bypassed score threshold. Remediation: ApexKYC hard stop; retraining.

---

## 11. Closure and Lessons Learned

### 11.1 Closure Checklist

- [ ] All evidence attached or linked
- [ ] Typology coded
- [ ] SAR filed OR no-SAR rationale approved
- [ ] Account disposition documented
- [ ] Continuing activity SAR calendar if applicable
- [ ] Status `ST-CLOSED` or `ST-SAR-FILED`
- [ ] QA sample pool updated

### 11.2 Lessons Learned

Thematic findings (≥ 3 similar cases in quarter) → FCC briefing by Investigations Manager. May trigger rule tuning, training update (`ANB-HRM-POL-0008`), or policy amendment proposal.

---

## 12. Escalation Paths

| Trigger | Escalate | Timeline |
|---|---|---|
| TF indicator | BSA Officer + CCO | Same day |
| Insider employee | General Counsel | Immediate |
| > USD 10M exposure | Head of Financial Crime | 24 hours |
| Media enquiry | CCO | Same day |
| 30-day SAR clock | AML Investigations Manager | T-10 days |
| Privilege question | General Counsel | Before external share |

---

## 13. Examples

### 13.1 Full Investigation — Structuring (Canonical)

| Field | Value |
|---|---|
| Case | `AML-CASE-20260718-0091` |
| Investigation | `INV-AML-20260720-0033` |
| Customer | `CUS-04928311` / `ACC-8871200456` |
| Alert | `ALT-20260718-0044` / `RULE-AML-0101` |
| Investigator | `EMP-400111` Marcus Lindholm |
| Finding | Patterned sub-CTR deposits; no business rationale |
| Outcome | `SAR-202607-004412`; account restricted |
| Status | `ST-SAR-FILED` |

### 13.2 Complex — Layered Shell Structure

`CUS-06291004` receives wires from three LLCs with common registered agent. `INV-AML-202608-0055` opened. Corporate registry drill-down; EDD `EDD-202608-0012` reviewed — BO opacity noted at onboarding. Layering typology substantiated. SAR filed; relationship exit approved by Head of Financial Crime.

### 13.3 No-SAR — Documented Rationale

Seasonal business explains cash spike; CDD expected activity updated; alert `ALT-202608-0200` closed no-SAR with RM invoice evidence. Approved by `EMP-400109` and `EMP-400102`.

---

## 14. Related Documents

| ID | Title |
|---|---|
| `ANB-CMP-POL-0001` | AML Policy — entity register Appendix A |
| `ANB-CMP-SOP-0004` | SAR Procedure |
| `ANB-CMP-SOP-0007` | CTR Procedure |
| `ANB-CMP-SOP-0005` | Sanctions Screening SOP |
| `ANB-CMP-SOP-0006` | EDD Procedure |
| `ANB-CMP-GDL-0008` | Compliance Monitoring Guide |
| `ANB-HRM-POL-0004` | Code of Conduct — confidentiality |
| `ANB-ADM-STD-0007` | Document Naming Standard |
| `ANB-ADM-POL-0001` | Records Retention |

---

## 15. Review Cycle

Annual review by AML Investigations Manager; interim update on FinCEN guidance or major examination finding within 45 days.

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | T. Walsh | Initial investigation manual |

---

## Appendix A — Investigation Plan Template

1. Case ID / Investigation ID  
2. Customer and accounts  
3. Hypothesis / typology  
4. Scope (date range, products)  
5. Evidence sources list  
6. Milestones and target dates  
7. Resource requirements  
8. SAR clock start date  

## Appendix B — Case Status Codes (Reference)

`ST-NEW` · `ST-ASSIGNED` · `ST-PEND-INFO` · `ST-PEND-MLRO` · `ST-SAR-FILED` · `ST-NO-SAR` · `ST-ESC-LEGAL` · `ST-ESC-LAW` · `ST-CLOSED` · `ST-REOPEN`

## Appendix C — Cross-Domain Future Use

Investigation records support: mortgage fraud review (`ANB-CBK-POL-0001`); corporate onboarding exit; internal audit thematics; regulatory examination sampling; customer complaint triage where financial crime nexus; vendor due diligence (`ANB-PRC-POL-0002`).

---

**End of Document** — `ANB-CMP-MAN-0001` v1.0 · C3
