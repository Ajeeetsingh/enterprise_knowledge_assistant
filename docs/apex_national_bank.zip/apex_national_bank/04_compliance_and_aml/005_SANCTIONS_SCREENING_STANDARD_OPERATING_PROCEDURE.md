# Apex National Bank — Sanctions Screening Standard Operating Procedure

**Standard Operating Procedure | OFAC/FATF Screening, False Positive Handling, and Watchlist Maintenance**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-SOP-0005` |
| **Document Title** | Sanctions Screening Standard Operating Procedure |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Sanctions |
| **Custodian** | Catherine O'Brien, Head of Sanctions (G8) — `EMP-400105` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SAN-SCRN`, `BP-SAN-ESC`, `BP-SAN-WL` |
| **System of Record** | ApexWatch · ApexKYC · ApexPay · ApexGuard |
| **Parent Policy** | `ANB-CMP-POL-0005` Sanctions & OFAC Screening Policy |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-POL-0002`, `ANB-CMP-SOP-0006` |

---

## 2. Purpose

Sanctions compliance is zero-tolerance: the Bank must not process transactions involving sanctioned parties, comprehensively sanctioned jurisdictions (without licence), or designated entities. This SOP operationalises real-time and batch screening, false positive resolution, escalation, watchlist maintenance, and audit evidence for `SCR-########` and `WL-########` records.

---

## 3. Scope

| Screening Point | System | Timing |
|---|---|---|
| Customer onboarding | ApexKYC / ApexWatch | Pre-account opening |
| Periodic refresh | ApexKYC | At CDD/EDD refresh |
| Payment initiation (wires, ACH, SWIFT) | ApexPay / ApexWatch | Real-time — block before release |
| Trade finance / documentary credits | ApexTrade | Pre-issuance |
| TM alert enrichment | ApexGuard | Batch daily |
| Employee / vendor (HR/PRC overlay) | ApexWatch | Onboarding + daily delta |

Geographies: US OFAC; UK HMT; EU consolidated list; UN Security Council; local lists per entity (`EMP-400108` maintains annex).

---

## 4. Definitions

| Term | Definition |
|---|---|
| **True Hit** | Confirmed match to sanctioned or designated party — block/reject/report |
| **False Positive** | Name/identifier similarity without identity match — documented clearance |
| **Near Match** | Partial match requiring analyst review before clearance |
| **SDN** | OFAC Specially Designated Nationals and Blocked Persons List |
| **50% Rule** | Entity owned 50%+ in aggregate by SDN(s) is blocked |
| **Screening Record** | `SCR-########` — audit trail of each screening event |

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Head of Sanctions | `EMP-400105` Catherine O'Brien | Programme; OFAC reporting; list governance |
| Sanctions Analysts | `EMP-400113` Aisha Mensah (lead) | Hit review; false positive disposition |
| KYC Operations | `EMP-400112` Meilin Zhang | Onboarding screening quality |
| Payments Operations | Treasury (TRY) | Wire hold/release per sanctions decision |
| BSA Officer | `EMP-400102` Robert Kinsella | SAR coordination on sanctions evasion |
| CCO | `EMP-100005` | Material true hit notification; licence applications |

---

## 6. Screening Workflow

### 6.1 Onboarding / Refresh

```
Customer data entered in ApexKYC
        │
        ├─ ApexWatch batch: name, alias, DOB, ID, address, country
        ├─ Generate SCR-######## (timestamp, lists version, algorithm version)
        │
        ├─ NO HIT ──► Clear; attach SCR- to KYC-########
        │
        └─ HIT / NEAR MATCH
                ├─ Auto-hold onboarding (ST-PEND-INFO)
                ├─ Assign to Sanctions Analyst (G3+)
                ├─ Review: identifiers, geography, vessel/IMO (if applicable)
                │
                ├─ FALSE POSITIVE ──► Document rationale; link WL- reference; clear
                ├─ TRUE HIT ──► DECLINE / block; BP-SAN-ESC; OFAC report if required
                └─ UNRESOLVED > 24h ──► Escalate Head of Sanctions
```

### 6.2 Payment Screening

```
Wire / payment instruction received (ApexPay)
        │
        ├─ Real-time screen: originator, beneficiary, bank BIC, narrative, country
        ├─ SCR-######## created per payment
        │
        ├─ CLEAR ──► Release
        ├─ HOLD ──► Sanctions queue; customer NOT informed of SAR/sanctions reason
        └─ REJECT ──► Return funds; log; true hit workflow
```

**SLA:** Real-time screening decision within **15 minutes** for automated clear; held items within **4 business hours**.

---

## 7. False Positive Handling

### 7.1 Analyst Disposition Checklist

| Step | Requirement |
|---|---|
| 1 | Compare full legal name, aliases, DOB/incorporation, nationality, ID |
| 2 | Review address and known identifiers (passport, LEI, vessel IMO) |
| 3 | Check gender / entity type mismatch |
| 4 | Document rationale in SCR- record (minimum 50 characters substantive) |
| 5 | Second review for any amount > USD 50,000 or correspondent payment |
| 6 | Never clear based on RM verbal assurance alone |

### 7.2 False Positive Rate Monitoring

Target: < 85% of onboarding hits cleared as false positive (industry benchmark). Sustained rate > 92% triggers tuning review with `EMP-400107` Compliance Testing — not unilateral threshold loosening.

---

## 8. Escalation — True Hit and Sanctions Evasion

| Scenario | Action | Report |
|---|---|---|
| SDN customer match | Block account; reject payments | OFAC blocking report within 10 business days |
| 50% rule entity | Block; legal review | OFAC if not previously reported |
| Sanctions evasion pattern (triangulation) | Open `AML-CASE-`; `INV-AML-` | SAR via `ANB-CMP-SOP-0004` |
| Maritime / AIS gap (trade) | Hold shipment docs; escalate | Head of Sanctions + Trade Compliance |
| Licence required transaction | CCO + Legal | OFAC licence application |

**BP-SAN-ESC** escalation path: Analyst → Head of Sanctions → CCO → General Counsel (within 1 hour for confirmed SDN payment attempt).

---

## 9. Watchlist Maintenance

| Activity | Frequency | Owner |
|---|---|---|
| OFAC / HMT / EU list ingestion | Daily automated + manual QA | ApexWatch ops |
| Internal watchlist (`WL-########`) updates | As needed — FCC approval for additions | Head of Sanctions |
| Algorithm / fuzzy match threshold change | Change control — CCO approval | Head of Sanctions + `CTL-CMP-010` |
| List version audit | Monthly | `EMP-400107` |
| Screening replay (lookback) | On major list update | Sanctions team |

**Watchlist record format:** `WL-OFAC-SDN-12844`, `WL-HMT-2026-004521`, `WL-INT-2026-0012` (internal).

---

## 10. Audit Evidence

Each `SCR-########` must retain:

- Input data snapshot (hashed where C3)
- List versions (OFAC publish date, etc.)
- Match score and matched `WL-` ID
- Analyst ID and disposition timestamp
- Escalation notes if applicable
- Payment reference (if wire)

Retention: `RET-AML-5Y`. Exam pack export via ApexDocs quarterly.

---

## 11. Decision Tree — Hit Disposition

```
Screening hit generated
        │
        ├─ Exact ID match (SSN/EIN/passport/IMO)? ──YES──► TRUE HIT
        │
        ├─ Name + DOB + country match? ──YES──► TRUE HIT (unless proven alias error)
        │
        ├─ Name only; common name; mismatched DOB ──► FALSE POSITIVE (documented)
        │
        ├─ Vessel / aircraft without IMO tail match ──► Escalate
        │
        └─ Correspondent bank BIC on list ──► TRUE HIT — reject all payments
```

---

## 12. Examples

### 12.1 False Positive — Common Name

Onboarding for `CUS-03115590` triggers hit on "Mohammed Ali" SDN entry. Analyst compares DOB (1985 vs 1972), nationality (US vs Syria), and passport number — no match. `SCR-202608-0156` disposition: false positive. Onboarding continues.

### 12.2 True Hit — Payment Rejection

Outbound wire to beneficiary matching SDN `WL-OFAC-SDN-12844`. ApexPay auto-holds. `SCR-202609-0441` confirmed true hit. Payment rejected; `REG-AML-005` blocking report initiated; account `ACC-8871200456` blocked. SAR consideration by BSA Officer.

---

## 13. Related Documents

`ANB-CMP-POL-0001` · `ANB-CMP-POL-0005` · `ANB-CMP-POL-0002` · `ANB-CMP-SOP-0004` · `ANB-CMP-SOP-0006` · `ANB-ADM-POL-0001` · `ANB-PRC-POL-0002` · `ANB-HRM-POL-0008` (sanctions training module E-5)

---

## 14. Review Cycle

Semi-annual procedural review; immediate update on OFAC enforcement action affecting screening logic.

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | C. O'Brien | Initial SOP implementing POL-0005 |

---

## Appendix A — Control Mapping

| Control | Description |
|---|---|
| `CTL-CMP-010` | Sanctions screening — 100% in-scope parties/transactions |
| `REG-AML-005` | OFAC sanctions compliance |

---

**End of Document** — `ANB-CMP-SOP-0005` v1.0
