# Apex National Bank — Suspicious Activity Report Procedure

**Standard Operating Procedure | Alert Handling, Investigation, Filing, and Confidentiality**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-SOP-0004` |
| **Document Title** | Suspicious Activity Report Procedure |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Financial Crime |
| **Custodian** | Robert Kinsella, BSA Officer (G8) — `EMP-400102` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C3) — SAR material |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-AML-SAR`, `BP-AML-TM`, `BP-AML-INV` |
| **System of Record** | ApexGuard · ApexRegRep · ApexDocs |
| **Regulatory Obligation** | `REG-AML-004` — 31 CFR 1020.320 |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-MAN-0001`, `ANB-CMP-SOP-0007` |

---

## 2. Purpose

When the Bank knows, suspects, or has reason to suspect that a transaction involves illicit funds, is designed to evade BSA requirements, or has no lawful purpose, it must file a Suspicious Activity Report with FinCEN. This Procedure governs alert disposition, investigation, filing criteria, confidentiality (no tipping off), and case closure for `SAR-########` records.

---

## 3. Scope

All customer types, products, and channels. Applies to:

- Transaction monitoring alerts (`ALT-########`)
- Employee referrals (ApexServe)
- Law enforcement requests
- 314(a) searches
- Counterparty bank SAR notifications
- Sanctions evasion investigations with ML nexus

---

## 4. Definitions

| Term | Definition |
|---|---|
| **SAR** | Suspicious Activity Report — FinCEN Form 111 — `SAR-########` |
| **Continuing Activity SAR** | Subsequent SAR on same activity pattern — 90-day review cycle |
| **No-SAR** | Investigation closed without filing — documented rationale required |
| **Tipping Off** | Disclosing SAR existence or investigation — **prohibited** |
| **5130 Account** | FinCEN BSA E-Filing credentials — restricted access |
| **MLRO / BSA Officer** | Filing authority — `EMP-400102` |

---

## 5. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| BSA Officer | `EMP-400102` Robert Kinsella | SAR filing; FinCEN liaison; 314(a)/(b) |
| Head of Financial Crime | `EMP-400101` Adeline Mercier | SAR quality review; FCC reporting |
| AML Investigations Manager | `EMP-400109` Trevor Walsh | Case assignment; closure quality |
| Senior Investigator | `EMP-400110` Elena Vasquez-Kim | Complex investigations |
| Financial Crime Analyst | `EMP-400111` Marcus Lindholm | Alert disposition; case support |
| General Counsel | `EMP-100006` Margaret Sullivan | Subpoenas; privilege; law enforcement |

---

## 6. Alert Handling Workflow

```
Alert ALT-######## generated (ApexGuard) OR referral received
        │
        ├─ Assign analyst within 4 business hours
        ├─ Status: ST-ASSIGNED
        │
        ├─ Initial review (24–48 hours)
        │       ├─ False positive ──► Close alert; document; tune rule if appropriate
        │       └─ Inconclusive / concern ──► Open AML-CASE-########
        │
        ├─ AML-CASE investigation
        │       ├─ Gather: transactions, CDD, open source, internal history
        │       ├─ INV-AML-######## if substantiated or complex
        │       │
        │       ├─ SAR required ──► ST-PEND-MLRO
        │       └─ No SAR ──► ST-NO-SAR (dual approval §9)
        │
        └─ Post-filing: ST-SAR-FILED; continuing activity calendar
```

**SLA:** Initial alert touch — 1 business day; case decision target — 30 days (60 for complex).

---

## 7. Investigation Workflow

Detailed investigation standards in `ANB-CMP-MAN-0001`. Minimum case file contents:

| Element | Required |
|---|---|
| Customer profile snapshot | `CRP-`, `CR-*`, `KYC-` |
| Alert / referral source | `ALT-` or ApexServe ID |
| Transaction narrative | 90-day minimum; 180-day for complex |
| Typology classification | Per AML Policy §12 |
| CDD/EDD review | Current `CDD-` / `EDD-` |
| Screening refresh | `SCR-`, `PEP-` |
| Investigator conclusion | SAR / No-SAR / escalate |
| Approver signatures | Per §9 |

---

## 8. Filing Criteria

File SAR when **any** of the following apply (non-exhaustive):

| Category | Examples |
|---|---|
| **Structuring / evasion** | Pattern below CTR threshold; smurfing |
| **No business purpose** | Layering; rapid pass-through |
| **Insider / employee** | Employee complicit in unusual activity |
| **TF / sanctions evasion** | Conflict zone flows; SDN circumvention |
| **Fraud proceeds** | Known or suspected fraud deposits |
| **Identity fraud** | Account opened with false ID |
| **PEP corruption nexus** | Unexplained wealth inconsistent with SOW |
| **Law enforcement** | Subpoena + corroborating suspicion |

**Amount:** No minimum dollar threshold for SAR — suspicion drives filing.

**Do not file duplicate SAR** for identical activity unless continuing activity SAR required.

---

## 9. Approval Workflow

| Decision | Primary Approver | Second Approver |
|---|---|---|
| SAR filing | BSA Officer (G8) | Head of Financial Crime (G9) review |
| No-SAR closure (substantiated investigation) | AML Investigations Manager (G7) | BSA Officer concurrence |
| No-SAR closure (inconclusive, low risk) | Senior Investigator (G6+) | AML Investigations Manager |
| Escalation to Law Enforcement | BSA Officer + General Counsel | CCO notified |
| Account exit post-SAR | Head of Financial Crime | Legal review |

---

## 10. Filing and Timelines

| Milestone | Deadline |
|---|---|
| Suspicion identified | Clock starts |
| FinCEN SAR submission | **30 calendar days** from initial detection — target **20 days** |
| Continuing activity review | Every 90 days while activity continues |
| Retention | `RET-AML-5Y` (SAR workbook C3 indefinitely while reopen possible) |

Submission via FinCEN BSA E-Filing through ApexRegRep; assign `SAR-########` upon acceptance.

---

## 11. Confidentiality

| Rule | Detail |
|---|---|
| SAR access | Role-restricted in ApexGuard — need-to-know |
| Customer notification | **Never** disclose SAR filed or under consideration |
| Employee queries | Direct to Compliance — no discussion with subject |
| Audit / exam | Secure exam room; C3 handling |
| Media | CCO + Group Communications only |
| Penalties | Federal offence; bank termination (`ANB-HRM-POL-0004`) |

314(b) voluntary sharing with other financial institutions — BSA Officer approval only.

---

## 12. Case Closure

| Closure Type | Status | Requirements |
|---|---|---|
| SAR filed | `ST-SAR-FILED` | SAR acknowledgement; monitoring plan |
| No SAR | `ST-NO-SAR` | Written rationale; approvers; retain 5 years |
| Law enforcement adopted | `ST-ESC-LAW` | Document LE contact reference |
| Account exited | `ST-CLOSED` | Exit documentation; no tipping off |
| Reopen | `ST-REOPEN` | New facts — new investigation ID |

---

## 13. Examples

### 13.1 Structuring SAR (Canonical)

`INV-AML-20260720-0033` on `CUS-04928311`: four sub-threshold deposits, no business rationale, prior profile inconsistent with cash intensity. BSA Officer files `SAR-202607-004412`. Account restricted. Continuing activity SAR scheduled 2026-10.

### 13.2 No-SAR — False Positive with Explanation

Wire alert `ALT-202608-0122` to UAE — matches `RULE-AML-0501`. Investigation confirms documented trade invoice in ApexTrade; activity consistent with `CDD-20260701-0088`. No-SAR closure approved by `EMP-400109` and `EMP-400102`.

---

## 14. Escalation Paths

| Situation | Escalate | Timeline |
|---|---|---|
| Potential TF | BSA Officer + CCO | Same day |
| Insider involvement | General Counsel | Immediate |
| 30-day deadline at risk | Head of Financial Crime | T-5 days |
| Customer lawsuit threat | General Counsel | Same day |
| Cross-border STR conflict | Head of Regulatory Affairs | 3 days |

---

## 15. Related Documents

Full compliance ecosystem per `ANB-CMP-POL-0001` §16. Critical: `ANB-CMP-MAN-0001`, `ANB-CMP-SOP-0007`, `ANB-CMP-SOP-0005`, `ANB-HRM-POL-0004`, `ANB-LEG-REF-0003` (FCC)

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | R. Kinsella | Initial SAR procedure |

---

## Appendix A — SAR Narrative Template (Outline)

1. Subject identification (name, TIN, accounts — no tipping off in external comms)
2. Period of activity
3. Summary of suspicious activity (who, what, when, where, how much)
4. Why suspicious — typology and red flags
5. Prior SAR history if any
6. Law enforcement contact if any
7. Action taken (restrict, exit, none)

## Appendix B — Case Status Flow

`ST-NEW` → `ST-ASSIGNED` → (`ST-PEND-INFO`) → `ST-PEND-MLRO` → `ST-SAR-FILED` | `ST-NO-SAR` → `ST-CLOSED`

---

**End of Document** — `ANB-CMP-SOP-0004` v1.0 · C3
