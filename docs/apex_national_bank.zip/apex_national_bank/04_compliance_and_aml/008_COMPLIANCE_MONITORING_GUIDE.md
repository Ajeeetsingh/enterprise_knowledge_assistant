# Apex National Bank — Compliance Monitoring Guide

**Compliance Guide | Monitoring Programme, Control Testing, Issue Tracking, and KPI/KRI Framework**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-GDL-0008` |
| **Document Title** | Compliance Monitoring Guide |
| **Version** | 1.0 |
| **Owner** | Compliance (CMP) — Compliance Testing |
| **Custodian** | Isabelle Fontaine, Head of Compliance Testing (G8) — `EMP-400107` |
| **Approver** | Samuel A. Okonkwo, CCO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-REG-MON`, `BP-AML-RISK` |
| **System of Record** | ApexAudit · ApexGuard · ApexDocs |
| **Related Documents** | `ANB-CMP-POL-0001`, `ANB-CMP-SOP-0004`, `ANB-CMP-SOP-0009` |

---

## 2. Purpose

Independent monitoring and testing provide assurance that the AML/BSA programme operates as designed. This Guide defines the annual monitoring programme, sampling methodology, control testing, issue tracking, remediation, and the KPI/KRI framework reported to FCC and Board committees.

---

## 3. Scope

| Domain | Controls | Owner |
|---|---|---|
| AML / BSA | `CTL-CMP-001` through `CTL-CMP-040` | Compliance Testing |
| Sanctions | `CTL-CMP-010` | Compliance Testing + Sanctions QA |
| CTR / SAR | `CTL-CMP-030`, `CTL-CMP-031` | Compliance Testing |
| KYC / CDD / EDD | `CTL-CMP-002`, `CTL-CMP-003`, `CTL-CMP-050` | Compliance Testing |
| Regulatory reporting data | `CTL-CMP-080` | Compliance Testing + FIN liaison |
| Training | `CTL-CMP-060` | Compliance Testing + HR |

Internal Audit (IAD) maintains separate plan — coordinated to avoid duplication.

---

## 4. Monitoring Programme Structure

### 4.1 Annual Plan

| Quarter | Focus | Deliverable |
|---|---|---|
| Q1 | KYC/CDD sampling; onboarding timeliness | Monitoring report to FCC |
| Q2 | TM alert quality; sanctions false positive rate | Thematic review |
| Q3 | SAR/CTR timeliness; investigation file quality | Exam readiness pack |
| Q4 | Full programme effectiveness; KPI annual summary | Board PRCC appendix |

Plan approved by Head of Compliance Testing and Head of Financial Crime by **31 January** each year.

### 4.2 Risk-Based Prioritisation

Higher sampling on:

- `CR-H` and PEP populations
- Branches with elevated CTR errors (`SIT-0412` network monitored)
- New products (ApexPay cross-border launch)
- Prior examination findings
- High alert volume rules (`RULE-AML-0101`, `RULE-AML-0401`)

---

## 5. Sampling Methodology

| Population | Sample Size | Method |
|---|---|---|
| Retail onboarding files | 5% per quarter (min 50) | Random stratified by channel |
| Commercial / EDD files | 100% of new correspondent; 25% other EDD | Risk-based |
| TM alert dispositions | 10% closed alerts | Random + all > USD 100k |
| SAR investigations | 100% filed SARs; 15% no-SAR closures | Mandatory full review on SARs |
| CTR filings | 10% monthly + 100% late filings | Random |
| Sanctions dispositions | 5% false positives; 100% true hits | Risk-based |
| Training completion | 100% role-based overdue | System extract |

Sample sizes increase 2x for any control rated "Needs Improvement" in prior quarter.

---

## 6. Control Testing

### 6.1 Test Procedure (Standard)

1. **Design effectiveness** — control documented and aligned to `REG-AML-###`
2. **Operating effectiveness** — sample evidence matches procedure
3. **Exception classification** — Critical / High / Medium / Low
4. **Root cause** — people, process, system, external
5. **Remediation** — action owner, due date, retest

### 6.2 Control Register (Extract)

| Control ID | Test Frequency | Pass Criteria |
|---|---|---|
| `CTL-CMP-001` | Quarterly | 100% onboarding with CIP before account active |
| `CTL-CMP-002` | Quarterly | CDD complete per `ANB-CMP-GDL-0007` |
| `CTL-CMP-010` | Monthly | 100% payments screened before release |
| `CTL-CMP-020` | Monthly | TM coverage ≥ 99.5% transactions |
| `CTL-CMP-030` | Monthly | CTR filed within 5 business days (target) |
| `CTL-CMP-031` | Monthly | SAR within 20-day target |
| `CTL-CMP-040` | Quarterly | Investigation files complete per Manual |
| `CTL-CMP-070` | Annual | Monitoring plan executed ≥ 95% |

Evidence retained `RET-AUD-7Y` in ApexAudit.

---

## 7. Issue Tracking

| Severity | Definition | Escalation | Remediation SLA |
|---|---|---|---|
| **Critical** | Regulatory report missed; sanctions true hit processed; SAR tipping off | CCO + Board notification | 5 business days |
| **High** | Systemic CDD gap; TM rule down > 24h | FCC | 15 business days |
| **Medium** | Sample error rate > 5% | Head of Financial Crime | 30 business days |
| **Low** | Documentation minor gap | Process owner | 60 business days |

Issues logged in ApexAudit with unique ID `ISS-CMP-YYYY-####`. Status: Open → Remediation → Retest → Closed.

---

## 8. KPI / KRI Framework

### 8.1 Key Performance Indicators (KPIs)

| KPI ID | Metric | Target | Owner |
|---|---|---|---|
| `KPI-CMP-001` | AML training completion (in-scope staff) | 100% by due date | HR + CMP |
| `KPI-CMP-002` | KYC refresh within SLA | ≥ 98% | KYC Operations |
| `KPI-CMP-003` | CTR filing within 5 business days | ≥ 99% | BSA Officer |
| `KPI-CMP-004` | SAR filing within 20 calendar days | ≥ 95% | BSA Officer |
| `KPI-CMP-005` | TM alert backlog > 30 days | < 2% of open alerts | Head of Financial Crime |
| `KPI-CMP-006` | Monitoring exceptions closed on time | ≥ 90% | Compliance Testing |
| `KPI-CMP-007` | Sanctions false positive clearance SLA | ≥ 98% within 4 hours | Head of Sanctions |

### 8.2 Key Risk Indicators (KRIs)

| KRI ID | Metric | Amber | Red | Action |
|---|---|---|---|---|
| `KRI-CMP-001` | SAR rate per 10,000 customers | > industry + 20% | > industry + 50% | Typology review |
| `KRI-CMP-002` | No-SAR rate after full investigation | > 70% | > 85% | Investigation quality review |
| `KRI-CMP-003` | PEP undetected post-onboarding | > 0.1% | > 0.5% | KYC rule change |
| `KRI-CMP-004` | CTR aggregation misses | > 0 | > 1 | Immediate remediation |
| `KRI-CMP-005` | Open Critical issues | > 0 | > 2 | CCO briefing |
| `KRI-CMP-006` | TM rule auto-closure rate | > 60% | > 75% | Rule tuning audit |

Dashboard: ApexInsight — Financial Crime Compliance tile; monthly FCC pack.

---

## 9. Operational Workflow — Monitoring Cycle

```
Annual plan approved (Jan)
        │
        ├─ Extract populations from ApexKYC / ApexGuard / ApexRegRep
        ├─ Execute samples per §5
        ├─ Document workpapers in ApexAudit
        │
        ├─ Exceptions? ──YES──► ISS-CMP- log; assign owner
        │       └─ Retest after remediation
        │
        ├─ Quarterly report ──► FCC
        └─ Annual effectiveness ──► Board PRCC (with Head of Financial Crime)
```

---

## 10. Coordination with Finance and HR

| Partner | Interaction |
|---|---|
| `EMP-600106` Farhan Siddiqui (FIN Regulatory Reporting) | Reconcile BSA data feeds to Call Report; joint test of `CTL-CMP-080` |
| HR (`ANB-HRM-POL-0008`) | Training completion extracts; disciplinary linkage for tipping off |
| Internal Audit | Share plan; no duplicate testing same control same period |

---

## 11. Examples

**Example 1 — CDD Sample Finding:** Q1 sample finds 3 of 120 retail files missing address verification. Classified Medium. `ISS-CMP-2026-0042` opened. KYC Operations remediate; ApexKYC validation rule tightened. Retest pass Q2.

**Example 2 — KRI Red:** `KRI-CMP-004` triggered — missed aggregation at `SIT-0412`. Critical issue. Retrospective CTR filed; teller retraining; BSA Officer briefs FCC within 5 days.

---

## 12. Related Documents

`ANB-CMP-POL-0001` · all `04_compliance_and_aml/` siblings · `ANB-ADM-POL-0001` · `ANB-LEG-REF-0003` · `ANB-FIN-SOP-0003` · `ANB-HRM-POL-0008`

---

## 13. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | I. Fontaine | Initial monitoring guide; KPI/KRI v1 |

---

## Appendix A — Monitoring Workpaper Checklist

- [ ] Sample selection documented and reproducible
- [ ] Control ID and `REG-AML-` linkage
- [ ] Evidence screenshots / file IDs (`KYC-`, `SAR-`, etc.)
- [ ] Exception severity assigned
- [ ] Root cause documented
- [ ] Remediation ticket linked
- [ ] Reviewer sign-off (independent from process owner)

---

**End of Document** — `ANB-CMP-GDL-0008` v1.0
