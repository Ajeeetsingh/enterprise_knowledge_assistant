# Apex National Bank — Risk Appetite Statement

**Board-Approved Statement | Risk Appetite, Tolerance, Limits, and Escalation Thresholds**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-STMT-0001` |
| **Document Title** | Risk Appetite Statement |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) |
| **Custodian** | Victoria Chen, Head of Enterprise Risk (G9) — `EMP-400205` |
| **Approver** | Board of Directors (on BRC recommendation) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual (BRC recommends; Board approves) |
| **Business Process** | `BP-RSK-APP` |
| **System of Record** | ApexRisk · ApexInsight |
| **Related Documents** | `ANB-RSK-POL-0001`, `ANB-TRY-POL-0001`, `ANB-CBK-POL-0001` |

---

## 2. Purpose

The Risk Appetite Statement translates Board strategy into measurable boundaries for risk-taking across credit, market, liquidity, operational, compliance, model, vendor, and resilience dimensions. It defines appetite (`RAM-####`), tolerance (`RTM-####`), escalation thresholds, and capital/liquidity considerations for FY2026–FY2027.

---

## 3. Scope

Applies to Apex National Bank, N.A. and consolidated subsidiaries for which the CRO is accountable to BRC. Local addenda for UK/EU entities maintained by Head of Enterprise Risk with local boards.

---

## 4. Governance

| Body | Role |
|---|---|
| Board of Directors | Approves this Statement annually |
| Board Risk Committee | Recommends; monitors adherence quarterly |
| CRO (`EMP-100004`) | Accountable for monitoring and breach reporting |
| ALCO | Liquidity and IRRBB limits within appetite |
| GrCC | Credit concentrations within appetite |
| ORC | Operational KRIs and resilience tolerances |
| BTR | Impact tolerances for Important Business Services |

---

## 5. Qualitative Appetite Statements

| `RCAT` | Appetite Statement |
|---|---|
| `RCAT-0001` Credit | **Moderate.** Grow prudently in core markets; avoid speculative or opaque structures; CRE concentration managed. |
| `RCAT-0002` Market | **Low.** Hedge structural exposures; trading activity limited to client facilitation and treasury management. |
| `RCAT-0003` Liquidity | **Conservative.** Maintain robust HQLA; LCR/NSFR well above regulatory minima; survive 30-day severe stress. |
| `RCAT-0004` Operational | **Low–Moderate.** Accept operational risk inherent in scale; zero tolerance for uncontrolled single points of failure on Tier 1 systems. |
| `RCAT-0005` Compliance | **Zero tolerance** for wilful breach; minimal appetite for known control gaps without remediation plan. |
| `RCAT-0006` Financial crime | **Zero tolerance** for sanctions breach and intentional ML facilitation. |
| `RCAT-0007` Model | **Low.** Models must be validated before use; limited appetite for unvalidated AI in customer decisions. |
| `RCAT-0009` Third party | **Moderate** with **low appetite** for irreplaceable critical vendors without exit plan. |
| `RCAT-0010` Cyber | **Low.** Assume breach; minimise blast radius; recover CBS within impact tolerance. |
| `RCAT-0011` Resilience | **Low.** Critical services recover within Board-approved impact tolerances; annual scenario testing mandatory. |

---

## 6. Quantitative Appetite Metrics (`RAM-####`)

| RAM ID | Metric | Appetite (Limit) | Tolerance (`RTM`) | Escalation |
|---|---|---|---|---|
| `RAM-0001` | Common Equity Tier 1 ratio | ≥ 11.5% | ≥ 11.0% | < 11.0% → BRC within 5 days |
| `RAM-0002` | Tier 1 leverage ratio | ≥ 8.5% | ≥ 8.0% | < 8.0% → ExCo + BRC |
| `RAM-0003` | LCR | ≥ 120% | ≥ 115% | < 115% → ALCO daily |
| `RAM-0004` | NSFR | ≥ 115% | ≥ 110% | < 110% → ALCO |
| `RAM-0005` | NPL ratio (consolidated) | ≤ 1.25% | ≤ 1.50% | > 1.50% → GrCC thematic |
| `RAM-0006` | Commercial CRE concentration / capital | ≤ 300% | ≤ 350% | > 350% → BRC |
| `RAM-0007` | Single-name exposure / capital | ≤ 15% | ≤ 20% | > 20% → BRC approval required |
| `RAM-0008` | Operational loss (rolling 12m) | ≤ USD 420M | ≤ USD 500M | > USD 500M → ORC + ExCo |
| `RAM-0009` | Model issues — open High+ | 0 Tier 1 production issues | ≤ 2 Medium | Any High on Tier 1 → CRO |
| `RAM-0010` | Critical vendor without exit plan | 0 | 0 | Any → BTR notification |
| `RAM-0011` | CBS disruption events > tolerance | 0 per year | 0 | Any → COO + BTR same day |
| `RAM-0012` | Cyber Severity 1 incidents | ≤ 2 per year | ≤ 3 | > 3 → BRC thematic review |

---

## 7. Credit Appetite Detail

| Segment | Growth Appetite | Underwriting Guardrails |
|---|---|---|
| Retail mortgage | Moderate | Max LTV 90% (80% without MI); min FICO 620 standard |
| SMB | Moderate | Max leverage 4.5x; industry concentration limits |
| Middle-market C&I | Moderate | GrCC approval > USD 50M |
| CRE income-producing | **Constrained** | Max 35% of commercial portfolio; stress `SCN-2026-CRD-001` |
| Leveraged finance | **Low** | Limited to relationship clients; EDD mandatory |
| Correspondent / FI | **Low** | FCC + CCO alignment (`ANB-CMP-POL-0001`) |

---

## 8. Liquidity and Funding Appetite

Aligned with `ANB-TRY-POL-0001` and Contingency Funding Plan:

| Metric | Appetite |
|---|---|
| Survival horizon (severe stress) | ≥ 30 calendar days |
| Wholesale funding > 1 year maturity | ≥ 40% of wholesale book |
| Intraday liquidity buffer | ≥ USD 8B |
| Contingent liquidity (FHLB + Fed) | Fully documented; tested annually |

Stress scenario `SCN-2026-LIQ-001` must not breach `RAM-0003` in reverse stress test.

---

## 9. Operational Resilience Objectives

| CBS ID | Impact Tolerance (Max Disruption) | Recovery Target |
|---|---|---|
| `CBS-00000001` | 4 hours | Normal operations within 4h |
| `CBS-00000002` | 2 hours | SWIFT alternate path within 2h |
| `CBS-00000003` | 2 hours | RTO 2h / RPO 0 (`ANB-ITO-PLN-0002`) |
| `CBS-00000004` | 8 hours | Manual fallback onboarding within 8h |
| `CBS-00000005` | 4 hours | Treasury desk operational within 4h |

Scenarios `SCN-2026-COR-001`, `SCN-2026-CYB-001`, `SCN-2026-CLD-001` tested annually per `ANB-RSK-POL-0007`.

---

## 10. Escalation and Breach Management

```
Metric breaches RTM (tolerance)
        │
        ├─ Within 5% of RAM ──► Owner action plan; ORC/ALCO/GrCC note
        ├─ Breaches RAM ──► CRO notification within 1 business day
        │
        └─ Sustained breach > 5 days OR critical RAM
                ├─ ExCo briefing
                ├─ BRC report at next meeting (or extraordinary)
                └─ Remediation plan with Board visibility
```

Operating **outside** appetite requires BRC unanimity and Board notification (`ANB-LEG-REF-0003` §7.2).

---

## 11. Capital Considerations

Capital plan (`EMP-600111` Arun Balakrishnan) must support appetite under baseline and stress. CCAR/DFAST severe scenario must maintain CET1 ≥ 9.5% post-stress minimum. Dividend and buyback recommendations require CRO concurrence if stress utilisation > 75% of capital buffer.

---

## 12. Monitoring and Reporting

| Deliverable | Frequency | Owner |
|---|---|---|
| Appetite dashboard | Monthly | Head of Enterprise Risk |
| Breach register | Continuous | ApexRisk |
| Quarterly appetite attestation | Quarterly | Business unit heads to CRO |
| Board risk report | Quarterly | CRO to BRC |

---

## 13. Examples

**Example — CRE stress:** `SCN-2026-CRD-001` projects NPL rise to 1.55%. Breaches `RAM-0005` tolerance. GrCC initiates sector review; new CRE originations paused 30 days; `RREG-202608-0201` updated.

**Example — LCR:** Market volatility reduces HQLA eligibility. LCR falls to 114%. ALCO daily meetings invoked; `RAM-0004` tolerance breached; funding plan adjusted within 48 hours.

---

## 14. Related Documents

Full cross-reference per `ANB-RSK-POL-0001` §15. Key: `ANB-RSK-FRM-0001`, `ANB-RSK-POL-0005`, `ANB-RSK-POL-0007`, `ANB-ITO-PLN-0002`, `ANB-TRY-PLN-0002`, `ANB-FIN-BUD-0005`.

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-30 | V. Chen | FY26/27 appetite — BRC recommended, Board approved |

---

## Appendix A — Heat Map (Residual Risk vs Appetite — Q2 2026 Snapshot)

| Domain | Residual | Appetite | Status |
|---|---|---|---|
| Credit | Medium | Moderate | Within |
| Liquidity | Low | Conservative | Within |
| Operational | Medium | Low–Moderate | Watch — `KRI-0042` elevated |
| Cyber | Medium | Low | Action plan active |
| Model | Low | Low | Within |
| Vendor | Medium | Moderate | Within — 1 critical exit plan due |
| Compliance | Low | Zero wilful | Within |

---

**End of Document** — `ANB-RSK-STMT-0001` v1.0
