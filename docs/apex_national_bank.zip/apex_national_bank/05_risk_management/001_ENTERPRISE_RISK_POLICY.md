# Apex National Bank — Enterprise Risk Management Policy

**Enterprise Policy | ERM Governance, Three Lines of Defence, and Risk Lifecycle**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-POL-0001` |
| **Document Title** | Enterprise Risk Management Policy |
| **Version** | 1.0 |
| **Owner** | Risk Department (RSK) |
| **Custodian** | Helena Brandt, Chief Risk Officer (G11) — `EMP-100004` |
| **Approver** | Board Risk Committee (BRC) |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Retention** | `RET-POL-10Y` |
| **Taxonomy** | `T2` → `T2.7` Enterprise Risk Framework → `POL` |
| **Business Process** | `BP-RSK-APP`, `BP-RSK-RCSA`, `BP-RSK-KRI`, `BP-RSK-ACC`, `BP-RSK-STRESS` |
| **System of Record** | ApexRisk · ApexDocs · ApexInsight |
| **Related Documents** | See §16 |

> **Authority.** This Policy is the apex instrument of the Bank's Enterprise Risk Management (`ERM`) programme. It implements the risk scope in `ANB-ADM-REF-0001` §7.8 and is approved by the Board Risk Committee per `ANB-LEG-REF-0003` §7.2.

---

## 2. Purpose

Apex National Bank operates at `$58.2B` revenue with nineteen jurisdictions, forty-one million daily transactions on ApexCore, and material credit, market, liquidity, operational, model, compliance, and strategic exposures. ERM exists so that risk-taking is deliberate, measured, within Board-approved appetite, and reported transparently to management and the Board.

This Policy establishes governance, the Three Lines of Defence, risk ownership, the enterprise risk lifecycle, reporting, Board oversight, and risk culture — and introduces the **canonical risk entity register** for all documents in `05_risk_management/` and downstream domains.

---

## 3. Scope

### 3.1 Applies To

All legal entities in the Apex Financial Group; all risk categories in the enterprise taxonomy; all employees and contractors with risk responsibilities; third parties where risk is outsourced or concentrated.

### 3.2 Risk Categories (`RCAT-####`)

| Code | Category | Owner Function |
|---|---|---|
| `RCAT-0001` | Credit risk | Head of Credit Risk (`EMP-400201`) |
| `RCAT-0002` | Market risk | Head of Market & Liquidity Risk (`EMP-400206`) |
| `RCAT-0003` | Liquidity risk | Group Treasurer / ALCO |
| `RCAT-0004` | Operational risk | Head of Operational Risk (`EMP-400202`) |
| `RCAT-0005` | Compliance / conduct risk | CCO (`EMP-100005`) |
| `RCAT-0006` | Financial crime risk | Head of Financial Crime (`EMP-400101`) |
| `RCAT-0007` | Model risk | Head of Model Risk (`EMP-400204`) |
| `RCAT-0008` | Strategic / business risk | ExCo / business unit heads |
| `RCAT-0009` | Third-party / vendor risk | Head of Third-Party Risk (`EMP-400208`) |
| `RCAT-0010` | Technology / cyber risk | CISO (`EMP-100010`) |
| `RCAT-0011` | Resilience / continuity risk | Head of Business Continuity (`EMP-400207`) |

### 3.3 Regulatory Reference (Non-Exhaustive)

OCC heightened standards; FFIEC IT and BCP handbooks; Basel III / US capital rules; SR 11-7 model risk; CCAR/DFAST; UK/EU operational resilience; GDPR interaction with risk data.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Risk within appetite | Zero unapproved appetite breaches > 5 business days |
| O-2 | Risk register current | 100% material risks in `RREG-` with owner |
| O-3 | RCSA coverage | ≥ 95% in-scope processes assessed annually |
| O-4 | KRI monitoring | 100% Tier 1 KRIs reported monthly to ORC |
| O-5 | Stress testing | Annual enterprise stress per BRC calendar |
| O-6 | Risk culture | 100% risk training completion; speak-up themes reviewed |
| O-7 | Exam readiness | No repeat material finding on same control in consecutive exams |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **ERM** | Enterprise Risk Management — integrated framework across all `RCAT-*` |
| **Risk Appetite** | Aggregate level and types of risk the Board is willing to accept — `ANB-RSK-STMT-0001` |
| **Risk Tolerance** | Maximum acceptable variation around appetite — `RTM-####` |
| **RCSA** | Risk & Control Self-Assessment — `BP-RSK-RCSA` |
| **KRI / KCI** | Key Risk / Control Indicator |
| **Risk Acceptance** | Documented decision to operate with a known gap — `BP-RSK-ACC` |
| **Material Risk** | Risk that could individually or collectively threaten safety, soundness, or strategic objectives |

Entity identifiers: Appendix A.

---

## 6. Three Lines of Defence

| Line | Who | Accountability |
|---|---|---|
| **First** | Business lines, operations, IT, branches | Own and manage risks; maintain controls; escalate incidents and losses |
| **Second** | Risk (RSK), Compliance (CMP), Finance control functions | Framework, challenge, monitoring, reporting, independent credit/model opinion |
| **Third** | Internal Audit (IAD) | Independent assurance to Board Audit Committee |

**Non-delegation:** First Line may not override Risk credit objection on GrCC votes; may not downgrade `CRR-*` without Risk approval; may not accept Critical risk without CRO.

---

## 7. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Board Risk Committee | Chaired by Hugo Bertrand | Appetite, ERM policy, large exposures, stress tests |
| CRO (G11) | `EMP-100004` Helena Brandt | Accountable executive; GrCC/ORC chair; BRC reporting |
| Head of Credit Risk (G9) | `EMP-400201` Lars Henriksson | Credit framework; GrCC secretariat; watchlist |
| Head of Operational Risk (G8) | `EMP-400202` Deepa Ramanathan | ORC secretariat; loss data; RCSA; KRIs |
| Head of Model Risk (G8) | `EMP-400204` Kenji Okada | Model inventory; validation; AI/ML governance |
| Head of Enterprise Risk (G9) | `EMP-400205` Victoria Chen | Stress testing; enterprise risk register |
| Head of Market & Liquidity Risk (G9) | `EMP-400206` Patrick O'Malley | Market/liquidity limits; ALCO support |
| Head of Business Continuity (G8) | `EMP-400207` Sandra Okoye | BCP; impact tolerances; crisis coordination |
| Head of Third-Party Risk (G8) | `EMP-400208` Nathan Brooks | Vendor tiering; concentration (with PRC) |
| Head of Special Assets (G8) | `EMP-400209` Elaine Morrison | Workout; impaired assets |
| CFO | `EMP-100002` Priya Raghunathan | Capital; provisioning interface |
| CCO | `EMP-100005` Samuel A. Okonkwo | Compliance/conduct risk overlay |
| COO | `EMP-100003` Daniel K. Ortega | BCP invocation; operational resilience |
| CIO | `EMP-100007` Arjun Patel | DR execution; technology recovery |
| CPO | `EMP-100013` Ian McAllister | Procurement; vendor contract execution |

---

## 8. Policy Statements

**ERM-1.** All material risks are identified, assessed, treated, monitored, and reported through the risk lifecycle (§9).

**ERM-2.** Risk-taking must remain within the Board-approved Risk Appetite Statement (`ANB-RSK-STMT-0001`). Breaches escalate per §12.

**ERM-3.** Independent challenge: Credit and model decisions require affirmative Risk vote where charter mandates (`ANB-LEG-REF-0003` GrCC).

**ERM-4.** Risk acceptances are time-bound, owned, and reported. Critical acceptances require CRO and BRC notification.

**ERM-5.** Loss events above threshold are recorded in ApexRisk within 5 business days (`BP-RECN-LOSS`).

**ERM-6.** Stress testing and scenario analysis are performed annually and on trigger events (`BP-RSK-STRESS`).

**ERM-7.** Risk culture: employees must escalate concerns without retaliation (`ANB-HRM-POL-0004`).

**ERM-8.** Records retained per `ANB-ADM-POL-0001`; risk assessments `RET-RSK-7Y`.

---

## 9. Risk Lifecycle

```
IDENTIFY → ASSESS → TREAT → MONITOR → REPORT → REVIEW
    │         │        │         │         │        │
 RREG-    RASS-    Accept/    KRI/KCI   BRC/ORC/   Annual
          Mitigate  Avoid/    REV-      GrCC      refresh
                    Transfer  loss
```

| Stage | Output | System |
|---|---|---|
| Identify | `RREG-########` entry | ApexRisk |
| Assess | `RASS-########`; inherent/residual rating | ApexRisk |
| Treat | Controls `CTL-*`; action plans | ApexRisk / ApexServe |
| Monitor | `KRI-####` / `KCI-####` dashboards | ApexInsight |
| Report | Monthly ORC pack; quarterly BRC pack | ApexDocs |
| Review | Annual RCSA; trigger-based refresh | ApexRisk |

---

## 10. Risk Rating Scale (Inherent / Residual)

| Score | Label | Heat Map Colour | Action |
|---|---|---|---|
| 1–4 | Low | Green | Manage routinely |
| 5–9 | Medium | Amber | Enhanced monitoring |
| 10–15 | High | Orange | Treatment plan; ORC review |
| 16–25 | Critical | Red | CRO escalation; no acceptance without BRC |

---

## 11. Enterprise Scenarios (Canonical)

Reused across BCP, DR, stress test, and ORC scenario libraries:

| Scenario ID | Event | Primary `RCAT` |
|---|---|---|
| `SCN-2026-CYB-001` | Ransomware / major cyberattack on hybrid cloud | `RCAT-0010` |
| `SCN-2026-COR-001` | ApexCore outage — primary z/OS partition | `RCAT-0011` |
| `SCN-2026-SWF-001` | SWIFT gateway / messaging outage | `RCAT-0004` |
| `SCN-2026-CLD-001` | Hyperscaler regional failure (us-east-1) | `RCAT-0010` |
| `SCN-2026-DC-001` | Charlotte data centre (`SIT-0002`) failure | `RCAT-0011` |
| `SCN-2026-INS-001` | Insider fraud — privileged access abuse | `RCAT-0004` |
| `SCN-2026-PAY-001` | ApexPay payment processing disruption | `RCAT-0004` |
| `SCN-2026-VEN-001` | Critical vendor compromise (managed connectivity) | `RCAT-0009` |
| `SCN-2026-REG-001` | Regulatory enforcement / consent order | `RCAT-0005` |
| `SCN-2026-LIQ-001` | Liquidity stress — wholesale funding freeze | `RCAT-0003` |
| `SCN-2026-CRD-001` | Credit portfolio deterioration — CRE sector | `RCAT-0001` |
| `SCN-2026-PAN-001` | Pandemic — 40% absenteeism | `RCAT-0011` |
| `SCN-2026-FLD-001` | Flood — lower Manhattan (`SIT-0001`) | `RCAT-0011` |
| `SCN-2026-EQ-001` | Earthquake — San Francisco (`SIT-0100`) | `RCAT-0011` |
| `SCN-2026-PWR-001` | Extended power outage — Charlotte | `RCAT-0011` |
| `SCN-2026-BRN-001` | Branch network unavailability (`SIT-0412` region) | `RCAT-0004` |
| `SCN-2026-TEL-001` | Telecom / WAN outage | `RCAT-0010` |
| `SCN-2026-DAT-001` | Data corruption — replication lag | `RCAT-0010` |

---

## 12. Escalation Paths

| Situation | Escalate To | Timeline |
|---|---|---|
| Appetite breach (any `RAM-####`) | CRO → BRC | Same day |
| Critical risk unmitigated | CRO → ExCo | 2 business days |
| Op loss > USD 5M | ORC → ExCo | 5 business days |
| Credit concentration breach | GrCC → BRC | Next meeting |
| Model validation fail — Tier 1 | Head of Model Risk → CRO → BRC | 10 business days |
| CBS impact tolerance breach | COO → BTR | Same day |
| Vendor critical failure | Head of Third-Party Risk → ORC | 4 hours |

---

## 13. Risk Reporting

| Report | Audience | Frequency | Owner |
|---|---|---|---|
| Enterprise Risk Dashboard | ExCo | Monthly | CRO |
| Operational Risk Pack | ORC | Monthly | Head of Operational Risk |
| Credit Portfolio Report | GrCC | Monthly | Head of Credit Risk |
| Risk Appetite Monitor | BRC | Quarterly | Head of Enterprise Risk |
| Stress Test Results | BRC / FIN | Annual + ad hoc | `EMP-400205` / `EMP-600111` |
| KRI Heat Map | ORC | Monthly | ApexInsight |

---

## 14. Examples

**Example 1 — Risk acceptance:** Legacy fax interface for wire confirmations cannot meet MFA standard by deadline. `RASS-202608-0044` rates residual Medium. `BP-RSK-ACC` documents 90-day acceptance `RSK-202608-0128`; compensating manual callback control; ORC approval.

**Example 2 — Scenario linkage:** `SCN-2026-COR-001` exercised in 2026 DR test `DR-20260415-0001`. `BCP-202604-0003` invoked in tabletop; RTO met for `CBS-0003`; lessons learned logged `REV-202604-0088`.

---

## 15. Related Documents

### 15.1 Risk Domain

| ID | Title | File |
|---|---|---|
| `ANB-RSK-STMT-0001` | Risk Appetite Statement | `002_RISK_APPETITE_STATEMENT.md` |
| `ANB-RSK-FRM-0001` | Credit Risk Framework | `003_CREDIT_RISK_FRAMEWORK.md` |
| `ANB-RSK-POL-0005` | Operational Risk Policy | `004_OPERATIONAL_RISK_POLICY.md` |
| `ANB-RSK-POL-0004` | Model Risk Management Policy | `005_MODEL_RISK_POLICY.md` |
| `ANB-RSK-FRM-0002` | Vendor Risk Framework | `006_VENDOR_RISK_FRAMEWORK.md` |
| `ANB-RSK-POL-0007` | Business Continuity Policy | `007_BUSINESS_CONTINUITY_POLICY.md` |
| `ANB-ITO-PLN-0002` | Disaster Recovery Plan | `008_DISASTER_RECOVERY_PLAN.md` |
| `ANB-RSK-STD-0002` | RCSA Standard | *(planned)* |
| `ANB-RSK-TPL-0003` | Risk Assessment Template | *(planned)* |

### 15.2 Foundation, Governance, HR, Finance, Compliance

| ID | Title |
|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard |
| `ANB-ADM-STD-0006` | Knowledge Taxonomy |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter |
| `ANB-HRM-POL-0004` | Code of Conduct |
| `ANB-HRM-POL-0008` | Training & Certification Policy |
| `ANB-FIN-SOP-0003` | Financial Closing SOP |
| `ANB-FIN-STD-0004` | Chart of Accounts — `CC-RSK-100` |
| `ANB-CBK-POL-0001` | Loan Approval Policy |
| `ANB-CMP-POL-0001` | AML Policy |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy |
| `ANB-TRY-POL-0001` | Liquidity & Funding Policy |

---

## 16. Review Cycle

Annual review by CRO for BRC approval; interim update on material regulatory change within 60 days.

---

## 17. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 1.0 | 2026-07-30 | H. Brandt | Initial published ERM policy | BRC |

---

## 18. Appendices

### Appendix A — Canonical Risk Entity Register

**Authoritative for `05_risk_management/` and downstream domains.**

#### A.1 Core Risk Objects

| Entity | Format | Example | System | Retention |
|---|---|---|---|---|
| Risk ID | `RSK-########` | `RSK-202608-0128` | ApexRisk | `RET-RSK-7Y` |
| Enterprise Risk Register Entry | `RREG-########` | `RREG-202607-0044` | ApexRisk | `RET-RSK-7Y` |
| Risk Category | `RCAT-####` | `RCAT-0004` | ApexRisk | `RET-POL-10Y` |
| Risk Event | `REV-########` | `REV-202604-0088` | ApexRisk | `RET-RSK-7Y` |
| Risk Assessment | `RASS-########` | `RASS-202608-0044` | ApexRisk | `RET-RSK-7Y` |
| Key Risk Indicator | `KRI-####` | `KRI-0042` | ApexRisk | `RET-RSK-7Y` |
| Key Control Indicator | `KCI-####` | `KCI-0018` | ApexRisk | `RET-RSK-7Y` |
| Risk Appetite Metric | `RAM-####` | `RAM-0001` | ApexRisk | `RET-POL-10Y` |
| Risk Tolerance Metric | `RTM-####` | `RTM-0001` | ApexRisk | `RET-POL-10Y` |

#### A.2 Credit and Model

| Entity | Format | Example |
|---|---|---|
| Credit Risk Rating | `CRR-####` | `CRR-0006` (Pass / Watch) |
| Model | `MDL-########` | `MDL-202401-0044` |
| Model Validation | `MVAL-########` | `MVAL-202607-0012` |

#### A.3 Third Party and Resilience

| Entity | Format | Example |
|---|---|---|
| Vendor Risk Assessment | `VRA-########` | `VRA-202608-0099` |
| Business Impact Analysis | `BIA-########` | `BIA-202605-0003` |
| Business Continuity Plan | `BCP-########` | `BCP-202604-0003` |
| Disaster Recovery Event | `DR-########` | `DR-20260415-0001` |
| Critical Business Service | `CBS-########` | `CBS-00000003` |
| Critical Asset | `AST-########` | `AST-00000001` (ApexCore) |
| Scenario | `SCN-2026-*` | See §11 |

#### A.4 Critical Business Services Register

| ID | Service | Owner | Max Tolerable Disruption |
|---|---|---|---|
| `CBS-00000001` | Retail payments & account servicing | RTL / ITO | 4 hours |
| `CBS-00000002` | Wholesale payments & SWIFT | TRY / CBK | 2 hours |
| `CBS-00000003` | Core ledger & real-time posting | ITO | 2 hours |
| `CBS-00000004` | Customer onboarding & KYC | CMP / RTL | 8 hours |
| `CBS-00000005` | Treasury & liquidity management | TRY | 4 hours |

#### A.5 Risk Personnel Register (Extended)

| Employee ID | Name | Grade | Role |
|---|---|---|---|
| `EMP-100004` | Helena Brandt | G11 | Chief Risk Officer |
| `EMP-400201` | Lars Henriksson | G9 | Head of Credit Risk |
| `EMP-400202` | Deepa Ramanathan | G8 | Head of Operational Risk |
| `EMP-400203` | Julien Faucher | G6 | Risk Manager — Retail & Operations |
| `EMP-400204` | Kenji Okada | G8 | Head of Model Risk |
| `EMP-400205` | Victoria Chen | G9 | Head of Enterprise Risk |
| `EMP-400206` | Patrick O'Malley | G9 | Head of Market & Liquidity Risk |
| `EMP-400207` | Sandra Okoye | G8 | Head of Business Continuity |
| `EMP-400208` | Nathan Brooks | G8 | Head of Third-Party Risk |
| `EMP-400209` | Elaine Morrison | G8 | Head of Special Assets |

---

**End of Document** — `ANB-RSK-POL-0001` v1.0 · C2 · Effective 2026-08-01
