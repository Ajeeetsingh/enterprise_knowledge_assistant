# Apex National Bank — Disaster Recovery Plan

**Disaster Recovery Plan | Technical Recovery, Failover, Backup, and Validation**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ITO-PLN-0002` |
| **Document Title** | Disaster Recovery Plan |
| **Version** | 2.0 |
| **Owner** | IT Operations (ITO) |
| **Custodian** | Ravi Subramanian, Head of IT Operations (G11) — `EMP-500101` |
| **Approver** | Arjun Patel, CIO (G11) — `EMP-100007` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual + test |
| **Business Process** | `BP-RES-DR`, `BP-ITSM-INC`, `BP-ITSM-CAP` |
| **System of Record** | ApexServe · ApexCloud · ApexVault · ApexMonitor |
| **Related Documents** | `ANB-RSK-POL-0007`, `ANB-RSK-POL-0001`, `ANB-ISC-SOP-0003` |

> **Note.** This Plan implements technical recovery for the enterprise. Business continuity coordination per `ANB-RSK-POL-0007`; operational plan detail also in `ANB-ITO-PLN-0001`.

---

## 2. Purpose

Disaster recovery restores technology services supporting Critical Business Services after catastrophic failure — data centre loss, cyberattack, corruption, or cloud regional outage. This Plan defines declaration criteria, recovery procedures, RTO/RPO by tier, failover, backup strategy, testing, validation, and lessons learned.

---

## 3. Scope

All production systems in ApexServe CMDB; Tier 1 and Tier 2 applications; infrastructure at `SIT-0001`, `SIT-0002`, and ApexCloud regions; interfaces to SWIFT, card networks, and core banking.

---

## 4. Critical Assets (`AST-########`)

| Asset ID | System | Tier | Primary Site | DR Site / Region |
|---|---|---|---|---|
| `AST-00000001` | ApexCore (z/OS + DB2) | 1 | `SIT-0001` NY | `SIT-0002` Charlotte — sync replication |
| `AST-00000002` | ApexPay | 1 | ApexCloud us-east-1 | us-west-2 active-passive |
| `AST-00000003` | SWIFT gateway | 1 | `SIT-0001` | `SIT-0002` + alternate BIC path |
| `AST-00000004` | ApexKYC | 1 | ApexCloud | Multi-region |
| `AST-00000005` | ApexGuard | 1 | ApexCloud | Multi-region |
| `AST-00000006` | ApexLedger (SAP) | 1 | `SIT-0002` | `SIT-0001` DR pair |
| `AST-00000007` | ApexOrigin | 1 | Salesforce + integration | DR org warm |
| `AST-00000008` | ApexDocs | 2 | ApexCloud | Geo-redundant storage |
| `AST-00000009` | ApexRisk / ApexModel | 2 | `SIT-0002` | Daily restore target |
| `AST-00000010` | ApexMail (M365) | 1 | Microsoft geo | Microsoft DR |

---

## 5. RTO / RPO Summary

| Tier | RTO | RPO | Systems |
|---|---|---|---|
| **Tier 1** | 2 hours | 0 (ApexCore); ≤ 15 min (ApexPay) | `AST-00000001`–`07`, `10` |
| **Tier 2** | 4 hours | ≤ 1 hour | `AST-00000008`, `09` |
| **Tier 3** | 24 hours | ≤ 4 hours | Internal dev, non-customer facing |
| **Tier 4** | 72 hours | ≤ 24 hours | Archive, low-priority |

Matches `ANB-RSK-STMT-0001` and Company Profile ApexCore specification.

---

## 6. Disaster Declaration

### 6.1 Declaration Criteria

| Condition | Action |
|---|---|
| Primary data centre unavailable > 30 minutes | DR Lead assesses; likely declaration |
| ApexCore unavailable > 15 minutes | Automatic DR bridge |
| Ransomware on Tier 1 production | CISO + CIO declare; isolate networks |
| Data corruption with replication propagate risk | Halt replication; point-in-time recovery |
| Cloud region hard-down (`SCN-2026-CLD-001`) | Failover to secondary region |
| Cyber Severity 1 (`SCN-2026-CYB-001`) | DR standby; may invoke clean-room rebuild |

### 6.2 Authority

| Role | Authority |
|---|---|
| Head of IT Operations (`EMP-500101`) | Declare DR event `DR-########` |
| CIO (`EMP-100007`) | Confirm / escalate |
| COO (`EMP-100003`) | Business alignment; CMT |
| CISO (`EMP-100010`) | Cyber-specific isolation orders |

---

## 7. Disaster Recovery Workflow

```
DR-######## declared
        │
        ├─ Activate DR command bridge (Teams + war room Charlotte)
        ├─ Notify: CIO, COO, CRO, CISO, BC (`EMP-400207`)
        │
        ├─ ASSESS — scope, CBS impact, attack vs infrastructure
        │
        ├─ RECOVER
        │       ├─ ApexCore: Charlotte takeover (GDPS / PPRC)
        │       ├─ ApexPay: Route traffic us-west-2
        │       ├─ SWIFT: Secondary gateway (`SCN-2026-SWF-001` playbooks)
        │       └─ Cloud: DNS failover; scale DR capacity
        │
        ├─ VALIDATE — synthetic transactions; reconciliation
        ├─ RE-ENTER — gradual production promotion
        │
        └─ STAND DOWN — DR- closed; post-incident review REV-*
```

---

## 8. Failover Procedures (Summary)

### 8.1 ApexCore (`AST-00000001`)

- **Architecture:** IBM GDPS; synchronous PPRC NY → Charlotte; HyperSwap capability.
- **Trigger:** Unplanned HyperSwap or manual takeover.
- **Runbook:** `RB-CORE-DR-001` in ApexDocs.
- **Validation:** Test debit/credit cycle; end-of-day batch readiness.
- **Scenario test:** `SCN-2026-COR-001` — last full test `DR-20260415-0001`.

### 8.2 ApexPay (`AST-00000002`)

- Route53 health checks; automatic failover us-east-1 → us-west-2.
- Queue drain before cutover; duplicate payment prevention controls active.
- **Scenario:** `SCN-2026-PAY-001` — 2026 Q1 exercise passed RTO.

### 8.3 SWIFT (`AST-00000003`)

- Primary and secondary messaging VMs; managed vendor `VEN-003301`.
- Manual fallback: limited message queue via alternate connector (4h capacity).
- **Scenario:** `SCN-2026-SWF-001`.

### 8.4 Cyber / Ransomware (`SCN-2026-CYB-001`)

1. Isolate affected segments (ISC runbook).
2. Preserve forensic images.
3. Restore from immutable backup (ApexVault WORM) — **not** production replication if contaminated.
4. Clean-room rebuild for compromised components.
5. Password rotation enterprise-wide if credential theft suspected.

---

## 9. Backup Strategy

| Data Class | Method | Frequency | Retention | Location |
|---|---|---|---|---|
| ApexCore DB2 | Snap + log shipping; tape vault | Continuous logs; daily full | 90 days online; 7y tape | Charlotte + offsite |
| ApexCloud volumes | Snapshots + cross-region copy | Hourly critical; daily standard | 35 days | Multi-region |
| ApexVault archive | Immutable WORM | Daily | Per `ANB-ADM-POL-0001` | Geo-separated |
| Configuration / IaC | Git + ApexBuild | Every commit | Indefinite | DevOps repo |
| ApexDocs | Geo-redundant storage | Continuous | Per retention class | Azure blob GR |

**RPO validation:** Quarterly restore sample; annual full Tier 1 restore test.

**Data corruption (`SCN-2026-DAT-001`):** Point-in-time recovery to last known good; halt replication; reconcile with ApexLedger.

---

## 10. Recovery Testing Programme

| Test | Frequency | Last Example | Result |
|---|---|---|---|
| ApexCore HyperSwap | Semi-annual | `DR-20260415-0001` | RTO 47 min — pass |
| ApexPay region failover | Quarterly | DR-202606-0022 | RTO 38 min — pass |
| SWIFT alternate path | Annual | DR-202605-0018 | RTO 1h 52m — pass |
| Full enterprise simulation | Annual | DR-20260415-0001 | CBS-003 within tolerance |
| Backup restore random sample | Quarterly | DR-202607-0033 | Pass |
| Cyber clean-room tabletop | Semi-annual | BCP-202604-0003 | Remediation items closed |

Test evidence: ApexServe change/incident records; stored C2 minimum 7 years.

---

## 11. Restoration Validation

Before production traffic:

| Check | Owner |
|---|---|
| Synthetic payment end-to-end | ApexPay ops |
| Core posting and balance reconciliation | Core ops + FIN |
| SWIFT test message | Treasury |
| KYC screening sample | CMP |
| TM alerts flowing | Financial Crime |
| Monitoring and alerting live | ApexMonitor |
| Security scan — no compromise persistence | ISC |

Sign-off: Head of IT Operations + affected business owner + CISO (if cyber).

---

## 12. Lessons Learned

Post-DR event or major test within **20 business days**:

| Output | Owner |
|---|---|
| Timeline reconstruction | ITO |
| RTO/RPO achieved vs target | BC |
| Root cause (`REV-########`) | Op Risk |
| Remediation actions in ApexServe | Process owners |
| ORC / BTR briefing | COO / CIO |
| Runbook updates in ApexDocs | Platform Engineering (`EMP-500102`) |

**Example:** `DR-20260415-0001` identified gap in manual wire procedure — fixed in `BCP-202604-0003`; `KCI-0022` added for DR runbook currency.

---

## 13. Roles

| Role | Employee | DR Responsibility |
|---|---|---|
| DR Commander | `EMP-500101` Ravi Subramanian | Overall execution |
| Platform Engineering | `EMP-500102` Yuki Nakagawa | Cloud and middleware |
| Service Management | `EMP-500103` Andrés Villalobos | Incident bridge; comms to IT |
| Cyber Defence | `EMP-500201` Marta Bauer | Ransomware path |
| Business Continuity | `EMP-400207` Sandra Okoye | CBS alignment |
| CRO | `EMP-100004` Helena Brandt | Appetite; `RAM-0011` |

---

## 14. Escalation

| Event | Escalate | Timeline |
|---|---|---|
| RTO breach imminent | COO + CRO | Immediate |
| Regulatory notification required | Legal + Compliance | Per jurisdiction |
| Vendor DR failure (`VEN-008812`) | CPO + Third-Party Risk | 1 hour |
| Data loss suspected | CISO + General Counsel | Immediate |

---

## 15. Related Documents

`ANB-RSK-POL-0007` · `ANB-RSK-POL-0001` · `ANB-RSK-POL-0005` · `ANB-RSK-FRM-0002` · `ANB-ISC-SOP-0003` · `ANB-ITO-SOP-0003` · `ANB-CMP-SOP-0004` (continuity of SAR capability)

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-04-01 | Head of IT Operations | Initial DR plan |
| 1.5 | 2026-06-15 | Platform Engineering | ApexCloud multi-region update |
| 2.0 | 2026-07-30 | R. Subramanian | Annual refresh; `DR-20260415-0001` lessons incorporated |

---

## Appendix A — DR Event Log (Canonical Examples)

| DR ID | Date | Scenario | Outcome |
|---|---|---|---|
| `DR-20260415-0001` | 2026-04-15 | `SCN-2026-COR-001` full simulation | Pass — RTO 47m |
| `DR-202605-0018` | 2026-05-22 | `SCN-2026-SWF-001` | Pass — RTO 1h 52m |
| `DR-202606-0022` | 2026-06-10 | `SCN-2026-CLD-001` ApexPay failover | Pass — RTO 38m |
| `DR-202607-0033` | 2026-07-08 | Backup restore sample | Pass |

## Appendix B — Decision Tree — Failover vs Fix-in-Place

```
Outage detected
        │
        ├─ Expected fix < 15 min AND no data risk? ──► Fix in place
        ├─ Cyber compromise suspected? ──► Isolate; do NOT fail over replicated malware
        ├─ Primary site physical damage? ──► DR site takeover
        ├─ Cloud AZ failure? ──► Auto failover if healthy region
        └─ Data corruption? ──► Stop replication; PITR from ApexVault
```

---

**End of Document** — `ANB-ITO-PLN-0002` v2.0
