# Apex National Bank — Operational Risk Policy

**Enterprise Policy | Operational Risk Taxonomy, Loss Events, RCSA, and KRIs**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-POL-0005` |
| **Document Title** | Operational Risk Policy |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) — Operational Risk |
| **Custodian** | Deepa Ramanathan, Head of Operational Risk (G8) — `EMP-400202` |
| **Approver** | Helena Brandt, CRO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-RSK-RCSA`, `BP-RSK-KRI`, `BP-RECN-LOSS`, `BP-RSK-ACC` |
| **System of Record** | ApexRisk · ApexServe · ApexLedger |
| **Related Documents** | `ANB-RSK-POL-0001`, `ANB-RSK-STD-0002`, `ANB-CMP-POL-0001` |

---

## 2. Purpose

Operational risk is the risk of loss from inadequate or failed internal processes, people, systems, or external events — including legal risk but excluding strategic and reputational risk (reported separately). This Policy defines taxonomy, incident and loss management, RCSA, KRIs/KCIs, scenario analysis, and ORC reporting.

---

## 3. Scope

All departments; all geographies; outsourced activities where the Bank retains operational risk. Includes technology, cyber (operational lens), third-party, fraud (shared with CMP), and resilience events.

---

## 4. Operational Risk Taxonomy (Basel Event Types)

| Level 1 | Level 2 Examples | `RCAT` Link |
|---|---|---|
| Internal fraud | Insider theft, unauthorized activity | `RCAT-0004` + CMP |
| External fraud | Cyber fraud, payment fraud | `RCAT-0004` |
| Employment practices | Wrongful termination, discrimination | `RCAT-0004` / HRM |
| Clients, products, business practices | Suitability, disclosure | `RCAT-0005` |
| Damage to physical assets | Fire, flood (`SCN-2026-FLD-001`) | `RCAT-0011` |
| Business disruption | System outage (`SCN-2026-COR-001`) | `RCAT-0011` |
| Execution, delivery, process | Failed reconciliation, data error | `RCAT-0004` |

Each loss event tagged with Basel category in ApexRisk.

---

## 5. Incident and Loss Event Management

### 5.1 Thresholds

| Threshold | Action |
|---|---|
| ≥ USD 10,000 gross loss | Record `REV-########` within 5 business days |
| ≥ USD 100,000 | ORC notification; root cause within 30 days |
| ≥ USD 1,000,000 | CRO briefing; `RASS-` if systemic |
| ≥ USD 5,000,000 | ExCo escalation per `ANB-RSK-POL-0001` |

### 5.2 Workflow (`BP-RECN-LOSS`)

```
Event detected (any channel)
        │
        ├─ Log in ApexServe / ApexRisk
        ├─ Assign owner; contain impact
        ├─ Create REV-########
        │
        ├─ Gross/net loss calculation → ApexLedger if financial
        ├─ Root cause: people / process / system / external
        │
        ├─ Control fail? ──► Update RCSA; ISS-* if needed
        └─ ORC reporting if above threshold
```

**Examples:** `SCN-2026-INS-001` insider fraud → `REV-202607-0044`; `SCN-2026-PAY-001` ApexPay outage → `REV-202608-0122` (business disruption, near-loss).

---

## 6. RCSA (`BP-RSK-RCSA`)

| Element | Standard |
|---|---|
| Coverage | 100% Tier 1 processes; 95% all in-scope annually |
| Methodology | `ANB-RSK-STD-0002` (planned); template `ANB-RSK-TPL-0003` |
| Scale | Inherent vs residual 1–25 per `ANB-RSK-POL-0001` §10 |
| Control rating | Effective / Needs improvement / Ineffective |
| Challenge | Second Line sample 15%; ORC challenge High residual |
| Output | `RASS-########` linked to `BP-*` in ApexRisk |

Retail branch network (`SIT-0412` region): `EMP-400203` Julien Faucher coordinates RCSA.

---

## 7. Key Risk Indicators (`KRI-####`) and KCIs

| KRI ID | Indicator | Amber | Red | Owner |
|---|---|---|---|---|
| `KRI-0040` | Severity 1 IT incidents / month | > 2 | > 4 | ITO |
| `KRI-0041` | Unresolved High RCSA findings | > 5 | > 10 | Process owners |
| `KRI-0042` | Payment STP failure rate | > 0.5% | > 1.0% | ApexPay ops |
| `KRI-0043` | Op loss / budget (`RAM-0008`) | > 90% | > 100% | Head of Op Risk |
| `KRI-0044` | Critical risk acceptances open | > 3 | > 5 | CRO office |
| `KCI-0018` | Reconciliation break age > 5 days | > 20 items | > 50 | FIN |

Dashboard: ApexInsight — ORC tile; monthly pack to ORC.

---

## 8. Scenario Analysis

Annual operational scenario programme aligned with enterprise scenarios:

| Scenario | Purpose |
|---|---|
| `SCN-2026-CYB-001` | Ransomware — payment and core adjacency |
| `SCN-2026-VEN-001` | Vendor compromise — data exfiltration |
| `SCN-2026-REG-001` | Enforcement — consent order operational impact |
| `SCN-2026-BRN-001` | Branch unavailability — cash and CTR |
| `SCN-2026-DAT-001` | Data corruption — financial reporting |

Outputs: capital and loss estimates; control gaps; `RREG-` updates.

---

## 9. Roles and Responsibilities

| Role | Employee | Responsibility |
|---|---|---|
| Head of Operational Risk | `EMP-400202` Deepa Ramanathan | Policy; ORC secretariat; loss database |
| Risk Manager — Retail | `EMP-400203` Julien Faucher | Branch/process RCSA |
| Business process owners | G8–G9 per `ANB-ADM-GDL-0001` | First Line RCSA; incident reporting |
| CRO | `EMP-100004` | Appetite breaches; risk acceptances |
| CCO | `EMP-100005` | Conduct overlap; fraud nexus |
| Head of IT Operations | `EMP-500101` Ravi Subramanian | Technology incidents |
| CISO | `EMP-100010` Nadia Ferreira | Cyber events |

---

## 10. Risk Acceptance

| Severity | Approver | Max Duration |
|---|---|---|
| Low | Process owner + Op Risk | 180 days |
| Medium | Head of Operational Risk | 90 days |
| High | CRO | 60 days |
| Critical | CRO + BRC notification | 30 days — exceptional only |

Logged in ApexServe; referenced in ORC minutes.

---

## 11. Decision Tree — Incident Classification

```
Operational event
        │
        ├─ Financial loss or probable loss? ──YES──► REV- + loss recording
        ├─ Regulatory reportable? ──► CMP / Legal path
        ├─ Cyber / data breach? ──► `BP-SEC-IR` + `INC-*`
        ├─ CBS impact? ──► BCP / DR invocation
        └─ Near-miss only ──► REV- optional; trend analysis
```

---

## 12. Examples

**Example — SWIFT outage (`SCN-2026-SWF-001`):** 3-hour messaging failure. Wholesale payments delayed; `REV-202609-0088` records business disruption; gross loss USD 0; reputational review; `KRI-0042` amber. Remediation: secondary SWIFT path accelerated.

**Example — Insider fraud (`SCN-2026-INS-001`):** Employee overrides controls; USD 240k loss. `REV-202608-0033`; SAR consideration (`ANB-CMP-SOP-0004`); RCSA update for privileged access.

---

## 13. Related Documents

`ANB-RSK-POL-0001` · `ANB-RSK-STMT-0001` · `ANB-RSK-POL-0007` · `ANB-ITO-PLN-0002` · `ANB-CMP-GDL-0008` · `ANB-HRM-POL-0004` · `ANB-ADM-GDL-0001`

---

## 14. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-30 | D. Ramanathan | Initial operational risk policy |

---

## Appendix A — Operational Risk Heat Map (Enterprise View)

| Area | Residual | Trend |
|---|---|---|
| Technology / availability | Medium | ↑ cyber threat |
| Payments | Medium | Stable |
| Branch operations | Low–Medium | Stable |
| Third-party | Medium | Watch |
| Data quality | Medium | ↓ after remediation |

---

**End of Document** — `ANB-RSK-POL-0005` v1.0
