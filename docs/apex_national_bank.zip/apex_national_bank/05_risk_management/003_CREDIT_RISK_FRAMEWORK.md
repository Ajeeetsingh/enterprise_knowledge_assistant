# Apex National Bank — Credit Risk Framework

**Risk Framework | Credit Lifecycle, Ratings, Controls, and Portfolio Monitoring**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-FRM-0001` |
| **Document Title** | Credit Risk Framework |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) — Credit Risk |
| **Custodian** | Lars Henriksson, Head of Credit Risk (G9) — `EMP-400201` |
| **Approver** | Helena Brandt, CRO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-CRD-UW`, `BP-CRD-APPR`, `BP-CRD-EXC`, `BP-COLL-PROV`, `BP-RSK-STRESS` |
| **System of Record** | ApexCredit · ApexOrigin · ApexRisk · ApexModel |
| **Related Documents** | `ANB-CBK-POL-0001`, `ANB-RSK-POL-0001`, `ANB-RSK-STMT-0001` |

---

## 2. Purpose

This Framework defines how Apex National Bank identifies, measures, approves, monitors, and mitigates credit risk from origination through workout. It operationalises credit appetite (`RAM-0005`–`0007`) and integrates with the Loan Approval Policy, CECL provisioning, and GrCC governance.

---

## 3. Scope

All credit exposures: retail, mortgage, SMB, commercial, corporate, institutional, trade finance, and off-balance-sheet commitments. Excludes pure market/trading positions (Treasury) except counterparty credit.

---

## 4. Credit Lifecycle

```
Origination (ApexOrigin)
        │
        ├─ Application APP-* / customer CUS-*
        ├─ Underwriting & scoring (MDL-*)
        ├─ Risk rating CRR-* assigned
        ├─ Collateral valuation
        │
        ├─ Approval (delegated / GrCC / BRC)
        ├─ Documentation & booking (ApexCore)
        │
        ├─ Ongoing monitoring — covenants, annual review
        ├─ Watchlist / special assets (EMP-400209)
        │
        └─ Workout / charge-off / exit
```

---

## 5. Credit Risk Rating Scale (`CRR-####`)

| Code | Label | Definition | Review Frequency |
|---|---|---|---|
| `CRR-0001` | Strong | Excellent capacity; minimal concern | Annual |
| `CRR-0002` | Good | Stable; low default likelihood | Annual |
| `CRR-0003` | Satisfactory | Acceptable; normal monitoring | Annual |
| `CRR-0004` | Watch | Emerging weakness; heightened monitoring | Quarterly |
| `CRR-0005` | Special Mention | Potential weakness; action plan | Quarterly |
| `CRR-0006` | Substandard | Well-defined weakness; collateral reliance | Monthly |
| `CRR-0007` | Doubtful | Full collection improbable | Monthly |
| `CRR-0008` | Loss | Uncollectible | Immediate provisioning |

Retail scorecards map to master scale via `MDL-202402-0018` (retail PD model).

---

## 6. Lending Controls

| Control | Description | System |
|---|---|---|
| `CTL-CRD-001` | Dual approval above delegated limits | ApexOrigin |
| `CTL-CRD-002` | Independent Risk vote on GrCC | ApexCredit |
| `CTL-CRD-003` | KYC/sanctions clear before commitment | ApexKYC / `ANB-CMP-POL-0002` |
| `CTL-CRD-004` | Collateral perfection before draw | ApexDocs |
| `CTL-CRD-005` | Covenant testing quarterly for `CRR-0004`+ | ApexCredit |
| `CTL-CRD-006` | Concentration monitoring vs `RAM-0006` | ApexRisk |

---

## 7. Collateral

| Type | Valuation Frequency | Haircut (indicative) |
|---|---|---|
| Cash / deposits | Daily | 0–5% |
| Listed securities | Daily | 15–30% |
| Commercial real estate | Annual (external if > USD 10M) | 20–35% |
| Equipment | Annual | 30–50% |
| Accounts receivable | Quarterly | 40–60% |

Independent appraisal required for CRE > USD 10M and all substandard credits.

---

## 8. Concentration Risk

| Concentration | Limit | Monitor |
|---|---|---|
| CRE / total capital | `RAM-0006` | Monthly GrCC |
| Single name / capital | `RAM-0007` | ApexCredit daily |
| Industry (energy) | 8% of portfolio | ApexRisk |
| Geography (high-risk country) | Per country limit grid | Head of Credit Risk |
| Product (leveraged loan) | USD 12B notional cap | GrCC |

Breaches require remediation plan or BRC approval within 30 days.

---

## 9. Stress Testing

| Scenario | Description | Owner |
|---|---|---|
| `SCN-2026-CRD-001` | CRE price −30%; office vacancy spike | Head of Credit Risk |
| Baseline recession | Unemployment +3%; GDP −2% | `EMP-400205` + FIN |
| Sector shock | Energy default correlation | GrCC |
| Reverse stress | Identify scenarios breaching `RAM-0001` | Enterprise Risk |

Results feed CECL (`MDL-202401-0044`) and capital plan (`EMP-600111`).

---

## 10. Portfolio Monitoring

| Activity | Frequency | Output |
|---|---|---|
| Early warning indicators | Weekly | `KRI-0031`–`KRI-0035` |
| Watchlist review | Monthly | GrCC pack |
| Annual credit review | Per policy | ApexOrigin refresh |
| Covenant compliance | Quarterly | Exception report |
| Impairment / CECL | Monthly | ApexLedger / FIN close |
| Large exposure reporting | Quarterly | Regulatory |

**KRI examples:** `KRI-0031` — `CRR-0004`+ migration rate; `KRI-0032` — criticized exposure / total loans; `KRI-0033` — new origination risk score drift.

---

## 11. Credit Committees

| Committee | Authority | Chair |
|---|---|---|
| Regional Credit Committees | To USD 50M commercial | Regional Credit Officer (G8) |
| Group Credit Committee (GrCC) | To USD 500M | `EMP-100004` CRO |
| Board Risk Committee | > USD 500M; related party | Hugo Bertrand |

Voting: Risk affirmative required (`ANB-LEG-REF-0003` §7.9).

---

## 12. Decision Tree — Approval Routing

```
Exposure request
        │
        ├─ Retail within scorecard auto-decline? ──► Decline
        ├─ ≤ Regional limit? ──► Regional CC (Risk vote required)
        ├─ ≤ USD 500M? ──► GrCC
        └─ > USD 500M or related party ──► BRC
```

Financial crime concern (`CUS-*` / `CR-P`) — Compliance veto regardless of credit merit.

---

## 13. Examples

**Example 1 — Watchlist migration:** Commercial borrower `CUS-06291004` misses covenant; revenue decline 22%. Rating downgraded `CRR-0003` → `CRR-0004`. `RREG-202608-0155` updated; quarterly GrCC watchlist; RM action plan within 30 days.

**Example 2 — CRE stress:** `SCN-2026-CRD-001` increases criticized CRE by USD 1.2B. `RAM-0006` approaches tolerance. New office CRE paused; `EMP-400209` special assets capacity increased.

---

## 14. Related Documents

`ANB-CBK-POL-0001` · `ANB-CBK-TPL-0003` · `ANB-RSK-POL-0004` · `ANB-RSK-STMT-0001` · `ANB-CMP-POL-0001` · `ANB-FIN-SOP-0003` · `ANB-HRM-POL-0008` (credit certification)

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-30 | L. Henriksson | Initial credit framework |

---

## Appendix A — Credit Risk Heat Map (Illustrative)

| Segment | Inherent | Controls | Residual |
|---|---|---|---|
| Prime retail mortgage | Medium | Strong | Low |
| SMB | Medium | Adequate | Medium |
| Middle-market C&I | Medium–High | Strong | Medium |
| CRE office | High | Enhanced | Medium–High |
| Leveraged finance | High | Strict | Medium |

---

**End of Document** — `ANB-RSK-FRM-0001` v1.0
