# Apex National Bank — Model Risk Management Policy

**Enterprise Policy | Model Inventory, Validation, AI/ML Governance, and Lifecycle**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-POL-0004` |
| **Document Title** | Model Risk Management Policy |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) — Model Risk |
| **Custodian** | Kenji Okada, Head of Model Risk (G8) — `EMP-400204` |
| **Approver** | Helena Brandt, CRO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-MDL-INV`, `BP-MDL-VAL`, `BP-MDL-MON` |
| **System of Record** | ApexModel · ApexRisk · ApexInsight |
| **Regulatory Reference** | SR 11-7; OCC 2011-12; EU AI Act (high-risk AI where applicable) |
| **Related Documents** | `ANB-RSK-POL-0001`, `ANB-RSK-FRM-0001`, `ANB-CMP-POL-0001` |

---

## 2. Purpose

Models materially affect credit, fraud, AML, liquidity, and capital decisions. This Policy governs the full model lifecycle: inventory, development, independent validation, approval, deployment, monitoring, challenger models, and retirement — including traditional statistical models and AI/ML systems.

---

## 3. Scope

All models meeting the SR 11-7 definition: quantitative method applying statistical, economic, financial, or mathematical theories to process input data into quantitative estimates. Includes AI/ML, scorecards, CECL, VaR, AML TM rules with statistical calibration, and vendor models used by the Bank.

---

## 4. Definitions

| Term | Definition |
|---|---|
| **Model** | `MDL-########` — registered in ApexModel |
| **Model Tier** | 1 (material) / 2 (significant) / 3 (limited) |
| **Validation** | `MVAL-########` — independent challenge of conceptual soundness, inputs, outputs, use |
| **Challenger** | Parallel model or expert overlay testing incumbent |
| **AI/ML Model** | Models using machine learning with training data — enhanced governance |

---

## 5. Model Inventory (`BP-MDL-INV`)

Every model must have:

| Field | Required |
|---|---|
| Model ID | `MDL-########` |
| Owner (business) | Named G6+ |
| Developer | Team / vendor |
| Tier | 1 / 2 / 3 |
| Use case | Credit, AML, fraud, etc. |
| Input data sources | ApexCore, bureau, etc. |
| Validation status | Current / overdue / conditional |
| Next validation date | Per tier schedule |
| AI/ML flag | Y/N — if Y, enhanced controls |

**Quarterly attestation** by model owners to Head of Model Risk.

---

## 6. Apex National Bank Model Register (Extract)

| Model ID | Name | Type | Tier | Owner Function |
|---|---|---|---|---|
| `MDL-202401-0044` | CECL allowance — commercial | Statistical | 1 | FIN / RSK |
| `MDL-202402-0018` | Retail mortgage PD scorecard | Logistic regression | 1 | RSK / RTL |
| `MDL-202403-0022` | Commercial rating — financials | Expert + score | 1 | RSK / CBK |
| `MDL-202404-0055` | LCR / liquidity forecast | Time series | 1 | TRY / FIN |
| `MDL-202405-0061` | Market VaR — trading book | Monte Carlo | 1 | TRY |
| `MDL-202406-0077` | AML transaction monitoring calibration | Rules + ML | 1 | CMP |
| `MDL-202407-0088` | Fraud — real-time payment scoring | Gradient boosting ML | 1 | CMP / RSK |
| `MDL-202408-0099` | Customer digital onboarding fraud | Neural network ML | 2 | CMP / RTL |
| `MDL-202409-0105` | Prepayment model — mortgage | Statistical | 2 | RSK |
| `MDL-202410-0112` | Collections propensity | ML | 2 | RTL |
| `MDL-202411-0120` | Chatbot intent (ApexAssist) | NLP / LLM | 2 | CST / ITO |
| `MDL-202412-0133` | HR attrition risk (analytics) | ML | 3 | HRM |

Vendor-hosted models require same tiering and validation wrap.

---

## 7. Validation (`BP-MDL-VAL`)

| Tier | Initial Validation | Periodic Revalidation |
|---|---|---|
| Tier 1 | Full independent validation before production | Annual |
| Tier 2 | Full before production | Every 2 years |
| Tier 3 | Simplified / self-assessment with Model Risk QA | Every 3 years |

### 7.1 Validation Work Program

1. Conceptual soundness and methodology
2. Data quality and representativeness
3. Implementation and code review
4. Outcomes analysis / back-testing
5. Sensitivity and stress
6. Use test — appropriate for decision context
7. For AI/ML: bias/fairness testing, explainability, drift monitoring, training data lineage

Output: `MVAL-202607-0012` with rating **Satisfactory** / **Conditional** / **Unsatisfactory**.

**Unsatisfactory Tier 1:** Model use suspended until remediated; CRO and BRC notified.

---

## 8. Approval Workflow

| Action | Approver |
|---|---|
| Tier 1 production use | Head of Model Risk + business owner |
| Tier 1 conditional use | CRO approval with time-bound plan |
| Material model change | Revalidation or delta validation |
| AI/ML customer credit decision | CRO + fair lending review (Compliance) |
| Vendor model reliance | Head of Model Risk + Third-Party Risk |

---

## 9. Monitoring (`BP-MDL-MON`)

| Activity | Frequency | Trigger |
|---|---|---|
| Performance metrics (AUC, PSI, RMSE) | Monthly Tier 1 | Breach tolerance |
| Population stability | Monthly | PSI > 0.25 |
| Override rates | Monthly | Trend review |
| Drift (AI/ML) | Continuous | Auto-alert |
| Outcome tracking | Quarterly | CECL, default rates |

**KRI:** `KRI-0050` — Tier 1 models with overdue validation (target 0).

---

## 10. AI/ML Governance

| Requirement | Detail |
|---|---|
| Inventory | All AI/ML flagged in ApexModel |
| Explainability | SHAP or equivalent for Tier 1 credit/fraud |
| Fair lending | Disparate impact testing — Compliance sign-off |
| Training data | Documented; no unlawful bias; retention `RET-MDL-10Y` |
| Human override | Mandatory for adverse credit action |
| LLM use | `MDL-202412-*` — no autonomous customer credit decisions; human-in-loop |
| Adversarial robustness | Fraud ML tested annually |

Models `MDL-202407-0088` and `MDL-202408-0099` reviewed jointly with `EMP-400101` (Financial Crime) and `EMP-400106` (Fraud).

---

## 11. Challenger Models

Tier 1 credit and CECL models require challenger or overlay:

| Incumbent | Challenger Approach |
|---|---|
| `MDL-202402-0018` | Expert judgment sample + bureau-only shadow |
| `MDL-202401-0044` | Top-down allowance comparison |
| `MDL-202406-0077` | Rule-only baseline vs ML-augmented |

Challenger results reported to GrCC / ORC annually.

---

## 12. Model Retirement

```
Retirement trigger
        │
        ├─ Superseded by new MDL-*
        ├─ Business/product discontinued
        ├─ Unsatisfactory validation unresolved
        │
        ├─ Decommission plan: parallel run period, cutover date
        ├─ Archive documentation RET-MDL-10Y
        └─ ApexModel status = Retired
```

---

## 13. Examples

**Example 1:** `MVAL-202607-0012` on `MDL-202407-0088` finds PSI drift on geographic feature. Conditional approval — 90-day recalibration; enhanced monitoring weekly.

**Example 2:** Vendor scorecard for SMB without validation wrap — **prohibited** from credit decision until `VRA-*` and `MVAL-*` complete.

---

## 14. Related Documents

`ANB-RSK-FRM-0001` · `ANB-RSK-POL-0005` · `ANB-RSK-FRM-0002` · `ANB-CMP-POL-0001` · `ANB-CBK-POL-0001` · `ANB-HRM-POL-0008` · `ANB-ADM-POL-0001` (`RET-MDL-10Y`)

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-30 | K. Okada | Initial model risk policy; AI/ML addendum |

---

## Appendix A — Model Tier Decision Tree

```
New quantitative method
        │
        ├─ Affects credit, capital, liquidity, or AML filing? ──► Tier 1
        ├─ Material operational or fraud decision? ──► Tier 1 or 2
        ├─ Internal MI only, limited impact? ──► Tier 3
        └─ Uncertain ──► Head of Model Risk determination
```

---

**End of Document** — `ANB-RSK-POL-0004` v1.0
