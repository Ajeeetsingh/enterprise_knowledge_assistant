# Apex National Bank — Business Continuity Policy

**Enterprise Policy | BCP Governance, Critical Services, Crisis Management, and Testing**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-POL-0007` |
| **Document Title** | Business Continuity Policy |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) + IT Operations (ITO) + Administration (ADM) — joint |
| **Custodian** | Sandra Okoye, Head of Business Continuity (G8) — `EMP-400207` |
| **Approver** | Daniel K. Ortega, COO (G11) |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-RES-BIA`, `BP-RES-BCP`, `BP-RES-TOL` |
| **System of Record** | ApexServe · ApexRisk · ApexDocs |
| **Companion Plan** | `ANB-ITO-PLN-0001` Business Continuity Plan (operational detail) |
| **Related Documents** | `ANB-RSK-POL-0001`, `ANB-ITO-PLN-0002`, `ANB-ISC-SOP-0003` |

---

## 2. Purpose

Business continuity ensures Apex National Bank continues to deliver critical services through disruption — cyberattack, pandemic, natural disaster, facility loss, or vendor failure. This Policy establishes governance, critical business service identification, recovery objectives, crisis management, alternate sites, communications, and the testing programme.

---

## 3. Scope

All legal entities; all CBS; all sites (`SIT-####`); third-party dependencies. Technology recovery detailed in `ANB-ITO-PLN-0002`; this Policy covers **business** continuity and crisis coordination.

---

## 4. Governance

| Body | Role |
|---|---|
| Board Technology & Operational Resilience Committee (BTR) | Approves impact tolerances; reviews test outcomes |
| ExCo | BCP invocation; crisis authority |
| COO (`EMP-100003`) | Accountable executive; invocation with CIO/CRO |
| Operational Risk Committee (ORC) | Loss and resilience reporting |
| Crisis Management Team (CMT) | Tactical response — see §8 |
| Head of Business Continuity | Programme owner; BIA and test calendar |

---

## 5. Critical Business Services (`CBS-########`)

Authoritative register in `ANB-RSK-POL-0001` Appendix A.4. Summary:

| CBS ID | Service | Process Owner | Impact Tolerance |
|---|---|---|---|
| `CBS-00000001` | Retail payments & account servicing | Head of Consumer Banking | 4 hours |
| `CBS-00000002` | Wholesale payments & SWIFT | Group Treasurer | 2 hours |
| `CBS-00000003` | Core ledger & real-time posting | `EMP-500101` Head of IT Operations | 2 hours |
| `CBS-00000004` | Customer onboarding & KYC | `EMP-400112` Head of KYC Ops | 8 hours |
| `CBS-00000005` | Treasury & liquidity management | Group Treasurer | 4 hours |

Additional Important Business Services (IBS) tracked for UK/EU operational resilience rules.

---

## 6. Business Impact Analysis (`BIA-########`)

| BIA Element | Requirement |
|---|---|
| Frequency | Full enterprise BIA every 2 years; delta on material change |
| Output | `BIA-202605-0003` — maps CBS → processes → systems → vendors |
| Dependencies | ApexCore, ApexPay, ApexKYC, SWIFT, branches |
| Workarounds | Manual procedures documented per CBS |
| Staffing | Minimum staffing models per scenario |

**BIA owner:** Head of Business Continuity with business unit input.

---

## 7. Recovery Objectives

| Tier | RTO (Recovery Time) | RPO (Recovery Point) | Example CBS |
|---|---|---|---|
| Tier 1 | ≤ 2 hours | 0 (sync replication) | `CBS-00000003` |
| Tier 2 | ≤ 4 hours | ≤ 15 minutes | `CBS-00000001`, `CBS-00000005` |
| Tier 3 | ≤ 8 hours | ≤ 1 hour | `CBS-00000004` |
| Tier 4 | ≤ 24 hours | ≤ 4 hours | Non-critical internal |

Aligned with `ANB-RSK-STMT-0001` §9 and ApexCore profile (RTO 2h, RPO 0).

---

## 8. Crisis Management

### 8.1 Crisis Management Team

| Role | Member | Responsibility |
|---|---|---|
| Crisis Chair | COO (`EMP-100003`) | Overall command |
| Technology | CIO (`EMP-100007`) | DR coordination |
| Risk | CRO (`EMP-100004`) | Appetite; regulatory liaison |
| Security | CISO (`EMP-100010`) | Cyber incidents |
| Communications | CMO / Group Communications | Internal/external messaging |
| Legal | General Counsel (`EMP-100006`) | Regulatory notification |
| Business | Affected BU head | Workarounds; staffing |

### 8.2 Invocation Workflow

```
Disruption detected
        │
        ├─ Severity assessment (ITO / ISC / BC)
        ├─ CBS impact predicted within tolerance?
        │       NO ──► CMT activation; BCP-######## invoked
        │
        ├─ ExCo notification if CBS at risk or media/regulatory
        ├─ Execute playbooks (manual fallback, alternate site)
        │
        └─ Stand down when CBS stable 24h; post-incident review REV-*
```

**Invocation authority:** Site Incident Manager (G6+) initiates; COO confirms CMT within 1 hour for Severity 1.

---

## 9. Alternate Sites

| Site ID | Location | Purpose |
|---|---|---|
| `SIT-0001` | Lower Manhattan, NY | Primary data centre |
| `SIT-0002` | Charlotte, NC | DR data centre; warm standby |
| `SIT-0010` | Plano, TX | Branch continuity hub — Southwest |
| `SIT-0020` | Dublin, IE | EMEA continuity |
| `SIT-0100` | San Francisco, CA | Technology / cyber ops |
| `SIT-0412` | Charlotte — SouthPark | Flagship branch (`ANB-CMP-SOP-0007` cash) |

Work-from-home capacity supports `SCN-2026-PAN-001` (40% absenteeism). Critical trading and ops staff have assigned alternate locations.

---

## 10. Communication Plans

| Audience | Channel | Owner | Timing |
|---|---|---|---|
| Employees | Apex Mail, Teams, mass notification | HR + BC | Within 30 min Severity 1 |
| Regulators | Formal notification | Legal + Compliance | Per jurisdiction (e.g. 24–72h) |
| Customers | Website, mobile app, contact centre scripts | CST + MKT | When service impact confirmed |
| Media | Press office — COO/CEO approval | MKT + Legal | If public impact |
| Vendors | Account managers | PRC | As needed for recovery |

No customer communication of incomplete information; coordinate with `SCN-2026-REG-001` if enforcement overlap.

---

## 11. Testing Programme

| Test Type | Frequency | Scope |
|---|---|---|
| Tabletop | Quarterly | Rotating scenarios from §12 |
| Walkthrough | Semi-annual | Single CBS playbook |
| Simulation | Annual | Multi-team; may include vendors |
| Full interruption (tech) | Annual | Per `ANB-ITO-PLN-0002` |
| Branch exercise | Annual | `SIT-0412` region sample |

Results reported to ORC and BTR; deficiencies tracked to closure in ApexServe.

**Canonical test:** `BCP-202604-0003` — tabletop `SCN-2026-COR-001`; participants included RTL, TRY, ITO; gaps in manual wire procedure remediated.

---

## 12. Scenario Library (Enterprise)

All scenarios in `ANB-RSK-POL-0001` §11 apply. BCP-specific emphasis:

| Scenario | BCP Focus |
|---|---|
| `SCN-2026-CYB-001` | Ransomware — isolate; manual payment limits |
| `SCN-2026-COR-001` | Core outage — DR handoff; customer comms |
| `SCN-2026-PAN-001` | Staff absenteeism — cross-training activation |
| `SCN-2026-FLD-001` | NYC flood — `SIT-0001` fail to Charlotte |
| `SCN-2026-EQ-001` | SF earthquake — `SIT-0100` staff safety |
| `SCN-2026-BRN-001` | Branch closure — digital redirect; ATM cash |
| `SCN-2026-PWR-001` | Generator test; graceful degradation |
| `SCN-2026-TEL-001` | WAN failure — redundant paths |
| `SCN-2026-REG-001` | Consent order — resource reallocation |

---

## 13. Policy Statements

**BCP-1.** Every CBS has an owner, documented workaround, and tested plan (`BCP-########`).

**BCP-2.** Impact tolerances are not exceeded without BTR notification and remediation plan.

**BCP-3.** Third-party CBS dependencies require vendor BCP evidence (Tier 1 — `ANB-RSK-FRM-0002`).

**BCP-4.** Post-incident reviews mandatory for all CBS-impacting events within 20 business days.

**BCP-5.** Records retained `RET-RSK-7Y`; exercise evidence `RET-AUD-7Y`.

---

## 14. Examples

**Example — Branch unavailability (`SCN-2026-BRN-001`):** Hurricane closes `SIT-0412` region 72 hours. Mobile and online messaging activated; nearest branches listed; cash services via partner ATMs; CTR monitoring continues (`EMP-400104`); no CBS tolerance breach.

**Example — Pandemic (`SCN-2026-PAN-001`):** 38% absenteeism. CMT activates tiered staffing; critical roles in ApexPeople roster; KYC backlog managed within `CBS-00000004` 8h tolerance via overtime and vendor surge.

---

## 15. Related Documents

`ANB-RSK-POL-0001` · `ANB-RSK-STMT-0001` · `ANB-RSK-POL-0005` · `ANB-ITO-PLN-0002` · `ANB-ISC-SOP-0003` · `ANB-LEG-REF-0003` (BTR) · `ANB-HRM-POL-0004` · `ANB-CMP-SOP-0007`

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-30 | S. Okoye | Initial BCP policy |

---

## Appendix A — BCP Document Checklist (`BCP-########`)

- [ ] CBS ID and owner
- [ ] RTO/RPO targets
- [ ] Minimum staffing / roles
- [ ] Manual workaround steps
- [ ] System dependencies (`AST-*`, vendors)
- [ ] Communication tree
- [ ] Last test date and result
- [ ] Next test scheduled

---

**End of Document** — `ANB-RSK-POL-0007` v1.0
