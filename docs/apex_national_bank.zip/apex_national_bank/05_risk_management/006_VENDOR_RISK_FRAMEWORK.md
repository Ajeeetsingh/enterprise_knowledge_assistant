# Apex National Bank — Vendor Risk Framework

**Risk Framework | Third-Party Classification, Due Diligence, Monitoring, and Exit**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RSK-FRM-0002` |
| **Document Title** | Vendor Risk Framework |
| **Version** | 1.0 |
| **Owner** | Risk (RSK) + Procurement (PRC) — joint |
| **Custodian** | Nathan Brooks, Head of Third-Party Risk (G8) — `EMP-400208` |
| **Approver** | Helena Brandt, CRO (G11) and Ian McAllister, CPO (G10) |
| **Classification** | Confidential (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-VEN-DD`, `BP-VEN-MON`, `BP-VEN-CONC`, `BP-PRC-TPRM` |
| **System of Record** | ApexVendor · ApexRisk · ApexSource |
| **Companion Policy** | `ANB-PRC-POL-0002` Third-Party Risk Management Policy |
| **Related Documents** | `ANB-RSK-POL-0001`, `ANB-PRC-POL-0001`, `ANB-ISC-POL-0001` |

---

## 2. Purpose

Third-party relationships transfer or concentrate operational, cyber, compliance, and strategic risk. This Framework defines vendor classification, due diligence depth, security and financial assessment, critical vendor standards, continuous monitoring, and exit strategy — implementing the risk view of enterprise TPRM alongside Procurement execution.

---

## 3. Scope

All vendors, suppliers, outsourcers, cloud providers, and material subcontractors processing Bank data or supporting CBS. Employees and correspondent banks follow separate policies (`ANB-HRM-SOP-0007`, `ANB-CMP-SOP-0006`).

---

## 4. Vendor Classification

| Tier | Criteria | Examples | DD Depth |
|---|---|---|---|
| **Tier 1 — Critical** | Supports CBS; irreplaceable < 12 months; or > USD 50M annual spend | Core hosting, SWIFT connectivity, ApexCore MSP | Enhanced + annual |
| **Tier 2 — Important** | Material data access or regulatory exposure | KYC data provider, card processor | Standard + biennial |
| **Tier 3 — Standard** | Limited data; substitutable | Office supplies, training content | Lightweight |
| **Tier 4 — Low** | No Bank data; de minimis spend | Public data feeds | Minimal |

Tier assignment recorded in ApexVendor; Risk concurrence required for Tier 1.

---

## 5. Due Diligence Workflow (`BP-VEN-DD`)

```
Vendor request (ApexSource)
        │
        ├─ Tiering workshop — PRC + Risk + ISC + sponsor
        ├─ Create VRA-########
        │
        ├─ Financial health review (Tier 1/2)
        ├─ Security questionnaire + SOC 2 / ISO 27001 (Tier 1/2)
        ├─ Privacy / GDPR (LEG review if EU data)
        ├─ Compliance / sanctions (CMP for payment rails)
        ├─ BCP/DR capability (Tier 1)
        │
        ├─ APPROVE / APPROVE WITH CONDITIONS / DECLINE
        └─ Contract clauses per ANB-LEG-CTR-0001
```

**SLA:** Tier 1 DD complete before contract signature — target 30 business days.

---

## 6. Critical Vendor Register (Extract)

| Vendor ID | Name | Service | CBS Link | VRA |
|---|---|---|---|---|
| `VEN-004521` | Temenos Services Ltd | ApexCore application support | `CBS-00000003` | `VRA-202605-0044` |
| `VEN-008812` | AWS (Amazon Web Services) | Cloud — ApexCloud primary | Multiple CBS | `VRA-202606-0012` |
| `VEN-003301` | SWIFT + managed connector partner | Messaging | `CBS-00000002` | `VRA-202604-0099` |
| `VEN-012044` | World-Check (LSEG) | Sanctions/KYC data | `CBS-00000004` | `VRA-202607-0033` |
| `VEN-015522` | FIS — card processing | Debit/credit rails | `CBS-00000001` | `VRA-202608-0018` |

---

## 7. Security Reviews

| Tier | Requirements |
|---|---|
| Tier 1 | SOC 2 Type II (< 12 months); annual pen test summary; right-to-audit; incident notification 24h |
| Tier 2 | SOC 2 or ISO 27001; questionnaire |
| Tier 3 | Standard questionnaire |

ISC (`EMP-100010`, `EMP-500201`) performs technical assessment; findings tracked in ApexVendor.

**Scenario `SCN-2026-VEN-001`:** Critical vendor compromise — playbooks require notification within 4h; alternate vendor or manual procedure per `BCP-*`.

---

## 8. Financial Assessments

Tier 1/2: D&B rating, audited financials (public), or parent guarantee. Trigger re-assessment on:

- Credit rating downgrade below investment grade
- M&A affecting service
- Material litigation or insolvency rumour

Concentration reviewed by `BP-VEN-CONC` — `RAM-0010` (zero critical vendors without exit plan).

---

## 9. Continuous Monitoring

| Activity | Frequency | Owner |
|---|---|---|
| SOC report refresh | Annual Tier 1 | Third-Party Risk |
| Performance / SLA review | Quarterly Tier 1 | PRC category manager |
| Subcontractor change notification | Event-driven | Vendor manager |
| Concentration dashboard | Quarterly | `EMP-400208` + CRO |
| Issue escalation | Event-driven | ORC if operational impact |

**KRI:** `KRI-0060` — Tier 1 vendors with overdue DD refresh (target 0).

---

## 10. Exit Strategy

Every Tier 1 vendor requires documented exit plan in ApexVendor:

| Element | Required |
|---|---|
| Substitutability assessment | Alternate vendor or insource option |
| Data return / destruction | Contractual and tested |
| Transition timeline | Realistic — typically 12–24 months for core |
| CBS impact | Mapped to `CBS-*` |
| Last test date | Tabletop or partial switch |

**Example:** `VEN-008812` (AWS) — multi-region architecture; exit to secondary cloud documented; full exit deemed 18-month programme; `RAM-0010` monitored.

---

## 11. Roles

| Role | Employee | Responsibility |
|---|---|---|
| Head of Third-Party Risk | `EMP-400208` Nathan Brooks | Framework; Tier 1 oversight |
| CPO | `EMP-100013` Ian McAllister | Sourcing; contract execution |
| CISO | `EMP-100010` Nadia Ferreira | Security assessment |
| CRO | `EMP-100004` | Concentration; appetite |
| Business sponsor | G9+ | Ongoing performance |
| Compliance | `EMP-100005` | Regulated activity vendors |

---

## 12. Decision Tree — Tiering

```
New vendor
        │
        ├─ Accesses customer NPI/PII? ──► Minimum Tier 2
        ├─ Supports CBS or Tier 1 system? ──► Tier 1
        ├─ Spend > USD 50M/year? ──► Tier 1
        ├─ Substitutable within 90 days? ──► Likely Tier 2/3
        └─ Else ──► Tier 3/4
```

---

## 13. Examples

**Example — Cloud failure (`SCN-2026-CLD-001`):** AWS us-east-1 impairment. `VEN-008812` incident bridge; failover to us-west-2 per DR plan; `REV-202608-0155` near-loss event; VRA updated with lessons learned.

**Example — Vendor compromise (`SCN-2026-VEN-001`):** Managed connectivity provider breach. Traffic isolated; `VRA-202604-0099` enhanced monitoring; exit plan acceleration approved by ORC.

---

## 14. Related Documents

`ANB-PRC-POL-0002` · `ANB-PRC-POL-0001` · `ANB-RSK-POL-0005` · `ANB-RSK-POL-0007` · `ANB-ITO-PLN-0002` · `ANB-CMP-POL-0001` · `ANB-FIN-SOP-0008` (vendor payment)

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-30 | N. Brooks | Initial vendor risk framework |

---

## Appendix A — Vendor Risk Heat Map

| Vendor Tier | Count | Avg Residual | Open Issues |
|---|---|---|---|
| Tier 1 | 42 | Medium | 3 High |
| Tier 2 | 318 | Low–Medium | 12 Medium |
| Tier 3 | 2,840 | Low | — |
| Tier 4 | 8,200+ | Low | — |

---

**End of Document** — `ANB-RSK-FRM-0002` v1.0
