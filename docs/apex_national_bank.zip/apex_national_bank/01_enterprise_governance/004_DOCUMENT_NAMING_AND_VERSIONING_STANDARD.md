# Apex National Bank — Document Naming and Versioning Standard

**Enterprise Governance Standard | Identifiers, Filenames, Folder Hierarchy, and Version Lifecycle**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-STD-0007` |
| **Document Title** | Apex National Bank — Document Naming and Versioning Standard |
| **Version** | 1.0 |
| **Owner** | Enterprise Knowledge Management Office (EKMO), Administration Department (ADM) |
| **Custodian** | Nadine Okafor, Vice President, Enterprise Knowledge Management (G6) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer |
| **Secondary Approvers** | Margaret Sullivan, General Counsel; Thomas Nakamura, Chief Audit Executive |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-05-22 |
| **Effective Date** | 2026-07-01 |
| **Last Updated** | 2026-06-30 |
| **Review Cycle** | Annual (next review 2027-06-30) |
| **Supersedes** | None — initial published standard |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Governing Body** | Enterprise Knowledge Council (EKC) |
| **System of Record** | ApexDocs |
| **Keywords** | naming convention, document ID, versioning, filename, folder hierarchy, supersession, archive, OCR, evidence naming |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-ADM-STD-0005` · `ANB-ADM-STD-0006` · `ANB-ADM-POL-0001` · `ANB-ADM-MTX-0001` · `ANB-LEG-REF-0003` · `ANB-ADM-GDL-0001` |

> **Authority.** This Standard elaborates §10 (Document Naming Conventions) and §11 (Versioning Standards) of `ANB-ADM-REF-0001`. The conventions published in the Master Company Profile are reproduced here unchanged and extended to record classes not addressed there. Where any conflict exists, `ANB-ADM-REF-0001` prevails.

---

## 2. Document Purpose

A document that cannot be found, cited, or proven to be current is a control failure. During the 2025 OCC examination and the FY2025 SOX cycle, the single most common evidence deficiency raised across the industry was the inability to demonstrate *which version of a procedure was in force on a given date*.

This Standard removes that ambiguity by defining:

1. The **canonical document identifier** — permanent, never reused, never re-issued.
2. The **filename convention** applied to every rendition of every version.
3. The **folder hierarchy** in ApexDocs and ApexVault, aligned to the taxonomy in `ANB-ADM-STD-0006`.
4. The **version lifecycle** from draft through destruction, with the state transitions, approvals, and evidence required at each gate.
5. **Record-class naming rules** for the artefact families the Bank produces at volume: OCR captures, email attachments, audit workpapers, evidence, minutes, customer files, loan files, contracts, and incidents.

---

## 3. Scope

### 3.1 Applies To

| In Scope | Detail |
|---|---|
| Controlled documents | All types in `CV-DOCTYPE` (POL, STD, SOP, GDL, MAN, PLN, REF, HBK, CHK, MTX, FRM, TPL, CTR, RPT, MIN, MEM, REG, TRN, LOG, PRE) |
| Operational records | Customer, KYC, loan, case, incident, dispute, and evidence records |
| Renditions | PDF, DOCX, XLSX, MD, MSG, TIFF, and any other stored rendition of a controlled version |
| Storage locations | ApexDocs, ApexVault, ApexKYC, ApexOrigin, ApexAudit, ApexGuard, ApexServe attachments |
| All legal entities | Apex National Bank and all subsidiaries listed in `ANB-ADM-REF-0001` §2 |

### 3.2 Does Not Apply To

- Structured data records inside ApexCore, ApexLedger, and ApexInsight (no filename exists)
- Personal working notes never filed as a record
- System-generated log files retained under IT Operations standards
- Third-party documents received in their original form, which are **wrapped** rather than renamed (Section 9.6)

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Any document's authority and currency provable from its name alone | 100% of published renditions name-compliant |
| O-2 | Point-in-time reconstruction for examination and litigation | Any version in force on any date retrievable within 1 business day |
| O-3 | Eliminate duplicate and ambiguous copies | Zero `FINAL`, `v2 final`, `latest` artefacts in controlled libraries |
| O-4 | Machine-parseable naming for indexing and the Knowledge Graph | ≥ 99% automated parse success at ingestion |
| O-5 | Consistent supersession | Zero instances of two `Published` versions of one document ID |
| O-6 | Retention executable by name and metadata | 100% of records mapped to a `retention_code` at filing |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Document ID** | The permanent identifier `ANB-<DEPT>-<TYPE>-<SEQ>`. Assigned once, never reused, survives reorganisation. |
| **Version** | An approved, immutable state of a Document ID, expressed `Major.Minor`. |
| **Rendition** | A stored file representing a version in a particular format. |
| **Short Title** | The abbreviated human-readable title element of a filename, ≤ 40 characters. |
| **Status Token** | The lifecycle state embedded in a filename: `DRAFT`, `REVIEW`, `APPROVED`, `PUBLISHED`, `SUPERSEDED`, `ARCHIVED`. |
| **Supersession** | The act of replacing a `Published` version with a newer one, demoting the prior to `Superseded`. |
| **Working Copy** | A pre-approval draft in the ApexDocs draft library; not citable, not evidence. |
| **Record Copy** | The declared authoritative instance of a record for retention purposes. |
| **Convenience Copy** | Any duplicate outside the system of record; carries no authority and must not be cited. |
| **Wrapper Record** | A controlled container for an inbound third-party file whose original name must be preserved. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **EKMO (ADM)** | Owns this Standard, the Document ID register, and sequence allocation. Runs monthly naming compliance reporting. Executes bulk remediation. |
| **Document Owner (Department Head or delegate)** | Accountable for correct identifiers, versions, and supersession within the department's estate. |
| **Document Custodian (G5–G6)** | Requests IDs, applies names, executes lifecycle transitions, retires superseded copies. |
| **Author** | Produces content; must not self-approve (see `ANB-ADM-MTX-0001` §4). |
| **Approver** | Signs the version in ApexDocs workflow, fixing the effective date. |
| **Legal (LEG)** | Applies and releases legal hold, which freezes archive and destruction transitions. |
| **Records Management Team (ADM)** | Executes archive and destruction transitions under `ANB-ADM-POL-0001`. |
| **IT Operations (ITO)** | Enforces naming validation in ApexDocs; maintains ApexVault immutability and WORM configuration. |
| **Internal Audit (IAD)** | Tests naming and version integrity as part of records and SOX control testing. |
| **Compliance (CMP)** | Confirms regulated documents are retrievable point-in-time for supervisory requests. |

---

## 7. Standard — Document Identifier

### 7.1 Structure

```
ANB-<DEPT>-<TYPE>-<SEQ>
```

| Segment | Rule |
|---|---|
| `ANB` | Fixed enterprise prefix for all legal entities |
| `<DEPT>` | Three-letter canonical department code (`CV-DEPT`): HRM, FIN, RTL, CBK, TRY, LEG, CMP, RSK, ISC, ITO, CST, IAD, MKT, PRC, ADM |
| `<TYPE>` | Three-letter document type code (`CV-DOCTYPE`) |
| `<SEQ>` | Four-digit zero-padded sequence, allocated per department and type by EKMO |

### 7.2 Identifier Rules

1. **Permanence.** A Document ID is never reused, even after destruction of the document.
2. **Ownership transfer.** If ownership moves between departments, the ID does **not** change; `owner_department` metadata changes and a `MEM` records the transfer. Renumbering would break every inbound citation.
3. **No embedded semantics beyond the four segments.** Dates, versions, statuses, and geographies never appear in the ID.
4. **Allocation.** IDs are requested through ApexServe and allocated by EKMO within 2 business days. Self-allocation is prohibited.
5. **Retirement.** IDs of retired documents remain in the register marked `Retired` with a pointer to the replacement.
6. **Sub-identifiers.** Instance records derived from a controlled template use the suffix form `ANB-<DEPT>-<TYPE>-<SEQ>-<INSTANCE>` (e.g., `ANB-CMP-FRM-0003-REC-04928311`).

### 7.3 Document Type Codes

| Code | Type | Code | Type |
|---|---|---|---|
| `POL` | Policy | `FRM` | Form |
| `STD` | Standard | `TPL` | Template |
| `SOP` | Standard Operating Procedure | `CTR` | Contract / Agreement |
| `GDL` | Guideline | `RPT` | Report |
| `MAN` | Manual | `MIN` | Minutes |
| `PLN` | Plan | `MEM` | Memorandum |
| `REF` | Reference Document | `REG` | Regulatory Filing |
| `HBK` | Handbook | `TRN` | Training Material |
| `CHK` | Checklist | `LOG` | Register / Log |
| `MTX` | Matrix | `PRE` | Presentation |

---

## 8. Standard — Filename Convention

### 8.1 Controlled Document Filenames

```
<DocumentID>_<ShortTitle>_v<Major>.<Minor>_<STATUS>_<YYYYMMDD>.<ext>
```

| Element | Rule |
|---|---|
| `ShortTitle` | PascalCase or hyphenated, ≤ 40 characters, no spaces, no special characters other than hyphen |
| `STATUS` | `DRAFT` · `REVIEW` · `APPROVED` · `PUBLISHED` · `SUPERSEDED` · `ARCHIVED` |
| `YYYYMMDD` | Date of the version, not the date of download |
| Path length | Total path ≤ 200 characters |
| Classification suffix | C3 and C4 documents append `_C3` or `_C4` |

**Valid examples.**

```
ANB-ADM-REF-0001_MasterCompanyProfile_v4.0_PUBLISHED_20260630.md
ANB-ADM-STD-0006_EnterpriseKnowledgeTaxonomy_v1.0_PUBLISHED_20260630.md
ANB-CMP-POL-0001_AML-Policy_v7.2_PUBLISHED_20260315.pdf
ANB-HRM-POL-0002_Leave-Policy_v3.1_APPROVED_20260210.docx
ANB-ISC-SOP-0003_Security-Incident-Response_v5.0_PUBLISHED_20251118_C3.pdf
ANB-IAD-RPT-0142_Audit-RetailBranchCash-Q2FY26_v1.0_APPROVED_20260630_C2.pdf
ANB-CBK-CTR-0002_MasterLoanAgreement-Template_v2.3_PUBLISHED_20260420.docx
```

**Invalid examples.**

| Filename | Defect |
|---|---|
| `AML Policy final FINAL v2.docx` | No document ID; spaces; ambiguous version |
| `ANB-AML-POL-0001_...` | `AML` is not a canonical department code — must be `CMP` |
| `ANB-CMP-POL-1_Policy_v7.docx` | Sequence not four-digit; version not `Major.Minor` |
| `ANB-CMP-POL-0001_AMLPolicy_v7.2.pdf` | Missing `STATUS` and date components |
| `ANB-RSK-RPT-0088_Q2-Risk-Report_v1.0_PUBLISHED_20260701_C2 (copy).pdf` | Convenience copy artefact; parentheses prohibited |
| `ANB-ITO-PLN-0002_DR Plan_v2.0_PUBLISHED_20260415.docx` | Space in Short Title |

### 8.2 Character Set and Reserved Tokens

| Rule | Detail |
|---|---|
| Permitted characters | `A–Z`, `a–z`, `0–9`, hyphen `-`, underscore `_`, single period before extension |
| Prohibited | Spaces, `& % # @ ! $ ^ * ( ) [ ] { } , ; : ' " / \ ?`, non-ASCII characters, emoji |
| Reserved separators | `_` separates filename elements; `-` separates words within an element. Never interchange them. |
| Prohibited tokens | `final`, `FINAL`, `latest`, `new`, `old`, `copy`, `temp`, `use-this`, initials, personal names |
| Case | Document ID and STATUS uppercase; Short Title PascalCase or hyphenated; extension lowercase |

### 8.3 Operational Record Filenames

Operational records are indexed by relationship, not by document sequence:

```
<RecordType>_<CustomerID|AccountNumber|CaseID>_<Descriptor>_<YYYYMMDD>.<ext>
```

```
KYC_CUS-04928311_CDD-Refresh_20260512.pdf
LOAN_ACC-8871200456_CreditMemo_20260228.pdf
STMT_ACC-1029384756_Monthly_20260630.pdf
DISP_CAS-00417723_ChargebackEvidence_20260601.pdf
```

### 8.4 Record Type Prefix Register

| Prefix | Record Family | Primary System | Identifier Anchor |
|---|---|---|---|
| `KYC` | Customer due diligence | ApexKYC | `CUS-` |
| `AML` | Financial crime investigation | ApexGuard | `CAS-` |
| `SAR` | Suspicious Activity Report package (C3) | ApexGuard | `CAS-` |
| `CTR` | Currency Transaction Report package | ApexGuard | `CUS-` |
| `LOAN` | Credit file artefact | ApexCredit / ApexOrigin | `ACC-` / `FAC-` |
| `APPL` | Loan application artefact | ApexOrigin | `APP-` |
| `STMT` | Customer statement | ApexCore | `ACC-` |
| `DISP` | Dispute / chargeback | Apex360 | `CAS-` |
| `CMPL` | Complaint file | Apex360 | `CAS-` |
| `CONT` | Executed contract | ApexLegal / ApexDocs | `VEN-` / `CUS-` |
| `VEND` | Vendor due diligence artefact | ApexVendor | `VEN-` |
| `AUDW` | Audit workpaper | ApexAudit | `AUD-` |
| `EVID` | Control or compliance evidence | ApexAudit / ApexRisk | `CTL-` / `AUD-` |
| `INCD` | Incident record | ApexServe / ApexShield | `INC-` |
| `CHGR` | Change record | ApexServe | `CHG-` |
| `MINS` | Committee or board minutes package | ApexDocs | Committee code |
| `HRRE` | Employee record | ApexPeople | `EMP-` |
| `REGF` | Regulatory filing package | ApexRegRep | Filing reference |

---

## 9. Standard — Record-Class Naming Rules

### 9.1 OCR and Scanned Document Naming

Scanned material captured via ApexScan is named at capture, not later. Un-named scans are quarantined after 5 business days.

```
<RecordTypePrefix>_<EntityID>_<Descriptor>_<YYYYMMDD>_OCR<Confidence>.<ext>
```

| Element | Rule |
|---|---|
| `OCR<Confidence>` | Two-digit rounded mean OCR confidence, e.g. `OCR97` |
| Confidence < 85 | Flagged for manual verification; suffix `_VERIFY` appended until cleared |
| Multi-page batches | Suffix `_P<start>-<end>` where a physical batch is split |
| Source retention | The original scanned image is the record copy; the searchable-text rendition is derived and not separately retained |

```
KYC_CUS-04928311_PassportCopy_20260512_OCR97.pdf
LOAN_ACC-8871200456_SignedNote_20260228_OCR88.pdf
AUDW_AUD-014202_BranchCashCount_20260610_OCR82_VERIFY.pdf
CONT_VEN-104822_ExecutedMSA_20260118_OCR96_P1-42.pdf
```

**Rules.** OCR renditions never overwrite the source image. Where the OCR text layer is corrected, the correction is a new rendition with the same version; the original is retained for evidentiary integrity. Scans of C3/C4 material carry the classification suffix and are routed directly to ApexVault.

### 9.2 Email and Attachment Naming

Email declared as a record is captured with its transport metadata intact. Renaming an email file is prohibited where it would destroy header integrity; instead, a wrapper record is created.

```
EMAIL_<EntityID>_<Subject-Short>_<YYYYMMDD>_<HHMM>.msg
ATTC_<EntityID>_<Subject-Short>_<AttachmentDescriptor>_<YYYYMMDD>.<ext>
```

| Rule | Detail |
|---|---|
| Subject-Short | ≤ 30 characters, hyphenated, derived from the subject line with reply/forward prefixes removed |
| Time element | 24-hour `HHMM` in bank standard time of the sending mailbox, used to disambiguate same-day threads |
| Attachments | Extracted and named separately with `ATTC_`, linked to the parent email by `attached_to` |
| Threads | Only the final message in a thread is declared a record unless earlier messages contain distinct decisions |
| Prohibited | Renaming `.msg` files in a way that breaks Apex Mail journaling references |

```
EMAIL_CUS-04928311_Loan-Restructure-Consent_20260318_1447.msg
ATTC_CUS-04928311_Loan-Restructure-Consent_SignedAddendum_20260318.pdf
EMAIL_VEN-104822_MSA-Renewal-Terms_20260415_0921.msg
ATTC_AUD-014202_Evidence-Request-3_CashCountSheets_20260610.xlsx
```

Email retention is governed by `RET-EMAIL-7Y` in `ANB-ADM-POL-0001` §8.13; naming does not alter retention. Personal mailbox folder structures are not a record system.

### 9.3 Evidence Naming

Evidence supports an assertion that a control operated. Its name must state *what was tested*, *when*, and *by whom the test period is defined* — never a subjective label.

```
EVID_<ControlID|AuditID>_<TestPeriod>_<EvidenceDescriptor>_<YYYYMMDD>.<ext>
```

| Element | Rule |
|---|---|
| `TestPeriod` | `FY26Q2`, `FY26H1`, `FY26`, or `20260401-20260630` |
| `EvidenceDescriptor` | Names the artefact, not the conclusion: `AccessReviewExport`, not `AccessReviewPassed` |
| Population evidence | Suffix `_POP`; sample evidence `_SMP<n>` |
| Screenshots | Must include system, date, and operator in the descriptor; undated screenshots are rejected |
| Immutability | Evidence is written once to ApexVault; corrections are additive with `_R2`, never overwrites |

```
EVID_CTL-01188_FY26Q2_PrivilegedAccessReviewExport_20260705_POP.xlsx
EVID_CTL-01188_FY26Q2_PrivilegedAccessReviewApproval_20260708_SMP25.pdf
EVID_AUD-014202_20260401-20260630_BranchCashRecon-ApexCore_20260630.pdf
EVID_CTL-00742_FY26_ChangeApprovalRecords-ApexServe_20260131_R2.csv
```

Evidence naming is mandatory for SOX, ICFR, PCI DSS, and regulatory examination submissions. Evidence not conforming to this convention is treated as unsupported by Internal Audit and by external audit.

### 9.4 Meeting Minutes Naming

```
MINS_<CommitteeCode>_<MeetingDate:YYYYMMDD>_<Status>_v<Major>.<Minor>.<ext>
```

| Element | Rule |
|---|---|
| `CommitteeCode` | From `CV-COMMITTEE` (see `ANB-LEG-REF-0003` Appendix A) |
| Meeting date | Date of the meeting, **not** the date of drafting or approval |
| Status | `DRAFT` until adopted; `APPROVED` on adoption at the following meeting |
| Version | Minutes are `v0.x` until adopted, then `v1.0`; corrections after adoption require a formal amending resolution and produce `v2.0` |
| Packs | Board and committee packs use `PACK_<CommitteeCode>_<YYYYMMDD>` and are retained with the minutes |

```
MINS_BAC_20260618_DRAFT_v0.2.docx        # Board Audit Committee
MINS_BRC_20260625_APPROVED_v1.0.pdf      # Board Risk Committee
MINS_CAB_20260701_APPROVED_v1.0.pdf      # Change Advisory Board
MINS_EKC_20260624_APPROVED_v1.0.pdf      # Enterprise Knowledge Council
PACK_BRC_20260625_C3.pdf
```

Board and committee minutes are permanent records (`RET-GOV-PERM`). Drafting, approval, and retention are governed by `ANB-LEG-STD-0002`.

### 9.5 Audit Workpaper Naming

```
AUDW_<AUD-ID>_<SectionRef>_<WorkpaperTitle>_v<Major>.<Minor>_<YYYYMMDD>.<ext>
```

| Element | Rule |
|---|---|
| `AUD-ID` | Engagement identifier `AUD-######` from ApexAudit |
| `SectionRef` | Hierarchical workpaper reference: `A`, `A-1`, `A-1.2`, `C-3` |
| Lock | Workpapers lock on report issuance; post-issuance changes require CAE approval and produce a new version with a documented reason |
| Cross-reference | Every workpaper referencing evidence must cite the `EVID_` filename in its index |

```
AUDW_AUD-014202_A-1_PlanningMemo_v1.0_20260405.docx
AUDW_AUD-014202_C-3.2_CashCountTesting_v2.0_20260612.xlsx
AUDW_AUD-014202_D-1_IssueLog_v1.1_20260628.xlsx
```

Audit workpapers are `C2` minimum, `C3` where they contain investigation content. Retention is `RET-AUD-7Y`. Audit reports themselves use the controlled document convention (`ANB-IAD-RPT-####`).

### 9.6 Customer File Naming

A customer file is a virtual construct: the set of records linked to a `CUS-` identifier across ApexKYC, ApexCore, Apex360, and ApexVault. There is no single physical folder, and none should be created.

| Sub-file | Prefix | Typical Contents | Minimum Classification |
|---|---|---|---|
| Identity & onboarding | `KYC` | ID documents, CDD/EDD packs, beneficial ownership, adverse media | `C2` |
| Agreements | `CONT` | Account agreements, T&Cs acceptance, mandates | `C2` |
| Servicing | `STMT`, `CORR` | Statements, notices, correspondence | `C2` |
| Disputes & complaints | `DISP`, `CMPL` | Dispute forms, evidence, resolution letters | `C2` |
| Financial crime | `AML`, `SAR` | Investigations, filings | `C3` |

```
KYC_CUS-04928311_CDD-Refresh_20260512.pdf
KYC_CUS-04928311_BeneficialOwnership_20260512.pdf
CONT_CUS-04928311_DepositAccountAgreement_20240118.pdf
CORR_CUS-04928311_AddressChangeConfirmation_20260220.pdf
AML_CAS-00512908_InvestigationSummary_20260603_C3.pdf
```

> **Prohibition.** Customer material must never be filed under a relationship manager's name, branch nickname, or personal folder. Records not anchored to a `CUS-` identifier are unretrievable under a regulatory data request and constitute a records-management breach reportable to the Operational Risk Committee.

### 9.7 Loan File Naming

Loan files are anchored to the account number (`ACC-`) once booked, and to the application (`APP-`) before booking. The `FAC-` facility identifier links multi-account facilities.

| Stage | Anchor | Prefix | Representative Artefacts |
|---|---|---|---|
| Application | `APP-` | `APPL` | Application form, income verification, credit bureau pull |
| Underwriting | `APP-` | `LOAN` | Credit memorandum, risk rating, exception approvals |
| Approval | `APP-` / `FAC-` | `LOAN` | Approval record, conditions precedent |
| Documentation | `ACC-` / `FAC-` | `CONT` | Note, security agreements, guarantees, perfection evidence |
| Servicing | `ACC-` | `LOAN` | Amendments, waivers, covenant certificates, insurance |
| Workout / recovery | `ACC-` | `LOAN`, `AML` (if fraud) | Restructure agreements, charge-off approval, recovery records |

```
APPL_APP-1174200391_ApplicationForm_20260112.pdf
LOAN_APP-1174200391_CreditMemo_20260128.pdf
LOAN_ACC-8871200456_CreditMemo_20260228.pdf
CONT_ACC-8871200456_PromissoryNote_20260302.pdf
LOAN_ACC-8871200456_CovenantCertificate-FY26Q2_20260715.pdf
LOAN_ACC-8871200456_ChargeOffApproval_20270118_C2.pdf
```

Credit files are retained under `RET-CRD-LIFE-7Y`: life of facility plus seven years after final settlement. The credit file must be complete at booking; missing documentation is an exception requiring approval per the credit authority grid in `ANB-ADM-MTX-0001` §7.

### 9.8 Contract Naming

Contracts have two distinct forms: the **template** (a controlled document) and the **executed instrument** (an operational record).

| Form | Convention | Example |
|---|---|---|
| Template | Controlled document convention | `ANB-CBK-CTR-0002_MasterLoanAgreement-Template_v2.3_PUBLISHED_20260420.docx` |
| Executed instrument | `CONT_<CounterpartyID>_<ContractType>_<EffectiveDate>.<ext>` | `CONT_VEN-104822_MasterServicesAgreement_20260118.pdf` |
| Amendment | `CONT_<CounterpartyID>_<ContractType>-AMD<n>_<EffectiveDate>.<ext>` | `CONT_VEN-104822_MasterServicesAgreement-AMD2_20261101.pdf` |
| Schedule / SOW | `CONT_<CounterpartyID>_<ContractType>-SOW<n>_<EffectiveDate>.<ext>` | `CONT_VEN-104822_MasterServicesAgreement-SOW3_20260601.pdf` |
| Termination | `CONT_<CounterpartyID>_<ContractType>-TERM_<EffectiveDate>.<ext>` | `CONT_VEN-104822_MasterServicesAgreement-TERM_20280131.pdf` |

**Rules.** The executed instrument's effective date, not the signature date, is the date element. Amendments never supersede the base contract; the base remains active with amendments attached via `attached_to`. Where a non-standard template is used, the deviation memorandum is filed as `MEM` and referenced from the contract record — approval per `ANB-ADM-MTX-0001` §6.

### 9.9 Incident Naming

```
INCD_<INC-ID>_<Severity>_<SystemOrArea>_<ArtefactType>_<YYYYMMDD>.<ext>
```

| Element | Rule |
|---|---|
| `Severity` | `SEV1`–`SEV4` as declared at the time of the artefact; the incident record retains the highest severity reached |
| `ArtefactType` | `InitialReport`, `Timeline`, `ForensicImage`, `RootCause`, `PIR`, `RegulatoryNotification`, `Comms` |
| Classification | Security incidents default `C3`; technology availability incidents default `C1`, escalating to `C2` where customer impact is confirmed |
| Immutability | Forensic artefacts are written to ApexVault under legal-hold-ready storage at creation |

```
INCD_INC-00219845_SEV1_ApexCore_InitialReport_20260214.pdf
INCD_INC-00219845_SEV1_ApexCore_Timeline_20260215.xlsx
INCD_INC-00220117_SEV1_ApexOnline_ForensicImage_20260302_C3.dd
INCD_INC-00220117_SEV1_ApexOnline_RegulatoryNotification_20260304_C3.pdf
INCD_INC-00219845_SEV1_ApexCore_PIR_20260228.pdf
```

Severity 1 and 2 incident reports are approved by the Head of IT Operations or the CISO per `ANB-ADM-MTX-0001` §11 and retained under `RET-SEC-7Y`.

---

## 10. Standard — Folder Hierarchy

### 10.1 ApexDocs Controlled Library

Folder structure mirrors the taxonomy in `ANB-ADM-STD-0006`, never a department's internal team structure.

```
/ApexDocs
└── /Controlled
    └── /<L1 Domain>                       e.g. 02_Risk-and-Compliance
        └── /<L2 Category>                 e.g. 04_Financial-Crime
            └── /<L3 Sub-category>         e.g. AML-CFT
                ├── /Published
                ├── /Superseded
                └── /Drafts                (restricted to authors and reviewers)
```

| Rule | Detail |
|---|---|
| Depth | Maximum six levels below `/Controlled` |
| Naming | `NN_Title-Case-Hyphenated`, where `NN` is the taxonomy node ordinal |
| Personal folders | Prohibited in `/Controlled` |
| Duplicate placement | Prohibited; a document exists once and is surfaced elsewhere by metadata, not by copying |
| Access | Folder permissions never override document classification; classification is the control |

### 10.2 Operational Record Stores

| Store | Structure | Notes |
|---|---|---|
| ApexKYC | `/Customers/<CUS-prefix-2>/<CUS-ID>/<RecordType>` | Sharded by first two digits for scale |
| ApexOrigin / ApexCredit | `/Facilities/<FAC-ID>/<Stage>` | Stage = Application, Underwriting, Documentation, Servicing |
| Apex360 | `/Cases/<CAS-ID>` | Complaints and disputes |
| ApexAudit | `/Engagements/<AUD-ID>/<SectionRef>` | Locked at report issuance |
| ApexServe | `/Incidents/<INC-ID>` · `/Changes/<CHG-ID>` | Attachment store only; not a document library |
| ApexVault | `/Archive/<RecordClass>/<RetentionCode>/<Year>` | Immutable, WORM; write-once at archive transition |

### 10.3 Prohibited Storage

Controlled documents and records must not reside in personal drives, unmanaged network shares, unsanctioned cloud storage, local desktops, or email folders as the record copy. Discovery of a shadow repository is an operational risk event reportable to the Operational Risk Committee and, where customer data is involved, to Information Security under `ANB-ISC-POL-0001`.

---

## 11. Standard — Version Lifecycle

### 11.1 Version Number Semantics

| Element | Increment Trigger | Approval Required | Example |
|---|---|---|---|
| **Major** (`X`.0) | Change in scope, obligations, control requirements, risk position, or approval authority — anything altering what a reader must *do* | Full approval chain per `ANB-ADM-MTX-0001`; re-attestation may be required | v3.4 → v4.0 |
| **Minor** (x.`Y`) | Clarification, added example, updated system name, corrected reference, non-material procedural refinement | Document Owner approval; Approver notified | v4.0 → v4.1 |
| **Patch** (x.y.`Z`) | Typographical, formatting, metadata, or hyperlink correction with no meaning change; draft space only, folded into next Minor | Document Custodian | v4.1.2 |

First published version is **v1.0**. Pre-publication drafts run from **v0.1**.

### 11.2 Lifecycle State Machine

```
DRAFT ──► REVIEW ──► APPROVED ──► PUBLISHED ──► UNDER REVISION ──► SUPERSEDED ──► ARCHIVED ──► DESTROYED
  │          │           │             │                                                          ▲
  │          │           │             └── periodic review passes with no change ──► PUBLISHED    │
  │          └── rejected ──► DRAFT                                                               │
  └── abandoned ─────────────────────────────────────────────────────────────────────────────────┘
```

| Stage | Description | System State |
|---|---|---|
| **Draft** | Author development. Not citable. Visible to author and named collaborators only. | ApexDocs draft library |
| **Review** | Circulated to mandatory reviewers (always Legal and Compliance for policies). Comments resolved and dispositioned in writing. | ApexDocs review workflow; comments retained |
| **Approved** | Signed by the Approver per the Approval Matrix. Effective date set. | Immutable version created |
| **Published** | Released to the audience defined by classification. Indexed for enterprise search. Prior version automatically moved to Superseded. | Live in ApexDocs; searchable |
| **Under Revision** | A new draft exists; the published version remains authoritative until the successor is published. | Both versions visible with clear banner |
| **Superseded** | Replaced by a newer version. Read-only. Watermarked `SUPERSEDED`. Retained for audit trail. | ApexDocs superseded library |
| **Archived** | Beyond active use but within the retention period. | ApexVault, immutable storage |
| **Destroyed** | Retention expired and no legal hold. Destruction certified. | Destruction certificate retained permanently |

### 11.3 Gate Criteria

| Transition | Required Before Transition | Enforced By |
|---|---|---|
| Draft → Review | Complete mandatory metadata (`ANB-ADM-STD-0005` §5); taxonomy path assigned; reviewer list populated | ApexDocs validation |
| Review → Approved | All comments dispositioned in writing; mandatory reviewers signed; no open Legal or Compliance objection | ApexDocs workflow |
| Approved → Published | Effective date set; classification applied; predecessor identified; distribution list confirmed | EKMO publication check |
| Published → Under Revision | New draft created with justification recorded | Custodian |
| Published → Superseded | Successor version reaches Published | Automatic |
| Superseded → Archived | Active retention period elapsed; no legal hold | Records Management |
| Archived → Destroyed | Full retention elapsed; no legal hold; destruction approved and certified | Records Management + Legal (`ANB-ADM-POL-0001` §10) |

**Approval expiry.** An approval that has not resulted in publication within 90 days lapses and must be re-obtained (`ANB-ADM-REF-0001` §12.2).

### 11.4 Draft Workflow

1. Custodian requests or confirms the Document ID.
2. Draft created from the controlled template (`derived_from` edge asserted automatically).
3. Version begins at `v0.1`; each substantive revision increments the second element (`v0.2`, `v0.3`).
4. Drafts are visible only to the author and named collaborators; they are excluded from enterprise search and from AI retrieval indexes.
5. Drafts inactive for 180 days are flagged; inactive for 365 days are abandoned and deleted, with the ID returned to the register marked `Unused`.

### 11.5 Published Workflow

1. Approver signs in ApexDocs; the version becomes immutable.
2. Effective date set — may be future-dated for phased adoption; the prior version remains authoritative until then.
3. Predecessor automatically demoted to `Superseded` on the effective date.
4. Publication notice distributed per classification: C0/C1 enterprise-wide via ApexReach; C2 to entitled groups; C3/C4 by named distribution recorded in ApexDocs.
5. Where a Major version changes obligations, EKMO triggers attestation in ApexLearn for the affected population, with completion tracked by HRM.
6. Search index and Knowledge Graph refreshed within 24 hours.

### 11.6 Superseded Workflow

| Rule | Detail |
|---|---|
| Never deleted while in retention | The superseded version is the evidence of what the control required at a point in time |
| Watermark and banner | *"SUPERSEDED — replaced by [Document ID] v[X.Y] effective [date]. Not for operational use."* |
| Search behaviour | De-prioritised and visually flagged; retrieval requires acknowledgement of superseded status |
| Legal hold | Any version cited in litigation, examination, or an audit finding is placed under hold and cannot be destroyed regardless of retention expiry |
| Citation | Superseded versions may be cited only with an explicit as-of date, e.g. *"per ANB-CMP-POL-0001 v6.3, in force 2024-02-01 to 2025-09-30"* |

### 11.7 Archive Workflow

1. Records Management identifies eligible items via the retention engine (`ANB-ADM-POL-0001` §7).
2. Owner receives a 30-day notification of pending archive; objections escalate to the EKC.
3. Content and full metadata written to ApexVault under WORM; ApexDocs retains a stub with metadata and a retrieval link.
4. Archive transition logged immutably: item, date, actor, retention code, projected destruction date.
5. Retrieval from archive requires Owner or Legal authorisation and is logged; retrieval never re-activates the version.

### 11.8 Emergency and Out-of-Cycle Changes

| Scenario | Handling |
|---|---|
| Regulatory directive requiring immediate change | Interim `MEM` issued by the Owner with CCO countersignature, effective immediately; formal Major version within 30 days |
| Material error creating operational risk | Document flagged `UNDER REVISION — DO NOT RELY` in search; corrected version within 10 business days |
| Business continuity event | Email approval permitted; must be reconciled into ApexDocs within 5 business days (`ANB-ADM-REF-0001` §12.2) |
| Security vulnerability disclosure in a runbook | Immediate reclassification and access restriction by ISC; version history preserved |

---

## 12. Governance

### 12.1 Compliance Monitoring

EKMO publishes a monthly Naming and Version Integrity Report to the Enterprise Knowledge Council.

| Metric | Target | Escalation Threshold |
|---|---|---|
| Name-compliant published renditions | 100% | < 99% → Department Head |
| Documents with two concurrent `Published` versions | 0 | Any → immediate EKMO intervention |
| Documents in `Under Revision` > 180 days | 0 | > 5 per department → EKC |
| Drafts abandoned without disposition | < 2% | — |
| Prohibited-token filenames detected in controlled libraries | 0 | Any → Custodian remediation in 5 days |
| Archive transitions completed within SLA | ≥ 98% | < 95% → Records Management escalation |
| OCR captures below 85% confidence pending verification > 10 days | 0 | Any → Operations escalation |

### 12.2 Exceptions

Exceptions to this Standard require a documented business justification, a compensating control, and an expiry date not exceeding 12 months. Exceptions are approved by the Head of Administration (G9) for single-document cases and by the EKC for systemic or platform-level cases, per `ANB-ADM-MTX-0001` §10.

### 12.3 Non-Compliance

| Severity | Example | Consequence |
|---|---|---|
| Low | Malformed Short Title | Custodian correction within 5 business days |
| Medium | Missing status token; duplicate copies in controlled library | Department Head notified; remediation plan |
| High | Records stored outside the system of record; renamed evidence | Operational risk event; ORC reporting; possible disciplinary action |
| Critical | Destruction of a record under legal hold; falsified version history | Immediate escalation to General Counsel and Chief Audit Executive; conduct process under `ANB-HRM-POL-0004` Code of Conduct |

---

## 13. Examples

### 13.1 Full Version Lineage — AML Policy

| Version | Status | Effective | Filename | Change |
|---|---|---|---|---|
| v6.3 | Archived | 2024-02-01 | `ANB-CMP-POL-0001_AML-Policy_v6.3_ARCHIVED_20240201.pdf` | Prior framework |
| v7.0 | Superseded | 2025-09-30 | `ANB-CMP-POL-0001_AML-Policy_v7.0_SUPERSEDED_20250930.pdf` | Beneficial ownership threshold restated; EDD triggers expanded |
| v7.1 | Superseded | 2026-01-15 | `ANB-CMP-POL-0001_AML-Policy_v7.1_SUPERSEDED_20260115.pdf` | Sanctions screening reference corrected to ApexWatch |
| v7.2 | Published | 2026-03-15 | `ANB-CMP-POL-0001_AML-Policy_v7.2_PUBLISHED_20260315.pdf` | Adverse media refresh cadence clarified |
| v8.0 | Draft | — | `ANB-CMP-POL-0001_AML-Policy_v8.0_DRAFT_20260710.docx` | Under revision for FinCEN rule change |

An examiner asking *"what did your AML Policy require on 2025-11-04?"* is answered by v7.0, retrievable in one query with an unbroken approval trail.

### 13.2 Complete Loan File Naming Set

```
APPL_APP-1174200391_ApplicationForm_20260112.pdf
APPL_APP-1174200391_IncomeVerification_20260115_OCR94.pdf
LOAN_APP-1174200391_CreditBureauReport_20260116_C2.pdf
LOAN_APP-1174200391_CreditMemo_20260128.pdf
LOAN_APP-1174200391_ApprovalRecord-RegionalCredit_20260202.pdf
CONT_ACC-8871200456_PromissoryNote_20260302.pdf
CONT_ACC-8871200456_SecurityAgreement_20260302.pdf
LOAN_ACC-8871200456_UCC-PerfectionEvidence_20260309.pdf
LOAN_ACC-8871200456_CovenantCertificate-FY26Q2_20260715.xlsx
```

Each artefact resolves to `FAC-00114820`, to `CUS-04928311`, and to the credit policy that governs it — enabling a complete file production in a single graph traversal.

### 13.3 Rejected Filename Remediation Log

| Submitted | Rejection Reason | Corrected |
|---|---|---|
| `Q2 Risk Report FINAL.xlsx` | No ID, spaces, prohibited token | `ANB-RSK-RPT-0088_Enterprise-Risk-Report-FY26Q2_v1.0_APPROVED_20260715_C2.xlsx` |
| `evidence_screenshot.png` | No control ID, no date, no descriptor | `EVID_CTL-01188_FY26Q2_ApexID-PrivilegedRoleExport_20260705.png` |
| `minutes june.docx` | No committee code, no date format, no version | `MINS_ORC_20260611_APPROVED_v1.0.docx` |
| `MSA signed scan.pdf` | No counterparty, no contract type, no date | `CONT_VEN-104822_MasterServicesAgreement_20260118_OCR96.pdf` |
| `incident write up v3.docx` | No incident ID, no severity, prohibited version format | `INCD_INC-00219845_SEV1_ApexCore_RootCause_20260226.docx` |

---

## 14. Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Author | Enterprise Knowledge Management Office | Prepared | 2026-05-22 |
| Reviewer — Legal | Margaret Sullivan, General Counsel | Reviewed | 2026-06-10 |
| Reviewer — Internal Audit | Thomas Nakamura, Chief Audit Executive | Reviewed | 2026-06-12 |
| Reviewer — Compliance | Samuel A. Okonkwo, Chief Compliance Officer | Reviewed | 2026-06-15 |
| Reviewer — Technology | Arjun Patel, Chief Information Officer | Reviewed | 2026-06-17 |
| Ratifying Body | Enterprise Knowledge Council | Ratified | 2026-06-24 |
| Approver | Daniel K. Ortega, Chief Operating Officer | Approved | 2026-06-30 |

---

## 15. Review Cycle

| Trigger | Action | Owner |
|---|---|---|
| Annual scheduled review | Full re-validation of conventions and lifecycle gates | EKMO |
| New record class introduced | Add prefix and naming rule within 30 days | EKMO |
| New content system deployed | Register store structure and validation rules before go-live | ITO + EKMO |
| Regulatory or litigation finding on records | Targeted amendment within 60 days | EKMO + Legal |
| Audit finding on version integrity | Remediation plan within 30 days | EKMO |

Next scheduled review: **2027-06-30**.

---

## 16. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of naming and versioning conventions |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/ENTERPRISE_METADATA_STANDARD.md` | Metadata captured at each lifecycle gate |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | Determines folder hierarchy and classification |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Governs archive and destruction transitions |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Approver for each document type and exception |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Committee codes for minutes naming |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | Process codes referenced in operating documents |
| `ANB-LEG-STD-0002` | Board & Committee Minutes Standard | *(planned)* | Minutes drafting and adoption |
| `ANB-ISC-STD-0004` | Data Classification Standard | *(planned)* | Classification suffixes |

---

## 17. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-05-22 | EKMO | Initial draft consolidating `ANB-ADM-REF-0001` §10–§11 | — |
| 0.3 | 2026-06-04 | EKMO | Added OCR, email, and evidence naming following Internal Audit input | — |
| 0.6 | 2026-06-14 | EKMO | Added loan, customer, contract, and incident naming; folder hierarchy | — |
| 0.8 | 2026-06-20 | EKMO | Added lifecycle gate criteria and emergency change handling | — |
| 0.9 | 2026-06-24 | EKMO | EKC ratification amendments: exception authority and non-compliance tiers | — |
| 1.0 | 2026-06-30 | EKMO | First published version | D. K. Ortega |

---

## 18. Appendices

### Appendix A — Filename Grammar (Formal)

```
controlled_filename := document_id "_" short_title "_v" version "_" status "_" date [ "_" class ] "." ext
document_id         := "ANB-" dept "-" type "-" seq
dept                := "HRM"|"FIN"|"RTL"|"CBK"|"TRY"|"LEG"|"CMP"|"RSK"|"ISC"|"ITO"|"CST"|"IAD"|"MKT"|"PRC"|"ADM"
type                := "POL"|"STD"|"SOP"|"GDL"|"MAN"|"PLN"|"REF"|"HBK"|"CHK"|"MTX"|"FRM"|"TPL"|"CTR"|"RPT"|"MIN"|"MEM"|"REG"|"TRN"|"LOG"|"PRE"
seq                 := digit{4}
short_title         := (alpha|digit|"-"){1,40}
version             := digit+ "." digit+
status              := "DRAFT"|"REVIEW"|"APPROVED"|"PUBLISHED"|"SUPERSEDED"|"ARCHIVED"
date                := YYYYMMDD
class               := "C2"|"C3"|"C4"
ext                 := lowercase{2,4}

record_filename     := prefix "_" entity_id "_" descriptor "_" date [ "_OCR" digit{2} ] [ "_VERIFY" ] "." ext
entity_id           := ("CUS-"digit{8})|("ACC-"digit{10})|("CAS-"digit{8})|("VEN-"digit{6})
                     | ("FAC-"digit{8})|("APP-"digit{10})|("AUD-"digit{6})|("INC-"digit{8})
                     | ("CHG-"digit{8})|("EMP-"digit{6})|("CTL-"digit{5})|("RSK-"digit{5})
```

### Appendix B — Status Token to Metadata Mapping

| Status Token | `status` Value | Citable | Search Visible | Editable | Retention Clock |
|---|---|---|---|---|---|
| `DRAFT` | Draft | No | No | Yes | Not started |
| `REVIEW` | Review | No | No | Comments only | Not started |
| `APPROVED` | Approved | Yes (as of effective date) | Limited | No | Starts at effective date |
| `PUBLISHED` | Published | Yes | Yes | No | Active |
| `SUPERSEDED` | Superseded | Historical only | Flagged | No | Active (superseded clock) |
| `ARCHIVED` | Archived | Historical only | Metadata stub | No | Archive period |
| — | Destroyed | No | No | No | Complete; certificate retained |

### Appendix C — Version Increment Decision Aid

| Question | Answer | Result |
|---|---|---|
| Does the change alter what someone must do, approve, or evidence? | Yes | **Major** |
| Does it change scope, applicability, or risk position? | Yes | **Major** |
| Does it change an approval authority or limit? | Yes | **Major** |
| Does it add clarification, an example, or a corrected reference? | Yes | **Minor** |
| Does it rename a system to its canonical Apex name? | Yes | **Minor** |
| Does it fix a typographical error or broken hyperlink only? | Yes | **Patch** (draft space) |
| Is the document unchanged after periodic review? | Yes | No increment; `last_reviewed_date` updated |

### Appendix D — Quick Reference Card

| Need | Convention |
|---|---|
| New policy | `ANB-<DEPT>-POL-<SEQ>_<ShortTitle>_v1.0_DRAFT_<date>.docx` |
| Customer KYC document | `KYC_CUS-########_<Descriptor>_<date>.pdf` |
| Audit workpaper | `AUDW_AUD-######_<Section>_<Title>_v1.0_<date>.xlsx` |
| SOX control evidence | `EVID_CTL-#####_<Period>_<Descriptor>_<date>.<ext>` |
| Committee minutes | `MINS_<CommitteeCode>_<MeetingDate>_APPROVED_v1.0.pdf` |
| Executed vendor contract | `CONT_VEN-######_<ContractType>_<EffectiveDate>.pdf` |
| Security incident report | `INCD_INC-########_SEV<n>_<System>_<Artefact>_<date>_C3.pdf` |
| Scanned document | append `_OCR<confidence>` |
| Restricted document | append `_C3` |

---

**End of Document**

`ANB-ADM-STD-0007` · Version 1.0 · Classification: Internal (C1) · Owner: EKMO, Administration (ADM) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
