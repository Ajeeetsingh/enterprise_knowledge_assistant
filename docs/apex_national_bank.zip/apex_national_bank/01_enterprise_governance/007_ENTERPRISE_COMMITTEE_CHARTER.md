# Apex National Bank — Enterprise Committee Charter

**Enterprise Governance Reference | Committee Structure, Mandates, Membership, and Decision Rights**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-REF-0003` |
| **Document Title** | Apex National Bank — Enterprise Committee Charter |
| **Version** | 1.0 |
| **Owner** | Legal Department (LEG) — Corporate Secretariat |
| **Custodian** | Corporate Secretary, Legal Department (G8) |
| **Approver** | Margaret Sullivan, General Counsel |
| **Secondary Approvers** | Daniel K. Ortega, Chief Operating Officer; Eleanor Whitcombe, Independent Chair of the Board (Board-tier charters) |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Created Date** | 2026-05-19 |
| **Effective Date** | 2026-07-01 |
| **Last Updated** | 2026-06-30 |
| **Review Cycle** | Annual (next review 2027-06-30); Board-tier terms of reference reviewed by the Nominating & Corporate Governance Committee |
| **Supersedes** | None — initial published charter |
| **Retention** | `RET-GOV-PERM` — Corporate Governance Records |
| **Record Class** | Corporate Governance Records |
| **Governing Body** | Board of Directors (Board tier); Executive Committee (management tier) |
| **System of Record** | ApexDocs — Corporate Secretariat library |
| **Keywords** | committee, charter, terms of reference, quorum, voting, escalation, governance, Board, ExCo, council |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-ADM-STD-0005` · `ANB-ADM-STD-0006` · `ANB-ADM-STD-0007` · `ANB-ADM-POL-0001` · `ANB-ADM-MTX-0001` · `ANB-ADM-GDL-0001` · `ANB-LEG-STD-0002` |

> **Authority.** This Charter consolidates the committee structure described in `ANB-ADM-REF-0001` §2 (Governance Structure) and supplies terms of reference for each forum. Board committee mandates derive from the Board's own terms of reference and may be amended only by the Board. Management committee mandates derive from delegated authority under `ANB-ADM-MTX-0001`.

---

## 2. Document Purpose

Committees exist to make decisions that are too consequential for one person and too specialised for the whole Board. They fail in predictable ways: unclear mandate, overlapping remit, no quorum discipline, decisions recorded without dissent, and escalation paths that stop at the committee that created the problem.

This Charter prevents those failures by publishing, for every enterprise forum:

1. **Purpose** — what the committee exists to decide.
2. **Responsibilities** — its standing agenda and decision rights.
3. **Membership** — who sits, who chairs, who is a standing attendee without vote.
4. **Meeting frequency** and quorum.
5. **Voting rules** — including conflict recusal and the treatment of dissent.
6. **Escalation** — where a matter goes when the committee cannot or should not decide it.
7. **Outputs** — the records the committee produces and their retention.

It also gives every employee a single place to answer the question that delays more decisions than any other: *"Which forum takes this?"*

---

## 3. Scope

### 3.1 In Scope

| Tier | Forums |
|---|---|
| **Tier 1 — Board** | Board of Directors and its six standing committees |
| **Tier 2 — Executive** | Executive Committee (ExCo) |
| **Tier 3 — Management** | ALCO, Group Credit Committee, Operational Risk Committee, Financial Crime Committee, New Product Approval Committee, Data Governance Council, Enterprise Knowledge Council, Disclosure Committee, Technology Steering Committee, Information Security Council |
| **Tier 4 — Operational** | Regional Credit Committees, Change Advisory Board, Enterprise Architecture Review Board |

### 3.2 Out of Scope

- Subsidiary boards, which operate under their own local constitutional documents (they may impose stricter requirements, never looser)
- Project steering groups and working groups, which are time-bounded, hold no delegated authority, and must report into a Tier 3 or Tier 4 forum
- Line management meetings, which are not governance forums and produce no committee record

### 3.3 Naming Reconciliation

Common informal names map to canonical forums as follows. Only canonical names may be used in minutes, metadata, and controlled documents (`ANB-ADM-STD-0006` §11.3).

| Informal Name | Canonical Forum |
|---|---|
| "Credit Committee" | Group Credit Committee (GrCC) — or Regional Credit Committee, depending on exposure |
| "Compliance Committee" | Financial Crime Committee (management) or Board Public Responsibility & Compliance Committee (Board) |
| "Knowledge Governance Council" | Enterprise Knowledge Council (EKC) |
| "Security Committee" | Information Security Council (ISCL) |
| "Tech Steerco" | Technology Steering Committee (TSC) |
| "Architecture Board" | Enterprise Architecture Review Board (EARB) |
| "Risk Committee" | Board Risk Committee (Tier 1) or Operational Risk Committee (Tier 3) — never interchangeable |

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Every enterprise decision has an identifiable competent forum | Zero decisions escalated to ExCo for want of a forum |
| O-2 | Committees operate with discipline | ≥ 95% of meetings quorate; ≥ 98% of papers circulated within SLA |
| O-3 | Decisions are evidenced | 100% of Tier 1–3 meetings minuted and adopted within 20 business days |
| O-4 | Constructive challenge is visible | Dissent recorded wherever expressed; a material decision with no recorded challenge is a governance finding |
| O-5 | Escalation is used | Matters exceeding authority escalate rather than being decided informally |
| O-6 | Actions close | ≥ 90% of committee actions closed by their due date |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Charter / Terms of Reference** | The instrument establishing a committee's mandate, membership, and authority. |
| **Standing Member** | A member with vote and attendance obligation. |
| **Standing Attendee** | A required attendee without vote (typically Second and Third Line, or the Secretary). |
| **Quorum** | The minimum attendance required for decisions to be valid. |
| **Reserved Matter** | A decision that cannot be delegated below the specified forum. |
| **Recusal** | Withdrawal of a conflicted member from discussion and vote, recorded in the minutes. |
| **Dissent** | A recorded objection by a member to a decision carried by the committee. |
| **Escalation** | Referral of a matter to a higher forum because of authority, conflict, or deadlock. |
| **Out-of-Committee Decision** | A decision taken between meetings by written resolution under the committee's rules. |

---

## 6. Enterprise Committee Structure

```
                          BOARD OF DIRECTORS
                        (Chair: Eleanor Whitcombe)
                                   │
   ┌──────────┬──────────┬─────────┼─────────┬──────────────┬─────────────────┐
 Audit      Risk    Compensation  Nominating  Technology &   Public Responsibility
 Committee Committee & Human      & Corporate Operational    & Compliance
           (BRC)     Capital      Governance  Resilience     Committee
  (BAC)             (BCH)          (BNG)        (BTR)             (BPR)
                                   │
                          EXECUTIVE COMMITTEE (ExCo)
                          (Chair: Group CEO, G12)
                                   │
 ┌────────┬────────┬────────┬──────┴───┬────────┬────────┬────────┬────────┐
ALCO    GrCC     ORC      FCC       NPAC      DGC      EKC    Disclosure  TSC
                                                                Committee   │
                          ISCL ─────────────────────────────────┘           │
                                   │                                        │
                    ┌──────────────┴──────────────┐              ┌──────────┴────────┐
              Regional Credit Committees        CAB            EARB
```

| Tier | Authority Source | Minutes Retention |
|---|---|---|
| Tier 1 — Board | Corporate constitution; Board terms of reference | `RET-GOV-PERM` |
| Tier 2 — ExCo | Board delegation | `RET-GOV-PERM` |
| Tier 3 — Management | ExCo delegation under `ANB-ADM-MTX-0001` | `RET-POL-10Y` (10 years) |
| Tier 4 — Operational | Tier 3 delegation | 3 years (change records themselves under `RET-CTL-7Y`) |

---

## 7. Committee Terms of Reference

### 7.1 Board Audit Committee (BAC)

| Element | Detail |
|---|---|
| **Purpose** | Oversee the integrity of financial reporting, the effectiveness of internal control over financial reporting, the external auditor relationship, and the independence and effectiveness of Internal Audit. |
| **Responsibilities** | Review and recommend the annual report and financial statements to the Board · Approve the Internal Audit Charter (`ANB-IAD-REF-0002`), annual audit plan, and material plan changes · Review all significant audit findings and management remediation · Appoint, remunerate, and evaluate the external auditor and approve non-audit services · Oversee the whistleblowing channel and the outcomes of material investigations · Oversee the records management programme and receive legal hold breach reporting (`ANB-ADM-POL-0001` §11.1) · Approve the appointment and removal of the Chief Audit Executive. |
| **Chair** | Priscilla Vance (independent non-executive director; designated financial expert) |
| **Members** | Four independent non-executive directors. No executive director may be a member. |
| **Standing Attendees (no vote)** | Chief Audit Executive · Chief Financial Officer · General Counsel · External audit engagement partner · Corporate Secretary (Secretary) |
| **Frequency** | Quarterly, plus an additional meeting before publication of the annual report; not fewer than five meetings per year |
| **Quorum** | Three independent directors, including the Chair or a designated deputy |
| **Voting** | One vote per member; simple majority; Chair holds a casting vote. Dissent recorded by name. Private sessions held at every meeting with the CAE and with the external auditor, without management present. |
| **Escalation** | To the Board of Directors. Any matter suggesting management override of controls, financial misstatement, or interference with Internal Audit escalates to the Board immediately and without management filter. |
| **Outputs** | Minutes (`MINS_BAC_*`, permanent, C3) · Audit plan approval · External auditor appointment recommendation · Annual report recommendation · Issue and remediation tracking · Annual effectiveness self-assessment |

### 7.2 Board Risk Committee (BRC)

| Element | Detail |
|---|---|
| **Purpose** | Set and oversee the Bank's risk appetite, and satisfy the Board that risk-taking remains within it. |
| **Responsibilities** | Recommend the Risk Appetite Statement to the Board and monitor adherence · Approve the Enterprise Risk Management Policy (`ANB-RSK-POL-0001`) and the risk taxonomy · Approve credit exposures above $500,000,000 and any exposure escalated from the Group Credit Committee · Oversee capital adequacy, liquidity adequacy, and the stress-testing programme · Review concentration risk by sector, geography, product, and counterparty · Oversee model risk and receive independent validation outcomes · Approve the appointment and removal of the Chief Risk Officer. |
| **Chair** | Hugo Bertrand (independent non-executive director) |
| **Members** | Five non-executive directors, of whom at least four independent |
| **Standing Attendees (no vote)** | Chief Risk Officer · Chief Financial Officer · Group Treasurer · Chief Compliance Officer · Chief Audit Executive · Corporate Secretary (Secretary) |
| **Frequency** | Quarterly, with additional meetings on stress-test submission and on material risk events |
| **Quorum** | Three members including the Chair or deputy; the CRO must be present for any credit or appetite decision |
| **Voting** | Simple majority; Chair casting vote. Any decision to operate outside stated appetite requires unanimity of members present and immediate Board notification. |
| **Escalation** | To the Board of Directors for appetite changes, capital actions, and exposures above charter limits. Joint session with the Audit Committee where a risk issue has financial reporting implications. |
| **Outputs** | Minutes (`MINS_BRC_*`, permanent, C3) · Approved Risk Appetite Statement · Large exposure approvals · Stress-test results and conclusions · Risk policy approvals · Quarterly risk report to the Board |

### 7.3 Board Compensation & Human Capital Committee (BCH)

| Element | Detail |
|---|---|
| **Purpose** | Ensure that reward is aligned with risk, conduct, and long-term shareholder interest, and oversee executive succession. |
| **Responsibilities** | Approve executive remuneration policy and individual packages for ExCo members · Approve the enterprise incentive pool and its risk adjustment · Approve individual incentives above $1,000,000 (`ANB-ADM-MTX-0001` §13) · Approve malus and clawback applications · Review compensation for control-function staff to protect independence · Oversee succession planning for the Group CEO and ExCo · Review culture and conduct metrics. |
| **Chair** | Adaeze Nwosu (independent non-executive director) |
| **Members** | Four independent non-executive directors |
| **Standing Attendees (no vote)** | Chief Human Resources Officer · Chief Risk Officer (for risk adjustment items) · Chief Audit Executive (for conduct matters) · Corporate Secretary (Secretary) |
| **Frequency** | Quarterly, plus a remuneration-round meeting |
| **Quorum** | Three independent directors |
| **Voting** | Simple majority. No member may participate in a decision on their own remuneration. Risk and conduct adjustments require CRO input on the record. |
| **Escalation** | To the Board for the remuneration policy and CEO remuneration; to the Nominating & Corporate Governance Committee on succession matters affecting Board composition. |
| **Outputs** | Minutes (`MINS_BCH_*`, permanent, C3) · Remuneration policy · Incentive pool approval · Malus/clawback decisions · Succession plan · Say-on-pay disclosure input |

### 7.4 Board Nominating & Corporate Governance Committee (BNG)

| Element | Detail |
|---|---|
| **Purpose** | Maintain the composition, independence, and effectiveness of the Board and the Bank's governance framework. |
| **Responsibilities** | Recommend director appointments, re-elections, and committee composition · Assess director independence annually · Oversee Board and committee effectiveness reviews · Approve the corporate governance framework and this Charter's Tier 1 terms of reference · Oversee director induction and continuing education · Review conflicts of interest at Board level. |
| **Chair** | Eleanor Whitcombe (Independent Chair of the Board) |
| **Members** | Four independent non-executive directors |
| **Standing Attendees (no vote)** | General Counsel / Corporate Secretary (Secretary) · Chief Human Resources Officer |
| **Frequency** | Semi-annual, plus meetings as required for appointments |
| **Quorum** | Three independent directors |
| **Voting** | Simple majority; a director subject to a decision on their own appointment or independence recuses. |
| **Escalation** | To the Board of Directors and, where required, to shareholders. |
| **Outputs** | Minutes (`MINS_BNG_*`, permanent, C3) · Director appointment recommendations · Independence determinations · Board effectiveness review · Governance framework approvals |

### 7.5 Board Technology & Operational Resilience Committee (BTR)

| Element | Detail |
|---|---|
| **Purpose** | Oversee technology strategy, cyber resilience, operational resilience, and third-party concentration risk. |
| **Responsibilities** | Review the technology strategy and major investment programmes · Oversee the cyber security programme and threat landscape · Approve impact tolerances for important business services and review resilience testing outcomes · Oversee Tier 1 third-party and cloud concentration risk · Receive Severity 1 incident reporting and post-incident reviews · Approve the Information Security Policy at Board level (`ANB-ISC-POL-0001`) · Oversee data governance maturity in conjunction with the Audit Committee. |
| **Chair** | Kenji Sato (independent non-executive director) |
| **Members** | Four non-executive directors, at least one with substantive technology or cyber experience |
| **Standing Attendees (no vote)** | Chief Information Officer · Chief Information Security Officer · Chief Operating Officer · Chief Data Officer · Chief Risk Officer · Corporate Secretary (Secretary) |
| **Frequency** | Quarterly, plus extraordinary meetings on Severity 1 incidents with regulatory notification |
| **Quorum** | Three members including the Chair or deputy |
| **Voting** | Simple majority; Chair casting vote. CISO has a direct, unfiltered reporting line to the Chair and may request an extraordinary meeting. |
| **Escalation** | To the Board of Directors for resilience failures, material cyber incidents, and technology investment above charter limits; to the Risk Committee for appetite implications. |
| **Outputs** | Minutes (`MINS_BTR_*`, permanent, C3) · Impact tolerance approvals · Cyber programme assessment · Resilience testing conclusions · Third-party concentration review · Severity 1 incident dispositions |

### 7.6 Board Public Responsibility & Compliance Committee (BPR)

| Element | Detail |
|---|---|
| **Purpose** | Oversee regulatory compliance, conduct, fair treatment of customers, and community reinvestment. |
| **Responsibilities** | Approve the Anti-Money Laundering Policy (`ANB-CMP-POL-0001`) and the enterprise compliance programme · Oversee the BSA/AML programme and receive aggregate financial crime reporting · Oversee conduct risk, complaints, and fair lending outcomes · Review supervisory correspondence, examination findings, and enforcement matters · Oversee community reinvestment and public commitments · Approve the appointment and removal of the Chief Compliance Officer and the BSA Officer. |
| **Chair** | Marisol Reyes (independent non-executive director) |
| **Members** | Four independent non-executive directors |
| **Standing Attendees (no vote)** | Chief Compliance Officer · General Counsel · BSA Officer · Chief Audit Executive · Chief Risk Officer · Corporate Secretary (Secretary) |
| **Frequency** | Quarterly, plus meetings on material regulatory matters |
| **Quorum** | Three independent directors |
| **Voting** | Simple majority; Chair casting vote. Individual Suspicious Activity Reports are never presented; only aggregate programme metrics (`ANB-ADM-MTX-0001` §5). |
| **Escalation** | To the Board of Directors for enforcement actions, consent orders, and material customer detriment; to the Audit Committee where financial reporting is implicated. |
| **Outputs** | Minutes (`MINS_BPR_*`, permanent, C3) · AML and compliance policy approvals · Programme effectiveness assessment · Regulatory matter dispositions · CRA and public commitment reporting |

### 7.7 Executive Committee (ExCo)

| Element | Detail |
|---|---|
| **Purpose** | Execute the strategy approved by the Board, allocate capital and resources, and resolve escalations that exceed any single executive's authority. |
| **Responsibilities** | Approve the annual business plan and budget for Board ratification · Allocate capital between business units · Approve capital projects between $5,000,000 and $50,000,000 · Approve enterprise policies jointly with the owning Department Head · Resolve cross-departmental escalations and deadlocks · Approve the enterprise change portfolio and its prioritisation · Approve business continuity invocation and crisis response · Ratify management committee charters. |
| **Chair** | Marcus D. Whitfield, Group Chief Executive Officer (G12) |
| **Members** | All G11 Chief Officers: CFO, COO, CRO, CCO, General Counsel, CIO, CHRO, CAE (attends for governance items; recuses from management decisions to preserve independence) |
| **Standing Attendees (no vote)** | Business Unit Heads (G10) by invitation · CISO and CDO for relevant items · Corporate Secretary (Secretary) |
| **Frequency** | Weekly; extraordinary meetings on crisis invocation |
| **Quorum** | Five members including the Group CEO or a designated deputy; the CFO must be present for any financial decision |
| **Voting** | Consensus preferred. Where a vote is taken, simple majority with the Group CEO holding a casting vote. The CRO, CCO, and General Counsel each hold a **right of formal objection**: an objection is recorded and, if not resolved, escalates the matter to the relevant Board committee. The CAE does not vote on management decisions. |
| **Escalation** | To the Board of Directors or the relevant Board committee. Matters above $250,000,000, capital actions, and appetite breaches escalate automatically. |
| **Outputs** | Minutes (`MINS_EXCO_*`, permanent, C3) · Budget and plan recommendations · Capital allocation decisions · Policy approvals · Escalation dispositions · Crisis decisions log |

### 7.8 Asset & Liability Committee (ALCO)

| Element | Detail |
|---|---|
| **Purpose** | Manage the structure of the balance sheet — liquidity, funding, interest rate risk, and capital efficiency — within Board-approved appetite. |
| **Responsibilities** | Approve the funding plan and monitor liquidity metrics (LCR, NSFR, survival horizon) · Set and monitor interest rate risk limits (IRRBB, EVE, NII sensitivity) · Approve the Funds Transfer Pricing methodology and rates · Approve the investment portfolio strategy and HQLA composition · Approve deposit and loan pricing frameworks · Recommend the Liquidity & Funding Policy (`ANB-TRY-POL-0001`) and Contingency Funding Plan (`ANB-TRY-PLN-0002`) · Declare and stand down liquidity stress states. |
| **Chair** | Priya Raghunathan, Chief Financial Officer (G11) |
| **Members** | Group Treasurer · Chief Risk Officer · Head of Market & Liquidity Risk (G9) · Business Unit Heads for CRB, CMB, CIB (G10) · Head of Financial Planning & Analysis (G9) |
| **Standing Attendees (no vote)** | Head of Regulatory Reporting · Head of Balance Sheet Analytics · Internal Audit (observer) · ALCO Secretary (Treasury, G6) |
| **Frequency** | Monthly; weekly during a declared liquidity stress state |
| **Quorum** | Five members including the Chair (or CEO-designated deputy), the Group Treasurer, and the CRO or their delegate |
| **Voting** | Simple majority; Chair casting vote. The CRO may veto any decision that would breach Board-approved risk appetite; the veto is recorded and the matter escalates to the Board Risk Committee. |
| **Escalation** | To ExCo for capital and strategic implications; to the Board Risk Committee for appetite breaches and contingency funding plan invocation. |
| **Outputs** | Minutes (`MINS_ALCO_*`, 10 years, C3) · Funding plan · FTP rates · Limit sets · Liquidity stress declarations · Monthly ALCO pack |

### 7.9 Group Credit Committee (GrCC)

| Element | Detail |
|---|---|
| **Purpose** | Approve large and complex credit exposures, set credit policy, and govern credit exceptions across the Bank. |
| **Responsibilities** | Approve commercial and corporate exposures up to $500,000,000 and mortgage exposures above $15,000,000 (`ANB-ADM-MTX-0001` §8.1) · Approve the Loan Approval Policy (`ANB-CBK-POL-0001`) and underwriting standards · Review monthly credit exception reporting · Approve restructures above $50,000,000 and charge-offs above $5,000,000 · Set and monitor sector, country, and single-name concentration limits · Review watchlist and problem-asset migration · Approve credit risk rating methodology changes. |
| **Chair** | Helena Brandt, Chief Risk Officer (G11) |
| **Members** | Head of Credit Risk (G9) · Head of Commercial Banking (G10) · Head of Corporate & Investment Banking (G10) · Head of Consumer & Retail Banking (G10) · Chief Financial Officer · Head of Special Assets (G8) |
| **Standing Attendees (no vote)** | Presenting Relationship Manager and Credit Analyst · Legal (for documentation risk) · Compliance (for financial crime concerns) · Internal Audit (observer) · GrCC Secretary (Risk, G6) |
| **Frequency** | Weekly for transactions; monthly for policy and portfolio |
| **Quorum** | Four members including the Chair or the Head of Credit Risk, and at least two independent Risk votes |
| **Voting** | Approval requires a majority **and** an affirmative vote from Risk (Second Line). A business majority cannot approve credit over Risk objection. Sponsoring business members recuse from the vote on their own transactions. Dissent is recorded with reasons. |
| **Escalation** | Regional Credit Committees escalate upward into GrCC; GrCC escalates to the Board Risk Committee above $500,000,000, for related-party credit, and for any exception the Committee is unwilling to approve. |
| **Outputs** | Minutes (`MINS_GRCC_*`, 10 years, C3) · Credit approvals with conditions · Exception register · Concentration limit sets · Policy approvals · Monthly portfolio and watchlist report |

**Regional Credit Committees (Tier 4).** Constituted per region (Northeast, Southeast, Midwest, Southwest, West, EMEA, APAC). Chaired by the Regional Credit Officer (G8). Approve mortgage exposures to $15,000,000 and commercial exposures to $50,000,000. Same voting rule: Risk affirmative vote mandatory. Minutes retained 10 years. Escalate to GrCC.

### 7.10 Operational Risk Committee (ORC)

| Element | Detail |
|---|---|
| **Purpose** | Oversee operational risk across the enterprise: loss events, control effectiveness, resilience, and risk acceptances. |
| **Responsibilities** | Review operational loss events above the reporting threshold and their root causes · Review RCSA outcomes and challenge control ratings · Monitor Key Risk Indicators against thresholds · Approve and monitor Medium risk acceptances; review High and Critical acceptances approved by the CRO (`ANB-ADM-MTX-0001` §10.1) · Ratify system criticality tier assignments · Oversee business continuity and disaster recovery test outcomes · Review records-management and shadow-repository risk events (`ANB-ADM-POL-0001` §11.1) · Review third-party operational incidents. |
| **Chair** | Helena Brandt, Chief Risk Officer (G11) |
| **Members** | Head of Operational Risk (G8) · Chief Operating Officer · Head of IT Operations (G11) · Chief Information Security Officer (G10) · Head of Administration (G9) · Business Unit operational risk leads (G8) · Chief Compliance Officer |
| **Standing Attendees (no vote)** | Internal Audit (observer) · Head of Business Continuity · ORC Secretary (Risk, G6) |
| **Frequency** | Monthly |
| **Quorum** | Five members including the Chair or the Head of Operational Risk, plus at least two First Line representatives |
| **Voting** | Simple majority; Chair casting vote. Risk acceptances require the affirmative vote of the Head of Operational Risk. Members recuse from votes on loss events in their own area. |
| **Escalation** | To ExCo for losses above $5,000,000 or systemic control failures; to the Board Risk Committee for appetite breaches; to the Board Technology & Operational Resilience Committee for resilience failures. |
| **Outputs** | Minutes (`MINS_ORC_*`, 10 years, C2) · Loss event dispositions · Risk acceptance register · KRI dashboard · RCSA challenge outcomes · Monthly operational risk report |

### 7.11 Financial Crime Committee (FCC)

| Element | Detail |
|---|---|
| **Purpose** | Govern the Bank's defences against money laundering, terrorist financing, sanctions evasion, bribery, and fraud. |
| **Responsibilities** | Oversee the BSA/AML programme and its effectiveness · Review transaction monitoring performance, alert volumes, and disposition quality · Approve financial crime typologies and monitoring scenario changes · Review sanctions screening effectiveness and false-positive management · Approve high-risk customer relationships requiring committee-level decision (money services businesses, correspondent banks) · Review fraud loss trends and control responses · Oversee financial crime training and staffing adequacy. |
| **Chair** | Samuel A. Okonkwo, Chief Compliance Officer (G11) |
| **Members** | BSA Officer (G8) · Head of Financial Crime (G9) · Head of Fraud (G8) · Chief Risk Officer · General Counsel · Head of Consumer & Retail Banking (G10) · Head of Corporate & Investment Banking (G10) |
| **Standing Attendees (no vote)** | Head of Financial Crime Technology · Internal Audit (observer) · FCC Secretary (Compliance, G6) |
| **Frequency** | Monthly |
| **Quorum** | Four members including the Chair or the BSA Officer |
| **Voting** | Simple majority; Chair casting vote. The BSA Officer holds an absolute veto over any decision that would weaken the BSA/AML programme; the veto escalates directly to the Board Public Responsibility & Compliance Committee. |
| **Escalation** | To ExCo for resourcing and to the Board Public Responsibility & Compliance Committee for programme adequacy, enforcement matters, and BSA Officer vetoes. |
| **Outputs** | Minutes (`MINS_FCC_*`, 10 years, C3) · Programme effectiveness reporting · Scenario and typology approvals · High-risk relationship decisions · Aggregate SAR/CTR statistics (never individual reports) |

> **SAR confidentiality.** Individual Suspicious Activity Reports and their subjects are never named in Committee papers or minutes. Reporting is aggregate only. Access to individual SARs is limited to the named list maintained by the BSA Officer (`ANB-ADM-POL-0001` §9.3).

### 7.12 New Product Approval Committee (NPAC)

| Element | Detail |
|---|---|
| **Purpose** | Ensure that new products, and material changes to existing products, are launched only when risks are understood, controls exist, and the Bank can support them. |
| **Responsibilities** | Approve new products and material product changes before launch · Confirm target market definition and suitability assessment · Confirm operational, technology, and servicing readiness · Confirm regulatory analysis, disclosure adequacy, and fair-treatment assessment · Set post-launch review requirements and monitor outcomes · Approve product withdrawal and customer migration plans. |
| **Chair** | Daniel K. Ortega, Chief Operating Officer (G11) |
| **Members** | Chief Risk Officer · Chief Compliance Officer · General Counsel · Chief Financial Officer · Chief Information Officer · sponsoring Business Unit Head (G10) |
| **Standing Attendees (no vote)** | Product Manager (presenter) · Chief Marketing Officer · Head of Customer Support (G9) · Internal Audit (observer) · NPAC Secretary (COO office, G6) |
| **Frequency** | Monthly, plus ad hoc for time-critical launches |
| **Quorum** | Four members including the Chair, and mandatory presence of Risk, Compliance, and Legal |
| **Voting** | Approval requires **unanimity of Risk, Compliance, and Legal**; a single objection from any of the three blocks launch. The sponsoring Business Unit Head does not vote on their own product. Conditional approvals must state each condition and its owner. |
| **Escalation** | To ExCo where a business case is compelling but a control gap remains; ExCo may not override a Compliance or Legal objection on regulatory permissibility. |
| **Outputs** | Minutes (`MINS_NPAC_*`, 10 years, C2) · Product approval records with conditions · Post-launch review reports · Product withdrawal decisions |

### 7.13 Data Governance Council (DGC)

| Element | Detail |
|---|---|
| **Purpose** | Establish ownership, quality, lineage, and appropriate use of the Bank's data. |
| **Responsibilities** | Assign data ownership and stewardship for critical data elements · Approve the enterprise data dictionary and certified datasets · Set and monitor data quality standards and remediation · Approve data lineage requirements for regulatory reporting · Approve data classification changes (`ANB-ADM-MTX-0001` §14) · Concur on entity identifier formats and structured-data retention with the EKC and Records Management · Govern analytical and AI/ML data use in conjunction with Model Risk. |
| **Chair** | Elena Vasquez, Chief Data Officer (G10) |
| **Members** | Data Owners from each department (G8–G9) · Chief Information Security Officer · Head of Regulatory Reporting (G9) · Head of Enterprise Architecture (G9) · Head of Model Risk (G8) |
| **Standing Attendees (no vote)** | EKMO representative (G6) · Legal/Privacy counsel · Internal Audit (observer) · DGC Secretary (CDO office, G6) |
| **Frequency** | Monthly |
| **Quorum** | Six members including the Chair and at least four Data Owners |
| **Voting** | Simple majority; Chair casting vote. CISO holds a veto over any decision that would reduce protection of C2–C4 data. Data Owners cannot be outvoted on the definition of data they own; disputes escalate. |
| **Escalation** | To ExCo for resourcing and cross-business disputes; to the Board Technology & Operational Resilience Committee for data governance maturity; joint session with the EKC where document and data taxonomies interact. |
| **Outputs** | Minutes (`MINS_DGC_*`, 10 years, C2) · Data dictionary approvals · Data ownership register · Data quality scorecard · Classification decisions · Identifier format concurrence |

### 7.14 Enterprise Knowledge Council (EKC)

| Element | Detail |
|---|---|
| **Purpose** | Govern the Bank's document estate, knowledge taxonomy, metadata, and records programme so that information is findable, authoritative, and defensibly retained. |
| **Responsibilities** | Approve the Enterprise Knowledge Taxonomy (`ANB-ADM-STD-0006`) — Level 1 and Level 2 nodes, entity model, and relationship types · Approve the Enterprise Metadata Standard (`ANB-ADM-STD-0005`) and Tier A controlled vocabularies · Approve the Document Naming and Versioning Standard (`ANB-ADM-STD-0007`) · Approve changes to the Records Retention Policy (`ANB-ADM-POL-0001`) and retention schedule (`ANB-ADM-STD-0002`) · Review taxonomy health, naming compliance, and retention metrics quarterly · Approve systemic exceptions to knowledge standards · Adjudicate disputes over document ownership between departments · Receive archive restore-test results. |
| **Chair** | Daniel K. Ortega, Chief Operating Officer (G11) |
| **Secretariat** | Enterprise Knowledge Management Office (EKMO), Administration Department |
| **Members** | Head of Administration (G9) · General Counsel or delegate · Chief Compliance Officer or delegate · Chief Data Officer (G10) · Chief Information Security Officer (G10) · nominated Records Coordinators representing each business unit (G6–G8) |
| **Standing Attendees (no vote)** | VP Enterprise Knowledge Management (G6, Secretary) · Head of Records Management · Internal Audit (observer) · Enterprise Search product owner |
| **Frequency** | Quarterly, plus extraordinary meetings for material graph defects or regulatory records matters |
| **Quorum** | Five members including the Chair or the Head of Administration, and mandatory presence of Legal or Compliance |
| **Voting** | Simple majority; Chair casting vote. Legal holds a veto over any change that would weaken legal hold capability or defensible destruction. Taxonomy Level 1 changes require the Chair's affirmative vote in addition to a majority. |
| **Escalation** | To ExCo for funding and cross-department disputes; to the Board Audit Committee for records programme failures and hold breaches. |
| **Outputs** | Minutes (`MINS_EKC_*`, 10 years, C2) · Taxonomy and metadata approvals · Retention schedule approvals · Quarterly Taxonomy Health Report · Naming and Version Integrity Report · Exception register |

### 7.15 Disclosure Committee (DISC)

| Element | Detail |
|---|---|
| **Purpose** | Ensure that external disclosures are accurate, complete, timely, and consistent. |
| **Responsibilities** | Review the annual report, quarterly results, and regulatory filings before submission · Assess materiality of events for disclosure · Review earnings releases, investor presentations, and market-sensitive announcements · Confirm the effectiveness of disclosure controls and procedures · Oversee the Bank's approach to MNPI and information barriers in disclosure contexts. |
| **Chair** | Priya Raghunathan, Chief Financial Officer (G11) |
| **Members** | General Counsel · Chief Compliance Officer · Group Financial Controller (G9) · Head of Investor Relations (G8) · Head of Regulatory Reporting (G9) · Chief Risk Officer |
| **Standing Attendees (no vote)** | Chief Marketing Officer (for communications) · External counsel by invitation · Internal Audit (observer) · Disclosure Secretary (Finance, G6) |
| **Frequency** | Quarterly aligned to the reporting calendar, plus ad hoc for material events |
| **Quorum** | Four members including the Chair and the General Counsel |
| **Voting** | Consensus required. Any unresolved disagreement on materiality or accuracy escalates to the Board Audit Committee — the Committee may not publish over an unresolved objection. |
| **Escalation** | To the Board Audit Committee and the Board of Directors. |
| **Outputs** | Minutes (`MINS_DISC_*`, permanent as governance record, C3) · Disclosure sign-offs · Materiality assessments · Sub-certifications supporting officer certifications |

### 7.16 Technology Steering Committee (TSC)

| Element | Detail |
|---|---|
| **Purpose** | Prioritise and govern the enterprise technology portfolio, ensuring investment is aligned to strategy and delivery is controlled. |
| **Responsibilities** | Prioritise the technology investment portfolio within the ExCo-approved envelope · Approve programme initiation, stage gates, and closure for programmes above $5,000,000 · Monitor delivery health, benefits realisation, and technical debt · Approve technology standards and the reference architecture on EARB recommendation · Approve system criticality tier proposals for ORC ratification · Oversee legacy remediation and end-of-life estate reduction · Resolve cross-programme resource and dependency conflicts. |
| **Chair** | Arjun Patel, Chief Information Officer (G11) |
| **Members** | Chief Operating Officer · Chief Financial Officer · Chief Information Security Officer (G10) · Chief Data Officer (G10) · Head of IT Operations (G11) · Business Unit Heads (G10) for CRB, CMB, CIB, WAM · Head of Enterprise Architecture (G9) |
| **Standing Attendees (no vote)** | Programme directors (presenters) · Head of Portfolio Management Office (G8) · Internal Audit (observer) · TSC Secretary (CIO office, G6) |
| **Frequency** | Monthly |
| **Quorum** | Five members including the Chair or the COO, plus at least two Business Unit Heads |
| **Voting** | Simple majority; Chair casting vote. CISO holds a veto over any decision that materially increases security or resilience risk; the veto escalates to the Board Technology & Operational Resilience Committee. |
| **Escalation** | To ExCo for investment above $50,000,000 or portfolio re-baselining; to the Board Technology & Operational Resilience Committee for strategy and resilience matters. |
| **Outputs** | Minutes (`MINS_TSC_*`, 10 years, C2) · Portfolio prioritisation · Stage gate decisions · Architecture standard approvals · Delivery health reporting |

### 7.17 Information Security Council (ISCL)

| Element | Detail |
|---|---|
| **Purpose** | Direct the enterprise information security programme and provide a forum where security requirements and business realities are reconciled before they become incidents. |
| **Responsibilities** | Review the security programme roadmap and control maturity · Approve security standards subordinate to `ANB-ISC-POL-0001` · Review the threat landscape, vulnerability posture, and remediation performance against SLA · Review security exceptions approved under `ANB-ADM-MTX-0001` §10.2 and challenge recurring patterns · Review penetration test and red-team outcomes · Oversee identity and access governance, including recertification performance · Review third-party security assessments for Tier 1 vendors · Prepare Severity 1 security incident reporting for ORC and the Board Technology & Operational Resilience Committee. |
| **Chair** | Nadia Ferreira, Chief Information Security Officer (G10) |
| **Members** | Head of Cyber Defence (G8) · Head of Platform Engineering (G9) · Head of IT Operations (G11) · Head of Operational Risk (G8) · Chief Data Officer (G10) · business-aligned security officers (G7–G8) · Head of Physical Security (G7) |
| **Standing Attendees (no vote)** | Legal/Privacy counsel · Compliance representative · Internal Audit (observer) · ISCL Secretary (ISC, G6) |
| **Frequency** | Monthly; extraordinary session within 24 hours of a Severity 1 security incident |
| **Quorum** | Five members including the Chair or the Head of Cyber Defence |
| **Voting** | Simple majority; the CISO holds a casting vote and a veto over any proposal that would reduce control effectiveness below the approved baseline. Business members may escalate a CISO veto to the Board Technology & Operational Resilience Committee but may not override it. |
| **Escalation** | To ORC for operational risk implications, to TSC for funding, and to the Board Technology & Operational Resilience Committee for programme adequacy and material incidents. |
| **Outputs** | Minutes (`MINS_ISCL_*`, 10 years, C3) · Security standard approvals · Exception trend analysis · Vulnerability and remediation reporting · Penetration test dispositions · Access governance metrics |

### 7.18 Change Advisory Board (CAB)

| Element | Detail |
|---|---|
| **Purpose** | Authorise production change so that the Bank changes its systems deliberately, with known risk, and with a way back. |
| **Responsibilities** | Review and approve Normal medium- and high-impact changes (`ANB-ADM-MTX-0001` §11.1) · Assess change risk, conflict, and collision across the estate · Confirm test evidence, rollback plans, and communication plans · Review emergency changes retrospectively within 5 business days · Maintain and enforce change freeze calendars · Review failed changes and change-caused incidents, and require remediation · Approve standard change templates for pre-authorisation. |
| **Chair** | Head of IT Operations (G11) or designated deputy (G9) |
| **Members** | Platform engineering leads (G7–G9) · Application owners for affected systems (G6–G8) · Information Security representative (G7+) · Service management lead (G7) · Business representatives for customer-facing changes (G6+) |
| **Standing Attendees (no vote)** | Change requesters (presenters) · Operational Risk representative · CAB Secretary (ITO service management, G5) |
| **Frequency** | Twice weekly; daily during change freeze periods and major release windows; emergency CAB convened within 2 hours as required |
| **Quorum** | Chair or deputy, plus the affected application owner, plus the Information Security representative for any security-relevant change |
| **Voting** | Approval by consensus of those present. Any single member may reject a change for inadequate testing, missing rollback, or unmanaged conflict; rejection stands unless overturned by the Head of IT Operations with the reason recorded. Changes to Tier 1 systems require explicit affirmative approval, never tacit consent. |
| **Escalation** | To the Head of IT Operations for disputed rejections; to TSC for systemic delivery quality issues; to ORC for change-caused incidents above the loss threshold. |
| **Outputs** | Change records in ApexServe (`RET-CTL-7Y`) · CAB decision log · Freeze calendar · Failed change analysis · Emergency change retrospective reviews. Minutes retained 3 years; individual change records retained 7 years. |

### 7.19 Enterprise Architecture Review Board (EARB)

| Element | Detail |
|---|---|
| **Purpose** | Ensure that solutions built or bought fit the Bank's target architecture, and that deviations are conscious, time-bounded, and paid for. |
| **Responsibilities** | Review solution designs for programmes above $5,000,000 and for any change to a Tier 1 system · Maintain the reference architecture, technology radar, and approved technology catalogue · Approve or reject architecture deviations and record the technical debt created · Review integration patterns, API standards, and data flows against the data dictionary · Assess build-versus-buy recommendations · Recommend architecture standards to TSC for approval. |
| **Chair** | Head of Enterprise Architecture (G9) |
| **Members** | Domain architects for channels, core banking, payments, data, and infrastructure (G7–G8) · Security architect (G8) · Data architect (G8) · Infrastructure and cloud lead (G8) |
| **Standing Attendees (no vote)** | Solution architects and programme technical leads (presenters) · Operational Risk representative · EARB Secretary (Enterprise Architecture, G5) |
| **Frequency** | Fortnightly; expedited review within 5 business days on request with justification |
| **Quorum** | Chair or deputy plus three domain architects, including the security architect for any externally exposed or data-bearing design |
| **Voting** | Consensus; where consensus fails, the Chair decides and records dissent. The security architect may block a design pending CISO adjudication. Deviations are approved only with a named owner, a remediation date, and recorded technical debt. |
| **Escalation** | To TSC for rejected designs with a compelling business case, and to the CIO for appeals. Unresolved security objections escalate to ISCL and, if needed, to the Board Technology & Operational Resilience Committee. |
| **Outputs** | Architecture decision records · Deviation approvals with expiry and debt entries · Reference architecture updates · Technology radar · Recommendations to TSC. Records retained 7 years under `RET-CTL-7Y`. |

---

## 8. Standards — Committee Operating Rules

### 8.1 Universal Operating Rules

**C-1 — Written charter.** No forum may exercise delegated authority without terms of reference published in this Charter or approved by the parent forum and registered with the Corporate Secretariat.

**C-2 — Papers before meetings.** Papers are circulated at least **5 business days** before Tier 1 and Tier 2 meetings, and **3 business days** before Tier 3 and Tier 4 meetings. Late papers are taken only with the Chair's express agreement, recorded in the minutes. A decision may not be taken on a paper tabled at the meeting unless it is an emergency, and the emergency is stated.

**C-3 — Quorum.** Decisions taken without quorum are void. Quorum is assessed at the start of each item, not once at the start of the meeting.

**C-4 — Conflicts.** Members declare conflicts at the start of each meeting and again on any item as it arises. A conflicted member withdraws from discussion and vote; the recusal and its reason are minuted.

**C-5 — Dissent is recorded.** Any member may require their dissent to be recorded by name with reasons. A material decision recorded with no challenge whatsoever is itself a governance finding (`ANB-ADM-REF-0001` §2).

**C-6 — Control function independence.** Risk, Compliance, Legal, Information Security, and Internal Audit representatives may not be removed from a committee, have their voting rights curtailed, or be excluded from an item by the business members. Where a control function holds a veto under Section 7, that veto may only be escalated, never overridden.

**C-7 — Attendance discipline.** A member attending fewer than 75% of meetings in a rolling 12 months is reported to the Chair and their Department Head. Delegates must be named in advance, hold sufficient grade, and carry the member's vote only where the charter permits.

**C-8 — Minutes.** Minutes record attendance, apologies, declarations, decisions, dissent, actions with owners and due dates, and the papers relied upon. They are drafted within 5 business days, circulated within 10, and adopted at the next meeting (`ANB-LEG-STD-0002`). Naming follows `ANB-ADM-STD-0007` §9.4.

**C-9 — Actions.** Every action has a single named owner and a due date. Overdue actions are reported at every meeting and escalated to the owner's Department Head after 30 days past due.

**C-10 — Out-of-committee decisions.** Written resolutions are permitted where the charter allows, require the same quorum and voting threshold as a meeting, and are ratified at the next meeting. Credit approvals and NPAC approvals may not be taken out of committee.

**C-11 — Annual effectiveness review.** Every Tier 1, 2, and 3 forum conducts an annual self-assessment covering mandate clarity, paper quality, meeting discipline, and decision quality. Results go to the parent forum; Tier 1 results go to the Nominating & Corporate Governance Committee.

**C-12 — Charter amendment.** Tier 1 charters are amended by the Board on the recommendation of the Nominating & Corporate Governance Committee. Tier 2 and 3 charters are amended by ExCo. Tier 4 charters are amended by the parent Tier 3 forum. All amendments are registered with the Corporate Secretariat and produce a new Major version of this document.

### 8.2 Escalation Principles

| Principle | Detail |
|---|---|
| Escalate on authority | Where a matter exceeds the forum's delegated limit under `ANB-ADM-MTX-0001` |
| Escalate on conflict | Where recusals leave the forum unable to form a quorum or an impartial view |
| Escalate on deadlock | Where a control-function veto is exercised and cannot be resolved |
| Escalate on appetite | Where a decision would breach Board-approved risk appetite |
| Escalate on precedent | Where a decision would set a precedent beyond the forum's remit |
| Never escalate to avoid | Escalating a decision squarely within the forum's authority is a governance failure and is reported in the annual effectiveness review |

### 8.3 Committee Papers — Minimum Content

Every decision paper contains: the decision requested and the authority relied upon; the options considered and rejected; the risk assessment including Second Line opinion where applicable; financial impact; regulatory and legal analysis; operational readiness; the recommendation and its owner; and the consequences of not deciding. Papers without a stated decision request are information items and cannot produce a decision.

---

## 9. Governance

### 9.1 Committee Register

The Corporate Secretariat maintains the enterprise Committee Register in ApexDocs: forum name, code, tier, charter reference and version, chair, secretary, membership, meeting calendar, quorum, delegated limits, and parent forum. Any forum not in the Register holds no authority. The Register is reviewed quarterly by the Corporate Secretary and annually by Internal Audit.

### 9.2 Metrics

| Metric | Target | Reported To |
|---|---|---|
| Meetings held as scheduled | ≥ 95% | Parent forum |
| Meetings quorate | ≥ 95% | Corporate Secretariat |
| Papers circulated within SLA | ≥ 98% | Chair |
| Minutes adopted within 20 business days | 100% | Corporate Secretariat |
| Actions closed by due date | ≥ 90% | Parent forum |
| Member attendance ≥ 75% | 100% of members | Chair and Department Head |
| Annual effectiveness reviews completed | 100% | Nominating & Corporate Governance Committee |
| Decisions taken outside delegated authority | 0 | ExCo and Internal Audit |

### 9.3 Assurance

Internal Audit reviews governance forum operation at least every two years, testing charter compliance, quorum, conflict management, minute quality, action closure, and whether decisions fell within delegated authority. The Corporate Secretary performs an annual compliance check of the Committee Register against actual practice, including detection of unregistered forums exercising de facto authority.

---

## 10. Processes

### 10.1 Establishing a New Committee

| Step | Actor | Requirement |
|---|---|---|
| 1. Business case | Sponsor (G9+) | Demonstrate that no existing forum holds the remit |
| 2. Draft terms of reference | Sponsor with Corporate Secretariat | Must cover all elements in Section 7 format |
| 3. Overlap assessment | Corporate Secretariat | Confirm no duplication with an existing forum |
| 4. Authority confirmation | Legal and the delegating forum | Confirm the authority proposed is within the delegator's own |
| 5. Approval | ExCo (Tier 3) or the parent Tier 3 forum (Tier 4); Board for Tier 1 | Recorded in minutes |
| 6. Registration | Corporate Secretariat | Entered in the Committee Register; committee code allocated for `CV-COMMITTEE` |
| 7. Charter publication | EKMO | This document updated at the next Major version |

### 10.2 Standing Meeting Cycle

```
T-10 business days   Agenda set by Chair and Secretary; paper owners confirmed
T-5  business days   Papers submitted to Secretary (Tier 1/2) — T-3 for Tier 3/4
T-5/T-3              Papers circulated to members
T-1                  Conflicts declared in advance where known
T                    Meeting held; decisions and dissent recorded
T+5  business days   Draft minutes issued; actions logged in ApexServe
T+10 business days   Minutes circulated for comment
Next meeting         Minutes adopted; prior actions reviewed
T+20 business days   Adopted minutes filed and classified (RET-GOV-PERM or RET-POL-10Y)
```

### 10.3 Retiring a Committee

Retirement requires: a statement of where each responsibility transfers; confirmation that no delegated authority is left unassigned; transfer of open actions to the receiving forum; archival of the committee's records under the applicable retention code; and removal from the Committee Register. Minutes are never destroyed on retirement — they follow their retention class.

---

## 11. Examples

### 11.1 A Decision Traversing the Structure

A proposal to migrate ApexCore's data layer to a public cloud provider, valued at $84,000,000 over four years:

| Forum | Role | Outcome |
|---|---|---|
| EARB | Architecture fit, deviation assessment, integration patterns | Recommended with two time-bounded deviations |
| ISCL | Security control adequacy, encryption and key management, data residency | Conditional support; conditions attached |
| DGC | Data classification, lineage for regulatory reporting, residency of EU personal data | Concurrence with residency constraints |
| TSC | Portfolio prioritisation and stage gate 1 | Approved to proceed to business case |
| GrCC | Not engaged | Not a credit matter |
| ORC | System criticality tier and resilience risk | Tier 1 confirmed; resilience conditions set |
| ExCo | Capital project above $50,000,000 → escalated | Recommended to the Board |
| Board Technology & Operational Resilience Committee | Third-party concentration and resilience | Endorsed with concentration limit |
| Board of Directors | Capital project above $50,000,000 | Approved |

Nine forums, one decision, each with a distinct question. No forum re-litigated another's question.

### 11.2 A Control-Function Veto in Operation

At NPAC, a proposed structured deposit product is supported by the sponsoring Business Unit Head and Finance. Compliance objects on the ground that the disclosure does not adequately convey the loss scenarios to the target retail segment.

Under §7.12, unanimity of Risk, Compliance, and Legal is required. The objection blocks launch. The sponsor escalates to ExCo, which under §7.7 cannot override a Compliance objection on regulatory permissibility. The product returns to NPAC with revised disclosure and a narrowed target market, and is approved at the following meeting with three conditions and a six-month post-launch review.

### 11.3 Emergency Governance During a Severity 1 Incident

`INC-00220117` — ApexOnline compromise, 02:15 detection:

| Time | Forum / Actor | Action |
|---|---|---|
| 02:15 | Incident Commander (G8) | Incident declared SEV1; emergency authority under `ANB-ADM-MTX-0001` §10.2 |
| 04:15 | CISO notified | Within the 4-hour requirement |
| 06:00 | Crisis Management Team convened by the COO | Business continuity invocation considered |
| 09:00 | Extraordinary ISCL | Containment approved; forensic preservation instructed; legal hold triggered |
| 14:00 | Emergency CAB | Emergency changes authorised and logged |
| Day 1 | General Counsel | Legal hold issued (`ANB-ADM-POL-0001` §10.2) |
| Day 2 | Extraordinary Board Technology & Operational Resilience Committee | Regulatory notification decision |
| Day 5 | CAB | Retrospective review of emergency changes |
| Day 10 | ORC | Loss event recorded; root cause reviewed |
| Day 30 | Board Technology & Operational Resilience Committee | Post-incident review and remediation plan accepted |

---

## 12. Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Author | Corporate Secretariat, Legal Department | Prepared | 2026-05-19 |
| Reviewer — Operations | Daniel K. Ortega, Chief Operating Officer | Reviewed | 2026-06-08 |
| Reviewer — Risk | Helena Brandt, Chief Risk Officer | Reviewed | 2026-06-10 |
| Reviewer — Compliance | Samuel A. Okonkwo, Chief Compliance Officer | Reviewed | 2026-06-11 |
| Reviewer — Finance | Priya Raghunathan, Chief Financial Officer | Reviewed | 2026-06-12 |
| Reviewer — Technology | Arjun Patel, Chief Information Officer | Reviewed | 2026-06-15 |
| Reviewer — Internal Audit | Thomas Nakamura, Chief Audit Executive | Reviewed (no objection) | 2026-06-17 |
| Ratifying Body — Tier 2 and 3 charters | Executive Committee | Ratified | 2026-06-26 |
| Ratifying Body — Tier 1 charters | Board Nominating & Corporate Governance Committee | Ratified | 2026-06-24 |
| Approver | Margaret Sullivan, General Counsel | Approved | 2026-06-30 |
| Board Oversight | Board of Directors | Noted | 2026-06-25 |

---

## 13. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review of all terms of reference | Corporate Secretariat | Annually |
| Board committee change | Update Tier 1 terms of reference | Corporate Secretariat | 10 business days |
| New committee established | Add terms of reference; allocate committee code | Corporate Secretariat with EKMO | On approval |
| Executive appointment change | Update chairs and membership | Corporate Secretariat | 10 business days |
| Regulatory expectation change | Assess governance impact | Compliance with Corporate Secretariat | 60 days |
| Effectiveness review finding | Targeted amendment | Chair with Corporate Secretariat | 30 days |
| Audit finding on governance | Remediation plan | Corporate Secretariat | 30 days |

Next scheduled review: **2027-06-30**.

---

## 14. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of governance structure and executive roster |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/ENTERPRISE_METADATA_STANDARD.md` | `committee` metadata field and `CV-COMMITTEE` |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `CommitteeNode` and `presented_to` relationships |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | Minutes naming convention |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Retention of committee records |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Delegated limits exercised by each forum |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | Processes governed by each forum |
| `ANB-LEG-STD-0002` | Board & Committee Minutes Standard | *(planned)* | Minute drafting and adoption |
| `ANB-IAD-REF-0002` | Internal Audit Charter | *(planned)* | Audit Committee relationship |
| `ANB-RSK-POL-0001` | Enterprise Risk Management Policy | *(planned)* | Risk appetite and Three Lines model |
| `ANB-ITO-SOP-0003` | Change Management Procedure | *(planned)* | CAB operation |

---

## 15. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-05-19 | Corporate Secretariat | Initial draft of Tier 1 and Tier 2 terms of reference from `ANB-ADM-REF-0001` §2 | — |
| 0.4 | 2026-06-05 | Corporate Secretariat | Tier 3 management committee charters added | — |
| 0.6 | 2026-06-12 | Corporate Secretariat | TSC, ISCL, and EARB established following CIO and CISO proposals; naming reconciliation table added | — |
| 0.8 | 2026-06-18 | Corporate Secretariat | Universal operating rules C-1 to C-12 added after Internal Audit review; control-function veto rules formalised | — |
| 0.9 | 2026-06-26 | Corporate Secretariat | ExCo ratification amendments: quorum assessed per item; out-of-committee restrictions | — |
| 1.0 | 2026-06-30 | Corporate Secretariat | First published version | M. Sullivan |

---

## 16. Appendices

### Appendix A — Committee Code Register (`CV-COMMITTEE`)

| Code | Committee | Tier | Chair | Frequency | Minutes Retention |
|---|---|---|---|---|---|
| `BOD` | Board of Directors | 1 | Eleanor Whitcombe | Bi-monthly | `RET-GOV-PERM` |
| `BAC` | Board Audit Committee | 1 | Priscilla Vance | Quarterly+ | `RET-GOV-PERM` |
| `BRC` | Board Risk Committee | 1 | Hugo Bertrand | Quarterly+ | `RET-GOV-PERM` |
| `BCH` | Board Compensation & Human Capital Committee | 1 | Adaeze Nwosu | Quarterly | `RET-GOV-PERM` |
| `BNG` | Board Nominating & Corporate Governance Committee | 1 | Eleanor Whitcombe | Semi-annual | `RET-GOV-PERM` |
| `BTR` | Board Technology & Operational Resilience Committee | 1 | Kenji Sato | Quarterly | `RET-GOV-PERM` |
| `BPR` | Board Public Responsibility & Compliance Committee | 1 | Marisol Reyes | Quarterly | `RET-GOV-PERM` |
| `EXCO` | Executive Committee | 2 | Marcus D. Whitfield | Weekly | `RET-GOV-PERM` |
| `ALCO` | Asset & Liability Committee | 3 | Priya Raghunathan | Monthly | `RET-POL-10Y` |
| `GRCC` | Group Credit Committee | 3 | Helena Brandt | Weekly / Monthly | `RET-POL-10Y` |
| `ORC` | Operational Risk Committee | 3 | Helena Brandt | Monthly | `RET-POL-10Y` |
| `FCC` | Financial Crime Committee | 3 | Samuel A. Okonkwo | Monthly | `RET-POL-10Y` |
| `NPAC` | New Product Approval Committee | 3 | Daniel K. Ortega | Monthly | `RET-POL-10Y` |
| `DGC` | Data Governance Council | 3 | Elena Vasquez | Monthly | `RET-POL-10Y` |
| `EKC` | Enterprise Knowledge Council | 3 | Daniel K. Ortega | Quarterly | `RET-POL-10Y` |
| `DISC` | Disclosure Committee | 3 | Priya Raghunathan | Quarterly+ | `RET-GOV-PERM` |
| `TSC` | Technology Steering Committee | 3 | Arjun Patel | Monthly | `RET-POL-10Y` |
| `ISCL` | Information Security Council | 3 | Nadia Ferreira | Monthly | `RET-POL-10Y` |
| `RCC` | Regional Credit Committee (per region) | 4 | Regional Credit Officer (G8) | Weekly | `RET-POL-10Y` |
| `CAB` | Change Advisory Board | 4 | Head of IT Operations | Twice weekly | 3 years |
| `EARB` | Enterprise Architecture Review Board | 4 | Head of Enterprise Architecture | Fortnightly | `RET-CTL-7Y` |

### Appendix B — Which Forum Takes This?

| Question | Forum |
|---|---|
| Can we lend this customer $80 million? | Group Credit Committee |
| Can we lend this customer $8 million? | Senior Credit Officer (no committee required) |
| Can we launch this product? | New Product Approval Committee |
| Can we accept this residual risk for six months? | Operational Risk Committee (Medium) or CRO (High) |
| Can we run this unsupported software for another year? | Information Security Council → CISO and CIO approval |
| Can we deploy to ApexCore on Friday? | Change Advisory Board |
| Can we use a new database technology? | Enterprise Architecture Review Board → Technology Steering Committee |
| Who owns this data element? | Data Governance Council |
| Where does this document belong in the taxonomy? | Enterprise Knowledge Council (or EKMO for routine cases) |
| Can we destroy these records? | Records Management with Legal; systemic issues to the Enterprise Knowledge Council |
| Can we onboard this correspondent bank? | Financial Crime Committee |
| Can we say this publicly? | Disclosure Committee (financial) or CMO with Legal (marketing) |
| Can we spend $60 million on this programme? | Technology Steering Committee → ExCo → Board |
| Is our AML programme adequate? | Board Public Responsibility & Compliance Committee |

### Appendix C — Standing Agenda Template (Tier 3)

1. Attendance, apologies, and delegate confirmation
2. Declarations of conflict
3. Adoption of prior minutes
4. Actions outstanding — owners and due dates
5. Escalations received from subordinate forums
6. Decision items (each with a paper meeting §8.3 requirements)
7. Risk, Compliance, and Audit updates — standing item, never omitted
8. Metrics and management information
9. Items for escalation to the parent forum
10. Any other business (no decisions permitted)
11. Meeting effectiveness check (quarterly)

### Appendix D — Control-Function Veto Register

| Forum | Veto Holder | Scope of Veto | Escalation on Veto |
|---|---|---|---|
| ExCo | CRO, CCO, General Counsel | Formal objection right on any item | Relevant Board committee |
| ALCO | CRO | Decisions breaching risk appetite | Board Risk Committee |
| GrCC / RCC | Risk (Second Line) | Any credit approval requires affirmative Risk vote | Board Risk Committee |
| ORC | Head of Operational Risk | Risk acceptances | Board Risk Committee |
| FCC | BSA Officer | Anything weakening the BSA/AML programme | Board Public Responsibility & Compliance Committee |
| NPAC | Risk, Compliance, Legal (each) | Product launch | ExCo (which cannot override regulatory permissibility objections) |
| DGC | CISO | Reduced protection of C2–C4 data | Board Technology & Operational Resilience Committee |
| EKC | Legal | Weakening legal hold or defensible destruction | Board Audit Committee |
| TSC | CISO | Material increase in security or resilience risk | Board Technology & Operational Resilience Committee |
| ISCL | CISO | Control effectiveness below approved baseline | Board Technology & Operational Resilience Committee |
| CAB | Any member | Inadequate testing, missing rollback, unmanaged conflict | Head of IT Operations |
| EARB | Security architect | Externally exposed or data-bearing designs | ISCL, then CISO |

---

**End of Document**

`ANB-LEG-REF-0003` · Version 1.0 · Classification: Confidential (C2) · Owner: Legal (LEG) — Corporate Secretariat · Approver: Margaret Sullivan, General Counsel · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
