# Apex National Bank — Records Retention Policy

**Enterprise Governance Policy | Retention, Legal Hold, Archival, and Defensible Destruction**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-POL-0001` |
| **Document Title** | Apex National Bank — Records Retention Policy |
| **Version** | 1.0 |
| **Owner** | Administration Department (ADM) — Records Management Team |
| **Joint Owner** | Legal Department (LEG) |
| **Custodian** | Claire Bennett, Head of Administration (G9) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer |
| **Secondary Approvers** | Margaret Sullivan, General Counsel; Samuel A. Okonkwo, Chief Compliance Officer |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-05-18 |
| **Effective Date** | 2026-07-01 |
| **Last Updated** | 2026-06-30 |
| **Review Cycle** | Annual (next review 2027-06-30); schedule reviewed semi-annually |
| **Supersedes** | None — initial published policy |
| **Retention** | `RET-GOV-PERM` — Corporate Governance Records |
| **Record Class** | Policies and Standards (permanent as a governing instrument) |
| **Governing Body** | Enterprise Knowledge Council (EKC); Board Audit Committee oversight |
| **System of Record** | ApexDocs (policy) · ApexVault (archive) |
| **Keywords** | records retention, legal hold, destruction, archive, regulatory retention, disposition, WORM, e-discovery |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-ADM-STD-0002` · `ANB-ADM-STD-0005` · `ANB-ADM-STD-0006` · `ANB-ADM-STD-0007` · `ANB-ADM-MTX-0001` · `ANB-LEG-REF-0003` · `ANB-ADM-GDL-0001` |

> **Authority.** This Policy is the governing instrument for records retention across Apex National Bank. `ANB-ADM-STD-0002` Document Retention Schedule is its operative annex and prevails in matters of schedule detail. The summary table in `ANB-ADM-REF-0001` §11.4 is reproduced here in Section 8 and remains consistent with it.

---

## 2. Document Purpose

Apex National Bank retains records for three reasons: because law requires it, because the business needs it, and because litigation may demand it. It destroys records for one reason: because retaining data beyond its useful and lawful life is itself a risk — of privacy breach, of discovery cost, and of producing stale material that contradicts current practice.

This Policy establishes:

1. A single **enterprise retention schedule** expressed in retention codes bound to metadata, so retention executes automatically rather than by individual judgement.
2. A **legal hold** regime that suspends destruction reliably and provably, and releases it in a controlled way.
3. A **defensible destruction** process with certification, so the Bank can demonstrate that disposal was routine, authorised, and consistent — the standard that survives challenge in litigation and examination.
4. **Archival** arrangements that keep long-retention records immutable, retrievable, and readable for the whole retention period.

---

## 3. Scope

### 3.1 In Scope

All records created, received, or maintained by Apex National Bank, N.A., Apex National Bank (UK) plc, Apex Bank Europe SE, Apex Securities LLC, Apex Asset Management, Inc., Apex Trust Company, N.A., and Apex Global Services, in any format:

| Format | Examples |
|---|---|
| Electronic documents | ApexDocs controlled documents, operational records, scans |
| Structured data | Customer, account, and transaction data in ApexCore, ApexCredit, ApexLedger |
| Communications | Email, instant messaging, recorded telephony (ApexVoice), collaboration content |
| Physical records | Signed instruments, safe deposit records, wet-ink contracts, board minute books |
| Evidence artefacts | Audit workpapers, control test evidence, forensic images |
| Third-party held records | Records held by vendors under contract on the Bank's behalf |

### 3.2 Out of Scope

- Transient system caches, temporary files, and non-substantive drafts never declared a record
- Personal, non-business content in Bank systems (which is subject to acceptable-use policy, not retention)
- Duplicate convenience copies, which must be destroyed once the record copy is filed

### 3.3 Relationship to Privacy Obligations

Retention maxima under GDPR, CCPA/CPRA, and the UK Data Protection Act constrain retention where the Bank's business preference would be longer. Where a regulatory **minimum** and a privacy **maximum** conflict, Legal determines the position and records the determination against the retention code. Data subject erasure requests do not override statutory retention requirements; the Bank responds by restricting processing, not by destroying regulated records.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Every record carries an enforceable retention code | ≥ 99% of records with a valid `retention_code` at filing |
| O-2 | No record destroyed while under legal hold | Zero hold breaches — a critical control |
| O-3 | Destruction is routine, authorised, and certified | 100% of destruction events with a retained certificate |
| O-4 | Long-retention records remain retrievable and readable | Annual restore test success ≥ 99% |
| O-5 | Over-retention reduced | Eligible-but-not-destroyed backlog < 5% of eligible volume |
| O-6 | E-discovery scoping executable from the Knowledge Graph | Hold scoped and applied within 24 hours of Legal instruction |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Record** | Information, regardless of format, created or received in the course of business and retained as evidence of an activity, obligation, or decision. |
| **Record Copy** | The single declared authoritative instance of a record. All other instances are convenience copies with no retention obligation. |
| **Record Class** | A grouping of records sharing legal, regulatory, and business retention drivers. |
| **Retention Code** | The machine-enforceable identifier binding a record class to a retention period and trigger (e.g., `RET-AML-5Y`). |
| **Retention Trigger** | The event that starts the retention clock: creation, publication, account closure, contract expiry, final settlement, separation, or supersession. |
| **Active Retention** | The period during which a record remains in its operational system. |
| **Archive Retention** | The period during which a record resides in ApexVault under immutable storage. |
| **Legal Hold** | A Legal Department instruction suspending destruction for identified records pending litigation, investigation, or examination. |
| **Custodian (Hold)** | An individual whose records fall within a hold's scope and who must preserve them. |
| **Defensible Destruction** | Destruction executed under a documented, consistently applied policy, with authorisation and certification. |
| **Disposition** | The final action taken on a record at the end of retention: destruction, permanent preservation, or transfer. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Chief Operating Officer** | Accountable executive for the records management programme; approves this Policy. |
| **Records Management Team (ADM)** | Owns and operates the retention schedule, disposition runs, archive operations, and destruction certification. Maintains the Records Inventory. |
| **General Counsel / Legal (LEG)** | Issues, scopes, monitors, and releases legal holds. Determines conflicts between retention minima and privacy maxima. Approves all destruction runs. |
| **Chief Compliance Officer (CMP)** | Confirms regulatory retention minima are correctly reflected; owns AML/BSA retention requirements; approves retention for supervisory correspondence. |
| **Chief Data Officer / DGC** | Ensures structured data retention in ApexCore, ApexCredit, and ApexLedger aligns with this Policy. |
| **Chief Information Security Officer (ISC)** | Ensures destruction methods meet cryptographic and media sanitisation standards; owns security evidence retention. |
| **IT Operations (ITO)** | Operates ApexVault WORM storage, backup lifecycle, and technical execution of disposition; ensures backups do not become a shadow archive. |
| **Department Heads (G9–G11)** | Accountable for retention compliance within their department; nominate Records Coordinators. |
| **Records Coordinators (G5–G6)** | Departmental point of contact; classify records, respond to disposition notices, acknowledge holds. |
| **Chief Audit Executive (IAD)** | Independently tests retention, hold, and destruction controls; reports to the Board Audit Committee. |
| **All Employees** | Preserve records under hold; file records in systems of record; destroy convenience copies. |

---

## 7. Standard — Retention Framework

### 7.1 Retention Principles

**P-1 — One record copy.** Each record has exactly one authoritative instance in a designated system of record. Retention attaches to it and to nothing else.

**P-2 — Retention is metadata-driven.** Every record carries `record_class` and `retention_code` at filing (`ANB-ADM-STD-0005` §5). Records without them cannot be dispositioned and are treated as indefinitely retained — an over-retention defect, not an acceptable state.

**P-3 — Longest applicable period governs.** Where a record falls into multiple classes, the longest retention applies to the whole record. Records are not split to shorten retention.

**P-4 — Hold overrides everything.** A legal hold suspends all disposition regardless of expiry, business preference, or system automation.

**P-5 — Destruction is the default at expiry.** Absent a hold or a permanent classification, records are destroyed on schedule. Indefinite retention "just in case" is prohibited.

**P-6 — Backups are not archives.** Backup media exist for recovery, are subject to their own short rotation, and are never used to satisfy retention or to restore records that have been lawfully destroyed.

**P-7 — Format viability.** Records retained beyond seven years are stored in formats guaranteed readable for the retention period (PDF/A, CSV, TIFF); proprietary formats are converted at archive.

### 7.2 Retention Triggers

| Trigger | Applies To | Clock Starts |
|---|---|---|
| Creation | Correspondence, reports, minutes, evidence | Date of creation |
| Publication / effective date | Policies, standards, procedures | Effective date of the version |
| Supersession | Superseded document versions | Date successor becomes Published |
| Relationship closure | Customer records | Date the last account is closed |
| Final settlement | Credit files | Date of final payment, charge-off, or release of security |
| Contract expiry or termination | Contracts | Later of expiry, termination, or final performance |
| Separation | Employee records | Date employment ends |
| Fiscal year end | Financial and tax records | End of the fiscal year to which they relate |
| Case closure | Complaints, disputes, investigations | Date of final resolution |
| Filing | Regulatory filings, SAR/CTR | Date of submission |

### 7.3 Retention Code Structure

```
RET-<CLASS>-<PERIOD>
```

`CLASS` identifies the record family; `PERIOD` expresses the total minimum retention (`5Y`, `7Y`, `10Y`, `PERM`) or a compound trigger (`LIFE-7Y`, `TERM-7Y`).

---

## 8. Standard — Enterprise Retention Schedule

### 8.1 Master Schedule

Operative detail resides in `ANB-ADM-STD-0002`. Where that Schedule and this table differ in detail, the Schedule governs.

| Retention Code | Record Class | Active Retention | Archive Retention | Total Minimum | Trigger | Primary Driver |
|---|---|---|---|---|---|---|
| `RET-GOV-PERM` | Corporate governance records (Board minutes, charters, resolutions, articles) | Permanent | Permanent | Permanent | Creation | Corporate law; Board governance |
| `RET-POL-10Y` | Policies and standards (superseded versions) | 3 years | 7 years | 10 years | Supersession | SOX; examination evidence |
| `RET-CUS-7Y` | Customer account records | Life of relationship | 7 years after closure | 7 years post-closure | Relationship closure | GLBA; Reg E/Z; state law |
| `RET-AML-5Y` | AML/BSA records (CTR, SAR, CDD, EDD, sanctions screening) | 5 years | — | 5 years | Filing / record creation | BSA; FinCEN 31 CFR 1010.430 |
| `RET-CRD-LIFE-7Y` | Credit files | Life of facility | 7 years after final settlement | 7 years post-settlement | Final settlement | Reg B; safety and soundness |
| `RET-HRM-7Y` | Employee personnel records | Duration of employment | 7 years after separation | 7 years post-separation | Separation | Employment law; ERISA |
| `RET-FIN-10Y` | Financial and accounting records | 2 years | 8 years | 10 years | Fiscal year end | SOX; tax; Call Report support |
| `RET-CTR-TERM-7Y` | Contracts | Term of contract | 7 years after expiry | 7 years post-expiry | Expiry / termination | Statute of limitations; TPRM |
| `RET-AUD-7Y` | Audit workpapers and reports | 3 years | 4 years | 7 years | Report issuance | SOX; IIA Standards; OCC |
| `RET-SEC-7Y` | Security incident and forensic records | 2 years | 5 years | 7 years | Incident closure | PCI DSS; GLBA Safeguards; NIST |
| `RET-MKT-5Y` | Marketing materials (published) | 1 year | 4 years | 5 years | Publication | UDAAP; Reg DD/Z advertising |
| `RET-EMAIL-7Y` | Email and instant messaging | 1 year in mailbox | 6 years journaled | 7 years | Send/receive | SEC 17a-4; FINRA 4511; discovery |

### 8.2 Extended Schedule — Additional Classes

These classes are introduced by this Policy to complete coverage for record families produced by the Bank and are registered in `ANB-ADM-STD-0002`.

| Retention Code | Record Class | Total Minimum | Trigger | Driver |
|---|---|---|---|---|
| `RET-REG-7Y` | Regulatory filings and supervisory correspondence | 7 years | Filing / receipt | OCC, Federal Reserve, FCA, BaFin |
| `RET-CMPL-7Y` | Customer complaints and dispute files | 7 years | Case closure | CFPB; UDAAP; FCA DISP |
| `RET-MDL-10Y` | Model documentation and validation reports | 10 years | Model retirement | SR 11-7 Model Risk Guidance |
| `RET-VEN-7Y` | Vendor due diligence and third-party risk assessments | 7 years | Relationship termination | OCC 2023-17 TPRM |
| `RET-TRN-5Y` | Training and attestation records | 5 years | Completion | Compliance training obligations |
| `RET-RSK-7Y` | Risk assessments, RCSA outputs, risk acceptances | 7 years | Assessment date | ERM framework; ORC |
| `RET-CTL-7Y` | Control test evidence (SOX, ICFR, PCI) | 7 years | Test period end | SOX §404; PCI DSS |
| `RET-VOICE-3Y` | Recorded telephony (ApexVoice) — general servicing | 3 years | Recording date | Consumer protection; dispute resolution |
| `RET-VOICE-7Y` | Recorded telephony — trading and dealing lines | 7 years | Recording date | MiFID II; Dodd-Frank |
| `RET-TAX-10Y` | Tax returns, computations, transfer pricing documentation | 10 years | Fiscal year end | IRS; HMRC; local tax authority |
| `RET-PROP-6Y` | Property, lease, and facilities records | 6 years post-disposal | Disposal / lease end | Property law; tax |
| `RET-INS-7Y` | Insurance policies and claims | 7 years | Claim closure / policy expiry | Contract; claims longtail |
| `RET-LEG-10Y` | Litigation and legal matter files | 10 years | Matter closure | Legal privilege management; appeals |

### 8.3 Retention by Business Domain — Practical Mapping

| Domain (`ANB-ADM-STD-0006`) | Representative Records | Retention Codes |
|---|---|---|
| `T1` Governance & Legal | Board and committee minutes, charters, resolutions, legal matter files, entity records | `RET-GOV-PERM`, `RET-LEG-10Y` |
| `T2` Risk & Compliance | KYC/CDD, SAR, CTR, sanctions screening, RCSA, compliance monitoring, model validation | `RET-AML-5Y`, `RET-RSK-7Y`, `RET-MDL-10Y`, `RET-REG-7Y` |
| `T3` Customer & Products | Account agreements, disclosures, applications, product terms | `RET-CUS-7Y`, `RET-MKT-5Y` |
| `T4` Banking Operations | Statements, reconciliations, disputes, complaints, servicing records | `RET-CUS-7Y`, `RET-CMPL-7Y` |
| `T5` Finance & Treasury | Ledgers, journals, regulatory reports, tax filings, funding plans | `RET-FIN-10Y`, `RET-TAX-10Y`, `RET-REG-7Y` |
| `T6` Technology & Data | Incident reports, forensic images, change records, access reviews, DR tests | `RET-SEC-7Y`, `RET-CTL-7Y` |
| `T7` People & Workplace | Personnel files, payroll, training, conduct cases | `RET-HRM-7Y`, `RET-TRN-5Y` |
| `T8` Corporate Services | Vendor contracts, due diligence, marketing, property records | `RET-CTR-TERM-7Y`, `RET-VEN-7Y`, `RET-PROP-6Y` |

---

## 9. Standard — Record Class Detail

### 9.1 Customer Records (`RET-CUS-7Y`)

| Element | Requirement |
|---|---|
| Trigger | Closure of the customer's last account; not closure of an individual account |
| Contents | Account agreements, mandates, signature cards, statements, notices, correspondence, servicing instructions |
| System | ApexCore, Apex360, ApexVault |
| Classification | C2 minimum; contains PII |
| Special rules | Dormant and escheated accounts follow state unclaimed property law, which may extend retention beyond seven years. Deceased-customer estate records retain for seven years after estate settlement. |
| Privacy interaction | Erasure requests are honoured only for data outside the regulated record set; the regulated set is restricted rather than deleted, and the restriction is logged. |

### 9.2 Loan and Credit Records (`RET-CRD-LIFE-7Y`)

| Element | Requirement |
|---|---|
| Trigger | Final settlement — payoff, charge-off with recovery efforts concluded, or release of security, whichever is latest |
| Contents | Applications, income and asset verification, appraisals, credit memoranda, approval records, executed instruments, perfection evidence, covenant certificates, amendments, workout and recovery records |
| System | ApexOrigin, ApexCredit, ApexVault |
| Classification | C2; C3 where the file contains fraud investigation content |
| Special rules | Adverse action notices retain 25 months under Reg B — within, not additional to, the credit file period. Foreclosed property records retain seven years after disposal of the property. Charged-off accounts retain seven years after the final recovery action, which may be years after charge-off. |

### 9.3 AML, KYC, and Financial Crime Records (`RET-AML-5Y`)

| Element | Requirement |
|---|---|
| Trigger | SAR and CTR: date of filing. CDD/EDD: five years after account closure. |
| Contents | Identity verification, beneficial ownership, risk rating, EDD packs, adverse media, sanctions screening results, transaction monitoring alerts and dispositions, investigation files, SAR and CTR packages |
| System | ApexKYC, ApexGuard, ApexWatch, ApexVault |
| Classification | SAR-related material is **C3 Restricted** without exception |
| Special rules | SAR confidentiality is absolute: existence may not be disclosed to the subject or to anyone outside the authorised need-to-know list maintained by the BSA Officer. Alert dispositions — including "no further action" decisions — are records and are retained; they are the primary evidence of monitoring effectiveness at examination. Five years is a floor; the Bank retains for seven years where the material also forms part of a customer or credit file. |

### 9.4 Audit Evidence (`RET-AUD-7Y`)

| Element | Requirement |
|---|---|
| Trigger | Issuance of the final audit report |
| Contents | Planning memoranda, risk assessments, programmes, workpapers, testing evidence, issue logs, management responses, validation of remediation |
| System | ApexAudit, ApexVault |
| Classification | C2 minimum; C3 where investigations or individual conduct are involved |
| Special rules | Workpapers lock on report issuance. Post-issuance amendment requires CAE approval and produces a new version with a documented reason (`ANB-ADM-STD-0007` §9.5). Audit files supporting a regulatory finding are placed under hold until the finding is formally closed by the regulator. |

### 9.5 Compliance Evidence (`RET-CTL-7Y`, `RET-REG-7Y`)

| Element | Requirement |
|---|---|
| Contents | Compliance monitoring and testing results, regulatory change assessments, attestations, training completion, supervisory correspondence, examination responses, remediation evidence |
| System | ApexAudit, ApexDocs, ApexRegRep |
| Special rules | Supervisory correspondence and examination materials are retained seven years from closure of the examination cycle and are automatically flagged for hold consideration on receipt. Regulatory change assessments are retained even where the conclusion is "no impact" — the assessment is the control. |

### 9.6 Security Evidence (`RET-SEC-7Y`)

| Element | Requirement |
|---|---|
| Contents | Incident reports, timelines, forensic images, root cause analyses, post-incident reviews, vulnerability scans, penetration test reports, access reviews, DLP events, security exception approvals |
| System | ApexShield, ApexServe, ApexVault |
| Classification | C3 default for incident and forensic material |
| Special rules | Forensic images are written to hold-ready immutable storage at creation and are never stored on general-purpose shares. Security logs used as evidence are exported and retained as records; the underlying platform log rotation does not satisfy retention. Incidents notified to a regulator or affected individuals are automatically placed under hold. |

### 9.7 Board and Governance Records (`RET-GOV-PERM`)

| Element | Requirement |
|---|---|
| Contents | Board and Board committee minutes, resolutions, charters, terms of reference, delegated authority instruments, articles, constitutional documents, statutory registers |
| System | ApexDocs (Corporate Secretariat library), ApexVault |
| Classification | C3 for Board and Board committee material |
| Special rules | Permanent retention with no disposition path. Physical minute books are held in fire-rated storage with an off-site duplicate. Board packs are retained with the minutes as part of the governance record. Draft minutes are superseded on adoption but retained as part of the record set. |

### 9.8 Meeting and Committee Records

| Committee Tier | Retention | Notes |
|---|---|---|
| Board and Board committees | `RET-GOV-PERM` | Permanent, C3 |
| Executive Committee (ExCo) | `RET-GOV-PERM` | Permanent, C3 |
| Management committees (ALCO, GrCC, ORC, FCC, NPAC, DGC, EKC) | `RET-POL-10Y` (10 years) | C2; decisions with capital, credit, or regulatory effect escalate to permanent |
| Operational forums (CAB, working groups) | 3 years | C1; change records themselves retain under `RET-CTL-7Y` |

Minutes are records from the moment of adoption. Agendas, packs, and decision logs form part of the record set and are retained together (`ANB-ADM-STD-0007` §9.4).

### 9.9 Contracts (`RET-CTR-TERM-7Y`)

| Element | Requirement |
|---|---|
| Trigger | Later of expiry, termination, or completion of final performance obligation |
| Contents | Executed agreement, amendments, schedules, SOWs, termination notices, deviation memoranda, related due diligence |
| System | ApexLegal, ApexDocs, ApexVault |
| Special rules | Contracts with perpetual obligations (indemnities, confidentiality, IP assignment) retain permanently or for the obligation's life plus seven years, whichever is longer. Contracts under dispute are held until the dispute and any appeal period conclude. Vendor contracts supporting critical services retain with their due diligence packs as a single record set (`RET-VEN-7Y` aligned to the contract clock). |

### 9.10 Email and Electronic Communications (`RET-EMAIL-7Y`)

| Element | Requirement |
|---|---|
| Structure | 1 year in the user mailbox; 6 further years in the Apex Mail journal archive; total 7 years |
| Scope | Email, instant messaging, and collaboration messages on Bank-approved platforms |
| Special rules | Journaling is automatic and cannot be disabled by users or administrators. Deletion from a mailbox does not delete the journaled copy. Personal email and unapproved messaging platforms are prohibited for business communication; use is a conduct matter under `ANB-HRM-POL-0004` Code of Conduct. Where an email is the record copy of a decision (approval during a continuity event, contractual acceptance), it is filed into the appropriate system of record and inherits that record class — the journal is not a filing system. |
| Trading communications | Communications on dealing lines and trading chat retain 7 years under `RET-VOICE-7Y` alignment. |

---

## 10. Processes

### 10.1 Records Inventory

Records Management maintains an enterprise Records Inventory in ApexDocs, refreshed annually and on material change, recording for each record class: owning department, systems of record, volume, format, retention code, legal driver, classification, and disposition method. Department Heads attest to the accuracy of their entries annually; the attestation is evidence for Internal Audit and examination.

### 10.2 Legal Hold Lifecycle

```
TRIGGER ──► SCOPE ──► ISSUE ──► ACKNOWLEDGE ──► PRESERVE ──► MONITOR ──► RELEASE ──► RESUME DISPOSITION
```

| Step | Actor | Requirement | SLA |
|---|---|---|---|
| **Trigger** | Any employee → Legal | Reasonable anticipation of litigation, receipt of a subpoena, regulatory investigation, or examination request | Notify Legal same business day |
| **Scope** | Legal + EKMO | Define custodians, record classes, systems, date range, and entity anchors using the Knowledge Graph (`ANB-ADM-STD-0006` §10.3) | 2 business days |
| **Issue** | General Counsel or delegate | Written hold notice to named custodians and Records Management; systems flag applied in ApexDocs, ApexVault, ApexKYC, ApexCredit, Apex Mail | 24 hours from scoping |
| **Acknowledge** | Custodians | Written acknowledgement in ApexServe; non-acknowledgement escalates to Department Head at day 5 and to ExCo at day 10 | 5 business days |
| **Preserve** | Custodians + ITO | Automated suspension of deletion and disposition; mailbox retention overridden; backup expiry suspended for in-scope data | Immediate |
| **Monitor** | Legal | Quarterly re-issue reminder; scope reviewed on case development; new custodians added as identified | Quarterly |
| **Release** | General Counsel only | Written release notice; systems flags cleared; disposition eligibility recalculated | 5 business days from matter closure |
| **Resume** | Records Management | Records re-enter the disposition queue at the next scheduled run | Next cycle |

**Absolute rules.** Only the General Counsel or a named delegate may release a hold. A hold overrides every other retention rule. Destroying, altering, or concealing a record under hold is gross misconduct and may constitute a criminal offence; such events are reported immediately to the General Counsel, the Chief Audit Executive, and the Board Audit Committee.

### 10.3 Disposition and Destruction

| Step | Actor | Control |
|---|---|---|
| 1. Eligibility identification | Records Management (automated) | Retention engine identifies records past total retention with no active hold |
| 2. Owner notification | Records Management | 30-day notice to Document Owner and Records Coordinator listing items proposed for destruction |
| 3. Objection window | Owner | Objections require documented business or legal justification; unsupported objections are refused |
| 4. Legal clearance | Legal | Confirms no hold, no anticipated litigation, no open regulatory matter touching the population |
| 5. Compliance clearance | Compliance | Confirms no open supervisory matter for regulated classes |
| 6. Authorisation | Head of Administration (G9) for routine runs; General Counsel for any run containing customer, AML, or audit records | Recorded in ApexDocs |
| 7. Execution | ITO / Records Management | Method per Section 10.4 |
| 8. Certification | Records Management | Destruction certificate generated: record classes, volumes, date range, method, authorising parties, operator |
| 9. Certificate retention | Records Management | Destruction certificates retained **permanently** under `RET-GOV-PERM` |

Destruction runs execute on a **quarterly** cycle. Ad-hoc destruction outside the scheduled cycle is prohibited except under a privacy erasure determination approved by Legal.

### 10.4 Destruction Methods

| Media / Format | Method | Standard |
|---|---|---|
| Electronic records in ApexDocs / ApexVault | Cryptographic erasure of the object key plus logical deletion | NIST SP 800-88 *Purge* |
| Structured data in ApexCore / ApexCredit / ApexLedger | Anonymisation or physical row deletion per DGC-approved procedure | NIST SP 800-88 |
| Email journal | Journal expiry policy execution | Vendor-attested |
| Decommissioned storage media | Degaussing or physical destruction with certificate | NIST SP 800-88 *Destroy* |
| Physical paper records | Cross-cut shredding by an accredited vendor, witnessed, with certificate of destruction | NAID AAA equivalent |
| Physical media (tape, disk) | Vendor destruction under contract with serial-level certification | Contractual + ISC verification |

Information Security verifies method adequacy annually. Vendor destruction certificates are filed against the destruction run record.

### 10.5 Archive Operations

| Control | Requirement |
|---|---|
| Storage | ApexVault, WORM-configured, immutable for the retention period |
| Integrity | Cryptographic hash recorded at write; integrity verified on a rolling annual sample of at least 2% of archived objects |
| Retrievability | Restore test annually per record class; results reported to the EKC and Internal Audit |
| Format viability | Records retained beyond 7 years converted to PDF/A, TIFF, or CSV at archive; conversion logged with the original hash |
| Geographic constraint | EU and UK personal data archived within the applicable jurisdiction per `ANB-ADM-REF-0001` data residency requirements |
| Access | Retrieval requires Owner or Legal authorisation; every retrieval logged with requester, purpose, and date |

### 10.6 Physical Records

Physical records are inventoried at box level with a barcode, a record class, a retention code, and a destruction-eligible date. Off-site storage is under contract with an accredited vendor subject to third-party risk assessment (`ANB-PRC-POL-0002`). Physical-to-digital conversion follows `ANB-ADM-STD-0007` §9.1; the digital copy becomes the record copy only when the conversion is quality-assured and Legal has confirmed that the original need not be preserved for evidentiary or statutory reasons (wet-ink instruments, notarised documents, and negotiable instruments are always preserved physically).

---

## 11. Governance

### 11.1 Oversight

| Body | Role | Frequency |
|---|---|---|
| Board Audit Committee | Oversees the records management programme; receives hold breach and destruction exception reporting | Quarterly |
| Enterprise Knowledge Council | Approves schedule changes; reviews retention metrics and restore test results | Quarterly |
| Operational Risk Committee | Receives records-related operational risk events | Monthly |
| Data Governance Council | Aligns structured data retention and privacy positions | Monthly |
| Records Management Team | Operates the programme | Continuous |

### 11.2 Key Metrics

| Metric | Target | Escalation |
|---|---|---|
| Records with valid `retention_code` at filing | ≥ 99% | Department Head < 97% |
| Legal hold acknowledgement within 5 business days | 100% | ExCo at day 10 |
| Hold breaches (destruction under hold) | 0 | Immediate GC + CAE + Board Audit Committee |
| Destruction runs with complete certification | 100% | EKC |
| Eligible-but-not-destroyed backlog | < 5% | EKC quarterly |
| Annual restore test success | ≥ 99% | ITO remediation plan |
| Records held outside a system of record (detected) | 0 | ORC event |
| Departmental inventory attestation completion | 100% annually | Department Head to ExCo |

### 11.3 Assurance

Internal Audit performs a full records management audit at least every two years, covering schedule accuracy, hold operation, destruction certification, archive integrity, and shadow repository detection. Compliance tests regulated record classes within its monitoring plan. External auditors test SOX-relevant retention as part of ICFR.

---

## 12. Examples

### 12.1 Worked Retention Calculations

| Scenario | Trigger Date | Calculation | Destruction Eligible |
|---|---|---|---|
| Deposit customer closes last account 2026-03-15 | 2026-03-15 | `RET-CUS-7Y` = closure + 7 years | 2033-03-15 |
| SAR filed 2026-04-02 | 2026-04-02 | `RET-AML-5Y` = filing + 5 years | 2031-04-02 (retained to 2033 where part of a customer file) |
| Commercial facility charged off 2025-11-30; final recovery 2027-06-30 | 2027-06-30 | `RET-CRD-LIFE-7Y` = final settlement + 7 years | 2034-06-30 |
| AML Policy v7.0 superseded 2026-03-15 | 2026-03-15 | `RET-POL-10Y` = supersession + 10 years | 2036-03-15 |
| Vendor MSA terminated 2028-01-31 | 2028-01-31 | `RET-CTR-TERM-7Y` = termination + 7 years | 2035-01-31 |
| SEV1 security incident closed 2026-03-10 | 2026-03-10 | `RET-SEC-7Y` = closure + 7 years | 2033-03-10 |
| Audit report `ANB-IAD-RPT-0142` issued 2026-06-30 | 2026-06-30 | `RET-AUD-7Y` = issuance + 7 years | 2033-06-30 |
| Employee separates 2026-08-31 | 2026-08-31 | `RET-HRM-7Y` = separation + 7 years | 2033-08-31 |
| Board minutes 2026-06-25 | 2026-06-25 | `RET-GOV-PERM` | Never |

### 12.2 Legal Hold Scoping Example

**Matter.** `CAS-00612044` — commercial customer dispute alleging improper facility termination.

| Scope Element | Value |
|---|---|
| Entity anchors | `CUS-04928311`, `FAC-00114820`, `ACC-8871200456` |
| Custodians | Relationship Manager, Credit Analyst, Regional Credit Officer, Head of Commercial Banking, two Legal counsel |
| Record classes | Credit files, customer records, email and IM, meeting minutes of the Group Credit Committee referencing the facility, complaint file |
| Systems flagged | ApexCredit, ApexOrigin, ApexCore, Apex360, Apex Mail journal, ApexDocs |
| Date range | 2023-01-01 to hold release |
| Graph query | `CustomerNode(CUS-04928311)` ← `concerns_customer` ← records; `FacilityNode(FAC-00114820)` ← `concerns_facility` ← records; expand `attached_to` closure |
| Issued | 2026-05-04 · Acknowledged by all custodians by 2026-05-08 |
| Effect | 1,847 records suspended from disposition; two records due for destruction in the Q2 run removed from the queue |

### 12.3 Destruction Run Record

| Field | Value |
|---|---|
| Run reference | `DESTR-2026-Q2-003` |
| Population | Marketing materials published 2020-01-01 to 2021-03-31 (`RET-MKT-5Y`) |
| Volume | 4,112 electronic objects; 22 physical boxes |
| Owner notification | 2026-05-01; objection window closed 2026-05-31; two objections received, one upheld (item under an open UDAAP review) |
| Legal clearance | Margaret Sullivan, General Counsel — 2026-06-03 |
| Compliance clearance | Samuel A. Okonkwo, Chief Compliance Officer — 2026-06-04 |
| Authorisation | Claire Bennett, Head of Administration — 2026-06-05 |
| Method | Cryptographic erasure (electronic); accredited cross-cut shredding, witnessed (physical) |
| Certificate | `DESTR-2026-Q2-003-CERT.pdf` — retained permanently under `RET-GOV-PERM` |

---

## 13. Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Author | Records Management Team, Administration (ADM) | Prepared | 2026-05-18 |
| Reviewer — Legal | Margaret Sullivan, General Counsel | Reviewed | 2026-06-09 |
| Reviewer — Compliance | Samuel A. Okonkwo, Chief Compliance Officer | Reviewed | 2026-06-11 |
| Reviewer — Risk | Helena Brandt, Chief Risk Officer | Reviewed | 2026-06-12 |
| Reviewer — Security | Nadia Ferreira, Chief Information Security Officer | Reviewed | 2026-06-15 |
| Reviewer — Technology | Arjun Patel, Chief Information Officer | Reviewed | 2026-06-16 |
| Reviewer — Internal Audit | Thomas Nakamura, Chief Audit Executive | Reviewed (no objection) | 2026-06-18 |
| Ratifying Body | Enterprise Knowledge Council | Ratified | 2026-06-24 |
| Approver | Daniel K. Ortega, Chief Operating Officer | Approved | 2026-06-30 |
| Board Oversight | Board Audit Committee — noted | Noted | 2026-06-18 |

---

## 14. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual policy review | Full review and re-approval | Records Management | Annually |
| Semi-annual schedule review | Validate periods against regulatory change | Records Management + Compliance | Every 6 months |
| New regulation with retention impact | Assess and amend schedule | Compliance + Legal | 60 days |
| New system of record | Register in inventory; configure retention | ITO + Records Management | Before go-live |
| Litigation or examination finding on records | Targeted amendment | Legal + Records Management | 30 days |
| Material hold breach | Root cause, control redesign, Board Audit Committee report | GC + CAE | Immediate |

Next scheduled review: **2027-06-30**. Next schedule review: **2027-01-31**.

---

## 15. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of retention summary and classification model |
| `ANB-ADM-STD-0002` | Document Retention Schedule | *(operative annex)* | Detailed schedule; governs where detail differs |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/ENTERPRISE_METADATA_STANDARD.md` | `record_class` and `retention_code` fields |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | Entity anchors for hold scoping |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | Archive and destruction lifecycle transitions |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Destruction and exception authority |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Oversight bodies and escalation |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | Process-to-record mapping |
| `ANB-CMP-POL-0001` | Anti-Money Laundering Policy | *(planned)* | AML record requirements |
| `ANB-ISC-POL-0001` | Information Security Policy | *(planned)* | Destruction and media sanitisation standards |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy | *(planned)* | Vendor-held records |

---

## 16. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-05-18 | Records Management | Initial draft from `ANB-ADM-REF-0001` §11.4 summary schedule | — |
| 0.4 | 2026-06-02 | Records Management | Extended schedule added (13 additional classes); triggers formalised | — |
| 0.6 | 2026-06-11 | Records Management | Legal hold lifecycle rewritten following General Counsel review | — |
| 0.8 | 2026-06-18 | Records Management | Destruction methods aligned to NIST SP 800-88 after ISC review; archive integrity testing added | — |
| 0.9 | 2026-06-24 | Records Management | EKC ratification amendments: quarterly destruction cycle; certificate permanence | — |
| 1.0 | 2026-06-30 | Records Management | First published version | D. K. Ortega |

---

## 17. Appendices

### Appendix A — Retention Code Index

| Code | Class | Total Minimum | Owner |
|---|---|---|---|
| `RET-GOV-PERM` | Corporate governance | Permanent | LEG |
| `RET-POL-10Y` | Policies and standards | 10 years | ADM |
| `RET-CUS-7Y` | Customer account records | Closure + 7 | RTL / CBK |
| `RET-AML-5Y` | AML/BSA records | 5 years | CMP |
| `RET-CRD-LIFE-7Y` | Credit files | Settlement + 7 | CBK / RSK |
| `RET-HRM-7Y` | Personnel records | Separation + 7 | HRM |
| `RET-FIN-10Y` | Financial and accounting | 10 years | FIN |
| `RET-CTR-TERM-7Y` | Contracts | Expiry + 7 | LEG / PRC |
| `RET-AUD-7Y` | Audit workpapers and reports | 7 years | IAD |
| `RET-SEC-7Y` | Security incident and forensic | 7 years | ISC |
| `RET-MKT-5Y` | Marketing materials | 5 years | MKT |
| `RET-EMAIL-7Y` | Email and IM | 7 years | ITO / ADM |
| `RET-REG-7Y` | Regulatory filings and correspondence | 7 years | CMP |
| `RET-CMPL-7Y` | Complaints and disputes | 7 years | CST |
| `RET-MDL-10Y` | Model documentation | 10 years | RSK |
| `RET-VEN-7Y` | Vendor due diligence | 7 years | PRC |
| `RET-TRN-5Y` | Training records | 5 years | HRM |
| `RET-RSK-7Y` | Risk assessments | 7 years | RSK |
| `RET-CTL-7Y` | Control test evidence | 7 years | RSK / IAD |
| `RET-VOICE-3Y` | Telephony — servicing | 3 years | CST |
| `RET-VOICE-7Y` | Telephony — trading | 7 years | TRY |
| `RET-TAX-10Y` | Tax records | 10 years | FIN |
| `RET-PROP-6Y` | Property and facilities | Disposal + 6 | ADM |
| `RET-INS-7Y` | Insurance and claims | 7 years | FIN |
| `RET-LEG-10Y` | Legal matter files | Closure + 10 | LEG |

### Appendix B — Legal Hold Notice Template (Content Requirements)

A hold notice is valid only if it contains all of the following:

1. Matter reference (`CAS-`) and a plain-language description of the matter
2. Effective date of the hold and the statement that it remains in force until released in writing by the General Counsel
3. Named custodians and their acknowledgement obligation with deadline
4. Record classes, systems, and entity anchors in scope
5. Date range in scope
6. Explicit instruction to suspend deletion, including of email, chat, notes, and drafts
7. Explicit prohibition on altering, annotating, or moving in-scope records
8. Statement of consequences for non-compliance, including disciplinary and legal exposure
9. Contact point in Legal for scope questions
10. Instruction that questions about scope must never be resolved by deleting anything

### Appendix C — Disposition Decision Tree

```
Is the record under legal hold?
├── Yes ──► RETAIN. No disposition. Re-evaluate on release.
└── No
    └── Is the record class permanent (RET-GOV-PERM)?
        ├── Yes ──► PRESERVE permanently in ApexVault.
        └── No
            └── Has total minimum retention elapsed from the trigger?
                ├── No ──► RETAIN. Move to archive if active period elapsed.
                └── Yes
                    └── Is there an open regulatory, audit, or dispute matter touching the population?
                        ├── Yes ──► RETAIN. Refer to Legal for hold assessment.
                        └── No ──► DESTROY in the next quarterly run, with certification.
```

### Appendix D — Regulatory Retention Drivers

| Driver | Applies To | Minimum |
|---|---|---|
| Bank Secrecy Act / FinCEN 31 CFR 1010.430 | CTR, SAR, CDD, funds transfer records | 5 years |
| Sarbanes-Oxley Act §802 | Audit and review workpapers | 7 years |
| Regulation B (ECOA) | Credit applications, adverse action notices | 25 months (12 months consumer) |
| Regulation Z (TILA) | Disclosures and advertising | 2 years (within longer file retention) |
| Regulation E | Electronic transfer records, error resolution | 2 years |
| Regulation DD | Deposit account disclosures and advertising | 2 years |
| GLBA Safeguards Rule | Security programme and incident records | Programme life + evidence period |
| SEC Rule 17a-4 / FINRA 4511 | Broker-dealer books, records, and communications | 6 years (first 2 accessible) |
| Dodd-Frank / CFTC | Trading communications and records | 5–7 years |
| MiFID II | Dealing telephony and electronic communications | 5–7 years |
| GDPR Art. 5(1)(e) | Personal data — storage limitation | Maximum, not minimum |
| PCI DSS | Cardholder data environment logs and evidence | 1 year online, 3 months immediately available (Bank standard: 7 years for evidence) |
| OCC / Federal Reserve examination | Supervisory correspondence and responses | 7 years (Bank standard) |
| State unclaimed property law | Dormant and escheated accounts | Jurisdiction-specific; may exceed 7 years |

> Where the Bank's standard exceeds the regulatory minimum, the Bank's standard applies. Where a jurisdiction imposes a longer period on a subsidiary, the local period applies to records of that entity.

---

**End of Document**

`ANB-ADM-POL-0001` · Version 1.0 · Classification: Internal (C1) · Owner: Administration (ADM) with Legal (LEG) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
