# Apex National Bank — Enterprise Knowledge Taxonomy

**Enterprise Governance Standard | Canonical Classification, Entity Model, and Knowledge Graph Foundation**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-STD-0006` |
| **Document Title** | Apex National Bank — Enterprise Knowledge Taxonomy |
| **Version** | 1.0 |
| **Owner** | Enterprise Knowledge Management Office (EKMO), Administration Department (ADM) |
| **Custodian** | Nadine Okafor, Vice President, Enterprise Knowledge Management (G6) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer |
| **Secondary Approvers** | Elena Vasquez, Chief Data Officer; Margaret Sullivan, General Counsel |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-05-20 |
| **Effective Date** | 2026-07-01 |
| **Last Updated** | 2026-06-30 |
| **Review Cycle** | Annual (next review 2027-06-30); L3 node additions permitted quarterly |
| **Supersedes** | None — initial published standard |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Governing Body** | Enterprise Knowledge Council (EKC) |
| **System of Record** | ApexDocs |
| **Keywords** | taxonomy, knowledge graph, ontology, controlled vocabulary, entity model, semantic search, EKMO, classification |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-ADM-STD-0005` · `ANB-ADM-STD-0007` · `ANB-ADM-POL-0001` · `ANB-ADM-MTX-0001` · `ANB-LEG-REF-0003` · `ANB-ADM-GDL-0001` |

> **Authority.** This Standard operationalises the four-level taxonomy defined in `ANB-ADM-REF-0001` Appendix C and supplies the entity model, relationship model, and controlled vocabularies consumed by `ANB-ADM-STD-0005` Enterprise Metadata Standard. Where this Standard conflicts with the Master Company Profile, the Master Company Profile prevails.

---

## 2. Document Purpose

Apex National Bank holds several million documents across ApexDocs, ApexVault, ApexKYC, ApexOrigin, ApexGuard, ApexAudit, and Apex360. Without a single classification scheme, the same concept is described five different ways by five departments, and retrieval degrades into folder archaeology.

This Standard exists to:

1. Define **one** enterprise knowledge hierarchy to which every document is classified.
2. Define the **business object (entity) model** — the nouns the Bank recognises — so that documents, records, customers, facilities, controls, and systems can be linked rather than merely stored.
3. Define **knowledge graph node and edge types** so that Shadow Mode knowledge services, enterprise search, and RAG retrieval traverse relationships deterministically.
4. Publish **controlled vocabularies, synonyms, and aliases** so search recall does not depend on the searcher guessing departmental jargon.
5. Provide the **metadata mapping** that binds taxonomy nodes to the mandatory fields in `ANB-ADM-STD-0005`.

This Standard is the foundation of the Knowledge Graph. Documents that are not correctly classified here are effectively invisible to enterprise discovery, regardless of their content quality.

---

## 3. Scope

### 3.1 In Scope

| Category | Examples |
|---|---|
| Controlled documents | Policies, standards, SOPs, guidelines, manuals, plans, handbooks |
| Operational records | Customer files, KYC files, credit files, complaint cases, incident reports |
| Governance records | Board and committee minutes, charters, resolutions, regulatory filings |
| Evidence artefacts | Audit workpapers, RCSA outputs, control test evidence, penetration test reports |
| Contracts and legal | MSAs, loan agreements, NDAs, vendor contracts, legal hold notices |
| Correspondence designated as record | Email and chat preserved under `RET-EMAIL-7Y` |

### 3.2 Out of Scope

- Transient drafts never promoted beyond `Draft` status
- System telemetry, application logs, and market data feeds (governed by IT Operations data standards)
- Structured data in ApexCore, ApexLedger, and ApexInsight (governed by the Data Governance Council under a separate data dictionary; this Standard governs *document* and *knowledge object* classification, and references data entities only where documents point at them)

### 3.3 Applicability

All employees (G1–G12), contractors, and third parties authoring or filing documents on behalf of Apex National Bank, Apex National Bank (UK) plc, Apex Bank Europe SE, Apex Securities LLC, Apex Asset Management, Inc., Apex Trust Company, N.A., and Apex Global Services.

---

## 4. Objectives

| # | Objective | Success Measure |
|---|---|---|
| O-1 | Every published document classified to exactly one L4 node | ≥ 99% of Published documents with complete `taxonomy_l1`–`taxonomy_l4` |
| O-2 | Entity references resolvable across systems | ≥ 95% of operational records carry at least one valid typed identifier |
| O-3 | Search precision sufficient for examination response | Median time-to-locate an authoritative policy ≤ 90 seconds |
| O-4 | Knowledge graph connectivity | < 2% orphan documents (no inbound or outbound relationship) |
| O-5 | Vocabulary discipline | Zero unregistered synonyms in controlled fields at quarterly EKMO audit |
| O-6 | Regulatory traceability | 100% of regulated document types mapped to at least one `regulatory_driver` |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Taxonomy Node** | A named position in the four-level classification hierarchy. Nodes are identified by a stable node code (e.g., `T2.4`). |
| **Business Object / Entity** | A real-world thing the Bank recognises and identifies (Customer, Account, Facility, Vendor, Employee, Control, System, Committee). |
| **Knowledge Object** | A document or record together with its metadata, taxonomy assignment, entity references, and relationships. |
| **Knowledge Graph** | The directed, typed graph whose nodes are Knowledge Objects and Business Objects and whose edges are relationships defined in Section 10. |
| **Ontology** | The formal statement of entity types, permitted relationships, and constraints governing the graph. |
| **Controlled Vocabulary (CV)** | An enumerated list of permitted values for a metadata field, maintained by EKMO. |
| **Preferred Term** | The single authorised label for a concept. All synonyms resolve to it. |
| **Alias / Synonym** | An alternative label mapped to a Preferred Term for search expansion only; never stored in a controlled field. |
| **Facet** | A metadata dimension exposed as a search filter (e.g., `owner_department`, `classification`). |
| **Orphan Document** | A Knowledge Object with no resolvable inbound or outbound relationship. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Enterprise Knowledge Management Office (EKMO), ADM** | Owns this Standard, the taxonomy register, and all controlled vocabularies. Operates the classification quality dashboard. Approves L3 node additions between EKC cycles. |
| **Enterprise Knowledge Council (EKC)** | Approves L1 and L2 changes, entity model changes, and relationship type additions. Reviews quarterly taxonomy health reporting. Chaired by the COO; see `ANB-LEG-REF-0003` §7. |
| **Chief Data Officer / Data Governance Council (DGC)** | Ensures alignment between the document taxonomy and the enterprise data dictionary. Owns entity identifier standards for Customer, Account, and Product. |
| **Document Owner (Department)** | Assigns and maintains correct taxonomy and entity references for documents it owns. Accountable for classification accuracy. |
| **Document Custodian (G5–G6)** | Applies taxonomy at creation, corrects on review, remediates orphan and misclassification flags within 30 days. |
| **Department Head (G9–G11)** | Confirms departmental taxonomy coverage annually; sponsors new L3 nodes. |
| **Information Security (ISC)** | Ensures taxonomy does not leak sensitive context through node names, tags, or aliases; approves classification interaction rules for C3/C4 material. |
| **Compliance (CMP)** | Confirms regulated content is discoverable under `regulatory_driver` and `business_process`; validates AML/KYC taxonomy branches. |
| **Internal Audit (IAD)** | Independently tests classification accuracy as a records-management control. |
| **Legal (LEG)** | Confirms taxonomy supports legal hold scoping and e-discovery collection by node and entity. |

---

## 7. Enterprise Knowledge Hierarchy

### 7.1 Structural Rules

1. The hierarchy has exactly **four levels**: L1 Domain → L2 Category → L3 Sub-category → L4 Document Type.
2. Every document is classified to **exactly one L4 node**; L1–L3 are inherited, never entered independently.
3. L4 values are drawn from `CV-DOCTYPE` (`ANB-ADM-STD-0005` §6.4) and must equal the `<TYPE>` segment of the `document_id`.
4. Node codes are stable identifiers. Renaming a label does not change the node code.
5. Where a document could plausibly sit in two branches, classify by **owning accountability**, not by subject mention. An Information Security requirement inside a Retail SOP is classified under Banking Operations if RTL owns it.

### 7.2 Level 1 Domains

| Node | L1 Domain | Primary Owning Departments | Typical Business Units |
|---|---|---|---|
| `T1` | Governance & Legal | LEG, ADM, IAD | CC |
| `T2` | Risk & Compliance | RSK, CMP | CC |
| `T3` | Customer & Products | RTL, CBK, MKT | CRB, CMB, CIB, WAM |
| `T4` | Banking Operations | RTL, CST, ITO, CBK | CRB, CMB, ETO |
| `T5` | Finance & Treasury | FIN, TRY | CC, TM |
| `T6` | Technology & Data | ITO, ISC | ETO |
| `T7` | People & Workplace | HRM, ADM | CC |
| `T8` | Corporate Services | PRC, ADM, MKT | CC |

### 7.3 Level 2 and Level 3 Register

#### T1 — Governance & Legal

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T1.1` | Corporate Governance | Board Governance · Committee Governance · Delegated Authority · Corporate Policy Framework |
| `T1.2` | Legal Affairs | Litigation & Disputes · Legal Opinions · Legal Hold · Regulatory Enforcement |
| `T1.3` | Corporate Secretariat | Entity Management · Minutes & Resolutions · Statutory Filings · Signing Authority |
| `T1.4` | Contracts & Commercial Legal | Contract Templates · Executed Agreements · Obligation Registers · Contract Disputes |
| `T1.5` | Regulatory Affairs | Supervisory Correspondence · Examination Management · Regulatory Change Log |

#### T2 — Risk & Compliance

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T2.1` | Credit Risk | Underwriting Standards · Credit Authority · Portfolio Monitoring · Watchlist & Impairment · Provisioning |
| `T2.2` | Market & Liquidity Risk | Market Risk Limits · IRRBB · Liquidity Stress Testing · Counterparty Risk |
| `T2.3` | Operational Risk | RCSA · Loss Event Management · KRI Management · Resilience Risk |
| `T2.4` | Financial Crime | AML/CFT · KYC & CDD · Sanctions & OFAC · Fraud · SAR & CTR Reporting |
| `T2.5` | Regulatory Compliance | Regulatory Change Management · Compliance Monitoring & Testing · Conduct & Market Abuse · Consumer Protection & Fair Lending |
| `T2.6` | Model Risk | Model Inventory · Model Development · Independent Validation · Model Performance Monitoring |
| `T2.7` | Enterprise Risk Framework | Risk Appetite · Risk Taxonomy · Stress Testing · Capital Adequacy Risk |

#### T3 — Customer & Products

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T3.1` | Deposit Products | Savings · Checking · Money Market & CDs · Product Terms & Fee Schedules |
| `T3.2` | Lending Products | Consumer Loans · Mortgages · Commercial Lending · Corporate Lending |
| `T3.3` | Cards | Consumer Cards · Business & Corporate Cards · Disputes & Chargebacks |
| `T3.4` | Investments & Wealth | Brokerage · Managed Portfolios · Retirement · Trust & Estate |
| `T3.5` | Insurance Distribution | Partner Products · Suitability & Disclosure |
| `T3.6` | Digital Channels | Mobile & Online Banking · Open Banking APIs · Digital Servicing |
| `T3.7` | Customer Documentation | Applications · Agreements · Disclosures · Customer Correspondence |

#### T4 — Banking Operations

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T4.1` | Branch Operations | Cash Handling · Vault & Teller Controls · Safe Deposit · Branch Security |
| `T4.2` | Payments & Settlement | Domestic Payments · Cross-Border Payments · Reconciliation · Nostro Management |
| `T4.3` | Loan Servicing | Booking · Billing & Collections · Modifications · Payoff & Release |
| `T4.4` | Trade Operations | Documentary Credits · Guarantees · Supply-Chain Finance |
| `T4.5` | Customer Servicing | Contact Centre Operations · Complaints · Disputes · Authentication |
| `T4.6` | Operational Control | Reconciliation Standards · Exception Handling · Operational Loss Recording |

#### T5 — Finance & Treasury

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T5.1` | Financial Control | Close & Consolidation · Chart of Accounts · Journal Control · Intercompany |
| `T5.2` | Regulatory Reporting | Call Reports · FR Y-9C · Capital Reporting · Disclosure |
| `T5.3` | Planning & Analysis | Budgeting · Forecasting · Profitability & MI |
| `T5.4` | Liquidity & Funding | Funding Plans · Contingency Funding · FTP · Investment Portfolio |
| `T5.5` | Tax | Tax Compliance · Transfer Pricing · Withholding |
| `T5.6` | Expense & Procure-to-Pay Control | Expense Governance · Invoice Control · Corporate Card Control |

#### T6 — Technology & Data

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T6.1` | Application Management | Application Lifecycle · Release Management · Runbooks |
| `T6.2` | Infrastructure & Cloud | Data Centre · Cloud Platform · Network · Capacity |
| `T6.3` | Information Security | Security Policy & Standards · Identity & Access · Vulnerability Management · Security Operations · Cryptography |
| `T6.4` | Data Governance | Data Dictionary · Data Quality · Lineage · Data Classification |
| `T6.5` | Resilience | Business Continuity · Disaster Recovery · Incident Management · Third-Party Resilience |
| `T6.6` | Change Management | Change Standards · CAB Records · Emergency Change |

#### T7 — People & Workplace

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T7.1` | Employment | Hiring · Onboarding · Offboarding · Employment Contracts |
| `T7.2` | Reward | Compensation · Benefits · Incentive Governance |
| `T7.3` | Learning | Mandatory Training · Professional Development · Certification |
| `T7.4` | Conduct | Code of Conduct · Conflicts of Interest · Disciplinary · Speak-Up |
| `T7.5` | Workplace Services | Facilities · Physical Security · Health & Safety · Travel Administration |

#### T8 — Corporate Services

| L2 Node | L2 Category | L3 Sub-categories |
|---|---|---|
| `T8.1` | Procurement & Vendors | Sourcing · Vendor Due Diligence · Third-Party Risk · Vendor Performance |
| `T8.2` | Records & Knowledge | Records Management · Retention & Disposal · Knowledge Standards · Taxonomy & Metadata |
| `T8.3` | Marketing & Communications | Brand · Campaigns · Regulated Advertising · Corporate Communications |
| `T8.4` | Real Estate | Property Portfolio · Leases · Workplace Projects |

### 7.4 Worked Classification Examples

| Document | L1 | L2 | L3 | L4 | Node Path |
|---|---|---|---|---|---|
| `ANB-CMP-POL-0001` AML Policy | Risk & Compliance | Financial Crime | AML/CFT | `POL` | `T2.4` |
| `ANB-CMP-SOP-0004` SAR Filing Procedure | Risk & Compliance | Financial Crime | SAR & CTR Reporting | `SOP` | `T2.4` |
| `ANB-RTL-FRM-0002` Mortgage Application | Customer & Products | Lending Products | Mortgages | `FRM` | `T3.2` |
| `ANB-CBK-POL-0001` Loan Approval Policy | Risk & Compliance | Credit Risk | Credit Authority | `POL` | `T2.1` |
| `ANB-ISC-SOP-0003` Security Incident Response Plan | Technology & Data | Information Security | Security Operations | `SOP` | `T6.3` |
| `ANB-ITO-PLN-0002` Disaster Recovery Plan | Technology & Data | Resilience | Disaster Recovery | `PLN` | `T6.5` |
| `ANB-LEG-STD-0002` Board & Committee Minutes Standard | Governance & Legal | Corporate Secretariat | Minutes & Resolutions | `STD` | `T1.3` |
| `ANB-PRC-POL-0002` Third-Party Risk Management Policy | Corporate Services | Procurement & Vendors | Third-Party Risk | `POL` | `T8.1` |
| `ANB-ADM-STD-0006` (this document) | Corporate Services | Records & Knowledge | Taxonomy & Metadata | `STD` | `T8.2` |
| `ANB-IAD-RPT-0142` Branch Cash Controls Audit | Governance & Legal | Corporate Governance | Corporate Policy Framework | `RPT` | `T1.1` |

> **Note on audit reports.** Internal Audit reports are classified under the *governance* branch (`T1.1`) rather than the audited subject matter, because the Third Line owns the artefact. The audited subject is captured through `business_process` and `document_relationships` (`assesses:`), preserving discoverability from both directions.

---

## 8. Entity Taxonomy — Business Objects

### 8.1 Core Entity Register

| Entity | Identifier Format | Authoritative System | Owning Function | Typical Documents Attached |
|---|---|---|---|---|
| **Customer** | `CUS-########` | ApexCore / Apex360 | RTL, CBK | KYC files, agreements, complaints, correspondence |
| **Account** | `ACC-##########` | ApexCore | RTL, CBK, TRY | Statements, disclosures, dispute evidence |
| **Credit Facility** | `FAC-########` | ApexCredit | CBK, RSK | Credit memoranda, loan agreements, covenant certificates |
| **Loan Application** | `APP-##########` | ApexOrigin | RTL, CBK | Applications, appraisals, decision records |
| **Employee** | `EMP-######` | ApexPeople | HRM | Contracts, performance records, disciplinary files |
| **Vendor / Third Party** | `VEN-######` | ApexVendor | PRC | Contracts, due diligence packs, performance reviews |
| **Case** | `CAS-########` | Apex360 / ApexGuard | CST, CMP | Complaint files, investigation files, chargeback evidence |
| **Incident** | `INC-########` | ApexServe / ApexShield | ITO, ISC | Incident reports, forensic evidence, post-incident reviews |
| **Change** | `CHG-########` | ApexServe | ITO | Change records, CAB approvals, rollback plans |
| **Audit Engagement** | `AUD-######` | ApexAudit | IAD | Workpapers, reports, issue tracking, validation memoranda |
| **Product** | Canonical product name | ApexCore / Apex360 | RTL, CBK, WAM | Terms, disclosures, marketing collateral |
| **System** | Canonical system name | ApexServe CMDB | ITO, ISC | Runbooks, architecture documents, DR plans |
| **Department** | `CV-DEPT` code | ApexPeople | HRM, ADM | Org charts, departmental policies |
| **Business Unit** | `CV-BU` code | ApexPeople | HRM, FIN | Business plans, MI packs |
| **Committee** | `CV-COMMITTEE` value | ApexDocs | LEG | Charters, agendas, minutes, resolutions |
| **Legal Entity** | Canonical entity name | ApexLegal | LEG | Statutory filings, entity records |
| **Regulation** | `CV-REG` value | ApexDocs | CMP, LEG | Regulatory change assessments, filings |
| **Risk** | `RSK-#####` | ApexRisk | RSK | RCSA outputs, risk assessments, acceptances |
| **Control** | `CTL-#####` | ApexRisk | RSK, IAD | Control descriptions, test evidence |
| **Business Process** | `BP-` code | ApexDocs (CV-PROCESS) | ADM, process owners | SOPs, manuals, checklists |
| **Model** | `MDL-#####` | ApexModel | RSK | Model documentation, validation reports |
| **Location / Site** | `SIT-####` | ApexWorkplace | ADM | Site continuity plans, facilities records |

> `FAC-`, `APP-`, `RSK-`, `CTL-`, `MDL-`, and `SIT-` identifier formats are introduced by this Standard for graph completeness and are registered with EKMO and the Data Governance Council. Identifier formats already published in `ANB-ADM-REF-0001` Appendix A are unchanged and remain authoritative.

### 8.2 Entity Attribute Minimums

Every entity referenced from a document must carry, at minimum:

| Attribute | Requirement |
|---|---|
| Identifier | Typed, pattern-valid per `ANB-ADM-STD-0005` §7.8 |
| Entity type | From Section 8.1 register |
| Owning department | `CV-DEPT` value |
| Authoritative system | Canonical system name from `ANB-ADM-REF-0001` §8 |
| Classification floor | Customer, Employee, and Case entities imply `classification` ≥ C2 |

### 8.3 Entity Hierarchies

```
Legal Entity
└── Business Unit (CRB | CMB | CIB | WAM | TM | ETO | CC)
    └── Department (15 canonical codes)
        └── Business Process (BP-*)
            └── Control (CTL-*)

Customer
├── Account (ACC-*)
│   └── Transaction (system-level, not document-classified)
├── Credit Facility (FAC-*)
│   └── Loan Application (APP-*)
└── Case (CAS-*)

Vendor
├── Contract (document: CTR)
└── Vendor Risk Assessment (document: RPT)
```

---

## 9. Knowledge Graph — Node Types

The Knowledge Graph contains two node families.

### 9.1 Knowledge Object Nodes (documents and records)

| Node Type | Populated From | Key Properties |
|---|---|---|
| `DocumentNode` | ApexDocs published metadata | `document_id`, `version`, `status`, `classification`, taxonomy path, `owner_department` |
| `RecordNode` | ApexKYC, ApexOrigin, ApexGuard, ApexAudit, ApexServe | record identifier, `record_class`, `retention_code`, source system |
| `EvidenceNode` | ApexAudit, ApexRisk, ApexShield | evidence reference, control tested, test date |
| `MinutesNode` | ApexDocs (`MIN`) | committee, meeting date, decisions, attendance |

### 9.2 Business Object Nodes

| Node Type | Identifier | Notes |
|---|---|---|
| `CustomerNode` | `CUS-` | C2 floor; access filtered by entitlement |
| `AccountNode` | `ACC-` | Linked to CustomerNode |
| `FacilityNode` | `FAC-` | Linked to CustomerNode and credit documents |
| `EmployeeNode` | `EMP-` | Used for authorship, custodianship, approval lineage |
| `VendorNode` | `VEN-` | Third-party risk graph root |
| `CaseNode` | `CAS-` | Complaints, investigations, disputes |
| `IncidentNode` | `INC-` | Technology and security incidents |
| `SystemNode` | Canonical system name | Enables blast-radius and dependency queries |
| `ProcessNode` | `BP-` | Bridges documents to `ANB-ADM-GDL-0001` |
| `RiskNode` / `ControlNode` | `RSK-` / `CTL-` | Bridges to `ANB-RSK-POL-0001` framework |
| `RegulationNode` | `CV-REG` value | Regulatory traceability |
| `CommitteeNode` | `CV-COMMITTEE` value | Bridges to `ANB-LEG-REF-0003` |
| `DepartmentNode` / `BusinessUnitNode` | `CV-DEPT` / `CV-BU` | Ownership and accountability queries |

---

## 10. Knowledge Graph — Relationship Types

### 10.1 Document-to-Document Edges

These extend `CV-REL` in `ANB-ADM-STD-0005` §6.9.

| Edge | Direction | Meaning | Cardinality |
|---|---|---|---|
| `governs` | Policy → subordinate document | Policy sets requirements the target must satisfy | 1 → many |
| `implements` | SOP/STD → Policy | Target realises the policy's requirements | many → 1 |
| `supersedes` | New version → prior version | Replacement in the version lineage | 1 → 1 |
| `supports` | Document → Document | Provides supporting detail or procedure | many → many |
| `evidenced_by` | Control document → Report/Record | Control operation demonstrated by target | 1 → many |
| `derived_from` | Instance → Template/Form | Created from a controlled template | many → 1 |
| `assesses` | Audit/Risk report → subject document or process | Third or Second Line opinion on target | many → many |
| `references` | Document → Document | Non-binding citation | many → many |
| `attached_to` | Operational record → parent file | Record forms part of a case/customer/loan file | many → 1 |
| `translates` | Localised version → authoritative English source | Translation lineage | many → 1 |

### 10.2 Document-to-Entity Edges

| Edge | From → To | Example |
|---|---|---|
| `owned_by` | Document → Department | AML Policy `owned_by` CMP |
| `applies_to_bu` | Document → Business Unit | Branch Operations Manual `applies_to_bu` CRB |
| `concerns_customer` | Record → Customer | KYC file `concerns_customer` CUS-04928311 |
| `concerns_account` | Record → Account | Statement `concerns_account` ACC-1029384756 |
| `concerns_facility` | Credit memo → Facility | Credit memorandum `concerns_facility` FAC-00114820 |
| `concerns_vendor` | Contract → Vendor | MSA `concerns_vendor` VEN-104822 |
| `authored_by` / `approved_by` | Document → Employee | Approval lineage for SOX and examination evidence |
| `documents_process` | SOP → Business Process | Complaint SOP `documents_process` BP-CST-CMPL |
| `describes_system` | Runbook → System | Runbook `describes_system` ApexCore |
| `mitigates_risk` | Control document → Risk | Password Standard `mitigates_risk` RSK-00212 |
| `driven_by` | Document → Regulation | KYC Policy `driven_by` BSA |
| `presented_to` | Report/Minutes → Committee | Audit report `presented_to` Audit Committee |
| `held_under` | Any node → Legal Hold matter | Records preserved under a `CAS-` matter |

### 10.3 Traversal Patterns in Regular Use

| Question | Traversal |
|---|---|
| "Which procedures break if we change the AML Policy?" | `ANB-CMP-POL-0001` ← `implements` ← {SOP, FRM, CHK} |
| "Produce every document touching this customer." | `CustomerNode` ← `concerns_customer` ← {records}, then `attached_to` closure |
| "What controls evidence Basel III capital reporting?" | `RegulationNode(Basel III)` ← `driven_by` ← documents → `evidenced_by` → reports |
| "If ApexCore is degraded, which procedures are affected?" | `SystemNode(ApexCore)` ← `describes_system` ← {runbooks, SOPs, DR plans} |
| "Show the approval chain for this version." | `DocumentNode` → `authored_by`/`approved_by` → `EmployeeNode` + workflow evidence |
| "Scope a legal hold for a vendor dispute." | `VendorNode` ← `concerns_vendor` ← {contracts, cases, email records} |

---

## 11. Controlled Vocabularies, Synonyms, and Aliases

### 11.1 Vocabulary Ownership

Vocabularies are tiered. Tier A changes require EKC approval; Tier B changes require EKMO approval with DGC notification.

| Tier | Vocabularies | Change Authority |
|---|---|---|
| **A** | `CV-DEPT`, `CV-BU`, `CV-CLASS`, `CV-DOCTYPE`, `CV-STATUS`, `CV-RECORD` | Enterprise Knowledge Council |
| **B** | `CV-PROCESS`, `CV-REG`, `CV-RISK`, `CV-CONTROL`, `CV-REL`, `CV-COMMITTEE`, `CV-GEO`, `CV-KEYWORD`, `CV-CAVEAT` | EKMO, with DGC notification |

### 11.2 Preferred Terms and Registered Synonyms

Synonyms drive query expansion in enterprise search. They are **never** stored in controlled metadata fields.

| Preferred Term | Registered Synonyms / Aliases | Notes |
|---|---|---|
| Know Your Customer (KYC) | client due diligence, onboarding checks, CDD pack | `CDD` is a distinct sub-concept but expands to KYC in search |
| Suspicious Activity Report (SAR) | suspicious activity filing, FinCEN SAR | Documents remain C3 |
| Currency Transaction Report (CTR) | large cash report, currency report | — |
| Credit Facility | facility, line, limit, exposure line | Do not use "loan" as synonym for revolving facility |
| Non-Performing Asset (NPA) | NPL, impaired loan, bad loan | Preferred term per `ANB-ADM-REF-0001` §13 |
| ApexCore | core banking, Temenos, host system | Vendor names are aliases only |
| ApexGuard | Actimize, TM system, transaction monitoring platform | Never use vendor name in metadata |
| ApexDocs | DMS, OpenText, SharePoint | System of record |
| ApexServe | ServiceNow, ITSM, ticketing | — |
| Risk and Control Self-Assessment (RCSA) | control self assessment, self-assessment | — |
| Business Continuity Plan (BCP) | continuity plan, resilience plan | Distinct from Disaster Recovery Plan |
| Relationship Manager (RM) | coverage banker, account officer | — |
| Material Non-Public Information (MNPI) | inside information, price-sensitive information | Triggers information barrier |
| Third-Party Risk Management | vendor risk, supplier risk, TPRM | — |
| Enterprise Knowledge Management Office | EKMO, knowledge office, records team | Records Management sits within ADM |

### 11.3 Prohibited and Deprecated Terms

| Prohibited / Deprecated | Use Instead | Reason |
|---|---|---|
| "Compliance Department AML Unit" | Compliance (CMP) | Sub-unit names are not canonical departments |
| "IT Department" | IT Operations (ITO) | `CV-DEPT` value |
| "Ops" | Banking Operations (taxonomy) or specific department | Ambiguous |
| "Confidential-Internal" | `C1` Internal or `C2` Confidential | Hybrid labels break validation |
| "Final", "Final v2", "Latest" | Version number + `status` | Version discipline per `ANB-ADM-STD-0007` |
| "Customer ID number" | `CUS-########` | Identifier format |

---

## 12. Search Taxonomy and Semantic Hierarchy

### 12.1 Facet Order in Enterprise Search

ApexDocs presents facets in fixed order so users build muscle memory:

1. `knowledge_domain` (L1)
2. `taxonomy_l2`
3. `document_type`
4. `owner_department`
5. `business_unit`
6. `status`
7. `classification` (entitlement-filtered)
8. `applicable_geographies`
9. `effective_date` range
10. `regulatory_driver`

### 12.2 Ranking Signals

| Signal | Weight Class | Rationale |
|---|---|---|
| `status = Published` | Strong positive | Authoritative version |
| `status = Superseded` | Strong negative | Historical only; visually flagged |
| Exact taxonomy L3/L4 match to query intent | Strong positive | Precision |
| Authored `keywords` match | Strong positive | Human-curated |
| Derived `extracted_topics` match | Weak positive | Advisory only |
| `next_review_date` overdue > 90 days | Negative | `OVERDUE REVIEW` flag |
| Document referenced by many others (`referenced_by` count) | Moderate positive | Centrality |
| Classification above user entitlement | Excluded | Hard filter, not ranking |

### 12.3 Semantic Layers

| Layer | Content | Consumer |
|---|---|---|
| **Lexical** | Full text, titles, keywords | Enterprise Search |
| **Structural** | Taxonomy path, document type, ownership | Faceted navigation |
| **Relational** | Graph edges (Section 10) | Knowledge Graph traversal, impact analysis |
| **Semantic** | Summaries, extracted topics and entities | Semantic search, RAG candidate generation |
| **Entitlement** | Classification, caveats, information barriers | Access filtering — applied before all others |

> **Retrieval rule.** Entitlement filtering is applied first, always. No ranking signal may promote a document above a user's clearance, and no AI assistant may summarise content the requesting user cannot open.

---

## 13. Document Categories and Metadata Mapping

### 13.1 Taxonomy-to-Metadata Binding

| Taxonomy Element | Metadata Field (`ANB-ADM-STD-0005`) | Validation |
|---|---|---|
| L1 Domain | `taxonomy_l1`, `knowledge_domain` | Must be equal to one another |
| L2 Category | `taxonomy_l2` | Must be a child of `taxonomy_l1` |
| L3 Sub-category | `taxonomy_l3` | Must be a child of `taxonomy_l2` |
| L4 Document Type | `taxonomy_l4`, `document_type` | Must equal `<TYPE>` in `document_id` |
| Entity references | `entity_references`, `customers` | Pattern-valid typed identifiers |
| Process linkage | `business_process` | Value from `CV-PROCESS` (`ANB-ADM-GDL-0001`) |
| Relationship edges | `document_relationships`, `parent_document`, `related_documents` | Targets must resolve |
| Regulatory linkage | `regulatory_driver` | Value from `CV-REG` |
| Retention linkage | `retention_code`, `record_class` | Consistent with `ANB-ADM-POL-0001` |

### 13.2 Document Category Profiles

Each category defines which optional metadata becomes mandatory.

| Category | Typical Types | Additional Mandatory Fields |
|---|---|---|
| **Governing documents** | POL, STD | `regulatory_driver`, `review_cycle`, `approval_authority` |
| **Operating documents** | SOP, MAN, CHK, GDL | `business_process`, `parent_document` |
| **Instruments** | CTR, FRM, TPL | `entity_references`, `parent_document` |
| **Assurance artefacts** | RPT (audit, risk), LOG | `entity_references` (`AUD-`/`RSK-`), `risk_category` |
| **Governance records** | MIN, MEM (board/committee) | `committee`, `approval_authority` |
| **Customer records** | FRM, CTR, RPT under customer files | `customers`, `contains_pii=true`, classification ≥ C2 |
| **Technology records** | PLN, RPT, SOP | `systems_referenced`, `entity_references` (`INC-`/`CHG-`) |
| **Regulatory submissions** | REG | `regulatory_driver`, `applicable_entities`, `approval_authority` |

---

## 14. Governance

### 14.1 Change Control

| Change Type | Approver | Cadence | Notification |
|---|---|---|---|
| New L4 assignment rules | EKMO | Continuous | Custodians |
| New or retired L3 node | EKMO (EKC ratification) | Quarterly | Department Heads, DGC |
| New or retired L2 node | Enterprise Knowledge Council | Annual | ExCo, all Custodians |
| New or retired L1 domain | Enterprise Knowledge Council + COO | Annual, exceptional | ExCo, Board Technology & Operational Resilience Committee (informational) |
| New entity type or identifier format | EKC with Data Governance Council concurrence | Quarterly | ITO, ISC |
| New relationship type (`CV-REL`) | EKC | Quarterly | Knowledge platform engineering |
| Synonym / alias registration | EKMO | Monthly | Search operations |

Retirement of any node requires a migration plan showing every affected document's destination node. Nodes are never deleted while documents remain classified to them.

### 14.2 Quality Monitoring

EKMO publishes a monthly Taxonomy Health Report to the EKC containing:

| Metric | Target | Escalation |
|---|---|---|
| Published documents with complete taxonomy path | ≥ 99% | Department Head at < 97% |
| Orphan documents (no graph edges) | < 2% | Custodian remediation within 30 days |
| Broken relationship references | 0 | Immediate Custodian action |
| Documents classified to deprecated nodes | 0 | EKMO-led migration |
| Unregistered values in Tier A vocabularies | 0 | Publication rejection; EKC report |
| Overdue review (> 90 days) | < 3% | Department Head escalation per `ANB-ADM-REF-0001` Appendix B |

### 14.3 Assurance

Internal Audit tests classification accuracy on a sample basis within records-management audits. Compliance tests that regulated content is discoverable by `regulatory_driver` during monitoring cycles. Findings are tracked in ApexAudit and reported to the Audit Committee.

---

## 15. Standards

**S-1.** Every published document carries exactly one L4 node. Publication is rejected without a complete path.

**S-2.** Classification follows owning accountability, not subject mention.

**S-3.** Controlled fields accept preferred terms only. Aliases exist for search expansion and must not appear in metadata.

**S-4.** Every operational record carries at least one typed entity reference.

**S-5.** Every SOP, form, template, and checklist declares a `parent_document`.

**S-6.** Every relationship asserted must resolve to an existing node. Broken edges are defects, not warnings.

**S-7.** Customer, Employee, and Case entity references force a minimum classification of `C2`.

**S-8.** Taxonomy node codes are immutable identifiers; labels may be edited, codes may not be reused.

**S-9.** Where taxonomy and retention appear to conflict, retention (`ANB-ADM-POL-0001`) governs disposal and taxonomy governs discovery. Neither overrides classification (`ANB-ISC-STD-0004`).

**S-10.** No department may operate a private taxonomy, shadow index, or parallel folder classification as a substitute for this Standard.

---

## 16. Processes

### 16.1 Classify a New Document

1. Custodian selects L1 by owning accountability.
2. Custodian selects L2 and L3 from the register in Section 7.3.
3. L4 auto-populates from `document_type`; mismatch is rejected at validation.
4. Custodian adds `business_process` (from `ANB-ADM-GDL-0001`) and entity references.
5. Custodian asserts `parent_document` and at least one `related_documents` value.
6. ApexDocs validates against `ANB-ADM-STD-0005` §7 before permitting Review.

### 16.2 Request a New Taxonomy Node

| Step | Actor | SLA |
|---|---|---|
| Submit request in ApexServe with business justification, expected volume, and candidate parent node | Custodian / Department Head | — |
| Assess overlap with existing nodes and search impact | EKMO | 5 business days |
| Reject with guidance, or provisionally approve with node code | EKMO | 10 business days |
| Ratify at quarterly EKC | Enterprise Knowledge Council | Next cycle |
| Publish updated register and notify Custodians | EKMO | 3 business days post-ratification |

### 16.3 Reclassify Existing Documents

Bulk reclassification is executed by EKMO, never by individual users, and requires: an impact list, Owner sign-off, preservation of prior classification in the metadata change log, and reindexing confirmation. Reclassification never alters `document_id`, `version`, or approval lineage.

### 16.4 Onboard a New Entity Type

New entity types require: identifier format proposal, authoritative system nomination, owning function, classification floor, and DGC concurrence. EKC approves; ITO implements the graph node type; EKMO publishes.

---

## 17. Examples

### 17.1 Fully Classified Knowledge Object — KYC Refresh File

```yaml
document_id: ANB-CMP-FRM-0003-REC-04928311
title: Customer KYC File — CUS-04928311 CDD Refresh
document_type: FRM
owner_department: CMP
business_unit: CRB
taxonomy_l1: Risk & Compliance          # T2
taxonomy_l2: Financial Crime            # T2.4
taxonomy_l3: KYC & CDD
taxonomy_l4: FRM
knowledge_domain: Risk & Compliance
business_process: BP-ONB-KYC
customers: [CUS-04928311]
entity_references: [CUS-04928311, ACC-1029384756]
parent_document: ANB-CMP-POL-0002
related_documents: [ANB-CMP-POL-0001, ANB-ADM-POL-0001]
document_relationships:
  - implements:ANB-CMP-POL-0002
  - attached_to:CUS-04928311
regulatory_driver: [BSA, FinCEN, GLBA]
classification: C2
contains_pii: true
record_class: AML/BSA Records
retention_code: RET-AML-5Y
systems_referenced: [ApexKYC, Apex360]
source_system: ApexKYC
```

### 17.2 Graph Fragment — Policy Impact Analysis

```
RegulationNode(BSA)
   ▲ driven_by
DocumentNode(ANB-CMP-POL-0001 v7.2, T2.4, C2)
   ▲ implements            ▲ implements           ▲ implements
DocumentNode(SOP-0004)  DocumentNode(FRM-0003)  DocumentNode(POL-0005)
   │ documents_process        │ concerns_customer     │ driven_by
ProcessNode(BP-AML-SAR)   CustomerNode(CUS-…)      RegulationNode(OFAC)
   │ evidenced_by
EvidenceNode(AUD-014202 workpaper)
   │ presented_to
CommitteeNode(Financial Crime Committee)
```

Query: *"Which committee sees evidence that the AML Policy operates?"* resolves in three hops without any human knowing where the files are stored.

### 17.3 Synonym Expansion in Practice

A Retail Banking analyst searches **"bad loan report"**. Expansion resolves *bad loan* → **Non-Performing Asset (NPA)**, restricts to `taxonomy_l2 = Credit Risk`, `document_type ∈ {RPT, LOG}`, `status = Published`, and returns the watchlist and impaired asset reporting suite — without the analyst knowing the preferred term.

---

## 18. Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Author | Enterprise Knowledge Management Office | Prepared | 2026-05-20 |
| Reviewer — Data | Elena Vasquez, Chief Data Officer | Reviewed | 2026-06-08 |
| Reviewer — Legal | Margaret Sullivan, General Counsel | Reviewed | 2026-06-11 |
| Reviewer — Compliance | Samuel A. Okonkwo, Chief Compliance Officer | Reviewed | 2026-06-12 |
| Reviewer — Security | Nadia Ferreira, Chief Information Security Officer | Reviewed | 2026-06-15 |
| Ratifying Body | Enterprise Knowledge Council | Ratified | 2026-06-24 |
| Approver | Daniel K. Ortega, Chief Operating Officer | Approved | 2026-06-30 |

Approval recorded in ApexDocs workflow per `ANB-ADM-MTX-0001` §5 (Master Reference Documents).

---

## 19. Review Cycle

| Trigger | Action | Owner |
|---|---|---|
| Annual scheduled review | Full re-validation of L1–L3 register, entity model, and vocabularies | EKMO |
| Quarterly | L3 additions, synonym registration, health reporting | EKMO / EKC |
| Reorganisation | Reassess department and business unit mappings within 30 days | EKMO + HRM |
| New regulation with document impact | Assess `CV-REG` and taxonomy coverage within 60 days | CMP + EKMO |
| New enterprise system | Register `SystemNode` and update alias table within 30 days of go-live | ITO + EKMO |
| Material graph defect (> 5% orphans) | Emergency remediation plan to EKC | EKMO |

Next scheduled review: **2027-06-30**.

---

## 20. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Governs this Standard |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/ENTERPRISE_METADATA_STANDARD.md` | Consumes this taxonomy; supplies field definitions |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | Supplies identifiers classified here |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Retention codes bound to record classes |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Approval of taxonomy changes |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Defines EKC and DGC authority |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | Supplies `CV-PROCESS` values |
| `ANB-ISC-STD-0004` | Data Classification Standard | *(planned)* | Classification semantics |
| `ANB-RSK-POL-0001` | Enterprise Risk Management Policy | *(planned)* | Risk and control entity definitions |

---

## 21. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-05-20 | EKMO | Initial draft: L1–L3 register derived from `ANB-ADM-REF-0001` Appendix C | — |
| 0.4 | 2026-06-05 | EKMO | Added entity taxonomy and identifier formats; DGC review comments incorporated | — |
| 0.7 | 2026-06-15 | EKMO | Added knowledge graph node/edge model and synonym register following ISC review | — |
| 0.9 | 2026-06-24 | EKMO | EKC ratification amendments: Tier A/B vocabulary split; audit report classification rule | — |
| 1.0 | 2026-06-30 | EKMO | First published version | D. K. Ortega |

---

## 22. Appendices

### Appendix A — Taxonomy Node Code Index

| Code | Label | Code | Label |
|---|---|---|---|
| `T1` | Governance & Legal | `T5` | Finance & Treasury |
| `T1.1` | Corporate Governance | `T5.1` | Financial Control |
| `T1.2` | Legal Affairs | `T5.2` | Regulatory Reporting |
| `T1.3` | Corporate Secretariat | `T5.3` | Planning & Analysis |
| `T1.4` | Contracts & Commercial Legal | `T5.4` | Liquidity & Funding |
| `T1.5` | Regulatory Affairs | `T5.5` | Tax |
| `T2` | Risk & Compliance | `T5.6` | Expense & P2P Control |
| `T2.1` | Credit Risk | `T6` | Technology & Data |
| `T2.2` | Market & Liquidity Risk | `T6.1` | Application Management |
| `T2.3` | Operational Risk | `T6.2` | Infrastructure & Cloud |
| `T2.4` | Financial Crime | `T6.3` | Information Security |
| `T2.5` | Regulatory Compliance | `T6.4` | Data Governance |
| `T2.6` | Model Risk | `T6.5` | Resilience |
| `T2.7` | Enterprise Risk Framework | `T6.6` | Change Management |
| `T3` | Customer & Products | `T7` | People & Workplace |
| `T3.1` | Deposit Products | `T7.1` | Employment |
| `T3.2` | Lending Products | `T7.2` | Reward |
| `T3.3` | Cards | `T7.3` | Learning |
| `T3.4` | Investments & Wealth | `T7.4` | Conduct |
| `T3.5` | Insurance Distribution | `T7.5` | Workplace Services |
| `T3.6` | Digital Channels | `T8` | Corporate Services |
| `T3.7` | Customer Documentation | `T8.1` | Procurement & Vendors |
| `T4` | Banking Operations | `T8.2` | Records & Knowledge |
| `T4.1` | Branch Operations | `T8.3` | Marketing & Communications |
| `T4.2` | Payments & Settlement | `T8.4` | Real Estate |
| `T4.3` | Loan Servicing | | |
| `T4.4` | Trade Operations | | |
| `T4.5` | Customer Servicing | | |
| `T4.6` | Operational Control | | |

### Appendix B — Business Ontology (Triple Form)

```
(Document)        --owned_by-->        (Department)
(Department)      --part_of-->         (BusinessUnit)
(BusinessUnit)    --part_of-->         (LegalEntity)
(Document)        --implements-->      (Policy)
(Policy)          --driven_by-->       (Regulation)
(Document)        --documents_process--> (BusinessProcess)
(BusinessProcess) --executed_in-->     (System)
(BusinessProcess) --exposes-->         (Risk)
(Risk)            --mitigated_by-->    (Control)
(Control)         --evidenced_by-->    (EvidenceRecord)
(EvidenceRecord)  --presented_to-->    (Committee)
(Customer)        --holds-->           (Account)
(Customer)        --holds-->           (CreditFacility)
(CreditFacility)  --originated_by-->   (LoanApplication)
(Record)          --concerns_customer-->(Customer)
(Record)          --attached_to-->     (Case)
(Vendor)          --party_to-->        (Contract)
(Contract)        --governed_by-->     (Policy)
(Employee)        --authored-->        (Document)
(Employee)        --approved-->        (DocumentVersion)
(Incident)        --affected-->        (System)
(Incident)        --reported_in-->     (IncidentReport)
```

### Appendix C — Classification Decision Aid

| Question | If yes → |
|---|---|
| Is the artefact a Board or committee record? | `T1.3` Corporate Secretariat |
| Is it an independent Third Line opinion? | `T1.1` Corporate Governance (`assesses` links to subject) |
| Does it define enterprise risk requirements or measurement? | `T2` branch by risk type |
| Does it describe a product a customer buys? | `T3` branch by product family |
| Does it describe how work is executed operationally? | `T4` branch by operation |
| Does it concern the ledger, capital, liquidity, or tax? | `T5` branch |
| Does it concern a system, platform, data, or security control? | `T6` branch |
| Does it concern employment, reward, learning, conduct, or premises? | `T7` branch |
| Does it concern vendors, records, brand, or property? | `T8` branch |

### Appendix D — Anti-Patterns

| Anti-Pattern | Consequence | Correct Practice |
|---|---|---|
| Classifying by folder location | Duplicate and conflicting classification | Classify by accountability |
| Using vendor product names in metadata | Breaks system dependency queries | Use canonical Apex system name |
| Assigning multiple L4 nodes | Ambiguous retention and discovery | One L4; use relationships for secondary context |
| Free-text department names | Vocabulary drift, failed validation | `CV-DEPT` codes |
| Relying on tags instead of taxonomy | Untraceable, unauditable | Tags supplement only |
| Creating a departmental index outside ApexDocs | Shadow record system; records risk | Register content in ApexDocs |

---

**End of Document**

`ANB-ADM-STD-0006` · Version 1.0 · Classification: Internal (C1) · Owner: EKMO, Administration (ADM) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
