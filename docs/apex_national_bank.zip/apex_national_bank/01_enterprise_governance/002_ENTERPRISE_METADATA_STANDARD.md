# Apex National Bank — Enterprise Metadata Standard

**Enterprise Governance Standard | Mandatory Metadata Schema for All Controlled Documents**

---

## Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-STD-0005` |
| **Document Title** | Apex National Bank — Enterprise Metadata Standard |
| **Version** | 1.0 |
| **Owner** | Enterprise Knowledge Management Office (EKMO), Administration Department (ADM) |
| **Document Custodian** | Nadine Okafor, Vice President, Enterprise Knowledge Management (G6) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer, Apex National Bank |
| **Secondary Approvers** | Margaret Sullivan, General Counsel; Nadia Ferreira, Chief Information Security Officer; Samuel A. Okonkwo, Chief Compliance Officer |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-05-12 |
| **Last Updated** | 2026-06-30 |
| **Effective Date** | 2026-07-01 |
| **Review Cycle** | Annual (next scheduled review: 2027-06-30); event-driven review on schema change, regulatory mandate, or material reorganization |
| **Supersedes** | None — initial published standard |
| **Retention** | Permanent while in force; superseded versions retained 10 years in ApexVault |
| **Authoritative System of Record** | ApexDocs (Enterprise Document Management) |
| **Language / Locale** | English (US) — authoritative source text |
| **Related Documents** | `ANB-ADM-REF-0001` Master Company Profile · `ANB-ADM-STD-0002` Document Retention Schedule · `ANB-ISC-STD-0004` Data Classification Standard · `ANB-RSK-POL-0001` Enterprise Risk Management Policy · `ANB-CMP-POL-0001` Anti-Money Laundering Policy · `ANB-ITO-PLN-0001` Business Continuity Plan · `ANB-LEG-STD-0002` Board & Committee Minutes Standard |
| **Keywords** | enterprise metadata, ApexDocs, controlled vocabulary, document lifecycle, retention, classification, taxonomy, EKMO, knowledge discovery, governance, auditability |

> **Authority.** This Standard implements and expands the metadata contract defined in `ANB-ADM-REF-0001` Appendix D. Where this Standard and the Master Company Profile conflict, the Master Company Profile prevails until this Standard is formally amended. All field names, department codes, business-unit codes, classification codes, document-type codes, system names, and identifier formats used herein are canonical as defined in `ANB-ADM-REF-0001`.

---

## Table of Contents

1. [Purpose](#1-purpose)
2. [Scope and Applicability](#2-scope-and-applicability)
3. [Metadata Principles](#3-metadata-principles)
4. [Metadata Taxonomy](#4-metadata-taxonomy)
5. [Mandatory Metadata Fields](#5-mandatory-metadata-fields)
6. [Enterprise Controlled Vocabularies](#6-enterprise-controlled-vocabularies)
7. [Metadata Validation Rules](#7-metadata-validation-rules)
8. [Metadata Governance](#8-metadata-governance)
9. [Metadata Lifecycle](#9-metadata-lifecycle)
10. [Search and Knowledge Discovery](#10-search-and-knowledge-discovery)
11. [Metadata Examples](#11-metadata-examples)
12. [Compliance](#12-compliance)
13. [Appendix](#13-appendix)

---

## 1. Purpose

Enterprise metadata is the structured description of a document that makes the document governable, findable, retainable, and auditable across Apex National Bank.

Without consistent metadata, the Bank cannot:

- Locate the authoritative version of a policy, procedure, or contract under examination pressure
- Enforce classification, need-to-know access, and information-barrier rules
- Apply retention schedules and legal holds with defensible precision
- Reconstruct approval chains for SOX, BSA/AML, or supervisory examinations
- Build reliable document relationships for knowledge discovery, RAG systems, and investigation workflows
- Demonstrate that records management controls operate as designed

This Standard exists so that every document — whether a Board paper, a customer KYC file, a loan agreement, an incident report, or an operational email preserved as a record — carries a minimum, machine-readable, human-validated description that survives staff turnover, system migration, and regulatory scrutiny.

Metadata is not optional decoration. Under Apex National Bank's documented-decision culture, **metadata is a control**. Incomplete or inaccurate metadata is a documentation control deficiency reportable to the Enterprise Knowledge Council (EKC) and testable by Internal Audit (IAD).

---

## 2. Scope and Applicability

### 2.1 In Scope

This Standard applies to every document stored in, published from, or archived through:

- **ApexDocs** — enterprise system of record for controlled documents
- **ApexVault** — long-term archive, legal hold, and defensible disposal
- Operational record repositories that feed ApexDocs or ApexVault (including case files originating in ApexKYC, ApexOrigin, ApexGuard, ApexAudit, ApexServe, and Apex360)

Document types in scope include, without limitation: policies, standards, SOPs, guidelines, manuals, plans, handbooks, forms, templates, contracts, reports, minutes, memoranda, regulatory filings, training materials, checklists, registers, matrices, presentations, customer files, loan files, investigation files, board papers, and email or chat records designated as corporate records.

### 2.2 Out of Scope (with conditions)

| Content | Treatment |
|---|---|
| Transient working drafts never intended for publication | Not required to meet publication metadata until moved to Review |
| Personal OneDrive / mailbox content not designated as a record | Outside ApexDocs; if later designated a record, full metadata applies on intake |
| System-generated logs and telemetry | Governed by IT Operations data standards; record extracts entering ApexDocs require metadata |
| Market data feeds and trade tickets | Governed by Treasury and Markets systems; associated controlled documents require metadata |

### 2.3 Binding Effect

Publication in ApexDocs is rejected if mandatory metadata is incomplete or fails validation. Bypass of metadata validation requires written approval from EKMO and the document's Approver, logged in ApexServe, and is reported monthly to the EKC.

---

## 3. Metadata Principles

| Principle | Statement | Operational Implication |
|---|---|---|
| **Consistency** | The same concept uses the same field name and the same controlled value everywhere. | Department codes, BU codes, system names, and classification labels are taken exclusively from `ANB-ADM-REF-0001`. Free-text synonyms are prohibited in controlled fields. |
| **Standardization** | Field names, data types, and vocabularies are stable enterprise identifiers. | Schema additions are quarterly; removals and renames require EKC approval and a migration plan. |
| **Traceability** | Every published document has a named Owner, Custodian, Approver, and an immutable version history. | Approval evidence exists only in ApexDocs or ApexServe workflow — not in informal email. |
| **Discoverability** | Metadata is designed for retrieval by humans and machines. | Taxonomy, keywords, related documents, systems, regulations, and entity references are populated at publication. |
| **Auditability** | Metadata changes are logged with actor, timestamp, prior value, and new value. | Internal Audit may rely on metadata logs as control evidence. |
| **Regulatory Compliance** | Metadata supports retention, legal hold, classification, and examination readiness. | `retention_code`, `legal_hold`, `classification`, `contains_pii`, and `regulatory_driver` are treated as control fields. |
| **Machine Readability** | Values are structured, typed, and enumerable where possible. | Prefer controlled codes over prose. Dates are ISO 8601. Identifiers follow canonical formats. |
| **Enterprise Search Optimization** | Metadata improves ranking, filtering, and cross-document navigation. | Authored metadata outranks derived metadata when values conflict. |
| **Authored Beats Derived** | Human-entered values prevail over machine-generated suggestions. | Discrepancies are logged; derived fields never authorize publication alone. |
| **Least Privilege Labeling** | Classification and handling caveats reflect actual sensitivity. | Over-classification and under-classification are both control deficiencies. |

---

## 4. Metadata Taxonomy

Metadata at Apex National Bank is organized into seven categories. Every field in Section 5 belongs to exactly one category. Categories are used for schema governance, training, validation profiles, and reporting — they are not substitute taxonomy nodes for content classification (content taxonomy remains the four-level hierarchy in `ANB-ADM-REF-0001` Appendix C).

### 4.1 Administrative Metadata

Identity and ownership: who owns the document, who maintains it, who approved it, and how it is addressed to its audience.

Examples: `document_id`, `title`, `owner_department`, `custodian`, `approver`, `audience`, `author`.

### 4.2 Business Metadata

Business context that situates the document in products, processes, geographies, entities, and committees.

Examples: `business_unit`, `business_process`, `applicable_entities`, `applicable_geographies`, `products`, `committee`, `approval_authority`.

### 4.3 Technical Metadata

Systems, source platforms, and technical provenance.

Examples: `source_system`, `systems_referenced`, `language`, `file_format`, `checksum`.

### 4.4 Compliance Metadata

Regulatory drivers, retention, legal hold, and record class.

Examples: `regulatory_driver`, `retention_code`, `record_class`, `legal_hold`, `contains_pii`, `contains_mnpi`.

### 4.5 Knowledge Metadata

Discovery, relationships, and semantic context for the enterprise knowledge platform.

Examples: `taxonomy_l1`–`taxonomy_l4`, `keywords`, `tags`, `related_documents`, `document_relationships`, `entity_references`, `knowledge_domain`, `extracted_topics`.

### 4.6 Lifecycle Metadata

Versioning, status, dates, and supersession.

Examples: `version`, `status`, `created_date`, `effective_date`, `next_review_date`, `review_cycle`, `supersedes`, `superseded_by`.

### 4.7 Security Metadata

Classification, handling caveats, and access constraints.

Examples: `classification`, `handling_caveats`, `geographic_restriction`, `information_barrier_flag`.

---

## 5. Mandatory Metadata Fields

### 5.1 Field Specification Convention

Each field below is specified with: **Name** (ApexDocs technical name), **Description**, **Required**, **Allowed Values**, **Example**, and **Validation Rules**.

**Required** means:

- **M** — Mandatory at publication (ApexDocs rejects publish without a valid value)
- **C** — Conditional mandatory (required when a stated condition is true)
- **O** — Optional but recommended for discovery quality

Employee identifiers use the canonical format `EMP-######`. Customer, account, case, vendor, incident, change, and audit identifiers follow `ANB-ADM-REF-0001` Appendix A.

---

### 5.2 Identity and Ownership Fields

#### `document_id`

| Attribute | Detail |
|---|---|
| **Description** | Canonical enterprise document identifier. |
| **Required** | M |
| **Allowed Values** | Pattern `ANB\|ANBUK\|ANBEU\|ANBGS-<DEPT>-<TYPE>-<SEQ>` where `<DEPT>` is a canonical department code, `<TYPE>` is a document-type code, and `<SEQ>` is four-digit zero-padded. |
| **Example** | `ANB-CMP-POL-0001` |
| **Validation Rules** | Must match regex `^(ANB\|ANBUK\|ANBEU\|ANBGS)-[A-Z]{3}-[A-Z]{3}-[0-9]{4}$`. Department and type codes must exist in controlled vocabularies. Sequence must be unique within organisation prefix + department + type. Assigned by ApexDocs; manual override requires EKMO approval. |

#### `title`

| Attribute | Detail |
|---|---|
| **Description** | Full human-readable document title. |
| **Required** | M |
| **Allowed Values** | Free text, 5–200 characters; no leading/trailing whitespace. |
| **Example** | `Anti-Money Laundering (AML) Policy` |
| **Validation Rules** | Must not equal `short_title`. Must not contain filename-illegal characters (`\ / : * ? " < > \|`). |

#### `short_title`

| Attribute | Detail |
|---|---|
| **Description** | Filename-safe short title used in the ApexDocs filename convention. |
| **Required** | M |
| **Allowed Values** | PascalCase or hyphenated; max 40 characters; `[A-Za-z0-9-]` only. |
| **Example** | `AML-Policy` |
| **Validation Rules** | No spaces. Length ≤ 40. Must be unique within `document_id` version lineage. |

#### `document_type`

| Attribute | Detail |
|---|---|
| **Description** | Three-letter document type code. |
| **Required** | M |
| **Allowed Values** | Controlled vocabulary CV-DOCTYPE (Section 6.4). |
| **Example** | `POL` |
| **Validation Rules** | Must equal the `<TYPE>` segment of `document_id`. |

#### `owner_department`

| Attribute | Detail |
|---|---|
| **Description** | Canonical department code of the owning department. Ownership is departmental, not personal. |
| **Required** | M |
| **Allowed Values** | CV-DEPT: `HRM`, `FIN`, `RTL`, `CBK`, `TRY`, `LEG`, `CMP`, `RSK`, `ISC`, `ITO`, `CST`, `IAD`, `MKT`, `PRC`, `ADM` |
| **Example** | `CMP` |
| **Validation Rules** | Must equal the `<DEPT>` segment of `document_id` (except subsidiary prefixes where mapping is registered with EKMO). Joint ownership prohibited. |

#### `business_unit`

| Attribute | Detail |
|---|---|
| **Description** | Canonical business unit primary for the document's scope. |
| **Required** | M |
| **Allowed Values** | CV-BU: `CRB`, `CMB`, `CIB`, `WAM`, `TM`, `ETO`, `CC` |
| **Example** | `CC` |
| **Validation Rules** | Must be consistent with `owner_department` mapping in Section 6.3. Multi-BU applicability is recorded in `applicable_entities` / narrative scope, not by inventing new BU codes. |

#### `author`

| Attribute | Detail |
|---|---|
| **Description** | Employee ID of the primary author of the current version. |
| **Required** | M |
| **Allowed Values** | `EMP-######` present and active (or recently active) in ApexPeople. |
| **Example** | `EMP-104822` |
| **Validation Rules** | Author must not equal `approver` for the same version (separation of duties). |

#### `custodian`

| Attribute | Detail |
|---|---|
| **Description** | Employee ID of the day-to-day maintainer of the ApexDocs record. |
| **Required** | M |
| **Allowed Values** | `EMP-######`; typically Grade G5–G6. |
| **Example** | `EMP-088451` |
| **Validation Rules** | Must belong to `owner_department` unless a cross-department custodianship is registered with EKMO. |

#### `approver`

| Attribute | Detail |
|---|---|
| **Description** | Employee ID of the individual who authorized publication per the Approval Matrix. |
| **Required** | M (at Approved / Published) |
| **Allowed Values** | `EMP-######` with grade and role sufficient per `ANB-ADM-REF-0001` Section 12. |
| **Example** | `EMP-000217` |
| **Validation Rules** | Must differ from `author`. Grade sufficiency checked against Approval Matrix. Approval must exist as a completed ApexDocs/ApexServe workflow task. |

#### `approval_authority`

| Attribute | Detail |
|---|---|
| **Description** | Named authority level or body that sanctioned publication. |
| **Required** | M for `POL`, `STD`, `PLN`, `HBK`, `REG`, `MIN` |
| **Allowed Values** | Free text constrained to roles/committees in CV-COMMITTEE and executive titles in the Company Profile (e.g., `Chief Operating Officer`, `Group Credit Committee`, `Board Audit Committee`). |
| **Example** | `Chief Operating Officer` |
| **Validation Rules** | Must not invent committees not listed in `ANB-ADM-REF-0001` Section 2.1. |

#### `audience`

| Attribute | Detail |
|---|---|
| **Description** | Populations required to read, acknowledge, or apply the document. |
| **Required** | M |
| **Allowed Values** | One or more of: department codes, grade bands (`G1`–`G12`), named entitlement groups in ApexID, or `ALL-EMPLOYEES`. |
| **Example** | `ALL-EMPLOYEES` |
| **Validation Rules** | At least one audience value required. Grade bands must use canonical G1–G12. |

#### `language`

| Attribute | Detail |
|---|---|
| **Description** | ISO 639-1 language code of the authoritative text. |
| **Required** | M |
| **Allowed Values** | Prefer `en`. Other ISO 639-1 codes permitted for local translations; English remains authoritative unless Legal designates otherwise. |
| **Example** | `en` |
| **Validation Rules** | Two-letter lowercase ISO 639-1. |

---

### 5.3 Lifecycle Fields

#### `version`

| Attribute | Detail |
|---|---|
| **Description** | Published version number. |
| **Required** | M |
| **Allowed Values** | `Major.Minor` for published states; drafts may use `0.x` or `Major.Minor.Patch` in draft space only. |
| **Example** | `7.2` |
| **Validation Rules** | Must match filename version component. Major increment requires full approval chain. Patch versions are never published. |

#### `status`

| Attribute | Detail |
|---|---|
| **Description** | Lifecycle state of the document. |
| **Required** | M |
| **Allowed Values** | CV-STATUS: `Draft`, `Review`, `Approved`, `Published`, `Under Revision`, `Superseded`, `Archived`, `Destroyed` |
| **Example** | `Published` |
| **Validation Rules** | Transitions must follow Section 9. Filename STATUS token maps as: Draft→`DRAFT`, Review→`REVIEW`, Approved→`APPROVED`, Published→`PUBLISHED`, Superseded→`SUPERSEDED`, Archived→`ARCHIVED`. |

#### `created_date`

| Attribute | Detail |
|---|---|
| **Description** | Date the document record was first created. |
| **Required** | M |
| **Allowed Values** | ISO 8601 date (`YYYY-MM-DD`) or datetime with timezone. |
| **Example** | `2024-03-15` |
| **Validation Rules** | Must be ≤ `effective_date` and ≤ `last_updated`. Immutable after first publish. |

#### `effective_date`

| Attribute | Detail |
|---|---|
| **Description** | Date from which the published version is operative. |
| **Required** | M at Approved / Published |
| **Allowed Values** | ISO 8601 date. |
| **Example** | `2026-03-15` |
| **Validation Rules** | Must be ≥ `created_date`. For policies replacing a prior version, must be ≥ prior version `effective_date` unless Legal authorizes backdating (rare; logged). |

#### `last_updated`

| Attribute | Detail |
|---|---|
| **Description** | Timestamp of the last content or metadata change. |
| **Required** | M |
| **Allowed Values** | ISO 8601 datetime. |
| **Example** | `2026-03-15T14:22:08Z` |
| **Validation Rules** | System-maintained; must advance on every successful save. |

#### `review_cycle`

| Attribute | Detail |
|---|---|
| **Description** | Cadence for mandatory periodic review. |
| **Required** | M for controlled documents (`POL`, `STD`, `SOP`, `PLN`, `HBK`, `MAN`) |
| **Allowed Values** | CV-REVIEW: `Annual`, `Biennial`, `Event-driven`, `Annual + test` |
| **Example** | `Annual` |
| **Validation Rules** | `Annual + test` reserved for BCP/DR plans. Event-driven alone requires a stated trigger in document body. |

#### `next_review_date`

| Attribute | Detail |
|---|---|
| **Description** | Date by which the next review must complete. |
| **Required** | M when `review_cycle` is set |
| **Allowed Values** | ISO 8601 date. |
| **Example** | `2027-03-15` |
| **Validation Rules** | Must be > `effective_date`. Documents >90 days past this date are flagged `OVERDUE REVIEW`. |

#### `supersedes`

| Attribute | Detail |
|---|---|
| **Description** | Prior document ID and version replaced by this version. |
| **Required** | C — mandatory when replacing a prior published version |
| **Allowed Values** | `{document_id} v{version}` |
| **Example** | `ANB-CMP-POL-0001 v6.4` |
| **Validation Rules** | Referenced ID must exist. Circular supersession prohibited. |

#### `superseded_by`

| Attribute | Detail |
|---|---|
| **Description** | Successor document ID/version when this document is no longer authoritative. |
| **Required** | C — system-set when a successor is published |
| **Allowed Values** | `{document_id} v{version}` |
| **Example** | `ANB-CMP-POL-0001 v7.2` |
| **Validation Rules** | When set, `status` must be `Superseded`. |

---

### 5.4 Classification and Security Fields

#### `classification`

| Attribute | Detail |
|---|---|
| **Description** | Single information classification label. |
| **Required** | M |
| **Allowed Values** | CV-CLASS: `C0` (Public), `C1` (Internal), `C2` (Confidential), `C3` (Restricted), `C4` (Highly Confidential) |
| **Example** | `C2` |
| **Validation Rules** | Exactly one value. Default if blank at draft is `C1`, but blank at publish is rejected. Downgrade of C3/C4 requires Owner + ISC concurrence. Any document with `contains_pii=true` must be ≥ `C2`. |

#### `handling_caveats`

| Attribute | Detail |
|---|---|
| **Description** | Additional handling constraints beyond classification. |
| **Required** | O (C for C3/C4) |
| **Allowed Values** | CV-CAVEAT multi-select: `NO-FORWARD`, `INFORMATION-BARRIER`, `PRINT-PROHIBITED`, `ENCRYPTION-REQUIRED`, `NAMED-ACCESS-ONLY`, `NO-EMAIL` |
| **Example** | `NO-FORWARD; INFORMATION-BARRIER` |
| **Validation Rules** | `NO-EMAIL` required for C4. `PRINT-PROHIBITED` default for C3 unless ISC exception logged. |

#### `contains_pii`

| Attribute | Detail |
|---|---|
| **Description** | Whether the document contains personally identifiable information or nonpublic personal information. |
| **Required** | M |
| **Allowed Values** | `true` \| `false` |
| **Example** | `true` |
| **Validation Rules** | If `true`, `classification` ≥ C2 and `retention_code` must be compatible with GLBA/GDPR record classes. |

#### `contains_mnpi`

| Attribute | Detail |
|---|---|
| **Description** | Whether the document contains material non-public information. |
| **Required** | M |
| **Allowed Values** | `true` \| `false` |
| **Example** | `false` |
| **Validation Rules** | If `true`, `classification` must be `C3` or `C4`, and `INFORMATION-BARRIER` caveat is mandatory. |

#### `geographic_restriction`

| Attribute | Detail |
|---|---|
| **Description** | Jurisdictions where access is permitted. |
| **Required** | C — mandatory when cross-border access is restricted |
| **Allowed Values** | ISO country codes or named regions from CV-GEO. |
| **Example** | `US; GB` |
| **Validation Rules** | Values must be subset of countries served or booking centres listed in the Company Profile. |

---

### 5.5 Compliance and Retention Fields

#### `retention_code`

| Attribute | Detail |
|---|---|
| **Description** | Code from the Document Retention Schedule linking the document to a retention rule. |
| **Required** | M |
| **Allowed Values** | Codes published in `ANB-ADM-STD-0002` (e.g., `RET-POL-10Y`, `RET-AML-5Y`, `RET-GOV-PERM`). |
| **Example** | `RET-AML-5Y` |
| **Validation Rules** | Must exist in the Retention Schedule. Incompatible combinations of `record_class` and `retention_code` are rejected. |

#### `record_class`

| Attribute | Detail |
|---|---|
| **Description** | High-level records class for archival treatment. |
| **Required** | M |
| **Allowed Values** | CV-RECORD: `Corporate Governance`, `Policies and Standards`, `Customer Account Records`, `AML/BSA Records`, `Credit Files`, `Employee Personnel Records`, `Financial and Accounting Records`, `Contracts`, `Audit Workpapers and Reports`, `Security Incident and Forensic Records`, `Marketing Materials`, `Email and Instant Messaging` |
| **Example** | `AML/BSA Records` |
| **Validation Rules** | Must align with Company Profile Section 11.4 classes. |

#### `legal_hold`

| Attribute | Detail |
|---|---|
| **Description** | Whether destruction is suspended by Legal. |
| **Required** | M |
| **Allowed Values** | `true` \| `false` |
| **Example** | `false` |
| **Validation Rules** | Only Legal (LEG) may set `true`. While `true`, status may not transition to `Destroyed`. |

#### `regulatory_driver`

| Attribute | Detail |
|---|---|
| **Description** | Primary regulations or supervisory frameworks driving the document. |
| **Required** | C — mandatory for `POL`, `STD`, `SOP`, `REG`, and all AML/KYC/credit policy documents |
| **Allowed Values** | Multi-select from CV-REG (Section 6.8). |
| **Example** | `BSA; FinCEN; OCC` |
| **Validation Rules** | Free-text regulations not in CV-REG require EKMO registration before use. |

#### `risk_category`

| Attribute | Detail |
|---|---|
| **Description** | Primary enterprise risk taxonomy category addressed or created by the document. |
| **Required** | C — mandatory for Risk, Compliance, Audit, and control-bearing SOPs |
| **Allowed Values** | CV-RISK: `Credit`, `Market`, `Liquidity`, `Operational`, `Compliance`, `Financial Crime`, `Technology`, `Cyber`, `Model`, `Conduct`, `Strategic`, `Reputational` |
| **Example** | `Financial Crime` |
| **Validation Rules** | Must use Risk taxonomy terms consistent with `ANB-RSK-POL-0001`. |

#### `control_category`

| Attribute | Detail |
|---|---|
| **Description** | Nature of control the document defines or evidences. |
| **Required** | O (recommended for `POL`, `STD`, `SOP`, `CHK`) |
| **Allowed Values** | CV-CONTROL: `Preventive`, `Detective`, `Corrective`, `Directive`, `Compensating` |
| **Example** | `Directive` |
| **Validation Rules** | Multi-select permitted; at least one value when provided. |

---

### 5.6 Business Context Fields

#### `business_process`

| Attribute | Detail |
|---|---|
| **Description** | Named enterprise business process the document governs or supports. |
| **Required** | C — mandatory for `SOP`, `MAN`, `CHK`, and operational `RPT` |
| **Allowed Values** | CV-PROCESS (Section 6.5). |
| **Example** | `Customer Onboarding — KYC` |
| **Validation Rules** | Must match an entry in CV-PROCESS; new processes require EKC approval. |

#### `products`

| Attribute | Detail |
|---|---|
| **Description** | Canonical product names in scope. |
| **Required** | C — mandatory when the document is product-specific |
| **Allowed Values** | Product names exactly as listed in Company Profile Section 3. |
| **Example** | `Apex Fixed-Rate Mortgage; Apex Jumbo Mortgage` |
| **Validation Rules** | No invented product names. Multi-value semicolon-separated. |

#### `applicable_entities`

| Attribute | Detail |
|---|---|
| **Description** | Legal entities to which the document applies. |
| **Required** | M |
| **Allowed Values** | From Company Profile legal identity and subsidiaries (e.g., `Apex National Bank, N.A.`, `Apex Financial Group, Inc.`, `Apex Securities LLC`, `Apex Bank Europe SE`). |
| **Example** | `Apex National Bank, N.A.` |
| **Validation Rules** | At least one entity. Entity names must match Company Profile spelling. |

#### `applicable_geographies`

| Attribute | Detail |
|---|---|
| **Description** | Countries or regions of applicability. |
| **Required** | M |
| **Allowed Values** | CV-GEO (countries served per Company Profile Section 4.4, plus `Global`). |
| **Example** | `United States` |
| **Validation Rules** | `Global` implies all licensed jurisdictions; use sparingly and justify in document scope. |

#### `customers`

| Attribute | Detail |
|---|---|
| **Description** | Customer identifiers when the document is a customer record or case file. |
| **Required** | C — mandatory for customer files, KYC files, loan files, complaint cases |
| **Allowed Values** | `CUS-########` (and optionally `ACC-##########`). |
| **Example** | `CUS-04928311` |
| **Validation Rules** | Pattern `^CUS-[0-9]{8}$`. Classification floor C2. |

#### `committee`

| Attribute | Detail |
|---|---|
| **Description** | Board or management committee that received, approved, or owns the document. |
| **Required** | C — mandatory for `MIN` and for policies requiring committee ratification |
| **Allowed Values** | CV-COMMITTEE (Section 6.7). |
| **Example** | `Financial Crime Committee` |
| **Validation Rules** | Must be a committee named in Company Profile Section 2.1. |

---

### 5.7 Knowledge and Relationship Fields

#### `taxonomy_l1` … `taxonomy_l4`

| Attribute | Detail |
|---|---|
| **Description** | Four-level knowledge taxonomy path. Document is classified to exactly one L4 node. |
| **Required** | M |
| **Allowed Values** | Hierarchy per Company Profile Appendix C. |
| **Example** | L1=`Risk & Compliance`; L2=`Financial Crime`; L3=`AML/CFT`; L4=`POL` |
| **Validation Rules** | L4 must be consistent with `document_type`. Assignment to L1/L2 only is rejected. |

#### `knowledge_domain`

| Attribute | Detail |
|---|---|
| **Description** | Convenience label equal to `taxonomy_l1` for search facets. |
| **Required** | M |
| **Allowed Values** | The eight L1 domains in Appendix C. |
| **Example** | `Risk & Compliance` |
| **Validation Rules** | Must equal `taxonomy_l1`. |

#### `keywords`

| Attribute | Detail |
|---|---|
| **Description** | Controlled vocabulary terms for enterprise search. |
| **Required** | M |
| **Allowed Values** | 3–25 terms from CV-KEYWORD or approved domain glossaries; lowercase preferred for multi-word phrases. |
| **Example** | `aml, bsa, transaction monitoring, sar, ctr, sanctions` |
| **Validation Rules** | Minimum three keywords at publish. Synonym sprawl discouraged; prefer glossary terms from Company Profile Section 13. |

#### `tags`

| Attribute | Detail |
|---|---|
| **Description** | Supplementary free-text or semi-controlled labels for discovery. |
| **Required** | O |
| **Allowed Values** | Free text; max 15 tags. |
| **Example** | `program-northstar, us-only` |
| **Validation Rules** | Tags never replace taxonomy or keywords. Prohibited as sole classification mechanism. |

#### `related_documents`

| Attribute | Detail |
|---|---|
| **Description** | Document IDs of governing, supporting, or dependent documents. |
| **Required** | M |
| **Allowed Values** | One or more valid `document_id` values. |
| **Example** | `ANB-ADM-REF-0001; ANB-CMP-POL-0002; ANB-ADM-STD-0002` |
| **Validation Rules** | At least one related document for controlled publications. All enterprise documents must reference `ANB-ADM-REF-0001` unless EKMO grants a documented exception (operational customer records may reference their governing policy instead, plus the Company Profile at the policy layer). Broken references are rejected or flagged `ORPHAN-REF`. |

#### `parent_document`

| Attribute | Detail |
|---|---|
| **Description** | Governing policy or standard for a subordinate standard, SOP, form, or template. |
| **Required** | C — mandatory for `SOP`, `STD` subordinate to a policy, `FRM`, `TPL`, `CHK` |
| **Allowed Values** | Valid `document_id`. |
| **Example** | `ANB-CMP-POL-0001` |
| **Validation Rules** | Parent must be Published. Type hierarchy: SOP/FRM/TPL/CHK → POL or STD; STD → POL. |

#### `document_relationships`

| Attribute | Detail |
|---|---|
| **Description** | Typed relationships beyond simple related-document lists. |
| **Required** | O (recommended) |
| **Allowed Values** | Structured pairs: `relationship_type:target_document_id` where type ∈ CV-REL (Section 6.9). |
| **Example** | `implements:ANB-CMP-POL-0001; evidenced_by:ANB-IAD-RPT-0142` |
| **Validation Rules** | Target IDs must exist. Bidirectional derived links maintained by ApexDocs in `referenced_by`. |

#### `entity_references`

| Attribute | Detail |
|---|---|
| **Description** | Structured references to customers, vendors, employees, accounts, cases, or incidents. |
| **Required** | C — mandatory for operational records |
| **Allowed Values** | Typed identifiers: `CUS-`, `VEN-`, `EMP-`, `ACC-`, `CAS-`, `INC-`, `CHG-`, `AUD-`. |
| **Example** | `CUS-04928311; CAS-00417723` |
| **Validation Rules** | Patterns per Company Profile Appendix A. |

#### `systems_referenced`

| Attribute | Detail |
|---|---|
| **Description** | Canonical enterprise systems named in or governing the document. |
| **Required** | O (C when the document is a system SOP, runbook, or security standard) |
| **Allowed Values** | System names exactly as in Company Profile Section 8 (e.g., `ApexCore`, `ApexGuard`, `ApexDocs`). |
| **Example** | `ApexGuard; ApexKYC` |
| **Validation Rules** | No unofficial nicknames (`"Actimize"` alone is rejected; use `ApexGuard`). |

#### `source_system`

| Attribute | Detail |
|---|---|
| **Description** | System of origin for the document or record. |
| **Required** | M |
| **Allowed Values** | Canonical system name, typically `ApexDocs` for authored controlled documents; may be `ApexKYC`, `ApexOrigin`, `ApexGuard`, `ApexAudit`, `ApexServe`, `Apex Mail`, etc. |
| **Example** | `ApexDocs` |
| **Validation Rules** | Must be a named system in Company Profile Section 8 or an EKMO-registered source. |

#### `metadata_source`

| Attribute | Detail |
|---|---|
| **Description** | Provenance of the metadata package. |
| **Required** | M |
| **Allowed Values** | `authored` \| `derived` \| `hybrid` |
| **Example** | `hybrid` |
| **Validation Rules** | Publication requires `authored` or `hybrid`. Pure `derived` metadata cannot authorize publication. |

#### `summary_short` / `summary_detailed`

| Attribute | Detail |
|---|---|
| **Description** | Machine-generated or authored abstracts for discovery. |
| **Required** | O |
| **Allowed Values** | Free text; short ≤ 300 characters; detailed ≤ 2,000 characters. |
| **Example** | `Defines the Bank's BSA/AML program, monitoring, CTR/SAR obligations, and retention.` |
| **Validation Rules** | Advisory only. Never substitute for reading the document. Confidence recorded separately in `confidence_score` (heuristic, not a calibrated probability). |

---

## 6. Enterprise Controlled Vocabularies

Controlled vocabularies (CVs) are maintained by EKMO in ApexDocs. Only EKC may add, retire, or rename values in Level-A vocabularies (departments, business units, classification, document types, status).

### 6.1 Document Status (`CV-STATUS`)

| Value | Meaning |
|---|---|
| `Draft` | Author development; not citable |
| `Review` | Circulating for mandatory review |
| `Approved` | Signed; effective date set; not yet released to full audience |
| `Published` | Authoritative live version |
| `Under Revision` | Successor draft exists; current Published remains authoritative |
| `Superseded` | Replaced; read-only; watermarked |
| `Archived` | Past active use; within retention in ApexVault |
| `Destroyed` | Retention expired; destruction certified; metadata stub retained |

### 6.2 Business Units (`CV-BU`)

`CRB` · `CMB` · `CIB` · `WAM` · `TM` · `ETO` · `CC`

### 6.3 Departments (`CV-DEPT`) and Default BU Mapping

| Department Code | Department Name | Default `business_unit` |
|---|---|---|
| `HRM` | Human Resources | `CC` |
| `FIN` | Finance | `CC` |
| `RTL` | Retail Banking | `CRB` |
| `CBK` | Corporate Banking | `CIB` |
| `TRY` | Treasury | `TM` |
| `LEG` | Legal | `CC` |
| `CMP` | Compliance | `CC` |
| `RSK` | Risk | `CC` |
| `ISC` | Information Security | `ETO` |
| `ITO` | IT Operations | `ETO` |
| `CST` | Customer Support | `CRB` |
| `IAD` | Internal Audit | `CC` |
| `MKT` | Marketing | `CC` |
| `PRC` | Procurement | `CC` |
| `ADM` | Administration | `CC` |

*Note: Corporate Banking (`CBK`) may document CMB-scoped commercial lending content; `business_unit` may be `CMB` when the document's primary scope is Commercial Banking, while `owner_department` remains `CBK`.*

### 6.4 Document Types (`CV-DOCTYPE`)

`POL` · `STD` · `SOP` · `GDL` · `MAN` · `PLN` · `REF` · `HBK` · `CHK` · `MTX` · `FRM` · `TPL` · `CTR` · `RPT` · `MIN` · `MEM` · `REG` · `TRN` · `LOG` · `PRE`

### 6.5 Business Processes (`CV-PROCESS`) — Core Set

| Process ID | Process Name | Typical Owner |
|---|---|---|
| `BP-ONB-KYC` | Customer Onboarding — KYC | CMP / RTL / CBK |
| `BP-CRD-UW` | Credit Underwriting & Approval | CBK / RSK / RTL |
| `BP-CRD-SVC` | Loan Servicing | RTL / CBK / ITO |
| `BP-PAY-XBR` | Cross-Border Payments | ITO / TRY / CMP |
| `BP-AML-TM` | AML Transaction Monitoring | CMP |
| `BP-AML-SAR` | SAR Investigation & Filing | CMP |
| `BP-FRD-INV` | Fraud Investigation | CMP / RSK |
| `BP-ISC-IR` | Security Incident Response | ISC / ITO |
| `BP-ITO-CHG` | Technology Change Management | ITO |
| `BP-ITO-DR` | Disaster Recovery Execution | ITO |
| `BP-CST-CMPL` | Complaint Handling | CST / CMP |
| `BP-PRC-TPRM` | Third-Party Risk Management | PRC |
| `BP-HRM-JML` | Joiner–Mover–Leaver | HRM / ISC |
| `BP-FIN-CLOSE` | Financial Close & Reporting | FIN |
| `BP-TRY-LIQ` | Liquidity & Funding Management | TRY |
| `BP-IAD-ENG` | Internal Audit Engagement | IAD |
| `BP-LEG-CTR` | Contract Lifecycle | LEG / PRC |
| `BP-MKT-ADV` | Regulated Advertising Review | MKT / CMP |
| `BP-ADM-REC` | Records & Knowledge Management | ADM |
| `BP-BRD-GOV` | Board & Committee Governance | LEG |

### 6.6 Classifications (`CV-CLASS`)

| Code | Label |
|---|---|
| `C0` | Public |
| `C1` | Internal |
| `C2` | Confidential |
| `C3` | Restricted |
| `C4` | Highly Confidential |

### 6.7 Committees (`CV-COMMITTEE`)

Board: `Board of Directors`, `Audit Committee`, `Risk Committee`, `Compensation & Human Capital Committee`, `Nominating & Corporate Governance Committee`, `Technology & Operational Resilience Committee`, `Public Responsibility & Compliance Committee`.

Management: `Executive Committee`, `Asset & Liability Committee`, `Group Credit Committee`, `Operational Risk Committee`, `Financial Crime Committee`, `New Product Approval Committee`, `Change Advisory Board`, `Data Governance Council`, `Enterprise Knowledge Council`, `Disclosure Committee`.

### 6.8 Regulatory Drivers (`CV-REG`) — Illustrative Core Set

`BSA` · `FinCEN` · `OFAC` · `OCC` · `FRB` · `FDIC` · `CFPB` · `SEC` · `FINRA` · `GLBA` · `SOX` · `GDPR` · `CCPA` · `PCI DSS` · `Basel III` · `Reg E` · `Reg Z` · `Reg CC` · `FCA` · `PRA` · `ECB` · `BaFin` · `MAS` · `HKMA` · `RBI` · `DFSA` · `ISO 27001` · `NIST CSF`

### 6.9 Relationship Types (`CV-REL`)

| Type | Meaning |
|---|---|
| `governs` | Policy/standard governs the target |
| `implements` | Document implements requirements of the target |
| `supersedes` | Replaces the target |
| `supports` | Provides supporting procedure or evidence |
| `evidenced_by` | Control evidenced by the target report/record |
| `derived_from` | Created from the target template/form |
| `related_to` | General associative link |
| `attached_to` | Operational attachment to a case/customer/loan file |

### 6.10 Risk Levels and Priority (`CV-RISK-LEVEL`, `CV-PRIORITY`)

| Vocabulary | Values |
|---|---|
| Risk Level | `Critical`, `High`, `Medium`, `Low` |
| Priority | `P1`, `P2`, `P3`, `P4` |

Used on incident reports, audit issues, and risk assessments; not a substitute for `classification`.

### 6.11 Lifecycle Filename Tokens

| Metadata `status` | Filename STATUS token |
|---|---|
| Draft | `DRAFT` |
| Review | `REVIEW` |
| Approved | `APPROVED` |
| Published | `PUBLISHED` |
| Superseded | `SUPERSEDED` |
| Archived | `ARCHIVED` |

---

## 7. Metadata Validation Rules

### 7.1 Naming Validation

1. `document_id` must match the canonical pattern and controlled codes.
2. Filename must equal:
   `<document_id>_<short_title>_v<version>_<STATUS>_<YYYYMMDD>[ _C3|_C4].<ext>`
3. `short_title` ≤ 40 characters; `[A-Za-z0-9-]`.
4. Full path length ≤ 200 characters.
5. C3/C4 documents must append classification suffix in the filename.

### 7.2 Required Fields at Publication

ApexDocs rejects publication unless all **M** fields are populated and all applicable **C** fields for the document type are populated. Minimum publication set always includes:

`document_id`, `title`, `short_title`, `document_type`, `owner_department`, `business_unit`, `author`, `custodian`, `approver`, `audience`, `language`, `version`, `status`, `created_date`, `effective_date`, `last_updated`, `classification`, `contains_pii`, `contains_mnpi`, `retention_code`, `record_class`, `legal_hold`, `taxonomy_l1`–`taxonomy_l4`, `knowledge_domain`, `keywords`, `related_documents`, `applicable_entities`, `applicable_geographies`, `source_system`, `metadata_source`.

### 7.3 Duplicate Detection

- Exact `document_id` collision → hard fail.
- Same `owner_department` + `document_type` + normalized `title` while another Published version exists → soft fail requiring Custodian confirmation of intentional new sequence vs. version increment.
- Customer-file duplicates detected on identical `entity_references` + `document_type` + same calendar day → warning to Custodian.

### 7.4 Version Validation

- Published versions must be `Major.Minor` only.
- New Major requires Approval Matrix full chain.
- `supersedes` required when replacing.
- Concurrent Published versions of the same `document_id` are prohibited (except temporary dual-visibility during `Under Revision`, where only one is authoritative).

### 7.5 Relationship Validation

- All IDs in `related_documents`, `parent_document`, `document_relationships`, and `supersedes` must resolve.
- Orphan references after target retirement → EKC monthly report; Custodian must remediate within 30 days.
- `parent_document` type constraints enforced (Section 5.7).

### 7.6 Mandatory References

| Document Class | Mandatory Related References |
|---|---|
| Enterprise policies/standards | `ANB-ADM-REF-0001` |
| SOPs / forms / templates | Parent POL/STD + `ANB-ADM-REF-0001` (directly or via parent) |
| AML/KYC operational records | Governing CMP policy (`ANB-CMP-POL-0001` / `ANB-CMP-POL-0002`) |
| Credit files | `ANB-CBK-POL-0001` and applicable product forms |
| Board/committee minutes | `ANB-LEG-STD-0002` |

### 7.7 Date Validation

- `created_date` ≤ `effective_date` ≤ `next_review_date` (when review applies).
- Filename date component must equal the version's publication date (`YYYYMMDD`).
- Future `effective_date` > 365 days from approval requires Approver justification.

### 7.8 Identifier Validation

| Identifier | Pattern |
|---|---|
| Document ID | `^(ANB\|ANBUK\|ANBEU\|ANBGS)-[A-Z]{3}-[A-Z]{3}-[0-9]{4}$` |
| Employee | `^EMP-[0-9]{6}$` |
| Customer | `^CUS-[0-9]{8}$` |
| Account | `^ACC-[0-9]{10}$` |
| Case | `^CAS-[0-9]{8}$` |
| Vendor | `^VEN-[0-9]{6}$` |
| Incident | `^INC-[0-9]{8}$` |
| Change | `^CHG-[0-9]{8}$` |
| Audit engagement | `^AUD-[0-9]{6}$` |

### 7.9 Security Consistency Checks

- `contains_pii=true` ⇒ `classification` ∈ {C2, C3, C4}
- `contains_mnpi=true` ⇒ `classification` ∈ {C3, C4} and `INFORMATION-BARRIER` present
- `classification=C4` ⇒ `NO-EMAIL` present; `source_system` may not be `Apex Mail`
- Downgrade events require ISC concurrence ticket ID stored in metadata change log

---

## 8. Metadata Governance

### 8.1 Document Owner (Department)

- Accountable for accuracy and completeness of authored metadata
- Ensures Custodian is assigned and trained
- Approves classification (with ISC for C3/C4 changes)
- Remediate overdue review and orphan references within EKC SLAs

### 8.2 Department Head (G9–G11)

- Ensures departmental compliance with this Standard
- Escalates systemic metadata quality issues
- Confirms ownership transfers within 30 days of reorganization

### 8.3 Enterprise Knowledge Management Office (EKMO) — Administration (ADM)

- Owns this Standard and the ApexDocs metadata schema
- Maintains controlled vocabularies and taxonomy registration
- Operates validation rules and quality dashboards
- Secretariat to the Enterprise Knowledge Council
- Provides training, guidance, and exception logging
- Rejects non-compliant publication requests that bypass controls

### 8.4 Information Security (ISC)

- Owns security metadata semantics (`classification` alignment with `ANB-ISC-STD-0004`, handling caveats, MNPI controls)
- Concurs on C3/C4 downgrades and privileged access to restricted libraries
- Monitors metadata-related data-loss risks (misclassification, unauthorized tags exposing sensitive context)

### 8.5 Compliance (CMP)

- Ensures regulatory metadata (`regulatory_driver`, AML record classes, complaint/SAR linkages) supports supervisory expectations
- Challenges business units that omit drivers on regulated document types
- Uses metadata quality as an input to compliance monitoring and testing

### 8.6 Internal Audit (IAD)

- Independently tests metadata completeness, accuracy, and control operation
- May raise issues against departments and against EKMO as control owner
- Relies on metadata logs as audit evidence; does not modify production metadata except through documented audit trails in ApexAudit

### 8.7 Legal (LEG)

- Sole authority to set and release `legal_hold`
- Advises on retention conflicts and cross-border metadata restrictions
- Approves entity naming and minutes-related metadata standards

### 8.8 Enterprise Knowledge Council (EKC)

- Approves schema changes, vocabulary changes, and taxonomy amendments
- Reviews monthly metadata quality and exception reports
- Escalates persistent deficiencies to ExCo

---

## 9. Metadata Lifecycle

Metadata follows the document lifecycle defined in Company Profile Section 11.2.

```
Creation → Review → Approval → Publication → Revision → Superseded → Archived → Destroyed
```

| Stage | Metadata Obligations |
|---|---|
| **Creation** | Author populates identity, ownership draft fields, proposed classification, taxonomy, and keywords. `status=Draft`. `metadata_source` typically `authored` or `hybrid` if assisted. |
| **Review** | Mandatory reviewers validate classification, retention, regulatory drivers, and relationships. Comments dispositioned in ApexDocs. |
| **Approval** | Approver identity captured; `approval_authority` set; separation-of-duties validated; `status=Approved`; `effective_date` set. |
| **Publication** | Full mandatory set validated; search index updated; prior version auto-transitions to `Superseded` with `superseded_by` link; audience entitlements applied in ApexID. |
| **Revision** | Published version remains authoritative (`Under Revision` banner). New draft carries proposed version number; relationships to parent/related docs re-validated before publish. |
| **Superseded** | Metadata frozen except system fields (`superseded_by`, archive flags). Watermark applied. Remains searchable with de-prioritised ranking. |
| **Archived** | Record migrated to ApexVault per `retention_code`; metadata stub retained in ApexDocs for discovery. |
| **Destroyed** | Permitted only if `legal_hold=false` and retention expired. Destruction certificate retained permanently; metadata stub records destruction event, actor, and certificate ID. |

**Event-driven triggers** forcing metadata review: regulatory change affecting `regulatory_driver`; reorganization affecting `owner_department`; system rename affecting `systems_referenced`; classification standard change; merger or entity change affecting `applicable_entities`.

---

## 10. Search and Knowledge Discovery

### 10.1 Enterprise Search

ApexDocs full-text search is filtered and ranked using metadata facets: `classification` (respecting entitlement), `owner_department`, `document_type`, `business_unit`, `taxonomy_*`, `status`, `applicable_geographies`, `systems_referenced`, `keywords`, and date ranges. Published versions outrank Superseded. C3/C4 results appear only for named-access users.

### 10.2 Semantic Search

`keywords`, taxonomy paths, `summary_short` / `summary_detailed`, and `extracted_topics` feed semantic indexes. Authored keywords and taxonomy are trusted features; derived topics are secondary signals.

### 10.3 Knowledge Graph and Document Relationships

Typed `document_relationships`, `parent_document`, `related_documents`, and `entity_references` populate the enterprise knowledge graph used by Shadow Mode knowledge services. Graph edges enable traversal from a policy to implementing SOPs, from a customer to KYC and loan files, and from an incident to controlling standards.

### 10.4 Cross-Document Discovery

Investigators and auditors pivot on shared identifiers (`CUS-`, `CAS-`, `INC-`, `AUD-`) and shared `regulatory_driver` / `business_process` values to assemble complete evidence packs without relying on folder structures.

### 10.5 AI Assistants and Enterprise RAG

Retrieval-augmented generation and enterprise assistants must:

1. Filter candidates by user entitlement and `classification`
2. Prefer `status=Published` unless the user explicitly requests historical versions
3. Cite `document_id` and `version` in answers
4. Treat derived summaries as non-authoritative
5. Never surface C3/C4 content across information barriers

Metadata quality directly determines RAG precision. Missing `related_documents` or incorrect taxonomy increases hallucination risk and is treated as a knowledge-control defect.

### 10.6 Audit Investigations and Regulatory Discovery

IAD, CMP, LEG, and supervisory response teams use metadata to execute legal holds, produce retention proofs, demonstrate approval lineage, and export complete relationship graphs for examinations. Response packages include metadata manifests alongside content.

---

## 11. Metadata Examples

Examples below are illustrative but use only canonical codes, systems, and identifiers from the Company Profile.

### 11.1 Policy — AML Policy

```yaml
document_id: ANB-CMP-POL-0001
title: Anti-Money Laundering (AML) Policy
short_title: AML-Policy
document_type: POL
owner_department: CMP
business_unit: CC
author: EMP-104822
custodian: EMP-088451
approver: EMP-000311
approval_authority: Public Responsibility & Compliance Committee
audience: ALL-EMPLOYEES
language: en
version: "7.2"
status: Published
created_date: 2019-01-10
effective_date: 2026-03-15
last_updated: 2026-03-15T16:05:00Z
review_cycle: Annual
next_review_date: 2027-03-15
supersedes: ANB-CMP-POL-0001 v6.4
classification: C2
contains_pii: false
contains_mnpi: false
retention_code: RET-POL-10Y
record_class: Policies and Standards
legal_hold: false
regulatory_driver: [BSA, FinCEN, OFAC, OCC]
risk_category: Financial Crime
control_category: Directive
business_process: BP-AML-TM
applicable_entities: ["Apex National Bank, N.A.", "Apex Financial Group, Inc."]
applicable_geographies: [Global]
taxonomy_l1: Risk & Compliance
taxonomy_l2: Financial Crime
taxonomy_l3: AML/CFT
taxonomy_l4: POL
knowledge_domain: Risk & Compliance
keywords: [aml, bsa, transaction monitoring, sar, ctr, sanctions, correspondent banking]
related_documents: [ANB-ADM-REF-0001, ANB-CMP-POL-0002, ANB-CMP-SOP-0004, ANB-ADM-STD-0002]
systems_referenced: [ApexGuard, ApexKYC]
source_system: ApexDocs
metadata_source: authored
```

### 11.2 Procedure — Security Incident Response Plan

```yaml
document_id: ANB-ISC-SOP-0003
title: Security Incident Response Plan
short_title: Security-Incident-Response
document_type: SOP
owner_department: ISC
business_unit: ETO
parent_document: ANB-ISC-POL-0001
classification: C3
handling_caveats: [NO-FORWARD, PRINT-PROHIBITED, NAMED-ACCESS-ONLY]
contains_pii: true
contains_mnpi: false
status: Published
version: "5.0"
approver: EMP-000408   # CISO
approval_authority: Chief Information Security Officer
business_process: BP-ISC-IR
risk_category: Cyber
control_category: Corrective
systems_referenced: [ApexShield, ApexServe, ApexID]
related_documents: [ANB-ADM-REF-0001, ANB-ISC-POL-0001, ANB-ITO-TPL-0004]
retention_code: RET-SEC-7Y
record_class: Security Incident and Forensic Records
metadata_source: authored
```

### 11.3 Audit Report

```yaml
document_id: ANB-IAD-RPT-0142
title: Internal Audit Report — Retail Branch Cash Controls Q2 FY2026
short_title: Audit-RetailBranchCash-Q2FY26
document_type: RPT
owner_department: IAD
business_unit: CC
classification: C2
status: Approved
version: "1.0"
approver: EMP-000512   # Chief Audit Executive
approval_authority: Chief Audit Executive
committee: Audit Committee
entity_references: [AUD-014202]
business_process: BP-IAD-ENG
risk_category: Operational
related_documents: [ANB-ADM-REF-0001, ANB-IAD-REF-0002, ANB-RTL-MAN-0003]
systems_referenced: [ApexAudit, ApexCore, ApexTeller]
record_class: Audit Workpapers and Reports
retention_code: RET-AUD-7Y
metadata_source: hybrid
```

### 11.4 Loan Agreement

```yaml
document_id: ANB-CBK-CTR-0088
title: Executed Term Loan Agreement — Horizon Manufacturing Group
short_title: TermLoan-HorizonMfg
document_type: CTR
owner_department: CBK
business_unit: CMB
classification: C2
contains_pii: true
status: Published
version: "1.0"
customers: [CUS-06291004]
entity_references: [CUS-06291004, ACC-8871200456]
products: ["Commercial term loans and revolving lines of credit"]
parent_document: ANB-CBK-CTR-0002
related_documents: [ANB-CBK-POL-0001, ANB-CBK-TPL-0003]
systems_referenced: [ApexOrigin, ApexCredit, ApexCore]
business_process: BP-CRD-UW
record_class: Credit Files
retention_code: RET-CRD-LIFE-7Y
regulatory_driver: [OCC, Basel III]
metadata_source: authored
```

### 11.5 Customer KYC File

```yaml
document_id: ANB-CMP-FRM-0003-REC-04928311
title: Customer KYC File — CUS-04928311 CDD Refresh
short_title: KYC-CUS-04928311-CDD
document_type: FRM
owner_department: CMP
business_unit: CRB
classification: C2
contains_pii: true
contains_mnpi: false
customers: [CUS-04928311]
entity_references: [CUS-04928311]
business_process: BP-ONB-KYC
parent_document: ANB-CMP-POL-0002
related_documents: [ANB-CMP-POL-0001, ANB-CMP-POL-0002]
systems_referenced: [ApexKYC, Apex360]
source_system: ApexKYC
record_class: AML/BSA Records
retention_code: RET-AML-5Y
regulatory_driver: [BSA, FinCEN, GLBA]
risk_category: Financial Crime
status: Published
version: "3.0"
metadata_source: hybrid
```

### 11.6 Incident Report

```yaml
document_id: ANB-ITO-RPT-0311
title: Major Incident Report — ApexMobile Authentication Outage
short_title: Incident-ApexMobile-Auth
document_type: RPT
owner_department: ITO
business_unit: ETO
classification: C2
status: Published
version: "1.1"
entity_references: [INC-00993421, CHG-00451209]
business_process: BP-ITO-CHG
risk_category: Technology
priority: P1
systems_referenced: [ApexMobile, ApexID, ApexServe, ApexShield]
related_documents: [ANB-ITO-SOP-0003, ANB-ISC-SOP-0003, ANB-ITO-TPL-0004]
record_class: Security Incident and Forensic Records
retention_code: RET-SEC-7Y
metadata_source: authored
```

### 11.7 Board Minutes

```yaml
document_id: ANB-LEG-MIN-2026-06
title: Board of Directors Meeting Minutes — 18 June 2026
short_title: BoardMinutes-20260618
document_type: MIN
owner_department: LEG
business_unit: CC
classification: C2
contains_mnpi: true
handling_caveats: [INFORMATION-BARRIER, NO-FORWARD]
status: Approved
version: "1.0"
committee: Board of Directors
approval_authority: Board of Directors
parent_document: ANB-LEG-STD-0002
related_documents: [ANB-ADM-REF-0001, ANB-LEG-STD-0002]
record_class: Corporate Governance
retention_code: RET-GOV-PERM
applicable_entities: ["Apex Financial Group, Inc.", "Apex National Bank, N.A."]
metadata_source: authored
```

### 11.8 Vendor Contract

```yaml
document_id: ANB-PRC-CTR-0455
title: Master Services Agreement — Northgate Cloud Services
short_title: MSA-NorthgateCloud
document_type: CTR
owner_department: PRC
business_unit: CC
classification: C2
contains_pii: false
status: Published
version: "2.0"
entity_references: [VEN-104822]
parent_document: ANB-LEG-CTR-0001
related_documents: [ANB-PRC-POL-0001, ANB-PRC-POL-0002, ANB-ISC-POL-0001]
business_process: BP-PRC-TPRM
systems_referenced: [ApexSource, ApexVendor, ApexDocs]
record_class: Contracts
retention_code: RET-CTR-TERM-7Y
regulatory_driver: [OCC, GLBA]
metadata_source: authored
```

### 11.9 Mortgage Application

```yaml
document_id: ANB-RTL-FRM-0002-REC-10293847
title: Mortgage Application — ACC-1029384756
short_title: MortgageApp-ACC-1029384756
document_type: FRM
owner_department: RTL
business_unit: CRB
classification: C2
contains_pii: true
customers: [CUS-03115590]
entity_references: [CUS-03115590, ACC-1029384756]
products: [Apex Fixed-Rate Mortgage]
parent_document: ANB-RTL-FRM-0002
related_documents: [ANB-CBK-POL-0001, ANB-RTL-POL-0001]
systems_referenced: [ApexOrigin, ApexCore, ApexKYC]
business_process: BP-CRD-UW
source_system: ApexOrigin
record_class: Credit Files
retention_code: RET-CRD-LIFE-7Y
regulatory_driver: [CFPB, Reg Z, OCC, GLBA]
status: Published
version: "1.0"
metadata_source: hybrid
```

### 11.10 Email Record

```yaml
document_id: ANB-LEG-MEM-2201
title: Legal Hold Notice — Matter Horizon v. Apex
short_title: LegalHold-Horizon
document_type: MEM
owner_department: LEG
business_unit: CC
classification: C3
handling_caveats: [NO-FORWARD, NAMED-ACCESS-ONLY]
contains_pii: true
contains_mnpi: false
legal_hold: true
status: Published
version: "1.0"
source_system: Apex Mail
systems_referenced: [Apex Mail, ApexVault, ApexDocs]
record_class: Email and Instant Messaging
retention_code: RET-EMAIL-7Y
related_documents: [ANB-ADM-STD-0002]
entity_references: [CAS-00881234]
metadata_source: hybrid
audience: [LEG, CMP, IAD, named-custodians]
```

---

## 12. Compliance

This Standard supports — but does not itself constitute — the Bank's compliance with records, privacy, security, and prudential expectations. Metadata fields map to control needs as follows:

| Framework | Metadata Support |
|---|---|
| **SOX** | Approval lineage (`author`, `approver`, workflow evidence), version history, and retention of financial reporting procedures and certifications |
| **GLBA** | `contains_pii`, classification floor C2, retention of NPI-bearing customer records, access audience controls |
| **GDPR / CCPA** | Geographic restriction, PII flags, retention codes enabling erasure vs. legal-hold override, entity references for subject access |
| **PCI DSS** | Classification and handling for cardholder-data documents; systems_referenced linkage to card environments |
| **ISO 27001 / NIST CSF** | Security classification, incident document linkage, access and handling caveats, ISC ownership of security metadata semantics |
| **Basel III / OCC safety & soundness** | Credit file retention metadata, risk category, committee and approval authority for credit and capital policies |
| **BSA / FinCEN** | AML record class, five-year retention codes, SAR/CTR related documents with C3 controls |

Supervisory examinations may request metadata manifests. Departments must be able to export, for any in-scope population, the mandatory field set with timestamps and approver identity within examination response timelines coordinated by Compliance and Legal.

---

## 13. Appendix

### Appendix A — Metadata Dictionary (Complete Field Index)

| Field | Category | Req | Type |
|---|---|---|---|
| `document_id` | Administrative | M | String (pattern) |
| `title` | Administrative | M | String |
| `short_title` | Administrative | M | String |
| `document_type` | Administrative | M | Enum CV-DOCTYPE |
| `owner_department` | Administrative | M | Enum CV-DEPT |
| `author` | Administrative | M | EMP ID |
| `custodian` | Administrative | M | EMP ID |
| `approver` | Administrative | M* | EMP ID |
| `approval_authority` | Administrative | C | String (controlled) |
| `audience` | Administrative | M | List |
| `language` | Technical | M | ISO 639-1 |
| `business_unit` | Business | M | Enum CV-BU |
| `business_process` | Business | C | Enum CV-PROCESS |
| `products` | Business | C | List (canonical names) |
| `applicable_entities` | Business | M | List |
| `applicable_geographies` | Business | M | List CV-GEO |
| `customers` | Business | C | List CUS IDs |
| `committee` | Business | C | Enum CV-COMMITTEE |
| `version` | Lifecycle | M | Major.Minor |
| `status` | Lifecycle | M | Enum CV-STATUS |
| `created_date` | Lifecycle | M | Date |
| `effective_date` | Lifecycle | M* | Date |
| `last_updated` | Lifecycle | M | Datetime |
| `review_cycle` | Lifecycle | C | Enum CV-REVIEW |
| `next_review_date` | Lifecycle | C | Date |
| `supersedes` | Lifecycle | C | String |
| `superseded_by` | Lifecycle | C | String |
| `classification` | Security | M | Enum CV-CLASS |
| `handling_caveats` | Security | O/C | List CV-CAVEAT |
| `contains_pii` | Security | M | Boolean |
| `contains_mnpi` | Security | M | Boolean |
| `geographic_restriction` | Security | C | List |
| `retention_code` | Compliance | M | String (schedule) |
| `record_class` | Compliance | M | Enum CV-RECORD |
| `legal_hold` | Compliance | M | Boolean |
| `regulatory_driver` | Compliance | C | List CV-REG |
| `risk_category` | Compliance | C | Enum CV-RISK |
| `control_category` | Compliance | O | Enum CV-CONTROL |
| `taxonomy_l1`–`taxonomy_l4` | Knowledge | M | Taxonomy path |
| `knowledge_domain` | Knowledge | M | Enum L1 |
| `keywords` | Knowledge | M | List |
| `tags` | Knowledge | O | List |
| `related_documents` | Knowledge | M | List Doc IDs |
| `parent_document` | Knowledge | C | Doc ID |
| `document_relationships` | Knowledge | O | Typed list |
| `entity_references` | Knowledge | C | Typed IDs |
| `systems_referenced` | Technical | O/C | List systems |
| `source_system` | Technical | M | System name |
| `metadata_source` | Knowledge | M | authored/derived/hybrid |
| `summary_short` | Knowledge | O | String |
| `summary_detailed` | Knowledge | O | String |
| `confidence_score` | Knowledge | O | Number (heuristic) |
| `completeness_score` | Knowledge | O | Percentage |
| `last_validated_by` | Administrative | O | EMP ID |
| `referenced_by` | Knowledge | Derived | List Doc IDs |

\* Mandatory at Approved/Published states.

### Appendix B — Controlled Vocabulary Quick Reference

| CV ID | Purpose |
|---|---|
| CV-STATUS | Lifecycle states |
| CV-BU | Business units |
| CV-DEPT | Departments |
| CV-DOCTYPE | Document types |
| CV-PROCESS | Business processes |
| CV-CLASS | Classification C0–C4 |
| CV-CAVEAT | Handling caveats |
| CV-RECORD | Record classes |
| CV-REVIEW | Review cycles |
| CV-COMMITTEE | Board and management committees |
| CV-REG | Regulatory drivers |
| CV-RISK | Risk categories |
| CV-RISK-LEVEL | Critical/High/Medium/Low |
| CV-PRIORITY | P1–P4 |
| CV-CONTROL | Control categories |
| CV-REL | Document relationship types |
| CV-GEO | Countries and regions |
| CV-KEYWORD | Approved search keywords (maintained in ApexDocs) |

### Appendix C — Example Metadata Template (Copy Block)

Use the following template in document headers or ApexDocs intake forms. Replace bracketed values. Do not omit mandatory fields.

```yaml
# ANB Enterprise Metadata Template v1.0 — ANB-ADM-STD-0005
document_id: ANB-<DEPT>-<TYPE>-<SEQ>
title: "<Full Title>"
short_title: "<Short-Title>"
document_type: <POL|STD|SOP|...>
owner_department: <HRM|FIN|RTL|CBK|TRY|LEG|CMP|RSK|ISC|ITO|CST|IAD|MKT|PRC|ADM>
business_unit: <CRB|CMB|CIB|WAM|TM|ETO|CC>
author: EMP-######
custodian: EMP-######
approver: EMP-######
approval_authority: "<Role or Committee>"
audience: ["ALL-EMPLOYEES"]
language: en
version: "1.0"
status: Draft
created_date: YYYY-MM-DD
effective_date: YYYY-MM-DD
last_updated: YYYY-MM-DDThh:mm:ssZ
review_cycle: Annual
next_review_date: YYYY-MM-DD
supersedes: ""
classification: C1
handling_caveats: []
contains_pii: false
contains_mnpi: false
geographic_restriction: []
retention_code: RET-???
record_class: "<Record Class>"
legal_hold: false
regulatory_driver: []
risk_category: ""
control_category: ""
business_process: ""
products: []
applicable_entities: ["Apex National Bank, N.A."]
applicable_geographies: ["United States"]
customers: []
committee: ""
taxonomy_l1: ""
taxonomy_l2: ""
taxonomy_l3: ""
taxonomy_l4: ""
knowledge_domain: ""
keywords: []
tags: []
related_documents: [ANB-ADM-REF-0001]
parent_document: ""
document_relationships: []
entity_references: []
systems_referenced: []
source_system: ApexDocs
metadata_source: authored
summary_short: ""
```

### Appendix D — Alignment to Master Company Profile

| Topic | Authoritative Source |
|---|---|
| Department and BU codes | `ANB-ADM-REF-0001` §§2.3–2.4 |
| Classification model C0–C4 | `ANB-ADM-REF-0001` §9 |
| Document ID and type codes | `ANB-ADM-REF-0001` §10 |
| Versioning and lifecycle states | `ANB-ADM-REF-0001` §11 |
| Approval Matrix | `ANB-ADM-REF-0001` §12 |
| Ownership model (Owner/Custodian/Approver/Audience) | `ANB-ADM-REF-0001` Appendix B |
| Knowledge taxonomy L1–L4 | `ANB-ADM-REF-0001` Appendix C |
| Baseline metadata categories | `ANB-ADM-REF-0001` Appendix D |
| Enterprise systems names | `ANB-ADM-REF-0001` §8 |
| Identifier formats | `ANB-ADM-REF-0001` Appendix A |

---

**End of Document**

`ANB-ADM-STD-0005` · Version 1.0 · Classification: Internal (C1) · Owner: Enterprise Knowledge Management Office, Administration (ADM) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled and valid only on the date printed. The authoritative version resides in ApexDocs. All enterprise documents must comply with this Standard from the Effective Date.*
