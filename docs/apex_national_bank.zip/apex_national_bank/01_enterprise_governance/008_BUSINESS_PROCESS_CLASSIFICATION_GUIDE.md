# Apex National Bank — Business Process Classification Guide

**Enterprise Governance Guide | Process Hierarchy, Ownership, and Enterprise Mapping**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-GDL-0001` |
| **Document Title** | Apex National Bank — Business Process Classification Guide |
| **Version** | 1.0 |
| **Owner** | Administration Department (ADM) — Enterprise Knowledge Management Office (EKMO) |
| **Joint Owner** | Risk Department (RSK) — Operational Risk, for process-to-risk mapping |
| **Custodian** | Nadine Okafor, Vice President, Enterprise Knowledge Management (G6) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer |
| **Secondary Approvers** | Helena Brandt, Chief Risk Officer; Samuel A. Okonkwo, Chief Compliance Officer |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-05-27 |
| **Effective Date** | 2026-07-01 |
| **Last Updated** | 2026-06-30 |
| **Review Cycle** | Annual (next review 2027-06-30); process register updated quarterly |
| **Supersedes** | None — initial published guide |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Governing Body** | Enterprise Knowledge Council (EKC); Operational Risk Committee (ORC) for risk mapping |
| **System of Record** | ApexDocs (register) · ApexRisk (process-risk-control linkage) |
| **Keywords** | business process, process taxonomy, process hierarchy, CV-PROCESS, process owner, RCSA, control mapping, resilience |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-ADM-STD-0005` · `ANB-ADM-STD-0006` · `ANB-ADM-STD-0007` · `ANB-ADM-POL-0001` · `ANB-ADM-MTX-0001` · `ANB-LEG-REF-0003` |

> **Authority.** This Guide is the source of the `CV-PROCESS` controlled vocabulary referenced by `ANB-ADM-STD-0005` §6 and `ANB-ADM-STD-0006` §13.1. Departments, business units, and systems named here are those defined in `ANB-ADM-REF-0001` §7 and §8 and are not extended by this Guide.

---

## 2. Document Purpose

The Bank's documents describe processes; its risks arise in processes; its controls sit inside processes; and its regulators examine processes. Yet without a single process register, three teams describe the same activity three ways and the Bank cannot answer basic questions: *who owns this?*, *what breaks if this system fails?*, *which policy governs this?*

This Guide establishes a single enterprise process hierarchy and maps every process to the six dimensions that make it governable:

| Dimension | Why It Matters |
|---|---|
| **Departments** | Establishes accountable ownership |
| **Systems** | Enables impact and resilience analysis |
| **Documents** | Connects the process to its governing policy and operating procedure |
| **Risk Categories** | Drives RCSA scope and appetite monitoring |
| **Compliance Categories** | Drives regulatory traceability and examination response |
| **Business Entities** | Connects processes to the customers, accounts, facilities, and cases they act on |

The result is a process register that the Knowledge Graph can traverse: from a regulation, to the processes it governs, to the documents that describe them, to the controls that evidence them, to the committee that oversees them.

---

## 3. Scope

### 3.1 In Scope

Every recurring business activity performed by Apex National Bank and its subsidiaries that: produces a customer or regulatory outcome; creates, modifies, or consumes a record; carries an operational, compliance, or financial risk; or is subject to control testing.

### 3.2 Out of Scope

- One-off projects and programmes (governed by the Technology Steering Committee portfolio, not the process register)
- Individual task-level work instructions below Level 4
- Processes performed exclusively by a vendor with no Bank control point (these are mapped as **vendor dependencies** of a Bank process, not as processes)

### 3.3 Relationship to Other Classifications

| Classification | Answers | Owner |
|---|---|---|
| **Knowledge Taxonomy** (`ANB-ADM-STD-0006`) | Where does this *document* belong? | EKMO |
| **Process Classification** (this Guide) | What *activity* does the Bank perform? | EKMO with process owners |
| **Risk Taxonomy** (`ANB-RSK-POL-0001`) | What can go wrong? | Risk |
| **Data Dictionary** (Data Governance Council) | What does this *data element* mean? | Chief Data Officer |

The four are distinct and must not be conflated. A document sits in one taxonomy node and may describe several processes; a process may be described by several documents.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Every process has a single named owner | 100% of L3 processes with a named owner (G7+) |
| O-2 | Every operating document declares its process | ≥ 98% of SOPs, manuals, and checklists with a valid `business_process` |
| O-3 | Every critical process has documented controls | 100% of important business services with RCSA coverage |
| O-4 | System failure impact is knowable in minutes | Impact query resolvable from the graph without manual analysis |
| O-5 | Regulatory traceability is complete | 100% of `CV-REG` values mapped to at least one process |
| O-6 | Resilience tolerances are set where required | 100% of important business services with an approved impact tolerance |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Process Group (L1)** | The highest level of the hierarchy; a major domain of enterprise activity. |
| **Process Area (L2)** | A coherent grouping of processes managed together, usually by one department. |
| **Process (L3)** | The unit of governance: it has one owner, at least one governing document, a risk profile, and controls. `CV-PROCESS` values are assigned at this level. |
| **Sub-process (L4)** | A discrete step sequence within a process; documented but not separately owned. |
| **Process Owner** | The accountable individual (G7+) for design, performance, control effectiveness, and documentation currency. |
| **Process Operator** | The team or role that executes the process. |
| **Important Business Service** | A service whose disruption would cause intolerable harm to customers or market integrity; carries a Board-approved impact tolerance. |
| **Control Point** | A step at which a control operates and produces evidence. |
| **Handoff** | A transfer of work between departments — the highest-risk point in any process. |
| **Vendor Dependency** | A step performed by a third party within a Bank-owned process. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **EKMO (ADM)** | Owns this Guide and the `CV-PROCESS` register. Allocates process codes. Validates that documents cite valid process values. |
| **Process Owner (G7+)** | Accountable for the process end to end: design, documentation, controls, performance, and change. Signs the annual process attestation. |
| **Department Head (G9–G11)** | Confirms process ownership within the department; resolves cross-team disputes; sponsors process changes. |
| **Operational Risk (RSK)** | Maps processes to risks and controls in ApexRisk; challenges RCSA outputs; maintains the risk taxonomy linkage. |
| **Compliance (CMP)** | Maps processes to regulatory obligations; confirms coverage during monitoring. |
| **IT Operations (ITO)** | Maintains the process-to-system mapping in the CMDB; supplies criticality tiers. |
| **Business Continuity (ITO with ADM)** | Determines important business services and impact tolerances; runs business impact analysis. |
| **Internal Audit (IAD)** | Uses the register for audit universe construction; tests process control effectiveness. |
| **Enterprise Knowledge Council** | Approves L1 and L2 changes; ratifies L3 additions. |
| **Operational Risk Committee** | Ratifies process criticality and reviews process-level risk concentration. |

---

## 7. Process Classification Model

### 7.1 Code Format

```
BP-<AREA>-<PROCESS>
```

| Segment | Rule |
|---|---|
| `BP` | Fixed prefix — Business Process |
| `<AREA>` | Two-to-four letter Process Area code from the register in Section 8 |
| `<PROCESS>` | Three-to-five letter Process code, unique within the area |

Codes are permanent. A process that moves between departments keeps its code; only its owner changes. Retired codes are never reused.

### 7.2 Hierarchy Rules

1. Processes are registered and owned at **L3**. L1 and L2 are structural.
2. Every L3 process has exactly one owner, at least one governing policy, and at least one operating document.
3. A process may span departments; ownership then sits with the department accountable for the **outcome**, not the department performing the most steps.
4. Handoffs between departments must be explicit in the process documentation, with an owner on each side.
5. A process without a document is undocumented risk. A document without a process is unanchored guidance. Both are defects reported to the EKC.

### 7.3 Process Attributes

Every registered process carries:

| Attribute | Source |
|---|---|
| Process code and name | This Guide |
| Owner (named, G7+) | Department |
| Owning department and business unit | `CV-DEPT`, `CV-BU` |
| Governing documents | ApexDocs (`governs` / `documents_process` edges) |
| Systems used | ApexServe CMDB |
| Risk categories | ApexRisk |
| Compliance categories | ApexDocs (`CV-REG`) |
| Business entities acted upon | `ANB-ADM-STD-0006` §8.1 |
| Criticality tier | ITO, ratified by ORC |
| Important business service flag | Business Continuity, approved by Board Technology & Operational Resilience Committee |
| Volume and frequency | Process owner, refreshed annually |

---

## 8. Enterprise Process Hierarchy

### 8.1 Level 1 Process Groups

| L1 Code | Process Group | Primary Departments | Business Units |
|---|---|---|---|
| `P1` | Customer Lifecycle | RTL, CBK, CST, CMP | CRB, CMB, CIB, WAM |
| `P2` | Retail Banking Operations | RTL, CST | CRB |
| `P3` | Corporate & Commercial Banking | CBK | CMB, CIB |
| `P4` | Treasury & Markets | TRY | TM |
| `P5` | Credit & Lending | CBK, RTL, RSK | CRB, CMB, CIB |
| `P6` | Payments & Banking Operations | RTL, CBK, ITO | ETO |
| `P7` | Financial Crime & Compliance | CMP | CC |
| `P8` | Risk Management | RSK | CC |
| `P9` | Internal Audit & Assurance | IAD | CC |
| `P10` | Finance & Regulatory Reporting | FIN | CC |
| `P11` | Human Resources | HRM | CC |
| `P12` | Technology & IT Service Management | ITO | ETO |
| `P13` | Information Security | ISC | ETO |
| `P14` | Procurement & Vendor Management | PRC | CC |
| `P15` | Corporate Services, Legal & Knowledge | LEG, ADM, MKT | CC |

### 8.2 Process Area Codes

| Area Code | Process Area | L1 Group | Owning Department |
|---|---|---|---|
| `ONB` | Customer Onboarding | `P1` | RTL / CBK with CMP |
| `CST` | Customer Servicing & Complaints | `P1`, `P2` | CST |
| `DEP` | Deposit Operations | `P2` | RTL |
| `BRN` | Branch Operations | `P2` | RTL |
| `CARD` | Card Operations & Disputes | `P2` | RTL |
| `DIG` | Digital Channels | `P2` | RTL with ITO |
| `CORP` | Corporate Relationship Management | `P3` | CBK |
| `TRD` | Trade & Supply Chain Finance | `P3` | CBK |
| `TRY` | Treasury & Balance Sheet | `P4` | TRY |
| `MKT` | Markets Execution | `P4` | TRY |
| `CRD` | Credit Origination & Underwriting | `P5` | CBK / RTL with RSK |
| `SRV` | Loan Servicing | `P5` | RTL / CBK |
| `COLL` | Collections & Recovery | `P5` | RTL with RSK |
| `PAY` | Payments & Settlement | `P6` | ITO with RTL/CBK |
| `RECN` | Reconciliation & Control | `P6` | FIN with ITO |
| `AML` | Anti-Money Laundering | `P7` | CMP |
| `SAN` | Sanctions Screening | `P7` | CMP |
| `FRD` | Fraud Prevention & Investigation | `P7` | CMP with RSK |
| `REG` | Regulatory Compliance Management | `P7` | CMP |
| `RSK` | Enterprise Risk Management | `P8` | RSK |
| `MDL` | Model Risk Management | `P8` | RSK |
| `AUD` | Internal Audit | `P9` | IAD |
| `FIN` | Financial Control & Reporting | `P10` | FIN |
| `TAX` | Tax | `P10` | FIN |
| `HR` | Human Resources | `P11` | HRM |
| `ITSM` | IT Service Management | `P12` | ITO |
| `RES` | Resilience & Continuity | `P12` | ITO with ADM |
| `SEC` | Information Security | `P13` | ISC |
| `VEN` | Vendor & Third-Party Management | `P14` | PRC |
| `LEG` | Legal & Corporate Secretariat | `P15` | LEG |
| `KNW` | Knowledge & Records Management | `P15` | ADM |
| `BRD` | Brand & Communications | `P15` | MKT |

---

## 9. Process Register

Each table maps L3 processes to departments, systems, governing documents, risk categories, compliance categories, and business entities. Systems named are the canonical Apex platforms from `ANB-ADM-REF-0001` §8.

### 9.1 `P1` Customer Lifecycle

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-ONB-CIP` | Customer Identification & Verification | Head of Onboarding (G8), RTL | ApexKYC, ApexCore, Apex360 | `ANB-CMP-POL-0002`, `ANB-RTL-POL-0001` | Compliance, Financial Crime, Operational | BSA, FinCEN CIP, GLBA | Customer |
| `BP-ONB-KYC` | Customer Due Diligence & Refresh | Head of Financial Crime (G9), CMP | ApexKYC, ApexWatch, Apex360 | `ANB-CMP-POL-0002`, `ANB-CMP-FRM-0003` | Financial Crime, Compliance | BSA, FinCEN CDD Rule | Customer, Account |
| `BP-ONB-EDD` | Enhanced Due Diligence (High Risk, PEP, MSB) | Head of Financial Crime (G9), CMP | ApexKYC, ApexWatch | `ANB-CMP-POL-0002`, `ANB-CMP-POL-0001` | Financial Crime, Reputational | BSA, FinCEN, OFAC | Customer |
| `BP-ONB-ACCT` | Account Opening & Product Setup | Head of Retail Operations (G8), RTL | ApexCore, ApexOnline, ApexTeller | `ANB-RTL-POL-0001` | Operational, Conduct | Reg DD, Reg E, UDAAP | Customer, Account |
| `BP-ONB-CORP` | Corporate Client Onboarding | Head of Client Onboarding (G8), CBK | ApexKYC, ApexCore, Apex360 | `ANB-CMP-POL-0002`, `ANB-CBK-POL-0001` | Compliance, Credit, Operational | BSA, FinCEN, Beneficial Ownership | Customer, Legal Entity |
| `BP-ONB-EXIT` | Customer Exit & Relationship Termination | Head of Financial Crime (G9), CMP | ApexCore, ApexKYC, ApexGuard | `ANB-CMP-POL-0001` | Financial Crime, Conduct, Legal | BSA, UDAAP, Reg B | Customer, Account, Case |
| `BP-CST-CMPL` | Complaint Handling & Root Cause | Head of Customer Support (G9), CST | Apex360, ApexAssist, ApexVoice | `ANB-CST-SOP-0001` | Conduct, Compliance, Reputational | UDAAP, CFPB, FCA DISP | Customer, Case |
| `BP-CST-AUTH` | Customer Authentication & Verification | Head of Contact Centre (G8), CST | ApexID, ApexAssist, ApexVoice | `ANB-ISC-STD-0002` | Fraud, Operational, Cyber | GLBA, FFIEC Authentication | Customer |
| `BP-CST-CORR` | Customer Correspondence & Notices | Head of Customer Support (G9), CST | Apex360, ApexReach | `ANB-MKT-STD-0001` | Conduct, Compliance | Reg E, Reg Z, Reg DD | Customer, Account |

### 9.2 `P2` Retail Banking Operations

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-BRN-CASH` | Branch Cash Handling & Vault Control | Regional Retail Director (G7), RTL | ApexTeller, ApexCore | `ANB-RTL-MAN-0003` | Operational, Fraud, Physical Security | BSA (CTR), FFIEC | Account, Location |
| `BP-BRN-SDB` | Safe Deposit Box Administration | Regional Retail Director (G7), RTL | ApexCore, ApexWorkplace | `ANB-RTL-MAN-0003` | Operational, Legal | State law, BSA | Customer, Location |
| `BP-BRN-OPEN` | Branch Opening & Closing Controls | Regional Retail Director (G7), RTL | ApexTeller, ApexAccess | `ANB-RTL-MAN-0003` | Operational, Physical Security | FFIEC | Location |
| `BP-DEP-MAINT` | Deposit Account Maintenance | Head of Retail Operations (G8), RTL | ApexCore, ApexOnline | `ANB-RTL-POL-0001` | Operational, Conduct | Reg DD, Reg CC | Customer, Account |
| `BP-DEP-DORM` | Dormancy & Escheatment | Head of Retail Operations (G8), RTL | ApexCore, ApexVault | `ANB-RTL-POL-0001`, `ANB-ADM-POL-0001` | Operational, Legal, Compliance | State unclaimed property law | Customer, Account |
| `BP-DEP-FEE` | Fee Assessment & Waiver | Head of Retail Operations (G8), RTL | ApexCore | `ANB-RTL-POL-0001`, `ANB-ADM-MTX-0001` | Conduct, Operational | UDAAP, Reg DD | Customer, Account |
| `BP-CARD-ISS` | Card Issuance & Activation | Head of Cards (G8), RTL | ApexCore, ApexPay, ApexMobile | `ANB-RTL-POL-0001` | Operational, Fraud | Reg Z, PCI DSS | Customer, Account |
| `BP-CARD-DISP` | Card Dispute & Chargeback | Head of Cards (G8), RTL | Apex360, ApexPay | `ANB-CST-SOP-0001` | Operational, Conduct, Fraud | Reg E, Reg Z, network rules | Customer, Account, Case |
| `BP-DIG-ENRL` | Digital Channel Enrolment & Entitlement | Head of Digital Banking (G8), RTL | ApexOnline, ApexMobile, ApexID | `ANB-ISC-STD-0002` | Cyber, Fraud, Operational | GLBA, FFIEC | Customer |
| `BP-DIG-API` | Open Banking API Access Management | Head of Digital Banking (G8), RTL with ITO | Apex Connect, ApexID | `ANB-ISC-POL-0001` | Cyber, Third-Party, Compliance | Open Banking, GDPR, PSD2 (EU) | Customer, Vendor |

### 9.3 `P3` Corporate & Commercial Banking

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-CORP-REL` | Relationship Planning & Client Review | Sector Head (G8), CBK | Apex360, ApexInsight | `ANB-CBK-POL-0001` | Credit, Conduct, Strategic | BSA, Reg B | Customer |
| `BP-CORP-CASH` | Cash Management Service Delivery | Head of Transaction Banking (G8), CBK | ApexPay, Apex Business Online | `ANB-CBK-POL-0001` | Operational, Cyber | UCC 4A, FFIEC | Customer, Account |
| `BP-CORP-COV` | Covenant Monitoring & Reporting | Head of Portfolio Management (G8), CBK | ApexCredit, ApexInsight | `ANB-CBK-POL-0001` | Credit, Operational | Safety & soundness | Customer, Facility |
| `BP-TRD-LC` | Documentary Credits & Guarantees | Head of Trade Finance (G8), CBK | ApexTrade, ApexPay | `ANB-CBK-POL-0001` | Credit, Operational, Financial Crime | UCP 600, OFAC, BSA | Customer, Facility |
| `BP-TRD-SCF` | Supply Chain Finance Programme Management | Head of Trade Finance (G8), CBK | ApexTrade, ApexCredit | `ANB-CBK-POL-0001` | Credit, Operational, Third-Party | Safety & soundness | Customer, Facility |

### 9.4 `P4` Treasury & Markets

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-TRY-LIQ` | Liquidity Monitoring & Reporting | Head of Liquidity Management (G8), TRY | ApexTreasury, ApexInsight | `ANB-TRY-POL-0001` | Liquidity, Market, Compliance | Basel III LCR/NSFR, FR 2052a | Legal Entity |
| `BP-TRY-FUND` | Wholesale Funding Execution | Group Treasurer (G10), TRY | ApexTreasury, ApexTrade | `ANB-TRY-POL-0001` | Liquidity, Market, Legal | Basel III, SEC | Legal Entity |
| `BP-TRY-FTP` | Funds Transfer Pricing Administration | Head of Balance Sheet Management (G8), TRY | ApexTreasury, ApexLedger | `ANB-TRY-POL-0001` | Market, Operational, Model | IRRBB guidance | Business Unit |
| `BP-TRY-CFP` | Contingency Funding Plan Maintenance & Invocation | Group Treasurer (G10), TRY | ApexTreasury | `ANB-TRY-PLN-0002` | Liquidity, Strategic | Basel III, OCC | Legal Entity |
| `BP-TRY-INV` | Investment Portfolio Management | Head of Portfolio (G8), TRY | ApexTreasury, ApexLedger | `ANB-TRY-POL-0001` | Market, Credit, Liquidity | Basel III, FASB | Legal Entity |
| `BP-MKT-FX` | FX Execution & Client Hedging | Head of FX (G8), TRY | ApexTrade, ApexTreasury | `ANB-TRY-POL-0001` | Market, Conduct, Operational | Dodd-Frank, MiFID II, FX Global Code | Customer |
| `BP-MKT-DER` | Interest Rate Derivative Execution | Head of Rates (G8), TRY | ApexTrade | `ANB-TRY-POL-0001` | Market, Credit, Legal | Dodd-Frank, EMIR, ISDA | Customer |
| `BP-MKT-SURV` | Trade Surveillance & Conduct Monitoring | Head of Markets Compliance (G8), CMP | ApexGuard, ApexTrade | `ANB-CMP-POL-0006` | Conduct, Compliance, Reputational | MAR, Dodd-Frank, MiFID II | Employee, Customer |

### 9.5 `P5` Credit & Lending

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-CRD-APPL` | Credit Application Intake | Head of Origination (G8), RTL | ApexOrigin, Apex360 | `ANB-RTL-FRM-0002`, `ANB-CBK-POL-0001` | Credit, Operational, Conduct | Reg B, FCRA, HMDA | Customer, Application |
| `BP-CRD-UW` | Underwriting & Credit Assessment | Head of Credit Risk (G9), RSK | ApexOrigin, ApexCredit, ApexModel | `ANB-CBK-POL-0001`, `ANB-CBK-TPL-0003` | Credit, Model, Compliance | Reg B, Fair Lending, SR 11-7 | Application, Facility |
| `BP-CRD-APPR` | Credit Approval & Authority Exercise | Head of Credit Risk (G9), RSK | ApexCredit | `ANB-CBK-POL-0001`, `ANB-ADM-MTX-0001` | Credit, Operational | Reg O (related party), safety & soundness | Facility, Customer |
| `BP-CRD-DOC` | Credit Documentation & Perfection | Head of Credit Administration (G8), CBK | ApexCredit, ApexLegal, ApexDocs | `ANB-CBK-CTR-0002` | Legal, Operational, Credit | UCC, state law | Facility, Customer |
| `BP-CRD-EXC` | Credit Exception Management | Head of Credit Risk (G9), RSK | ApexCredit, ApexRisk | `ANB-CBK-POL-0001` | Credit, Compliance | Safety & soundness | Facility |
| `BP-SRV-BOOK` | Loan Booking & Disbursement | Head of Loan Servicing (G8), RTL | ApexCore, ApexCredit, ApexPay | `ANB-CBK-POL-0001` | Operational, Credit | Reg Z, RESPA | Account, Facility |
| `BP-SRV-BILL` | Billing, Payment Application & Statements | Head of Loan Servicing (G8), RTL | ApexCore | `ANB-RTL-POL-0001` | Operational, Conduct | Reg Z, RESPA, UDAAP | Account, Customer |
| `BP-SRV-MOD` | Loan Modification & Forbearance | Head of Special Assets (G8), RSK | ApexCredit, ApexOrigin | `ANB-CBK-POL-0001` | Credit, Conduct, Compliance | Reg X, CFPB servicing rules | Facility, Customer |
| `BP-SRV-PAY` | Payoff, Release & Lien Discharge | Head of Loan Servicing (G8), RTL | ApexCore, ApexLegal | `ANB-CBK-POL-0001` | Operational, Legal | State law, RESPA | Account, Facility |
| `BP-COLL-EARLY` | Early-Stage Collections | Head of Collections (G8), RTL | ApexCore, ApexReach, ApexVoice | `ANB-RTL-POL-0001` | Credit, Conduct, Compliance | FDCPA, UDAAP, TCPA | Customer, Account |
| `BP-COLL-LATE` | Late-Stage Collections & Workout | Head of Special Assets (G8), RSK | ApexCredit, ApexLegal | `ANB-CBK-POL-0001` | Credit, Legal, Conduct | FDCPA, bankruptcy law | Facility, Customer |
| `BP-COLL-CO` | Charge-Off & Recovery | Head of Collections (G8), RTL with RSK | ApexCredit, ApexLedger | `ANB-CBK-POL-0001`, `ANB-ADM-MTX-0001` | Credit, Financial Reporting | FFIEC charge-off guidance, CECL | Facility, Account |
| `BP-COLL-PROV` | Provisioning & Impairment Assessment | Head of Credit Risk (G9), RSK with FIN | ApexModel, ApexLedger | `ANB-RSK-POL-0004` | Credit, Model, Financial Reporting | CECL/IFRS 9, SOX, SR 11-7 | Facility, Business Unit |

### 9.6 `P6` Payments & Banking Operations

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-PAY-DOM` | Domestic Payment Processing (ACH, Wire, RTP) | Head of Payment Operations (G8), ITO | ApexPay, ApexCore | `ANB-ITO-SOP-0003` | Operational, Fraud, Cyber | NACHA, UCC 4A, Reg E, Reg J | Account, Customer |
| `BP-PAY-XB` | Cross-Border Payment Processing | Head of Payment Operations (G8), ITO | ApexPay, ApexWatch | `ANB-CMP-POL-0005` | Operational, Financial Crime, Compliance | OFAC, SWIFT CSP, FATF Travel Rule | Account, Customer |
| `BP-PAY-EXC` | Payment Exception & Repair | Head of Payment Operations (G8), ITO | ApexPay | `ANB-ITO-SOP-0003` | Operational, Fraud | NACHA, UCC 4A | Account |
| `BP-PAY-NOST` | Nostro & Intraday Liquidity Management | Head of Payment Operations (G8), ITO with TRY | ApexPay, ApexTreasury | `ANB-TRY-POL-0001` | Liquidity, Operational | Basel III intraday | Legal Entity |
| `BP-RECN-DAILY` | Daily Reconciliation & Breaks Management | Group Financial Controller (G9), FIN | ApexLedger, ApexCore, ApexPay | `ANB-FIN-SOP-0003` | Operational, Financial Reporting | SOX, FFIEC | Account, Business Unit |
| `BP-RECN-SUSP` | Suspense & Control Account Management | Group Financial Controller (G9), FIN | ApexLedger | `ANB-FIN-SOP-0003` | Operational, Financial Reporting | SOX | Business Unit |
| `BP-RECN-LOSS` | Operational Loss Recording | Head of Operational Risk (G8), RSK | ApexRisk, ApexLedger | `ANB-RSK-POL-0001` | Operational, Financial Reporting | Basel III operational risk, SOX | Business Unit |

### 9.7 `P7` Financial Crime & Compliance

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-AML-TM` | Transaction Monitoring & Alert Disposition | Head of Financial Crime (G9), CMP | ApexGuard, ApexKYC | `ANB-CMP-POL-0001` | Financial Crime, Compliance | BSA, FinCEN | Customer, Account, Case |
| `BP-AML-INV` | Financial Crime Investigation | Head of Financial Crime (G9), CMP | ApexGuard, Apex360 | `ANB-CMP-POL-0001` | Financial Crime, Legal, Reputational | BSA, FinCEN | Customer, Case |
| `BP-AML-SAR` | Suspicious Activity Report Filing | BSA Officer (G8), CMP | ApexGuard, ApexRegRep | `ANB-CMP-SOP-0004` | Financial Crime, Compliance, Legal | BSA, FinCEN 31 CFR 1020.320 | Customer, Case |
| `BP-AML-CTR` | Currency Transaction Report Filing | BSA Officer (G8), CMP | ApexCore, ApexRegRep | `ANB-CMP-POL-0001` | Compliance, Operational | BSA, FinCEN 31 CFR 1010.311 | Customer, Account |
| `BP-AML-RISK` | Customer Risk Rating & Re-rating | Head of Financial Crime (G9), CMP | ApexKYC, ApexModel | `ANB-CMP-POL-0002` | Financial Crime, Model | BSA, FinCEN CDD Rule | Customer |
| `BP-SAN-SCRN` | Sanctions Screening (Customer & Transaction) | Head of Sanctions (G8), CMP | ApexWatch, ApexPay | `ANB-CMP-POL-0005` | Financial Crime, Compliance, Reputational | OFAC, EU/UK sanctions, UN | Customer, Account |
| `BP-SAN-ESC` | Sanctions Hit Investigation & Escalation | Head of Sanctions (G8), CMP | ApexWatch, ApexGuard | `ANB-CMP-POL-0005` | Financial Crime, Legal | OFAC, blocking/rejection reporting | Customer, Case |
| `BP-FRD-DET` | Fraud Detection & Alerting | Head of Fraud (G8), CMP | ApexGuard, ApexPay, ApexMobile | *Fraud Risk Management Policy* | Fraud, Operational, Cyber | Reg E, FFIEC | Customer, Account |
| `BP-FRD-INV` | Fraud Investigation & Loss Recovery | Head of Fraud (G8), CMP | ApexGuard, Apex360 | *Fraud Risk Management Policy* | Fraud, Legal, Conduct | Reg E, Reg Z, BSA | Customer, Case |
| `BP-REG-CHG` | Regulatory Change Management | Head of Regulatory Affairs (G8), CMP | ApexDocs, ApexRisk | `ANB-CMP-POL-0006` | Compliance, Strategic | All applicable regimes | Regulation, Business Process |
| `BP-REG-MON` | Compliance Monitoring & Testing | Head of Compliance Testing (G8), CMP | ApexAudit, ApexRisk | `ANB-CMP-POL-0006` | Compliance, Conduct | All applicable regimes | Business Process, Control |
| `BP-REG-EXAM` | Regulatory Examination Management | Chief Compliance Officer (G11), CMP | ApexDocs, ApexRegRep | `ANB-CMP-POL-0006` | Compliance, Reputational | OCC, FRB, FCA, BaFin | Regulation, Legal Entity |
| `BP-REG-FILE` | Regulatory Filing & Submission | Head of Regulatory Reporting (G9), FIN | ApexRegRep, ApexLedger | `ANB-FIN-STD-0004` | Compliance, Financial Reporting | Call Report, FR Y-9C, Basel III | Legal Entity |

### 9.8 `P8` Risk Management

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-RSK-APP` | Risk Appetite Setting & Monitoring | Chief Risk Officer (G11), RSK | ApexRisk, ApexInsight | `ANB-RSK-POL-0001` | All | OCC heightened standards | Business Unit |
| `BP-RSK-RCSA` | Risk & Control Self-Assessment | Head of Operational Risk (G8), RSK | ApexRisk | `ANB-RSK-STD-0002`, `ANB-RSK-TPL-0003` | Operational, Compliance | Basel III, COSO | Business Process, Control, Risk |
| `BP-RSK-KRI` | Key Risk Indicator Monitoring | Head of Operational Risk (G8), RSK | ApexRisk, ApexInsight | `ANB-RSK-POL-0001` | Operational | Basel III | Business Process |
| `BP-RSK-ACC` | Risk Acceptance & Exception Governance | Head of Operational Risk (G8), RSK | ApexRisk, ApexServe | `ANB-ADM-MTX-0001` | All | OCC heightened standards | Risk, Control |
| `BP-RSK-STRESS` | Stress Testing & Scenario Analysis | Head of Enterprise Risk (G9), RSK | ApexModel, ApexInsight | `ANB-RSK-POL-0001` | Credit, Market, Liquidity, Model | CCAR/DFAST, Basel III | Legal Entity |
| `BP-MDL-INV` | Model Inventory Management | Head of Model Risk (G8), RSK | ApexModel | `ANB-RSK-POL-0004` | Model, Compliance | SR 11-7 | Model |
| `BP-MDL-VAL` | Independent Model Validation | Head of Model Risk (G8), RSK | ApexModel | `ANB-RSK-POL-0004` | Model | SR 11-7 | Model |
| `BP-MDL-MON` | Model Performance Monitoring | Head of Model Risk (G8), RSK | ApexModel, ApexInsight | `ANB-RSK-POL-0004` | Model, Credit | SR 11-7 | Model |

### 9.9 `P9` Internal Audit & Assurance

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-AUD-PLAN` | Audit Universe & Annual Plan | Chief Audit Executive (G11), IAD | ApexAudit, ApexRisk | `ANB-IAD-REF-0002` | All | IIA Standards, OCC | Business Process, Department |
| `BP-AUD-ENG` | Audit Engagement Execution | Head of Audit — Business Line (G8), IAD | ApexAudit | `ANB-IAD-TPL-0001` | All | IIA Standards, SOX | Audit Engagement, Control |
| `BP-AUD-RPT` | Audit Reporting & Issue Rating | Chief Audit Executive (G11), IAD | ApexAudit, ApexDocs | `ANB-IAD-TPL-0001`, `ANB-ADM-MTX-0001` | All | IIA Standards | Audit Engagement |
| `BP-AUD-VAL` | Issue Remediation Validation | Head of Audit Quality (G8), IAD | ApexAudit | `ANB-IAD-REF-0002` | All | IIA Standards | Control, Audit Engagement |
| `BP-AUD-SOX` | SOX / ICFR Control Testing | Group Financial Controller (G9), FIN with IAD | ApexAudit, ApexRisk | `ANB-FIN-SOP-0003` | Financial Reporting, Operational | SOX §404, PCAOB | Control, Business Process |

### 9.10 `P10` Finance & Regulatory Reporting

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-FIN-CLOSE` | Month-End Close & Consolidation | Group Financial Controller (G9), FIN | ApexLedger, ApexInsight | `ANB-FIN-SOP-0003` | Financial Reporting, Operational | SOX, US GAAP/IFRS | Legal Entity, Business Unit |
| `BP-FIN-JRNL` | Journal Entry Control & Review | Group Financial Controller (G9), FIN | ApexLedger | `ANB-FIN-SOP-0003` | Financial Reporting | SOX | Business Unit |
| `BP-FIN-COA` | Chart of Accounts Governance | Group Financial Controller (G9), FIN | ApexLedger | `ANB-FIN-STD-0004` | Financial Reporting, Operational | SOX, Call Report | Business Unit |
| `BP-FIN-PLAN` | Budgeting & Forecasting | Head of FP&A (G9), FIN | ApexPlan, ApexInsight | `ANB-ADM-MTX-0001` | Strategic, Financial Reporting | — | Business Unit |
| `BP-FIN-EXP` | Expense Management & Reimbursement | Head of Financial Operations (G8), FIN | ApexLedger, ApexSource | `ANB-FIN-POL-0001`, `ANB-FIN-POL-0002` | Operational, Conduct, Fraud | Anti-bribery (FCPA, UK Bribery Act) | Employee, Vendor |
| `BP-FIN-AP` | Accounts Payable & Invoice Processing | Head of Financial Operations (G8), FIN | ApexSource, ApexLedger | `ANB-PRC-POL-0001` | Operational, Fraud, Third-Party | SOX, FCPA | Vendor |
| `BP-FIN-DISC` | External Reporting & Disclosure | Chief Financial Officer (G11), FIN | ApexLedger, ApexRegRep | `ANB-LEG-REF-0003` §7.15 | Financial Reporting, Legal | SEC, SOX §302/906 | Legal Entity |
| `BP-TAX-COMP` | Tax Compliance & Filing | Head of Tax (G8), FIN | ApexLedger | *Tax Policy (planned)* | Compliance, Financial Reporting | IRS, HMRC, local tax law | Legal Entity |
| `BP-TAX-TP` | Transfer Pricing Documentation | Head of Tax (G8), FIN | ApexLedger, ApexDocs | *Tax Policy (planned)* | Compliance, Financial Reporting | OECD BEPS, local law | Legal Entity |

### 9.11 `P11` Human Resources

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-HR-HIRE` | Recruitment & Selection | Head of Talent Acquisition (G8), HRM | ApexPeople | `ANB-HRM-HBK-0001` | Operational, Conduct, Legal | EEOC, local employment law | Employee |
| `BP-HR-SCRN` | Pre-Employment Screening & Vetting | Head of Talent Acquisition (G8), HRM | ApexPeople, ApexID | `ANB-HRM-POL-0004` | Fraud, Conduct, Compliance | FCRA, FDIC §19, local law | Employee |
| `BP-HR-ONB` | Employee Onboarding & Access Provisioning | Head of HR Operations (G8), HRM with ITO | ApexPeople, ApexID, ApexLearn | `ANB-ISC-POL-0001` | Cyber, Operational | GLBA, SOX (access) | Employee |
| `BP-HR-PERF` | Performance & Talent Management | Head of Talent (G8), HRM | ApexPeople | `ANB-HRM-HBK-0001` | Conduct, Operational | Employment law | Employee |
| `BP-HR-COMP` | Compensation & Incentive Administration | Head of Reward (G8), HRM | ApexPeople | `ANB-HRM-POL-0005` | Conduct, Financial, Reputational | Incentive compensation rules, CRD | Employee |
| `BP-HR-TRN` | Mandatory Training & Attestation | Head of Learning (G8), HRM | ApexLearn | `ANB-HRM-HBK-0001` | Compliance, Conduct | BSA training, GLBA, local law | Employee |
| `BP-HR-COND` | Conduct Case & Disciplinary Management | Head of Employee Relations (G8), HRM | ApexPeople, ApexDocs | `ANB-HRM-POL-0004` | Conduct, Legal, Reputational | Employment law, FDIC §19 | Employee, Case |
| `BP-HR-EXIT` | Offboarding & Access Revocation | Head of HR Operations (G8), HRM with ITO | ApexPeople, ApexID | `ANB-ISC-POL-0001` | Cyber, Operational, Legal | SOX (access), GLBA | Employee |
| `BP-HR-LEAVE` | Leave & Mandatory Absence Administration | Head of HR Operations (G8), HRM | ApexPeople | `ANB-HRM-POL-0002` | Operational, Fraud, Compliance | FFIEC two-week absence, FMLA | Employee |

### 9.12 `P12` Technology & IT Service Management

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-ITSM-CHG` | Change Management | Head of IT Operations (G11), ITO | ApexServe, ApexBuild | `ANB-ITO-SOP-0003` | Technology, Operational, Cyber | SOX, FFIEC | System, Change |
| `BP-ITSM-INC` | Incident Management | Head of IT Operations (G11), ITO | ApexServe, ApexMonitor | `ANB-ITO-TPL-0004` | Technology, Operational | FFIEC, GLBA | System, Incident |
| `BP-ITSM-PRB` | Problem Management & Root Cause | Head of Service Management (G8), ITO | ApexServe | `ANB-ITO-SOP-0003` | Technology, Operational | FFIEC | System, Incident |
| `BP-ITSM-REL` | Release & Deployment Management | Head of Platform Engineering (G9), ITO | ApexBuild, ApexServe | `ANB-ITO-SOP-0003` | Technology, Operational | SOX | System, Change |
| `BP-ITSM-CAP` | Capacity & Performance Management | Head of Infrastructure (G8), ITO | ApexMonitor, ApexCloud | `ANB-ITO-PLN-0002` | Technology, Operational | FFIEC | System |
| `BP-ITSM-CMDB` | Configuration & Asset Management | Head of Service Management (G8), ITO | ApexServe | `ANB-ITO-SOP-0003` | Technology, Operational | SOX, PCI DSS | System |
| `BP-RES-BIA` | Business Impact Analysis | Head of Business Continuity (G8), ITO with ADM | ApexRisk, ApexServe | `ANB-ITO-PLN-0001` | Operational, Strategic | FFIEC BCM, operational resilience | Business Process, System |
| `BP-RES-BCP` | Business Continuity Planning & Testing | Head of Business Continuity (G8), ITO with ADM | ApexServe, ApexDocs | `ANB-ITO-PLN-0001` | Operational, Technology | FFIEC BCM, FCA/PRA resilience | Business Process, Location |
| `BP-RES-DR` | Disaster Recovery Testing & Invocation | Head of Infrastructure (G8), ITO | ApexCloud, ApexServe | `ANB-ITO-PLN-0002` | Technology, Operational | FFIEC, operational resilience | System |
| `BP-RES-TOL` | Impact Tolerance Setting & Monitoring | Chief Operating Officer (G11), ADM with ITO | ApexRisk | `ANB-ITO-PLN-0001` | Operational, Strategic | UK/EU operational resilience, FFIEC | Business Process |

### 9.13 `P13` Information Security

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-SEC-IAM` | Identity & Access Governance | Head of Identity (G8), ISC | ApexID, ApexAccess | `ANB-ISC-STD-0002` | Cyber, Operational, Compliance | SOX, GLBA, PCI DSS | Employee, System |
| `BP-SEC-RECERT` | Access Recertification | Head of Identity (G8), ISC | ApexID | `ANB-ISC-STD-0002` | Cyber, Compliance | SOX, PCI DSS | Employee, System |
| `BP-SEC-VULN` | Vulnerability Management & Patching | Head of Cyber Defence (G8), ISC | ApexShield, ApexMonitor | `ANB-ISC-POL-0001` | Cyber, Technology | PCI DSS, NIST CSF, FFIEC | System |
| `BP-SEC-SOC` | Security Monitoring & Threat Detection | Head of Cyber Defence (G8), ISC | ApexShield, ApexMonitor | `ANB-ISC-POL-0001` | Cyber | NIST CSF, GLBA Safeguards | System, Incident |
| `BP-SEC-IR` | Security Incident Response | Chief Information Security Officer (G10), ISC | ApexShield, ApexServe | `ANB-ISC-SOP-0003` | Cyber, Legal, Reputational | GLBA, GDPR 72-hour, state breach laws | Incident, Customer |
| `BP-SEC-DLP` | Data Loss Prevention & Insider Risk | Head of Cyber Defence (G8), ISC | ApexDLP, ApexShield | `ANB-ISC-STD-0004` | Cyber, Conduct, Compliance | GLBA, GDPR, PCI DSS | Employee, Customer |
| `BP-SEC-CLASS` | Data Classification & Labelling | Chief Data Officer (G10) with CISO | ApexDocs, ApexDLP | `ANB-ISC-STD-0004` | Compliance, Cyber | GLBA, GDPR, CCPA | Document, Data |
| `BP-SEC-PEN` | Penetration Testing & Red Team | Head of Cyber Defence (G8), ISC | ApexShield | `ANB-ISC-POL-0001` | Cyber | PCI DSS, FFIEC, CBEST/TIBER | System |
| `BP-SEC-EXC` | Security Exception Management | Chief Information Security Officer (G10), ISC | ApexServe, ApexRisk | `ANB-ADM-MTX-0001` §10.2 | Cyber, Operational | PCI DSS, NIST CSF | System, Risk |
| `BP-SEC-PHYS` | Physical Security & Access Control | Head of Physical Security (G7), ADM | ApexAccess, ApexWorkplace | `ANB-ISC-POL-0001` | Physical Security, Operational | FFIEC, GLBA | Location, Employee |

### 9.14 `P14` Procurement & Vendor Management

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-VEN-SRC` | Sourcing & Competitive Bidding | Head of Category Management (G8), PRC | ApexSource | `ANB-PRC-POL-0001` | Operational, Conduct, Third-Party | FCPA, anti-bribery, supplier diversity | Vendor |
| `BP-VEN-DD` | Vendor Due Diligence & Tiering | Head of Third-Party Risk (G8), PRC | ApexVendor, ApexRisk | `ANB-PRC-POL-0002` | Third-Party, Cyber, Compliance | OCC 2023-17, EBA outsourcing, DORA | Vendor |
| `BP-VEN-CTR` | Contract Negotiation & Execution | General Counsel (G11), LEG with PRC | ApexLegal, ApexSource | `ANB-LEG-CTR-0001`, `ANB-ADM-MTX-0001` §6 | Legal, Third-Party, Operational | OCC 2023-17 | Vendor, Contract |
| `BP-VEN-MON` | Ongoing Vendor Monitoring & Performance | Head of Third-Party Risk (G8), PRC | ApexVendor | `ANB-PRC-POL-0002` | Third-Party, Operational | OCC 2023-17, DORA | Vendor |
| `BP-VEN-CONC` | Concentration & Substitutability Assessment | Head of Third-Party Risk (G8), PRC with RSK | ApexVendor, ApexRisk | `ANB-PRC-POL-0002` | Third-Party, Strategic, Operational | OCC 2023-17, operational resilience | Vendor, Business Process |
| `BP-VEN-EXIT` | Vendor Exit & Transition | Head of Third-Party Risk (G8), PRC | ApexVendor, ApexLegal | `ANB-PRC-POL-0002` | Third-Party, Operational, Legal | OCC 2023-17, DORA | Vendor, Contract |

### 9.15 `P15` Corporate Services, Legal & Knowledge

| Process Code | Process (L3) | Owner | Systems | Governing Documents | Risk Categories | Compliance | Entities |
|---|---|---|---|---|---|---|---|
| `BP-LEG-MAT` | Legal Matter & Litigation Management | General Counsel (G11), LEG | ApexLegal, ApexDocs | `ANB-ADM-POL-0001` | Legal, Reputational, Financial | Court rules, privilege | Case, Customer, Vendor |
| `BP-LEG-HOLD` | Legal Hold Administration | General Counsel (G11), LEG | ApexDocs, ApexVault, Apex Mail | `ANB-ADM-POL-0001` §10.2 | Legal, Compliance, Operational | FRCP, e-discovery obligations | Case, Employee, Document |
| `BP-LEG-SEC` | Corporate Secretariat & Board Support | Corporate Secretary (G8), LEG | ApexDocs, ApexLegal | `ANB-LEG-STD-0002`, `ANB-LEG-REF-0003` | Legal, Compliance, Reputational | Corporate law, SEC | Committee, Legal Entity |
| `BP-LEG-ENT` | Legal Entity Management & Statutory Filing | Corporate Secretary (G8), LEG | ApexLegal | `ANB-LEG-REF-0003` | Legal, Compliance | Corporate law, local registry | Legal Entity |
| `BP-KNW-DOC` | Document Lifecycle Management | Head of Administration (G9), ADM | ApexDocs | `ANB-ADM-STD-0007` | Operational, Compliance | SOX, examination readiness | Document |
| `BP-KNW-TAX` | Taxonomy & Metadata Governance | Head of Administration (G9), ADM | ApexDocs | `ANB-ADM-STD-0006`, `ANB-ADM-STD-0005` | Operational, Compliance | Examination readiness | Document, Business Process |
| `BP-KNW-RET` | Records Retention & Disposition | Head of Administration (G9), ADM | ApexVault, ApexDocs | `ANB-ADM-POL-0001`, `ANB-ADM-STD-0002` | Legal, Compliance, Operational | BSA, SOX, GDPR, SEC 17a-4 | Document, Record |
| `BP-KNW-ARCH` | Archive Operations & Restore Testing | Head of Records Management (G7), ADM | ApexVault | `ANB-ADM-POL-0001` §10.5 | Operational, Legal | SOX, examination readiness | Record |
| `BP-KNW-SRCH` | Enterprise Search & Knowledge Delivery | Head of Administration (G9), ADM with ITO | ApexDocs, ApexInsight | `ANB-ADM-STD-0006` | Operational, Cyber | GLBA (entitlement), GDPR | Document, Employee |
| `BP-BRD-CAMP` | Marketing Campaign Development & Review | Chief Marketing Officer (G10), MKT | ApexBrand, ApexReach | `ANB-MKT-STD-0001` | Conduct, Compliance, Reputational | UDAAP, Reg DD, Reg Z advertising | Customer, Product |
| `BP-BRD-COMM` | Corporate Communications & Public Statements | Chief Marketing Officer (G10), MKT | ApexBrand, ApexReach | `ANB-MKT-STD-0001`, `ANB-ADM-MTX-0001` §5 | Reputational, Legal, Compliance | SEC Reg FD, market abuse | Legal Entity |
| `BP-BRD-SOC` | Social Media Governance | Head of Communications (G8), MKT | ApexBrand | `ANB-MKT-STD-0001` | Reputational, Conduct, Compliance | UDAAP, FINRA communications | Customer |

---

## 10. Standards — Mapping Requirements

### 10.1 Mandatory Mappings

Every registered L3 process must declare:

| Mapping | Minimum | Validation |
|---|---|---|
| Departments | Exactly one owning `CV-DEPT`; contributing departments listed | ApexDocs validation |
| Business unit | At least one `CV-BU` value | ApexDocs validation |
| Systems | All systems where the process executes or produces records | Reconciled to ApexServe CMDB quarterly |
| Documents | At least one governing policy **and** at least one operating document | EKMO monthly report |
| Risk categories | At least one `CV-RISK` value; operational risk is presumed for all | ApexRisk linkage |
| Compliance categories | All applicable `CV-REG` values, or an explicit "none applicable" determination by Compliance | Compliance monitoring |
| Business entities | All entity types the process creates, reads, or modifies | Knowledge Graph validation |
| Criticality tier | Tier 1–3 per `ANB-ADM-REF-0001` §8 | ORC ratification |

### 10.2 Cross-Dimension Consistency Rules

**M-1.** A process touching Customer or Account entities requires a `classification` floor of C2 on its operating documents.

**M-2.** A process mapped to BSA, FinCEN, or OFAC must have a Compliance-owned or Compliance-reviewed governing document.

**M-3.** A process executing on a Tier 1 system must have an approved business continuity plan and a tested disaster recovery path.

**M-4.** A process producing a regulatory filing must be mapped to `RET-REG-7Y` or a longer retention class.

**M-5.** A process with a vendor dependency must reference the vendor (`VEN-`) and its tier; Tier 1 dependencies require a documented exit plan.

**M-6.** A process with a control point must have that control registered in ApexRisk (`CTL-`) with an owner and a test frequency.

**M-7.** No process may be owned by a Second or Third Line function where that function also independently assesses it. Where Risk owns a process (for example `BP-CRD-UW`), Internal Audit provides the independent assessment.

### 10.3 Important Business Services

The following are designated important business services with Board-approved impact tolerances. Disruption beyond tolerance is reportable to the Board Technology & Operational Resilience Committee and, where thresholds are met, to regulators.

| Important Business Service | Constituent Processes | Primary Systems | Tier |
|---|---|---|---|
| Customer access to funds | `BP-DEP-MAINT`, `BP-BRN-CASH`, `BP-DIG-ENRL`, `BP-PAY-DOM` | ApexCore, ApexTeller, ApexOnline, ApexMobile, ApexPay | 1 |
| Payment execution | `BP-PAY-DOM`, `BP-PAY-XB`, `BP-PAY-EXC`, `BP-SAN-SCRN` | ApexPay, ApexCore, ApexWatch | 1 |
| Card authorisation | `BP-CARD-ISS`, `BP-FRD-DET` | ApexPay, ApexCore, ApexGuard | 1 |
| Lending decisioning and drawdown | `BP-CRD-APPL`, `BP-CRD-UW`, `BP-SRV-BOOK` | ApexOrigin, ApexCredit, ApexCore | 1 |
| Customer servicing and complaints | `BP-CST-CMPL`, `BP-CST-AUTH` | Apex360, ApexAssist, ApexVoice | 2 |
| Financial crime detection | `BP-AML-TM`, `BP-SAN-SCRN`, `BP-FRD-DET` | ApexGuard, ApexWatch | 1 |
| Regulatory reporting | `BP-REG-FILE`, `BP-FIN-CLOSE` | ApexRegRep, ApexLedger | 2 |
| Treasury liquidity management | `BP-TRY-LIQ`, `BP-PAY-NOST` | ApexTreasury, ApexPay | 1 |

---

## 11. Governance

### 11.1 Change Control

| Change | Approver | Cadence |
|---|---|---|
| New L3 process registration | EKMO with the owning Department Head; ORC notified | Quarterly |
| Process owner change | Department Head; EKMO updates the register | Continuous |
| New L2 process area | Enterprise Knowledge Council | Quarterly |
| New or retired L1 process group | Enterprise Knowledge Council with ExCo | Annual |
| Criticality tier change | IT Operations proposal; ORC ratification | Quarterly |
| Important business service designation | Business Continuity proposal; Board Technology & Operational Resilience Committee approval | Annual |
| Process retirement | Department Head with EKMO; confirmation that documents and controls are reassigned or retired | Continuous |

### 11.2 Annual Process Attestation

Each Process Owner attests annually that: the process description is accurate; the governing documents are current and within review cycle; system mappings match reality; controls are operating; handoffs are agreed with counterpart owners; and vendor dependencies are correctly recorded. Attestations are recorded in ApexRisk and are evidence for Internal Audit and examination.

### 11.3 Metrics

| Metric | Target | Escalation |
|---|---|---|
| L3 processes with a named owner (G7+) | 100% | Department Head |
| Processes with a current governing document | ≥ 98% | EKC quarterly |
| Operating documents citing a valid `business_process` | ≥ 98% | EKMO to Custodians |
| Processes with RCSA coverage | 100% for Tier 1 and 2 | ORC |
| System mappings reconciled to the CMDB | ≥ 98% | ITO |
| Important business services with tested recovery | 100% annually | Board Technology & Operational Resilience Committee |
| Annual attestations completed | 100% | Department Head to ExCo |
| Processes with an unassigned handoff | 0 | ORC |

---

## 12. Processes — Using This Guide

### 12.1 Register a New Process

| Step | Actor | SLA |
|---|---|---|
| Submit registration in ApexServe with proposed name, owner, scope boundary, and the six mappings | Department | — |
| Assess overlap with existing processes and boundary clarity | EKMO | 5 business days |
| Confirm risk and control linkage | Operational Risk | 5 business days |
| Confirm regulatory mapping | Compliance | 5 business days |
| Allocate `BP-` code and publish | EKMO | 3 business days |
| Ratify at the next quarterly cycle | EKC; ORC for criticality | Next cycle |

### 12.2 Classify an Existing Document to a Process

1. Identify the activity the document instructs or governs.
2. Locate the L3 process in Section 9 that produces that outcome.
3. If the document governs several processes, cite the primary process in `business_process` and the remainder in `document_relationships` using `documents_process:`.
4. If no process fits, do not invent a value — raise a registration request (§12.1). Unregistered free-text values are rejected at publication.

### 12.3 Answer an Impact Question

| Question | Method |
|---|---|
| "ApexPay is degraded — what is affected?" | `SystemNode(ApexPay)` → processes → important business services → documents → owners |
| "Which processes does the CDD Rule touch?" | `RegulationNode(FinCEN CDD Rule)` → processes → governing documents → controls |
| "Who owns the handoff between underwriting and documentation?" | `BP-CRD-UW` → handoff → `BP-CRD-DOC`; both owners named in the register |
| "What must we test for SOX this year?" | Processes mapped to Financial Reporting risk → controls → evidence (`EVID_CTL-*`) |
| "Which vendor failures would breach an impact tolerance?" | Vendor dependencies on important business service processes |

---

## 13. Examples

### 13.1 Full Mapping — `BP-AML-SAR` Suspicious Activity Report Filing

| Dimension | Mapping |
|---|---|
| **Process code** | `BP-AML-SAR` |
| **L1 / L2** | `P7` Financial Crime & Compliance / `AML` Anti-Money Laundering |
| **Owner** | BSA Officer (G8), Compliance |
| **Departments** | CMP (owner); RTL, CBK (referral sources); LEG (advice) |
| **Business units** | CC (owns), applies to CRB, CMB, CIB, WAM |
| **Systems** | ApexGuard (case), ApexRegRep (filing), ApexKYC (customer context), ApexVault (retention) |
| **Documents** | `ANB-CMP-POL-0001` (governs), `ANB-CMP-SOP-0004` (implements), `ANB-CMP-FRM-0003` (supporting) |
| **Risk categories** | Financial Crime, Compliance, Legal, Reputational |
| **Compliance categories** | BSA, FinCEN 31 CFR 1020.320, OFAC (where sanctions nexus) |
| **Entities** | Customer (`CUS-`), Account (`ACC-`), Case (`CAS-`) |
| **Controls** | `CTL-00318` 30-day filing deadline monitoring; `CTL-00319` quality review before filing; `CTL-00320` SAR confidentiality access control |
| **Classification** | C3 Restricted — all artefacts |
| **Retention** | `RET-AML-5Y` from filing date |
| **Criticality tier** | Tier 1 (financial crime detection) |
| **Oversight** | Financial Crime Committee (aggregate); Board Public Responsibility & Compliance Committee |
| **Approval authority** | BSA Officer (`ANB-ADM-MTX-0001` §5) |

### 13.2 Cross-Department Process with Handoffs — `BP-CRD-UW` to `BP-SRV-BOOK`

```
BP-CRD-APPL (RTL/CBK)   ──handoff──►  BP-CRD-UW (RSK)
   owner: Head of Origination           owner: Head of Credit Risk
   evidence: application, verification   evidence: credit memo, risk rating
                                              │
                                          handoff
                                              ▼
BP-CRD-DOC (CBK)        ◄──handoff──   BP-CRD-APPR (RSK)
   owner: Head of Credit Admin           owner: Head of Credit Risk
   evidence: executed instruments        evidence: approval record, conditions
        │
    handoff
        ▼
BP-SRV-BOOK (RTL)
   owner: Head of Loan Servicing
   evidence: booking record, disbursement confirmation
```

Four handoffs, four named owners, four evidence sets. Each handoff is a control point: conditions precedent must be satisfied and evidenced before the next process may start. The most common credit control failure in the industry — booking a facility before documentation is perfected — is prevented at the `BP-CRD-DOC` → `BP-SRV-BOOK` handoff.

### 13.3 Resilience Query in Practice

ApexCore experiences a Tier 1 outage at 09:12.

| Hop | Result |
|---|---|
| `SystemNode(ApexCore)` → processes | 14 L3 processes including `BP-DEP-MAINT`, `BP-BRN-CASH`, `BP-SRV-BILL`, `BP-PAY-DOM` |
| Processes → important business services | Customer access to funds; Payment execution; Lending drawdown |
| Services → impact tolerances | Breach at 2 hours (funds access), 4 hours (payments) |
| Processes → owners | Named G8–G9 owners paged automatically |
| Processes → documents | Manual workaround procedures surfaced to branch and contact centre |
| Processes → committees | ORC and Board Technology & Operational Resilience Committee notification thresholds |

The entire chain resolves from the register without a single phone call to establish who does what.

---

## 14. Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Author | Enterprise Knowledge Management Office, Administration (ADM) | Prepared | 2026-05-27 |
| Reviewer — Risk | Helena Brandt, Chief Risk Officer | Reviewed | 2026-06-10 |
| Reviewer — Compliance | Samuel A. Okonkwo, Chief Compliance Officer | Reviewed | 2026-06-12 |
| Reviewer — Technology | Arjun Patel, Chief Information Officer | Reviewed | 2026-06-15 |
| Reviewer — Data | Elena Vasquez, Chief Data Officer | Reviewed | 2026-06-16 |
| Reviewer — Internal Audit | Thomas Nakamura, Chief Audit Executive | Reviewed (no objection) | 2026-06-18 |
| Ratifying Body — criticality and risk mapping | Operational Risk Committee | Ratified | 2026-06-22 |
| Ratifying Body — process taxonomy | Enterprise Knowledge Council | Ratified | 2026-06-24 |
| Approver | Daniel K. Ortega, Chief Operating Officer | Approved | 2026-06-30 |

---

## 15. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full re-validation of the register and mappings | EKMO with process owners | Annually |
| Quarterly register update | New processes, owner changes, retirements | EKMO | Quarterly |
| Organisational restructure | Reassign ownership; confirm no orphan processes | EKMO with HRM | 30 days |
| New product launch | Register new or amended processes before go-live | Business Unit with EKMO | Before launch (NPAC condition) |
| New system go-live | Update system mappings | ITO with EKMO | Before go-live |
| New regulation | Map to affected processes | Compliance with EKMO | 60 days |
| Material incident or loss event | Reassess process design and controls | Process owner with Risk | 30 days |

Next scheduled review: **2027-06-30**.

---

## 16. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of departments, business units, and systems |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/ENTERPRISE_METADATA_STANDARD.md` | `business_process` field; `CV-PROCESS` consumer |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `ProcessNode` and `documents_process` edges |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | Naming of process artefacts and evidence |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Records produced by each process |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Approval points within processes |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Forums overseeing each process group |
| `ANB-RSK-STD-0002` | Risk & Control Self-Assessment Standard | *(planned)* | RCSA executed at process level |
| `ANB-ITO-PLN-0001` | Business Continuity Plan | *(planned)* | Impact tolerances and recovery |
| `ANB-CMP-POL-0006` | Compliance Policy | *(planned)* | Regulatory change mapping to processes |

---

## 17. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-05-27 | EKMO | Initial draft: L1 process groups derived from `ANB-ADM-REF-0001` §7 department mandates | — |
| 0.4 | 2026-06-08 | EKMO | Full L3 register drafted with department and system mappings | — |
| 0.6 | 2026-06-14 | EKMO | Risk and compliance category mappings added following Risk and Compliance review | — |
| 0.8 | 2026-06-19 | EKMO | Important business services and impact tolerance section added after Business Continuity input | — |
| 0.9 | 2026-06-24 | EKMO | EKC and ORC ratification amendments: consistency rules M-1 to M-7; annual attestation | — |
| 1.0 | 2026-06-30 | EKMO | First published version | D. K. Ortega |

---

## 18. Appendices

### Appendix A — `CV-PROCESS` Alphabetical Index

`BP-AML-CTR` · `BP-AML-INV` · `BP-AML-RISK` · `BP-AML-SAR` · `BP-AML-TM` · `BP-AUD-ENG` · `BP-AUD-PLAN` · `BP-AUD-RPT` · `BP-AUD-SOX` · `BP-AUD-VAL` · `BP-BRD-CAMP` · `BP-BRD-COMM` · `BP-BRD-SOC` · `BP-BRN-CASH` · `BP-BRN-OPEN` · `BP-BRN-SDB` · `BP-CARD-DISP` · `BP-CARD-ISS` · `BP-COLL-CO` · `BP-COLL-EARLY` · `BP-COLL-LATE` · `BP-COLL-PROV` · `BP-CORP-CASH` · `BP-CORP-COV` · `BP-CORP-REL` · `BP-CRD-APPL` · `BP-CRD-APPR` · `BP-CRD-DOC` · `BP-CRD-EXC` · `BP-CRD-UW` · `BP-CST-AUTH` · `BP-CST-CMPL` · `BP-CST-CORR` · `BP-DEP-DORM` · `BP-DEP-FEE` · `BP-DEP-MAINT` · `BP-DIG-API` · `BP-DIG-ENRL` · `BP-FIN-AP` · `BP-FIN-CLOSE` · `BP-FIN-COA` · `BP-FIN-DISC` · `BP-FIN-EXP` · `BP-FIN-JRNL` · `BP-FIN-PLAN` · `BP-FRD-DET` · `BP-FRD-INV` · `BP-HR-COMP` · `BP-HR-COND` · `BP-HR-EXIT` · `BP-HR-HIRE` · `BP-HR-LEAVE` · `BP-HR-ONB` · `BP-HR-PERF` · `BP-HR-SCRN` · `BP-HR-TRN` · `BP-ITSM-CAP` · `BP-ITSM-CHG` · `BP-ITSM-CMDB` · `BP-ITSM-INC` · `BP-ITSM-PRB` · `BP-ITSM-REL` · `BP-KNW-ARCH` · `BP-KNW-DOC` · `BP-KNW-RET` · `BP-KNW-SRCH` · `BP-KNW-TAX` · `BP-LEG-ENT` · `BP-LEG-HOLD` · `BP-LEG-MAT` · `BP-LEG-SEC` · `BP-MDL-INV` · `BP-MDL-MON` · `BP-MDL-VAL` · `BP-MKT-DER` · `BP-MKT-FX` · `BP-MKT-SURV` · `BP-ONB-ACCT` · `BP-ONB-CIP` · `BP-ONB-CORP` · `BP-ONB-EDD` · `BP-ONB-EXIT` · `BP-ONB-KYC` · `BP-PAY-DOM` · `BP-PAY-EXC` · `BP-PAY-NOST` · `BP-PAY-XB` · `BP-RECN-DAILY` · `BP-RECN-LOSS` · `BP-RECN-SUSP` · `BP-REG-CHG` · `BP-REG-EXAM` · `BP-REG-FILE` · `BP-REG-MON` · `BP-RES-BCP` · `BP-RES-BIA` · `BP-RES-DR` · `BP-RES-TOL` · `BP-RSK-ACC` · `BP-RSK-APP` · `BP-RSK-KRI` · `BP-RSK-RCSA` · `BP-RSK-STRESS` · `BP-SAN-ESC` · `BP-SAN-SCRN` · `BP-SEC-CLASS` · `BP-SEC-DLP` · `BP-SEC-EXC` · `BP-SEC-IAM` · `BP-SEC-IR` · `BP-SEC-PEN` · `BP-SEC-PHYS` · `BP-SEC-RECERT` · `BP-SEC-SOC` · `BP-SEC-VULN` · `BP-SRV-BILL` · `BP-SRV-BOOK` · `BP-SRV-MOD` · `BP-SRV-PAY` · `BP-TAX-COMP` · `BP-TAX-TP` · `BP-TRD-LC` · `BP-TRD-SCF` · `BP-TRY-CFP` · `BP-TRY-FTP` · `BP-TRY-FUND` · `BP-TRY-INV` · `BP-TRY-LIQ` · `BP-VEN-CONC` · `BP-VEN-CTR` · `BP-VEN-DD` · `BP-VEN-EXIT` · `BP-VEN-MON` · `BP-VEN-SRC`

**Total registered processes: 134**

### Appendix B — Risk Category Vocabulary (`CV-RISK`)

| Value | Definition | Primary Owner |
|---|---|---|
| Credit | Loss from a borrower or counterparty failing to meet obligations | RSK |
| Market | Loss from movements in rates, prices, or spreads | RSK / TRY |
| Liquidity | Inability to meet obligations as they fall due | TRY |
| Operational | Loss from inadequate or failed processes, people, systems, or external events | RSK |
| Compliance | Loss from failure to comply with laws, rules, or regulations | CMP |
| Financial Crime | Loss or sanction from money laundering, terrorist financing, sanctions breach, or bribery | CMP |
| Fraud | Loss from internal or external deception | CMP |
| Conduct | Detriment to customers or market integrity from Bank behaviour | CMP |
| Technology | Loss from failure, unavailability, or obsolescence of technology | ITO |
| Cyber | Loss from compromise of confidentiality, integrity, or availability by adversarial action | ISC |
| Third-Party | Loss arising from reliance on external providers | PRC |
| Model | Loss from model error or inappropriate model use | RSK |
| Legal | Loss from unenforceable rights, litigation, or legal uncertainty | LEG |
| Financial Reporting | Misstatement in financial or regulatory reporting | FIN |
| Physical Security | Loss from unauthorised physical access, damage, or harm | ADM |
| Strategic | Loss from poor strategic choices or failure to adapt | ExCo |
| Reputational | Loss of stakeholder confidence — a consequence category, always secondary to a primary cause | All |

### Appendix C — Process Documentation Standard

Every L3 process must be documented to the following minimum, in an SOP or Manual classified per `ANB-ADM-STD-0006`:

1. Process code, name, owner, and effective date
2. Purpose and scope boundary — where the process starts and stops
3. Trigger and inputs
4. Step sequence with the responsible role at each step
5. Control points, with control identifiers and the evidence each produces
6. Handoffs — counterpart process, counterpart owner, and what must be true before transfer
7. Systems used at each step
8. Decision points and approval authorities, cross-referenced to `ANB-ADM-MTX-0001`
9. Exception handling and escalation path
10. Outputs and records produced, with record class and retention code
11. Key performance and key risk indicators
12. Vendor dependencies and their tier
13. Manual workaround for system unavailability (mandatory for Tier 1 processes)

### Appendix D — Common Classification Errors

| Error | Consequence | Correction |
|---|---|---|
| Registering an L4 activity as an L3 process | Register bloat; ownership fragmentation | Merge into the parent process as a sub-process |
| Two departments each registering the same process | Duplicate controls; contested ownership | Single process, single owner, documented handoffs |
| Mapping a process only to its "main" system | Incomplete impact analysis | Map every system where the process executes or files records |
| Omitting compliance categories because "the policy covers it" | Regulatory traceability gap at examination | Map explicitly, or record a Compliance determination of non-applicability |
| Owning a process in Second Line while also assessing it | Independence breach | Reassign ownership or assessment (M-7) |
| Leaving a handoff unowned on one side | Work lost between departments — the most common operational loss cause | Named owner on both sides of every handoff |

---

**End of Document**

`ANB-ADM-GDL-0001` · Version 1.0 · Classification: Internal (C1) · Owner: Administration (ADM) with Risk (RSK) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
