# Apex National Bank — Approval Authority Matrix

**Enterprise Governance Matrix | Delegated Authority, Approval Limits, and Decision Rights**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ADM-MTX-0001` |
| **Document Title** | Apex National Bank — Approval Authority Matrix |
| **Version** | 1.0 |
| **Owner** | Administration Department (ADM) — Enterprise Knowledge Management Office (EKMO) |
| **Joint Owner** | Finance Department (FIN) for financial authority; Risk (RSK) for credit authority |
| **Custodian** | Claire Bennett, Head of Administration (G9) |
| **Approver** | Daniel K. Ortega, Chief Operating Officer |
| **Secondary Approvers** | Priya Raghunathan, Chief Financial Officer; Helena Brandt, Chief Risk Officer; Margaret Sullivan, General Counsel |
| **Status** | Approved — Published |
| **Classification** | Confidential (C2) |
| **Created Date** | 2026-05-25 |
| **Effective Date** | 2026-07-01 |
| **Last Updated** | 2026-06-30 |
| **Review Cycle** | Annual (next review 2027-06-30); limits reviewed on any change to the Board delegated authority instrument |
| **Supersedes** | None — initial published matrix |
| **Retention** | `RET-GOV-PERM` — Corporate Governance Records (delegated authority instrument) |
| **Record Class** | Corporate Governance Records |
| **Governing Body** | Executive Committee (ExCo); Board of Directors for authority above ExCo limits |
| **System of Record** | ApexDocs (matrix) · ApexServe (delegations and exceptions) |
| **Keywords** | approval authority, delegated authority, RACI, credit authority, financial authority, segregation of duties, exception approval |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-ADM-STD-0005` · `ANB-ADM-STD-0006` · `ANB-ADM-STD-0007` · `ANB-ADM-POL-0001` · `ANB-LEG-REF-0003` · `ANB-ADM-GDL-0001` |

> **Authority.** This Matrix consolidates and operationalises §5.3 (Financial Authority), §5.4 (Credit Authority), §5.5 (Decision Matrix) and §12 (Approval Matrix) of `ANB-ADM-REF-0001`. All limits reproduced here are identical to those in the Master Company Profile. Where any discrepancy arises, `ANB-ADM-REF-0001` prevails and this Matrix is corrected within 5 business days.

---

## 2. Document Purpose

Delegated authority is the mechanism by which the Board permits a bank of 68,000 people to make decisions without the Board making them. It works only when three things are unambiguous: **who** may decide, **up to what limit**, and **what evidence** the decision produces.

This Matrix provides a single, authoritative answer to those three questions for every recurring decision the Bank makes. It exists to:

1. Prevent unauthorised commitment of the Bank's capital, credit, and reputation.
2. Enforce segregation of duties so that no individual can originate, approve, and execute the same transaction.
3. Give Internal Audit, external audit, and regulators a testable control: any approval can be checked against a published limit.
4. Remove the most common operational failure mode in large banks — a decision made by someone who genuinely believed they were entitled to make it.

---

## 3. Scope

### 3.1 In Scope

| Domain | Covered Decisions |
|---|---|
| Documentation | Policy, standard, procedure, template, and reference document issuance |
| Credit | Consumer, mortgage, commercial, and corporate credit; exceptions; workout and charge-off |
| Expenditure | Purchase commitments, contracts, expenses, budget, capital projects |
| Third parties | Vendor onboarding, tiering, renewal, and termination |
| Risk | Risk acceptance, security exceptions, control exceptions, operational exceptions |
| Technology | Production change, emergency change, architecture deviation, access grants |
| Customer | Onboarding, high-risk relationships, offboarding, complaint redress |
| People | Hiring, compensation actions, termination for conduct |
| Governance | Records destruction, classification change, legal hold, public communication |

### 3.2 Out of Scope

- Board-reserved matters set out in the Board's own terms of reference (capital raising, dividend, M&A, appointment of executives) — these are not delegated and appear here only as escalation endpoints
- Statutory duties of the Corporate Secretary, which cannot be delegated
- Regulatory attestations personally signed by named executives

### 3.3 Applicability

All employees, contractors, and authorised agents across Apex National Bank, N.A. and all subsidiaries. Subsidiary boards may set **lower** local limits; they may never set higher ones.

---

## 4. Universal Approval Rules

These rules apply to every matrix in this document without exception.

**R-1 — Separation of duties.** The author or originator of a matter may never be its sole approver. A minimum of two distinct individuals must participate in any approval.

**R-2 — Grade sufficiency.** An approver must hold a grade at or above the level specified. Acting arrangements must be recorded in writing in ApexServe with defined start and end dates.

**R-3 — Evidence.** Approval is valid only when captured in ApexDocs workflow or ApexServe. Approval by email is permitted only during a declared business continuity event and must be reconciled into the system of record within five business days.

**R-4 — Conflict of interest.** An approver with a personal or financial interest in the outcome must recuse and escalate one level.

**R-5 — Independence of the Second and Third Lines.** Business management may not approve, amend, or veto Risk, Compliance, or Internal Audit opinions, ratings, or reports.

**R-6 — Approval expiry.** An approval that has not resulted in publication, execution, or drawdown within 90 days lapses and must be re-obtained.

**R-7 — Non-delegable by default.** Authority is personal. Delegation requires a written, time-bounded instrument recorded in ApexServe, may not exceed the delegator's own authority, and may not be sub-delegated.

**R-8 — No splitting.** Dividing a transaction, exposure, or engagement to remain below a threshold is a Code of Conduct violation under `ANB-HRM-POL-0004` and is treated as a conduct matter, not an administrative error.

**R-9 — Aggregate view.** Limits apply to total connected exposure or total contract value including options, renewals, and reasonably foreseeable extensions — not to the first tranche.

**R-10 — Escalation on exception.** Any exception to policy escalates **one authority level above** the level that would otherwise approve, irrespective of amount.

**R-11 — Four-eyes on execution.** Approval and execution are separate acts performed by separate individuals for all payments, credit drawdowns, contract signature, and production changes.

**R-12 — Silence is not approval.** Absence of objection within a review window never constitutes approval except where an escalation protocol explicitly provides for it and records it.

---

## 5. Matrix — Documentation and Policy Approval

| Document Type | Author | Mandatory Reviewers | Approver | Ratification / Notification |
|---|---|---|---|---|
| Enterprise Policy (bank-wide) | Department SME (G5–G6) | Legal, Compliance, Risk, EKMO | Department Head (G11) **and** COO | ExCo; Board committee where regulatorily required |
| Departmental Policy (single department) | Department SME (G5–G6) | Legal, Compliance, EKMO | Department Head (G9–G11) | ExCo notification |
| Standard | Function lead (G6) | Owning Department Head, Information Security (if technical) | Department Head (G9–G10) | EKMO registration |
| Standard Operating Procedure (SOP) | Process owner (G4–G5) | Line manager, Risk (if control-bearing) | Function Head (G7–G9) | Department Head notification |
| Guideline | SME (G4–G5) | Line manager | Function Head (G7) | — |
| Form / Template | Process owner (G4–G5) | Legal (if contractual), Compliance (if regulated) | Function Head (G7) | EKMO registration |
| Internal Audit report | Audit Manager (G6) | Audited Department Head (factual accuracy only) | Chief Audit Executive (G11) | Board Audit Committee |
| Risk assessment / RCSA | Process owner (G5) | Risk (Second Line challenge) | Department Head (G9–G11) | Operational Risk Committee |
| Regulatory filing | Regulatory Reporting Manager (G6) | Finance, Compliance, Legal | CFO or CCO (G11) | Disclosure Committee; Board where required |
| SAR / CTR filing | Financial Crime Investigator (G4–G5) | AML Team Lead | BSA Officer (G8, within Compliance) | Financial Crime Committee (aggregate only — individual SARs are C3) |
| Board / Committee minutes | Corporate Secretariat (G6) | Committee Chair | Committee (approval at next meeting) | Board of Directors |
| Incident report (Severity 1–2) | Incident Manager (G5–G6) | Information Security, Risk | Head of IT Operations (G11) or CISO (G10) | ExCo; regulator where notification thresholds met |
| Marketing material — regulated product | Marketing Manager (G5) | Compliance (mandatory), Legal, Product owner | Chief Marketing Officer (G10) | — |
| Press release / public statement | Communications Manager (G6) | Legal, Compliance, Investor Relations | CMO (G10); Group CEO for market-moving statements | Board notification |
| Master reference documents (Company Profile, taxonomy, metadata standard, this Matrix) | EKMO (G5–G6) | Legal, Compliance, all Department Heads | Chief Operating Officer (G11) | Enterprise Knowledge Council; ExCo |

**Version-specific rules.** A Major version increment requires the full approval chain above. A Minor increment requires Document Owner approval with the Approver notified. A Patch is applied by the Custodian in draft space only (`ANB-ADM-STD-0007` §11.1).

---

## 6. Matrix — Contracts and Signature Authority

### 6.1 Contract Approval

| Contract Category | Business Sponsor | Mandatory Reviewers | Approver | Escalation |
|---|---|---|---|---|
| Standard template, unmodified | Business sponsor (G5–G6) | Procurement | Authorised signatory per financial authority (§7.1) | Legal notification |
| Non-standard or amended terms | Business sponsor (G5–G6) | Legal (mandatory), Procurement, Information Security (if data access), Risk (if Tier 1 vendor) | General Counsel or delegate **and** value-based signatory | ExCo if above $10M |
| Any contract granting access to customer data | Business sponsor | Legal, ISC, Privacy (within LEG), Compliance | CISO **and** value-based signatory | Board Technology & Operational Resilience Committee if Tier 1 |
| Any contract with an offshore processing component | Business sponsor | Legal, Compliance, ISC, HRM (if resourcing) | CPO **and** value-based signatory | ExCo |
| Contract with a government or regulator | Legal | Compliance, Finance | General Counsel | Board notification |
| Intercompany agreement | Finance | Legal, Tax, Compliance | CFO | Disclosure Committee |

### 6.2 Signature Authority

Signature authority follows the financial authority grid in §7.1 by total contract value. In addition:

| Instrument | Signatory |
|---|---|
| Loan and security documentation | Two authorised officers, at least one G7+, per `ANB-CBK-POL-0001` |
| Guarantees and letters of credit issued by the Bank | Group Treasurer or CFO, countersigned per value |
| Deeds and instruments requiring seal | Corporate Secretary plus one Director |
| Regulatory attestations | Named executive personally; not delegable |
| Settlement agreements | General Counsel; above $10M also CFO; above $50M also Group CEO |
| Employment offers above G9 | CHRO; above G10 also Group CEO; G11 requires Compensation & Human Capital Committee |

---

## 7. Matrix — Financial Authority (Non-Credit Expenditure)

### 7.1 Expenditure Limits

| Grade | Single-Transaction Limit | Annual Cumulative Limit |
|---|---|---|
| G1–G3 | $5,000 | $25,000 |
| G4 | $25,000 | $150,000 |
| G5 (AVP) | $100,000 | $600,000 |
| G6 (VP) | $500,000 | $3,000,000 |
| G7 (SVP) | $2,000,000 | $12,000,000 |
| G8 (ED) | $10,000,000 | $50,000,000 |
| G9 (MD) | $25,000,000 | $120,000,000 |
| G10 (Group Head) | $100,000,000 | Business plan limit |
| G11 (ExCo member) | $250,000,000 | Approved budget |
| Board of Directors | Above $250,000,000 | Unlimited within charter |

**Rules of application.** Authority is personal and non-delegable except through a written, time-bounded delegation recorded in ApexServe. Transaction splitting to remain below a threshold is a Code of Conduct violation. All expenditure above **$1,000,000** additionally requires Procurement (PRC) sourcing sign-off; above **$10,000,000** requires Finance (FIN) and Legal (LEG) sign-off.

### 7.2 Expense Approval (Employee Reimbursement and Corporate Card)

| Expense Type | Threshold | Approver | Additional Requirement |
|---|---|---|---|
| Routine business expense | ≤ $1,000 | Line manager (G4+) | Receipt for any item ≥ $25 |
| Routine business expense | $1,000 – $10,000 | G6+ | Itemised receipts; business purpose statement |
| Routine business expense | > $10,000 | G8+ | Finance review |
| Travel — domestic | Any | Line manager (G5+) | Booked through approved channel |
| Travel — international | Any | G7+ | Compliance clearance for sanctioned or high-risk destinations |
| Travel — high-risk destination | Any | G9+ **and** Head of Physical Security | Security briefing mandatory |
| Client entertainment | ≤ $500 per head | G6+ | Guest names recorded; anti-bribery check |
| Client entertainment | > $500 per head | G9+ | Compliance pre-clearance |
| Gifts given or received | > $250 value | Compliance pre-clearance **and** G7+ | Recorded in the Gifts & Entertainment Register |
| Any expenditure involving a public official | Any value | General Counsel **and** CCO | Anti-bribery review; no exceptions |
| Charitable or political contribution | Any | CMO **and** General Counsel; > $100,000 also Group CEO | Board Public Responsibility & Compliance Committee reporting |

### 7.3 Budget Approval

| Action | Threshold | Approver |
|---|---|---|
| Departmental operating budget | Within approved plan | Department Head (G9–G11) |
| Departmental budget increase | ≤ 5% of departmental budget | Department Head with Finance concurrence |
| Departmental budget increase | 5–15% | ExCo member (G11) **and** CFO |
| Departmental budget increase | > 15% | ExCo |
| Business unit annual plan | Any | ExCo, ratified by Board |
| Capital project | ≤ $5,000,000 | Business Unit Head (G10) with CFO concurrence |
| Capital project | $5,000,000 – $50,000,000 | ExCo |
| Capital project | > $50,000,000 | Board of Directors |
| Unbudgeted commitment | > $1,000,000 | CFO **and** relevant ExCo member |
| Cost reallocation between business units | Any | CFO |

---

## 8. Matrix — Credit Authority

### 8.1 Credit Approval Grid

| Authority Level | Consumer Unsecured | Consumer Secured / Mortgage | Commercial / Corporate |
|---|---|---|---|
| Automated decisioning (ApexOrigin scorecard) | ≤ $25,000 | ≤ $500,000 conforming | Not applicable |
| Branch Manager (G5) | ≤ $50,000 | Referral only | Not applicable |
| Credit Manager (G6) | ≤ $150,000 | ≤ $1,500,000 | ≤ $1,000,000 |
| Senior Credit Officer (G7) | ≤ $250,000 | ≤ $5,000,000 | ≤ $10,000,000 |
| Regional Credit Committee | — | ≤ $15,000,000 | ≤ $50,000,000 |
| Group Credit Committee (GrCC) | — | > $15,000,000 | ≤ $500,000,000 |
| Board Risk Committee | — | — | > $500,000,000 |

All credit exceptions to policy, regardless of amount, escalate one authority level above the level that would otherwise approve the exposure.

### 8.2 Credit Approval Supporting Rules

| Rule | Requirement |
|---|---|
| Aggregation | Authority applies to **total connected exposure** of the borrowing group, including undrawn commitments, contingent exposures, and derivative potential future exposure |
| Independent credit opinion | Commercial and corporate exposures above $10,000,000 require an independent Risk (Second Line) recommendation before approval |
| Dual approval | No single individual may approve commercial credit above $1,000,000; a second approver at or above the required grade is mandatory |
| Related-party credit | Any exposure to a director, executive officer, or their related interests requires Board approval regardless of amount, with the interested party recused |
| Policy exception | Escalates one level; recorded in the credit file and reported monthly to the Group Credit Committee |
| Covenant waiver | Approved at the level that approved the facility; waivers to a defaulted covenant escalate one level |
| Pricing below the risk-adjusted floor | Requires Head of Credit Risk (G9) concurrence in addition to the credit approver |
| Country and sector concentration limits | Breach requires GrCC approval; sustained breach reported to the Board Risk Committee |

### 8.3 Problem Credit, Restructuring, and Charge-Off

| Action | Threshold | Approver |
|---|---|---|
| Watchlist transfer | Any | Senior Credit Officer (G7) |
| Risk rating downgrade to non-performing | Any | Head of Credit Risk (G9) |
| Forbearance or restructure | ≤ $5,000,000 | Senior Credit Officer (G7) **and** Head of Special Assets |
| Forbearance or restructure | > $5,000,000 | Regional Credit Committee |
| Forbearance or restructure | > $50,000,000 | Group Credit Committee |
| Charge-off — consumer | ≤ $250,000 | Head of Collections (G8) |
| Charge-off — commercial | ≤ $5,000,000 | Head of Credit Risk (G9) |
| Charge-off — commercial | > $5,000,000 | Group Credit Committee; > $50,000,000 also Board Risk Committee |
| Debt sale portfolio | Any | CRO **and** CFO; > $100,000,000 ExCo |
| Specific provision above $10,000,000 | Any | CRO **and** CFO, reported to Audit Committee |

---

## 9. Matrix — Vendor and Third-Party Approval

### 9.1 Vendor Onboarding

| Contract Value / Tier | Due Diligence Depth | Approver | Mandatory Consultees |
|---|---|---|---|
| < $50,000, non-critical | Standard screening | Category Manager (G6) | — |
| $50,000 – $250,000 | Standard due diligence | Head of Category (G7) | Legal for non-standard terms |
| $250,000 – $1,000,000 | Enhanced due diligence | Head of Procurement Operations (G8) | Legal, Information Security |
| Above $1,000,000 | Full due diligence | Chief Procurement Officer (G10) | Legal, Risk, Information Security, Finance |
| Tier 1 (critical service) — any value | Full due diligence plus resilience assessment | CPO **and** CRO | Legal, ISC, ITO, business sponsor, Compliance |
| Tier 1 with customer data offshore | Full plus data protection impact assessment | CPO, CRO **and** CISO | Legal/Privacy, Compliance; Board Technology & Operational Resilience Committee notified |
| Sole-source award above $250,000 | Justification memorandum required | CPO **and** CFO | Internal Audit informed |

### 9.2 Vendor Lifecycle Decisions

| Decision | Approver |
|---|---|
| Vendor tier assignment or change | CPO with CRO concurrence for Tier 1 |
| Annual vendor performance acceptance | Business sponsor (G7+) with Procurement |
| Contract renewal within existing terms | Original approval level |
| Contract renewal with increased value | Approval level for the new total value |
| Vendor risk finding acceptance | CRO for Tier 1; CPO for Tier 2–3 |
| Vendor exit / termination for cause | CPO, General Counsel, and business sponsor's Department Head |
| Fourth-party (subcontractor) approval for Tier 1 services | CPO **and** CISO |

Third-party governance operates under `ANB-PRC-POL-0002`; this Matrix sets the approval levels, not the due diligence methodology.

---

## 10. Matrix — Risk, Security, and Operational Exceptions

### 10.1 Risk Acceptance

| Residual Risk Rating | Duration | Approver | Reporting |
|---|---|---|---|
| Low | ≤ 12 months | Department Head (G9) | Departmental risk register |
| Medium | ≤ 12 months | Department Head (G9) **and** Head of Operational Risk (G8) | Operational Risk Committee |
| High | ≤ 6 months | ExCo member (G11) **and** CRO | ORC monthly; ExCo |
| Critical / outside appetite | ≤ 3 months | CRO **and** Group CEO | Board Risk Committee at next meeting |
| Any risk acceptance touching customer funds or data | Any | CRO **and** CISO | ORC and Board Technology & Operational Resilience Committee |

Risk acceptance is time-bounded without exception. Expiry without remediation escalates automatically to the next authority level; a second expiry escalates to the Board Risk Committee.

### 10.2 Information Security Exceptions

| Exception Type | Maximum Duration | Approver | Compensating Control |
|---|---|---|---|
| Standard configuration deviation | 90 days | Security Engineering Manager (G6) | Documented and monitored |
| Encryption or key management deviation | 30 days | CISO (G10) | Mandatory; ISC-designed |
| MFA bypass for a service account | 180 days | CISO **and** Head of Platform Engineering (G9) | Vaulted credentials, rotation, monitoring |
| Unsupported / end-of-life software in production | 180 days | CISO **and** CIO | Network isolation and enhanced monitoring |
| Firewall rule permitting inbound internet access to a Tier 1 system | 30 days | CISO **and** Head of IT Operations (G11) | Continuous monitoring; ORC notification |
| Any exception affecting cardholder data environment | 30 days | CISO **and** CCO | PCI QSA consultation |
| Emergency exception during a SEV1 incident | 72 hours, then formal | Incident Commander (G8+) with CISO notified within 4 hours | Retrospective approval mandatory |

### 10.3 Operational Exceptions

| Exception | Approver | Evidence |
|---|---|---|
| Deviation from a published SOP, single instance | Function Head (G7) | Recorded in ApexServe with justification |
| Deviation from a published SOP, recurring | Department Head (G9) with Risk consulted | SOP amendment required within 90 days |
| Manual override of an automated control | Department Head (G9) **and** Head of Operational Risk (G8) | Four-eyes execution; monthly ORC reporting |
| Suspension of a reconciliation | CFO **and** CRO | Daily reporting until resumed |
| Processing outside the approved cut-off | Head of Operations (G9) | Logged; loss event assessment |
| Waiver of a customer fee | ≤ $5,000 Branch Manager (G5); ≤ $50,000 Regional Director (G7); above CFO | Recorded in ApexCore with reason code |
| Goodwill payment / redress to a customer | ≤ $10,000 Head of Customer Support (G9); ≤ $250,000 CCO; above ExCo | Complaint file evidence; CFPB reporting where applicable |

---

## 11. Matrix — Technology Change and Access

### 11.1 Change Approval

| Change Class | Definition | Approver | Forum |
|---|---|---|---|
| Standard | Pre-authorised, low risk, repeatable, documented | Automated in ApexServe | CAB informed |
| Normal — low impact | Single non-Tier-1 system, no customer impact | Engineering Manager (G6) | CAB informed |
| Normal — medium impact | Multiple systems or customer-facing but reversible | Head of Platform Engineering (G9) | CAB approval |
| Normal — high impact | Tier 1 system, customer-facing, or irreversible | Head of IT Operations (G11) **and** CISO for security-relevant change | CAB approval mandatory |
| Major / programme release | Enterprise release, core banking, payments | CIO **and** affected Business Unit Head (G10) | CAB plus ExCo notification |
| Emergency | Required to restore service or close a critical vulnerability | Incident Commander (G8+) or Head of IT Operations | Retrospective CAB within 5 business days; ORC reporting |
| Architecture deviation | Departure from approved reference architecture | Enterprise Architecture Review Board | Escalates to CIO on rejection appeal |

Freeze periods (month-end, quarter-end, year-end, peak trading) permit only Emergency changes, approved by the Head of IT Operations with CFO concurrence during financial close.

### 11.2 Access Approval

| Access Type | Approver | Recertification |
|---|---|---|
| Standard role-based access | Line manager (G4+) | Semi-annual |
| Access to customer PII | Line manager **and** data owner (G6+) | Quarterly |
| Privileged / administrative access | Head of Platform Engineering (G9) **and** CISO | Quarterly |
| Production data access for a developer | CISO, time-bounded to 8 hours | Per grant; logged session |
| Access to C3 Restricted content | Named approval by the content owner (G9+) | Quarterly |
| Access to C4 Highly Confidential content | ExCo member owning the content, recorded by name | Per access |
| Third-party / vendor access | Business sponsor (G7+), CISO, and Procurement | Monthly |
| Emergency break-glass | Self-service with automatic CISO alert; retrospective approval within 24 hours | Every use reviewed |

---

## 12. Matrix — Customer Decisions

### 12.1 Customer Onboarding

| Customer Risk Rating | Approver | Additional Requirements |
|---|---|---|
| Low | Automated (ApexKYC) with Personal Banker (G2+) verification | CIP complete |
| Medium | Branch Manager or Relationship Manager (G5–G6) | CDD complete; adverse media clear |
| High | Compliance Officer (G6) **and** Business Head (G8) | EDD pack; source of wealth evidenced |
| Politically Exposed Person (PEP) | Head of Financial Crime (G9) **and** business sponsor | EDD; annual senior review |
| Correspondent banking relationship | BSA Officer (G8) **and** CCO | Wolfsberg questionnaire; on-site or equivalent review |
| Cash-intensive business | Head of Financial Crime (G9) | Enhanced monitoring profile |
| Money services business | CCO **and** Financial Crime Committee | Board Public Responsibility & Compliance Committee reporting |
| Customer in a sanctioned or high-risk jurisdiction | CCO **and** General Counsel | Case-by-case; may be prohibited outright |

### 12.2 Customer Exit and Adverse Action

| Decision | Approver |
|---|---|
| Account closure — customer request | Personal Banker (G2+) |
| Account closure — Bank-initiated, conduct or risk | Branch Manager (G5) with Compliance notified |
| Account closure — financial crime concern | BSA Officer (G8); SAR consideration mandatory before exit |
| Relationship exit — commercial customer | Business Head (G9) **and** CRO |
| Adverse action on a credit application | Credit decisioning authority for the exposure; Reg B notice issued within 30 days |
| Restriction of a customer's account | Head of Financial Crime (G9) or Head of Fraud (G8) |

---

## 13. Matrix — People Decisions

| Decision | Responsible | Approver | Consulted |
|---|---|---|---|
| Hire — G1–G6 | Hiring manager (G5+) | Department Head (G9) | HR Business Partner |
| Hire — G7–G9 | Department Head | ExCo member (G11) | CHRO |
| Hire — G10+ | ExCo member | Group CEO | Compensation & Human Capital Committee for G11 |
| Off-cycle salary increase | Line manager | Department Head **and** CHRO | Finance |
| Annual incentive pool | CHRO and CFO | ExCo | Compensation & Human Capital Committee ratifies |
| Individual incentive above $1,000,000 | Business Unit Head | Group CEO | Compensation & Human Capital Committee |
| Malus or clawback application | CHRO | Compensation & Human Capital Committee | Legal, Risk, CAE |
| Termination — performance | Line manager | Department Head (G9–G11) | HR Business Partner, Legal |
| Termination — conduct | HR Business Partner (G6) | Department Head (G9–G11) | Legal, Compliance; CHRO informed |
| Termination — G10+ | CHRO | Group CEO | Board Compensation & Human Capital Committee |
| Mandatory absence exemption for a sensitive role | Department Head | CHRO **and** CCO | Internal Audit informed |

---

## 14. RACI — Enterprise Decision Matrix

| Decision Type | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| New product launch | Product Manager (G6) | Business Unit Head (G10) | Risk, Compliance, Legal, Finance, ITO | NPAC, Internal Audit |
| Credit exposure above $50M | Relationship Manager (G6) | Chief Risk Officer (G11) | Corporate Banking, Legal | Group Credit Committee |
| Material technology change | Change Owner (G5) | Head of IT Operations (G11) | Information Security, affected business | CAB, Internal Audit |
| Policy issuance or amendment | Policy Author (G5–G6) | Department Head (G9–G11) | Legal, Compliance, EKMO | All staff in scope |
| Vendor onboarding above $1M | Category Manager (G6) | Chief Procurement Officer (G10) | Legal, Risk, Information Security, Finance | Business sponsor |
| Regulatory filing | Regulatory Reporting Manager (G6) | Chief Financial Officer (G11) | Compliance, Legal | Disclosure Committee |
| Employee termination for conduct | HR Business Partner (G6) | Department Head (G9–G11) | Legal, Compliance | CHRO |
| Data classification change | Data Steward (G5) | Chief Data Officer (G10) | Information Security, Legal | Data Governance Council |
| Public communication / press release | Communications Manager (G6) | Chief Marketing Officer (G10) | Legal, Compliance, Investor Relations | ExCo |
| Business continuity invocation | Site Incident Manager (G6) | Chief Operating Officer (G11) | ITO, ISC, affected business, Communications | Board, regulators |
| Records destruction run | Records Manager (G6) | Head of Administration (G9) | Legal, Compliance, Owner departments | Enterprise Knowledge Council |
| Legal hold issuance | Legal Counsel (G6) | General Counsel (G11) | EKMO, ITO, custodians' Department Heads | Chief Audit Executive |
| Taxonomy or metadata schema change | EKMO (G5–G6) | Head of Administration (G9) | CDO, Legal, Compliance, Department Heads | Enterprise Knowledge Council, ExCo |

---

## 15. Governance

### 15.1 Ownership of Limits

| Authority Domain | Limit Owner | Change Approval |
|---|---|---|
| Financial authority (§7.1) | CFO | ExCo, ratified by the Board |
| Credit authority (§8.1) | CRO | Board Risk Committee |
| Documentation authority (§5) | COO via EKMO | Enterprise Knowledge Council |
| Vendor authority (§9) | CPO | ExCo |
| Security exception authority (§10.2) | CISO | Board Technology & Operational Resilience Committee |
| Change authority (§11.1) | CIO | CAB, escalated to ExCo |
| People authority (§13) | CHRO | Compensation & Human Capital Committee |

### 15.2 Delegation Register

All delegations are recorded in ApexServe with: delegator, delegate, scope, monetary ceiling, start date, end date, and reason. The register is reviewed monthly by Finance for financial authority and quarterly by Internal Audit across all domains. Delegations lapse automatically on expiry, on the delegator's role change, or on the delegate's departure — no manual revocation is required, and no system will accept a lapsed delegation.

### 15.3 Monitoring and Assurance

| Control | Method | Frequency | Owner |
|---|---|---|---|
| Approval within authority | Automated system validation in ApexServe, ApexOrigin, ApexCredit, ApexLedger | Continuous | ITO |
| Post-approval sampling | Sample testing of approvals against the matrix | Monthly | Finance (expenditure), Risk (credit) |
| Segregation of duties conflicts | Entitlement analysis across ApexID roles | Quarterly | ISC with Internal Audit |
| Transaction splitting detection | Pattern analysis of near-threshold approvals by approver | Monthly | Finance |
| Delegation validity | Register reconciliation to ApexPeople | Monthly | HRM and Finance |
| Exception ageing | Expired risk acceptances and security exceptions | Monthly | Risk and ISC |
| Independent audit | Delegated authority framework audit | Every 2 years | Internal Audit |

### 15.4 Breach Handling

| Breach Type | Immediate Action | Reporting |
|---|---|---|
| Approval above authority — inadvertent | Ratify at the correct level or reverse; document | Department Head; Finance |
| Approval above authority — repeated | Authority suspended pending review | ORC; CHRO |
| Transaction splitting | Conduct investigation | CHRO, General Counsel, CAE |
| Credit approval outside authority | Exposure re-approved at the correct level or exited; loss assessment | GrCC; Board Risk Committee if material |
| Unauthorised contract execution | Legal review of enforceability; ratification or repudiation | General Counsel; ExCo |
| Security exception without approval | Immediate revert or emergency ratification | CISO; ORC |

---

## 16. Processes

### 16.1 Obtaining an Approval

1. Originator identifies the decision type in this Matrix and confirms the required approver grade and consultees.
2. Originator raises the request in the applicable system: ApexDocs (documents), ApexServe (exceptions, access, change), ApexOrigin/ApexCredit (credit), ApexLedger/ApexSource (expenditure and procurement).
3. Mandatory consultees provide written input within the SLA; Legal and Compliance objections block progression until resolved or escalated.
4. Approver records the decision with reasoning. "Approved" without reasoning is invalid for any matter above $1,000,000, any credit above $10,000,000, and any exception.
5. Execution is performed by a different individual (R-11).
6. The approval record is retained per `ANB-ADM-POL-0001` against the relevant record class.

### 16.2 Requesting a Delegation

| Step | Actor | SLA |
|---|---|---|
| Submit delegation request with scope, ceiling, and dates | Delegator | — |
| Validate delegate's grade sufficiency and training completion | HRM | 2 business days |
| Validate no segregation-of-duties conflict | ISC | 2 business days |
| Approve and register | Delegator's manager (one level above) | 3 business days |
| System entitlement applied | ITO | 1 business day |

Maximum delegation duration is 6 months for financial and credit authority, and 12 months for documentation authority. Delegations for annual leave are limited to the absence period plus five business days.

### 16.3 Escalation Path

```
Individual authority exceeded
        ↓
Next grade in the same department
        ↓
Department Head (G9–G11)
        ↓
Relevant management committee (GrCC · ORC · FCC · NPAC · CAB · DGC · EKC · ALCO)
        ↓
Executive Committee (ExCo)
        ↓
Relevant Board committee
        ↓
Board of Directors
```

An escalation may not skip a level except where a level is conflicted (R-4) or unavailable within the required timeframe, in which case the skip and its reason are recorded.

---

## 17. Examples

### 17.1 Commercial Credit — $75,000,000 Facility with a Policy Exception

| Step | Actor | Authority Basis |
|---|---|---|
| Origination and credit memorandum | Relationship Manager (G6), Credit Analyst | §5 documentation |
| Independent credit recommendation | Risk (Second Line) | §8.2 — mandatory above $10M |
| Would-be approver on amount alone | Group Credit Committee (≤ $500M) | §8.1 |
| Policy exception identified (LTV above standard) | — | §8.2 |
| Actual approver | **Board Risk Committee** — one level above GrCC | R-10 |
| Reporting | Monthly exception report to GrCC; Board Risk Committee minutes | §8.2 |
| Records | Credit file under `RET-CRD-LIFE-7Y`; minutes under `RET-GOV-PERM` | `ANB-ADM-POL-0001` |

### 17.2 Vendor Onboarding — Tier 1 Cloud Provider, $18,000,000 over 5 Years

| Requirement | Basis |
|---|---|
| Approver: CPO **and** CRO (Tier 1) | §9.1 |
| Signatory: G9 by value ($18M single-transaction sits within G9's $25M) | §7.1 |
| Procurement sourcing sign-off (> $1M) | §7.1 rules |
| Finance and Legal sign-off (> $10M) | §7.1 rules |
| Non-standard terms → General Counsel approval | §6.1 |
| Customer data access → CISO approval | §6.1 |
| Board Technology & Operational Resilience Committee notified | §9.1 |
| Contract record retained under `RET-CTR-TERM-7Y`; due diligence under `RET-VEN-7Y` | `ANB-ADM-POL-0001` |

Six distinct approvals, one contract. Each is separately evidenced in ApexSource and ApexDocs.

### 17.3 Emergency Security Exception During a SEV1

At 02:40 during `INC-00220117`, the Incident Commander (G8) disables a WAF rule to restore ApexOnline availability.

| Time | Action | Authority |
|---|---|---|
| 02:40 | Exception applied | §10.2 — emergency, 72 hours |
| 04:15 | CISO notified (within 4 hours) | §10.2 |
| 09:00 | Formal exception raised in ApexServe with compensating monitoring | §10.2 |
| Day 3 | CISO formal approval or revert | §10.2 |
| Day 5 | Retrospective CAB review of the associated emergency change | §11.1 |
| Day 10 | Post-incident review approved by Head of IT Operations | §5 |

Failure to obtain retrospective approval within 72 hours converts an authorised emergency action into an unapproved security exception and is reported to the Operational Risk Committee.

### 17.4 Documentation — Publishing an Enterprise Policy

`ANB-CMP-POL-0001` AML Policy v8.0: authored by a Compliance SME (G6); reviewed by Legal, Compliance, Risk, and EKMO; approved by the Chief Compliance Officer (G11) **and** the COO; ratified by the Board Public Responsibility & Compliance Committee as the named approver in the reserved document register; published by EKMO with attestation triggered in ApexLearn for all in-scope staff.

---

## 18. Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Author | Enterprise Knowledge Management Office, Administration (ADM) | Prepared | 2026-05-25 |
| Reviewer — Finance | Priya Raghunathan, Chief Financial Officer | Reviewed | 2026-06-09 |
| Reviewer — Risk | Helena Brandt, Chief Risk Officer | Reviewed | 2026-06-10 |
| Reviewer — Legal | Margaret Sullivan, General Counsel | Reviewed | 2026-06-12 |
| Reviewer — Compliance | Samuel A. Okonkwo, Chief Compliance Officer | Reviewed | 2026-06-15 |
| Reviewer — Procurement | Ian McAllister, Chief Procurement Officer | Reviewed | 2026-06-16 |
| Reviewer — Technology | Arjun Patel, Chief Information Officer | Reviewed | 2026-06-17 |
| Reviewer — Internal Audit | Thomas Nakamura, Chief Audit Executive | Reviewed (no objection) | 2026-06-18 |
| Ratifying Body | Executive Committee | Ratified | 2026-06-26 |
| Approver | Daniel K. Ortega, Chief Operating Officer | Approved | 2026-06-30 |
| Board Oversight | Board of Directors — delegated authority instrument noted | Noted | 2026-06-25 |

---

## 19. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full re-validation of all limits against risk appetite and inflation | EKMO with Finance and Risk | Annually |
| Board amends delegated authority | Immediate matrix update | EKMO | 5 business days |
| Organisational restructure | Re-map grades and roles | EKMO with HRM | 30 days |
| New business line or product family | Add decision types | EKMO with Business Unit | Before launch |
| Material control breach | Targeted limit or process review | Risk with EKMO | 30 days |
| Audit finding on delegated authority | Remediation plan | EKMO | 30 days |

Next scheduled review: **2027-06-30**.

---

## 20. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of all authority limits |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/ENTERPRISE_METADATA_STANDARD.md` | `approval_authority` metadata field |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | Approval of taxonomy changes |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | Version increments requiring approval |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Destruction and hold authority |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Committee approval authority and quorum |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | Process owners who exercise authority |
| `ANB-CBK-POL-0001` | Loan Approval Policy | *(planned)* | Credit underwriting standards |
| `ANB-PRC-POL-0001` / `ANB-PRC-POL-0002` | Procurement Policy / Third-Party Risk Management Policy | *(planned)* | Vendor process |
| `ANB-FIN-POL-0001` / `ANB-FIN-POL-0002` | Expense Policy / Travel Policy | *(planned)* | Expense categories and evidence |
| `ANB-HRM-POL-0004` | Code of Conduct | *(planned)* | Splitting and conflict of interest |
| `ANB-ISC-POL-0001` | Information Security Policy | *(planned)* | Security exception framework |
| `ANB-ITO-SOP-0003` | Change Management Procedure | *(planned)* | Change classes and CAB operation |

---

## 21. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-05-25 | EKMO | Initial draft consolidating `ANB-ADM-REF-0001` §5.3, §5.4, §5.5, §12 | — |
| 0.4 | 2026-06-08 | EKMO | Added vendor, security exception, and technology change matrices | — |
| 0.6 | 2026-06-14 | EKMO | Added customer onboarding and people matrices after CCO and CHRO input | — |
| 0.8 | 2026-06-19 | EKMO | Universal rules R-7 to R-12 added following Internal Audit review | — |
| 0.9 | 2026-06-26 | EKMO | ExCo ratification amendments: delegation maxima; breach handling table | — |
| 1.0 | 2026-06-30 | EKMO | First published version | D. K. Ortega |

---

## 22. Appendices

### Appendix A — Authority Quick Reference by Grade

| Grade | Expenditure | Consumer Credit | Commercial Credit | Documents | Notable Additional Authority |
|---|---|---|---|---|---|
| G1–G3 | $5,000 | — | — | — | Customer onboarding (low risk) |
| G4 | $25,000 | — | — | — | Routine expense approval |
| G5 (AVP) | $100,000 | $50,000 unsecured | — | Guidelines (author) | Account closure; fee waiver ≤ $5,000 |
| G6 (VP) | $500,000 | $150,000 unsecured; $1.5M secured | $1,000,000 | SOP authorship | Standard low-impact change |
| G7 (SVP) | $2,000,000 | $250,000 unsecured; $5M secured | $10,000,000 | Guidelines, forms, SOPs (approve) | Fee waiver ≤ $50,000; single SOP deviation |
| G8 (ED) | $10,000,000 | — | — | SOPs (approve) | Consumer charge-off ≤ $250,000; emergency change |
| G9 (MD) | $25,000,000 | — | — | Departmental policy, standards | Commercial charge-off ≤ $5M; risk acceptance (Low/Medium) |
| G10 (Group Head) | $100,000,000 | — | — | Standards | Vendor onboarding > $1M (CPO); marketing approval (CMO) |
| G11 (ExCo) | $250,000,000 | — | — | Enterprise policy | High risk acceptance; regulatory filings |
| Board | Above $250,000,000 | — | > $500,000,000 corporate | Board-reserved instruments | Related-party credit; capital projects > $50M |

### Appendix B — Mandatory Consultation Triggers

| Trigger | Mandatory Consultee |
|---|---|
| Any customer personal data leaves the Bank's control | Legal (Privacy) and CISO |
| Any commitment above $1,000,000 | Procurement |
| Any commitment above $10,000,000 | Finance and Legal |
| Any new or materially changed product | Risk, Compliance, Legal, Finance, ITO (NPAC) |
| Any decision affecting regulatory reporting | Finance and Compliance |
| Any deviation from an approved control | Risk |
| Any public statement | Legal, Compliance, Investor Relations |
| Any matter involving a public official or political exposure | General Counsel and CCO |
| Any use of an AI or machine-learning model in a decision | Risk (Model Risk) and CDO |
| Any change affecting a Tier 1 system | CISO and Head of IT Operations |

### Appendix C — Approval Evidence Requirements

| Decision Class | Minimum Evidence Retained |
|---|---|
| Documentation | ApexDocs workflow record: reviewers, comments, disposition, approver, date, version |
| Credit | Credit memorandum, independent risk opinion, approval record with conditions, exception rationale |
| Expenditure | Requisition, quotes or sourcing record, approval chain, purchase order, invoice match |
| Contract | Approval record, negotiated redlines, Legal sign-off, signature evidence, executed instrument |
| Risk acceptance | Risk description, residual rating, compensating controls, expiry date, approver identity |
| Security exception | Technical description, compensating control, expiry, CISO record |
| Change | Change record, test evidence, rollback plan, CAB decision, implementation record |
| Customer onboarding | CIP/CDD evidence, risk rating, approver identity, EDD pack where applicable |
| People | Requisition or case file, HR review, approval, Legal review where conduct-related |

### Appendix D — Common Failure Modes

| Failure Mode | Why It Happens | Control |
|---|---|---|
| Approval by the requester's direct report | Hierarchy confusion in matrix organisations | System validation against ApexPeople reporting line |
| Splitting a $1.2M purchase into three $400K orders | Avoiding Procurement involvement | Near-threshold pattern analysis (§15.3) |
| Verbal approval later "confirmed" by email | Speed pressure | R-3: only system-captured approval is valid |
| Delegation left open after the delegator's return | No expiry set | Mandatory end date; automatic lapse |
| Exception renewed indefinitely | Remediation never funded | Automatic escalation on expiry (§10.1) |
| Credit approved on facility amount, ignoring group exposure | Aggregation not checked | R-9 and ApexCredit group exposure validation |
| Second Line opinion "negotiated" with the business | Pressure on independence | R-5; CRO and CAE direct Board reporting lines |

---

**End of Document**

`ANB-ADM-MTX-0001` · Version 1.0 · Classification: Confidential (C2) · Owner: Administration (ADM) with Finance (FIN) and Risk (RSK) · Approver: Daniel K. Ortega, Chief Operating Officer · Effective 2026-07-01 · Next Review 2027-06-30

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
