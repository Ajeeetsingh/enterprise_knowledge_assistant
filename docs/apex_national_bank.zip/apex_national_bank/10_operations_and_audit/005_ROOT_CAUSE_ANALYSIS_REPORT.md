# Apex National Bank — Root Cause Analysis Report

**Major Problem RCA | INC-20260714-0001 / PRB-20260714-0001 — Edge Routing Change & Monitoring Gap**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-RCA-0001` |
| **Document Title** | Root Cause Analysis Report — Digital & Payments SEV-1 (14 July 2026) |
| **Problem ID** | `PRB-20260714-0001` |
| **Related Incident(s)** | `INC-20260714-0001` (+ precursor SEV-3 cluster June mobile timeouts) |
| **Known Error** | `KEDB-202607-0008` |
| **Version** | 1.0 Final |
| **Owner** | IT Operations — Problem Management |
| **RCA Facilitator** | Head of Service Management (G8) |
| **Approver** | Ravi Subramanian, Head of IT Operations — `EMP-500101`; CIO informed |
| **Classification** | Confidential (C2) |
| **Effective / Approved** | 2026-07-28 |
| **Business Process** | `BP-OPS-PRB`, `BP-OPS-CAPA`, `BP-OPS-CHG`, `BP-ITSM-PRB` |
| **System of Record** | ApexServe (Problem) · ApexDocs (this RCA) |
| **Related Documents** | `ANB-OPS-INC-0001`, `ANB-OPS-SOP-0002`, `ANB-OPS-POL-0001`, `ANB-ITO-SOP-0003`, `ANB-ISC-SOP-0003`, `ANB-ISC-STD-0007`, `ANB-IAD-RPT-0001`, `ANB-ITO-PLN-0002` |

---

## 2. Purpose

Identify root and contributing causes of SEV-1 service impairment on 14 July 2026, define corrective and preventive actions (`CAPA-` / `ACT-`), update the Known Error Database, and prevent recurrence across Digital, Payments, and ATM-adjacent dependencies.

---

## 3. Scope

In scope: change `CHG-20260714-0003`, F5/`CFG-` objects, monitoring suppressions, on-call practices, CMDB fidelity, vendor ATM symptom correlation, and cyber dual-track outcome. Out of scope: unrelated AML alert backlog; HR systems; Treasury settlement (not impacted).

---

## 4. Responsibilities

| Role | Responsibility |
|---|---|
| Problem Manager | Own `PRB-`; drive RCA to closure |
| Technical SMEs | Provide causal analysis; validate fixes |
| Change Manager | Address emergency change control gaps |
| Monitoring Lead | Alert hygiene & SLO burn alerts |
| ISC / SOC | Confirm non-cyber root |
| Service Owners | Accept CAPA into service improvement |
| IAD | May validate High CAPA independently |

---

## 5. Executive Conclusion

**Root cause:** An emergency edge-routing change introduced incorrect pool weighting and an iRule condition (`CFG-20260714-0099`) that black-holed a subset of API traffic under load, without a pre-prod replay at production-equivalent concurrency.

**Critical contributing causes:** (1) Tier-1 payment latency alert indefinitely suppressed; (2) emergency change PIR/risk documentation incomplete; (3) CMDB relationship for F5 pool members drifted; (4) retry storms amplified load (not a cyber attack).

---

## 6. Event Synopsis

See full timeline in `ANB-OPS-INC-0001`. Business impact: digital session failures, ApexPay latency, Northeast ATM decline spike (symptom via host timeouts), SEV-1 for 5h 35m. DR not invoked. Cyber intrusion ruled out at 11:40 ET.

---

## 7. Methods Used

| Method | Application |
|---|---|
| Timeline analysis | Bridge transcript + tool timestamps |
| 5-Whys | Primary causal chain (§8) |
| Fishbone (Ishikawa) | People/Process/Tech/Vendor/Monitor (§9) |
| Change diff review | `CHG-20260714-0003` vs prior good config |
| Monitoring forensics | PagerDuty suppressions; Grafana burn rates |
| Cyber exclusion | ApexShield / CrowdStrike / Sentinel hunt |

---

## 8. Five Whys

```
Why SEV-1 customer impact?
  → API and payment traffic failed or timed out at edge
Why?
  → F5 pool weighting / iRule sent traffic to saturated / incorrect members
Why?
  → Emergency change CHG-20260714-0003 deployed defective CFG-20260714-0099
Why?
  → Change tested only at low concurrency; CAB lite path skipped load test evidence
Why? (Root)
  → Emergency change process allowed production edge changes without mandatory
     production-equivalent validation gate or automated config lint for pool weights
     under time pressure, with inadequate compensating monitoring (alert suppressed).
```

---

## 9. Fishbone (Markdown)

```
                        INC-20260714-0001
                               │
        ┌──────────────┬───────┴────────┬──────────────┐
     People         Process          Technology      Detection
        │              │                 │              │
  Fatigue after     Emergency CHG     Bad iRule      ALR suppressed
  weekend on-call   PIR incomplete    Pool weights   Prometheus MON
  Single approver   No load test      CMDB drift     PagerDuty mute
  Retry amplification  Freeze N/A     F5 complexity  MTTD gap payments
```

---

## 10. Causal Factor Chart

| Factor | Type | Evidence | Controls Failed |
|---|---|---|---|
| Defective edge config | Root | Config diff; restore to baseline fixed | SSDLC/change validation |
| Missing load test | Contributing | CHG attachment absent | `ANB-OPS-POL-0001` |
| Alert suppression | Contributing | PagerDuty audit 03:10→incident | `BP-OPS-MON` |
| CMDB drift | Contributing | `CMDB-00077210` stale relations | `BP-ITSM-CMDB` |
| Client retry storm | Amplifying | Splunk `EVT-20260714-2001` | Rate-limit design |
| ATM declines | Symptom | Vendor host timeouts | Dependency mapping |

---

## 11. Why Not Cyber?

| Hypothesis | Result |
|---|---|
| Credential stuffing | Volume correlated to error retries; no credential validation anomalies beyond retries |
| WAF bypass / exploit | Palo Alto / F5 logs — no exploit signatures matched |
| Insider malicious change | Change attributed to named engineer; no policy violation beyond process shortcut; HR not engaged |
| Ransomware / malware | CrowdStrike clean on sampled `HOST-` |

Dual-track closed per `ANB-ISC-SOP-0003`.

---

## 12. Known Error

| Field | Value |
|---|---|
| **KEDB ID** | `KEDB-202607-0008` |
| **Error** | Edge pool weight misconfiguration under emergency change causes API black-hole |
| **Workaround** | Immediate rollback to last-known-good; enable rate-limit; unsuppress latency ALR |
| **Permanent fix** | Config lint + canary + mandatory load evidence for edge CHG |
| **KB / Runbook** | `KB-OPS-EDGE-001`, `RUN-OPS-SEV1-DIGITAL` |

---

## 13. Corrective / Preventive Actions (CAPA)

| ID | Action | Type | Owner | Due | Status | Linked CHG |
|---|---|---|---|---|---|---|
| `CAPA-20260714-0001` | Automated F5 pool-weight lint in ApexBuild | Preventive | Platform Eng | 2026-09-30 | Open | `CHG-` planned |
| `CAPA-20260714-0002` | Prohibit indefinite Tier-1 alert suppression; max 2h + approval | Preventive | Monitoring Lead | 2026-08-15 | Open | Policy update |
| `CAPA-20260714-0003` | Emergency edge changes require canary + second approver always | Corrective | Change Manager | 2026-08-31 | Open | `ANB-OPS-POL-0001` amend |
| `CAPA-20260714-0004` | Reconcile F5↔CMDB discovery job weekly | Preventive | CMDB Steward | 2026-08-31 | Open | — |
| `CAPA-20260714-0005` | Chaos/load test harness for digital edge quarterly | Preventive | SRE | 2026-10-31 | Open | — |
| `ACT-20260714-0011` | Update `RUN-OPS-SEV1-DIGITAL` with payments unsuppress step | Corrective | Problem Mgr | 2026-08-07 | Closed | — |
| `ACT-20260714-0012` | Training for on-call on suppression policy | Corrective | Service Mgmt | 2026-08-20 | Open | ApexLearn |

Alignment with IAD actions in `ANB-IAD-RPT-0001` (`ACT-2026-0142-01`, `-05`).

---

## 14. Workflow — RCA to Closure

```
PRB opened from SEV-1
   → RCA workshop (5-Whys + fishbone)
   → Draft ANB-OPS-RCA-0001
   → CAPA agreed with owners
   → Implement via CHG- (Normal)
   → Effectiveness review (30/60/90 days)
   → KEDB update / retire when fixed
   → PRB Closed (Known Error Resolved)
```

---

## 15. Approval Matrix

| Item | Approver |
|---|---|
| RCA conclusions | Head of IT Ops |
| CAPA dates > 90 days for SEV-1 root | CIO |
| Residual risk acceptance | CRO path / `BP-RSK-ACC` if needed |
| KEDB publish | Problem Manager |

---

## 16. Decision Tree — Problem vs Incident Only

```
SEV-1 or SEV-2?
   └─ Yes → Mandatory PRB + RCA
Recurring SEV-3 (≥5 / 30 days similar)?
   └─ Yes → PRB (auto-propose per CAPA from audit)
Single SEV-4 with clear fix?
   └─ Incident only; optional KB
```

---

## 17. Lessons Learned

1. Emergency speed without canary is false economy on edge Tier-1.  
2. Suppressed monitors are silent failures — treat as risk acceptance requiring `SEC-EXC-`/`OPS` approval.  
3. ATM symptoms may be downstream of digital/pay host latency — include acquiring in digital SEV-1 bridges.  
4. Cyber dual-track was correct; keep it; do not delay rollback for hunt when config rollback is safe.  
5. Audit findings (`ANB-IAD-RPT-0001`) correctly predicted emergency PIR weakness — accelerate CAPA.

---

## 18. Metrics — Effectiveness Gates

| Gate | Measure | Target |
|---|---|---|
| 30-day | Repeat edge-related SEV-1/2 | 0 |
| 60-day | Tier-1 suppressions > 2h | 0 unapproved |
| 90-day | CAPA-0001 deployed | Complete |
| Leading | Emergency CHG with load evidence | 100% |

---

## 19. Related Documents

`ANB-OPS-INC-0001` · `ANB-OPS-SOP-0002` · `ANB-OPS-POL-0001` · `ANB-OPS-SOP-0001` · `ANB-ITO-SOP-0003` · `ANB-ITO-PLN-0002` · `ANB-ISC-SOP-0003` · `ANB-ISC-STD-0007` · `ANB-IAD-RPT-0001` · `ANB-IAD-CHK-0001` · `ANB-RSK-POL-0001` · `ANB-RTL` ATM/digital ops · `ANB-ADM-MTX-0001`

---

## 20. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | Problem Management | Final RCA approved |

---

## Appendix A — Entity Index

`INC-20260714-0001` · `PRB-20260714-0001` · `CHG-20260714-0003` · `CFG-20260714-0099` · `KEDB-202607-0008` · `KB-OPS-EDGE-001` · `RUN-OPS-SEV1-DIGITAL` · `CAPA-20260714-0001`…`0005` · `ALR-20260714-0112` · `EVT-20260714-2001` · `CMDB-00077210` · `SRV-APEXONLINE` · `SRV-APEXPAY`

---

**End of Document** — `ANB-OPS-RCA-0001` v1.0
