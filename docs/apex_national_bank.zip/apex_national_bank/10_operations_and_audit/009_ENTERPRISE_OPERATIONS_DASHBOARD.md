# Apex National Bank — Enterprise Operations Dashboard

**Management Information Specification | Real-Time & Near-Real-Time Ops, Resilience, Risk & Audit Overlay**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-RPT-0002` |
| **Document Title** | Enterprise Operations Dashboard |
| **Version** | 1.0 |
| **Owner** | IT Operations (ITO) — Service Management & Reliability |
| **Custodian** | Head of Service Management (G8); MI published via ApexInsight |
| **Approver** | Ravi Subramanian, Head of IT Operations — `EMP-500101` |
| **Classification** | Confidential (C2) — executive views; Internal (C1) — team views |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-OPS-SLA`, `BP-OPS-AVAIL`, `BP-OPS-MON`, `BP-OPS-INC`, `BP-OPS-CHG`, `BP-OPS-PRB`, `BP-OPS-CAPA`, `BP-IAD-AUD` |
| **System of Record** | ApexInsight (dashboards) · ApexServe · ApexMonitor · ApexRisk · ApexAudit · ApexShield |
| **Related Documents** | `ANB-OPS-SOP-0001`, `ANB-OPS-RPT-0003`, `ANB-OPS-INC-0001`, `ANB-OPS-POL-0001`, `ANB-RSK-POL-0001`, `ANB-IAD-RPT-0001`, `ANB-ISC-POL-0001`, `ANB-RTL-RPT-FY26-0001` (retail MI affinity) |

---

## 2. Purpose

Define the enterprise operations dashboard — widgets, metrics, RAG thresholds, data sources, refresh cadences, and audience views — used by NOC, Service Owners, CIO/COO briefings, ORC, and Audit Committee technology packs to manage service health, incidents, changes, problems, capacity, cyber ops overlays, and remediation (CAPA/audit actions).

---

## 3. Scope

Tier 0/1 services in `ANB-OPS-SOP-0001` catalogue; enterprise ITSM KPIs; selected business operational metrics with technology dependency (ATM, digital, payments, fraud ops queues, complaints). Not a substitute for Finance GL dashboards or full AML MI.

---

## 4. Responsibilities

| Role | Duty |
|---|---|
| Dashboard Product Owner | Definition accuracy; backlog |
| Data stewards | Source quality (Serve/Monitor/Risk) |
| NOC | 24×7 primary consumers — ops wall |
| Service Owners | Act on amber/red for their `SRV-` |
| ORC / ExCo secretariat | Monthly extract alignment with `ANB-OPS-RPT-0003` |
| IAD | May rely on exports as evidence; independently validate |

---

## 5. Audience Views

| View | Audience | Refresh |
|---|---|---|
| **NOC Wall** | L1/L2/SRE | Real-time (≤ 1 min) |
| **Service Owner** | Each `SRV-` owner | 5 min |
| **Executive** | CIO/COO/CISO | 15 min + daily digest |
| **Risk / ORC** | Operational risk | Daily / weekly |
| **Audit Committee pack** | Quarterly extract | Point-in-time |

---

## 6. RAG Status Model

| RAG | Meaning | Escalation |
|---|---|---|
| **Green** | Within SLO/SLA; no open SEV-1/2 | Routine |
| **Amber** | Error budget burn high; SEV-2; CAPA overdue < 14d | Service Owner + Process Owner |
| **Red** | SEV-1 active; SLO breach; Critical CAPA/audit overdue; CBS tolerance breach | IC / Head of IT Ops / ExCo path |

Overall enterprise tile = worst of CBS digital, payments, core, identity.

---

## 7. Dashboard Panels

### 7.1 Service Health (Availability / SLO)

| Widget | Metric | Source | Target |
|---|---|---|---|
| Availability by `SRV-` | Monthly % / trailing 30d | ApexMonitor, Grafana | Per SLO catalogue |
| SLO burn rate | 1h / 6h / 3d | Prometheus | < 1× sustain |
| Synthetic probe map | Regions | ApexMonitor | 100% probes up |
| Dependency map | CMDB service map | ApexServe CMDB | Stale CI badge |

### 7.2 Incident Management

| Widget | Metric | Target |
|---|---|---|
| Open incidents by SEV | Count | SEV-1 = 0 steady state |
| MTTD / MTTR (7/30/90d) | Minutes/hours | Improve vs baseline |
| MTBF Tier 1 | Days between SEV-1/2 | ↑ |
| Bridge active | Boolean + duration | — |
| Incident trend | Volume by channel | Explain spikes |
| Cyber dual-track open | Count | Align ISC |

Reference incident: `INC-20260714-0001` marked on trend charts.

### 7.3 Problem & Known Error

| Widget | Metric | Target |
|---|---|---|
| Open P1/P2 problems | Count / age | P1 age ≤ 30d unless risk-accepted |
| KEDB articles | Active vs resolved | — |
| Recurrence after CAPA close | Count | 0 for P1 ≤ 90d |

### 7.4 Change Enablement

| Widget | Metric | Target |
|---|---|---|
| Change success rate | % | ≥ 98% Tier 1 |
| Emergency change % | % | ≤ 10% |
| Failed deployments | Count | RCA if SEV impact |
| CAB backlog | Packets | — |
| Freeze calendar | Status | Visible |

### 7.5 Monitoring Hygiene

| Widget | Metric | Target |
|---|---|---|
| Open suppressions Tier 1 | Count / max age | Max 2h unapproved = 0 |
| Page noise (false positive %) | % | ↓ QoQ |
| Coverage gaps | Services w/o gold monitors | 0 |

### 7.6 Ticket Backlog & Capacity

| Widget | Metric | Target |
|---|---|---|
| Backlog > 30 days | % | ≤ 5% SEV-3+ |
| On-call load | Pages / shift | Healthy band |
| Vendor OLA breaches | Count | Escaping |

### 7.7 Customer & Branch Ops Overlay

| Widget | Metric | Source |
|---|---|---|
| Digital complaint spike | Count linked to INC | Apex360 / CST |
| ATM availability | % up / cash-out success | ATM MI / vendor |
| Branch critical apps | ApexTeller status | Monitor |
| Fraud ops queue age | Cases | Fraud ops (overlay) |

### 7.8 Cyber Ops Overlay (Read-Only from ISC)

| Widget | Metric | Source |
|---|---|---|
| SOC SEV open | Count | ApexShield |
| Critical vulns past SLA | Count | ApexScan |
| Privileged recert overdue | Count | ApexID |
| Phishing click rate | % | Awareness MI |

### 7.9 Audit & CAPA / Regulatory

| Widget | Metric | Source |
|---|---|---|
| Open IAD High/Critical actions | Count / overdue | ApexAudit |
| CAPA from SEV-1 RCA | Status | ApexServe |
| Regulatory / MRA tech actions | RAG | ApexRegRep / Compliance |
| Validation pending (`BP-AUD-VAL`) | Count | ApexAudit |

Example: actions from `ANB-IAD-RPT-0001` / `AUD-2026-0142` tiled by due date.

### 7.10 Risk Heatmap

| Axis | Content |
|---|---|
| Likelihood × Impact | Open tech operational risks from ApexRisk |
| Concentration | Vendor / region / platform |
| Control effectiveness | Linked to recent audit OE results |

---

## 8. Workflow — From Signal to Action

```
Tile turns Amber/Red
   → Owner acknowledge in ApexInsight / Serve
   → Create/link INC- or CAPA task
   → Escalate per ANB-OPS-SOP-0001 matrix
   → Update bridge / ORC if enterprise red
   → Resolve → tile returns Green
   → Lessons to Monthly Review
```

---

## 9. Approval Matrix (Dashboard Changes)

| Change | Approver |
|---|---|
| New Tier 1 widget | Head of IT Ops |
| Threshold change (loosening) | Service Owner + Risk for CBS |
| Executive view layout | CIO |
| Audit Committee extract | CAE coordination for audit tiles |

---

## 10. Decision Tree — Enterprise RAG

```
Any CBS SEV-1 active OR impact tolerance breach?
   └─ Red
Else any SEV-2 OR Critical audit action overdue OR Tier-1 suppress > 2h?
   └─ Amber
Else
   └─ Green
```

---

## 11. Sample Executive Snapshot (Illustrative — 14 Jul 2026 12:00 ET)

| Tile | Status | Note |
|---|---|---|
| Enterprise CBS | Red | `INC-20260714-0001` active |
| ApexOnline | Red | Rollback in progress |
| ApexPay | Red | Queue drain |
| ApexID | Green | — |
| ATM NE | Amber | Vendor FLM |
| Emergency CHG % (MTD) | Amber | Spike |
| IAD High overdue | Amber | Pre-existing `AUD-2026-0142` actions not yet due |

---

## 12. Data Quality Rules

- SEV must match ApexServe (no shadow spreadsheets as SoR)  
- Incident-complaint linkage ≥ 90% for channel outages  
- Clock sync NTP across monitors for MTTD integrity  
- C2 executive exports — distribution controlled  

---

## 13. Related Documents

`ANB-OPS-SOP-0001` · `ANB-OPS-RPT-0003` · `ANB-OPS-INC-0001` · `ANB-OPS-RCA-0001` · `ANB-OPS-POL-0001` · `ANB-OPS-SOP-0002` · `ANB-ITO-PLN-0001` · `ANB-ITO-PLN-0002` · `ANB-ISC-SOP-0003` · `ANB-IAD-RPT-0001` · `ANB-RSK-POL-0001` · `ANB-CMP` MI overlays · Retail ATM/digital MI

---

## 14. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | Service Mgmt / SRE | Initial dashboard specification |

---

## Appendix A — Tool Feeds

ApexServe · ApexMonitor · Dynatrace · AppDynamics · Prometheus · Grafana · Splunk · PagerDuty · Microsoft Sentinel · CrowdStrike · ApexScan · ApexID · ApexInsight · ApexRisk · ApexAudit · ATM vendor feeds · Apex360 complaints

---

## Appendix B — Entity Cross-Walk

Dashboard drill-through must open: `INC-` `PRB-` `CHG-` `CAPA-` `AUD-`/`OBS-`/`ACT-` `SRV-` `CMDB-` `ALR-` `MON-`.

---

**End of Document** — `ANB-OPS-RPT-0002` v1.0
