# Apex National Bank — Enterprise Incident Report

**Major Incident Record | SEV-1 Digital Channels & Payments Degradation — 14 July 2026**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-INC-0001` |
| **Document Title** | Enterprise Incident Report — ApexOnline / ApexPay / Regional ATM Impact |
| **Incident ID** | `INC-20260714-0001` |
| **Version** | 1.0 Final (PIR-complete) |
| **Owner** | IT Operations (ITO) — Major Incident Management |
| **Incident Commander** | Ravi Subramanian, Head of IT Operations (G11) — `EMP-500101` |
| **Approver** | CIO Arjun Patel (`EMP-100007`); informed COO Daniel K. Ortega (`EMP-100003`) |
| **Classification** | Confidential (C2) |
| **Incident Start (detect)** | 2026-07-14 09:12 ET |
| **Incident End (resolve)** | 2026-07-14 14:47 ET |
| **Severity** | **SEV-1** |
| **Business Process** | `BP-OPS-INC`, `BP-ITSM-INC`, `BP-OPS-MON`, `BP-OPS-AVAIL`, `BP-PAY-DOM`, `BP-SEC-IR` |
| **System of Record** | ApexServe · ApexMonitor · ApexDocs |
| **Related RCA** | `ANB-OPS-RCA-0001` / `PRB-20260714-0001` |
| **Related Documents** | `ANB-OPS-SOP-0001`, `ANB-OPS-SOP-0002`, `ANB-OPS-POL-0001`, `ANB-ITO-PLN-0002`, `ANB-ITO-TPL-0004`, `ANB-ISC-SOP-0003`, `ANB-RTL-MAN-0004`, `ANB-RSK-POL-0001`, `ANB-LEG-POL-0004`, `ANB-IAD-RPT-0001` |
| **Template Affinity** | Completes structure expected by `ANB-ITO-TPL-0004` |

---

## 2. Purpose

Document the chronology, impact, containment, resolution, communications, and follow-up actions for Major Incident `INC-20260714-0001` to satisfy operational governance, regulatory exam readiness, insurance notice thresholds, and continuous improvement via Problem/RCA processes.

---

## 3. Scope

This report covers technology and customer-operations impacts to:

- `SRV-APEXONLINE` / `SRV-APEXMOBILE` (digital banking)  
- `SRV-APEXPAY` (payments hub — domestic ACH/RTP latency)  
- Regional ATM cash-out failures (Northeast metro set; vendor FLM engaged)  
- Monitoring & on-call (`MON-`, `ALR-`, PagerDuty)  
- Cyber defence coordination (rule-out of active intrusion)

---

## 4. Severity Matrix (Enterprise Operations)

| Severity | Definition | Ack SLA | Exec Notify | Examples |
|---|---|---|---|---|
| **SEV-1** | Critical CBS impaired; material customer/market impact | 15 min | CIO/COO ≤ 30–60 min | Core/payments/digital widespread; this incident |
| **SEV-2** | Significant degradation; limited CBS or major channel | 30 min | CIO ≤ 2h | Multi-region ATM network; CMB portal outage |
| **SEV-3** | Moderate; workaround exists | 1h | Service Owner | Branch printer farm; single app module |
| **SEV-4** | Minor localized | Next BD | As needed | Single ATM; non-critical batch delay |
| **SEV-5** | Cosmetic / request misclass | Queue | N/A | UI glitch no txn impact |

Cyber-confirmed incidents also follow `ANB-ISC-SOP-0003` severity; **higher severity wins**.

---

## 5. Responsibilities (Bridge)

| Role | Person / Team | Duty |
|---|---|---|
| Incident Commander | `EMP-500101` | Decide; prioritize; declare SEV |
| Technical Lead — Digital | Digital Platform On-Call | Mitigate ApexOnline/Mobile |
| Technical Lead — Payments | Payment Ops On-Call | ApexPay latency / queue drain |
| Monitoring | NOC / SRE | ApexMonitor, Dynatrace, Grafana |
| Cyber Liaison | Kevin Zhao `EMP-500204` / SOC | Rule-out; hunt |
| Comms | Marketing/CST Comms | Customer messaging approval |
| Business | Retail Digital + Payment Ops | Customer impact quantification |
| Vendor Mgmt | ATM Vendor (MSA) | FLM / host link |

---

## 6. Incident Summary

Between 09:12 and 14:47 ET on 14 July 2026, customers experienced elevated login failures and transaction timeouts on ApexOnline/ApexMobile, domestic payment submission latency on ApexPay, and a correlated spike in ATM “unable to process” declines across 214 ATMs in the Northeast. Root technical trigger later confirmed in RCA: faulty routing configuration deployed via emergency change `CHG-20260714-0003` interacting with an overloaded F5 pool and suppressed latency alerts.

**Cyber posture:** SOC investigated concurrent anomalous authentication spikes; concluded **no confirmed intrusion** — spikes were client retry storms. Case remained dual-tracked until 11:40 ET clear from ApexShield.

---

## 7. Timeline

| Time (ET) | Event | ID / Tool |
|---|---|---|
| 08:55 | Emergency change `CHG-20260714-0003` deployed (F5 / edge routing) | ApexServe / F5 |
| 09:12 | `ALR-20260714-0112` Dynatrace / AppDynamics Apdex drop ApexOnline | ApexMonitor |
| 09:14 | PagerDuty page SEV-2 (initial) to Digital On-Call | PagerDuty |
| 09:18 | Splunk/Prometheus show 5xx surge; Grafana dashboard red | Splunk, Grafana |
| 09:22 | Payment latency `MON-PAY-LAT-01` — note: related alert was **suppressed** since 03:10 | Prometheus |
| 09:25 | Incident opened `INC-20260714-0001`; bridge started | ApexServe |
| 09:33 | ATM switch decline spike reported by vendor | Vendor portal |
| 09:40 | Severity raised **SEV-1**; CIO/COO notified | Bridge |
| 09:45 | SOC joined — auth anomaly hunt `ALERT-20260714-0088` | ApexShield / Sentinel |
| 10:05 | Customer banner approved; CST surge staffing | ApexAssist / Voice |
| 10:40 | Rollback decision for `CHG-20260714-0003` | IC |
| 11:05 | Rollback complete; digital error rates declining | F5 / ApexBuild |
| 11:40 | SOC: intrusion **ruled out**; cyber track downgraded | `ANB-ISC-SOP-0003` |
| 12:15 | ApexPay queues draining; RTP backlogs clearing | ApexPay |
| 13:30 | ATM declines normalized except 11 machines (FLM) | Vendor |
| 14:47 | Service restoration declared; SEV-1 closed to monitoring | IC |
| 15:30 | Problem `PRB-20260714-0001` opened | ApexServe |
| +10 BD | RCA finalized `ANB-OPS-RCA-0001` | OPS |

---

## 8. Impact Assessment

| Dimension | Impact |
|---|---|
| Customers affected (est.) | ~1.8M digital session errors; ~420k distinct CIFs touched |
| Payments | ACH submissions delayed avg 37 min; RTP p95 latency 4.2× SLO |
| ATM | 214 ATMs elevated declines; ~9.2k failed cash-out attempts |
| Financial | Fee waivers / goodwill accrual tracked by Finance (non-material vs capital) |
| Regulatory | No personal-data breach; operational incident logged; Legal/Compliance informed |
| CBS | Digital servicing & domestic payments within impact tolerance — **breached for 5h 35m** |
| Reputation | Social spike; Comms holding statement issued |

Data classification of bridge notes: C2. No C3 data exfil indicators.

---

## 9. Detection & Monitoring Topology

```
Clients → F5 / Palo Alto → ApexOnline/Mobile / ApexPay
                ↓
     Dynatrace / AppDynamics (APM)
     Prometheus → Grafana (SLO burn)
     Splunk + Microsoft Sentinel (ApexSIEM/ApexShield)
                ↓
          ApexMonitor correlation
                ↓
     PagerDuty → On-Call → ApexServe INC-
```

**Failure mode:** Payment latency monitor suppressed (`ALR` suppression ticket aged); MTTD for payments path lagged digital path by ~10 minutes after first customer complaints.

---

## 10. Containment, Eradication, Recovery

| Action | Detail |
|---|---|
| Containment | Rollback `CHG-20260714-0003`; shed non-critical edge rules; rate-limit abusive retries |
| Eradication | Remove bad config object `CFG-20260714-0099`; restore known-good from CMDB baseline |
| Recovery | Warm pool scale-out; queue drain; ATM host re-sync; FLM for residual ATMs |
| DR | Evaluated per `ANB-ITO-PLN-0002`; **DR not invoked** (regionally recoverable; RTO still achievable via rollback) |

---

## 11. Communications

| Audience | Action |
|---|---|
| Exec | Bridge updates q30min while SEV-1 |
| Customers | Banner + push for Mobile; status page |
| Branches | ApexServe broadcast — expect digital overflow to teller |
| Regulators | Proactive courtesy notice via Compliance/Legal desk (non-breach); formal path `ANB-LEG-SOP-0007` if requested |
| Audit | Incident pack available for `AUD-2026-0142` |

---

## 12. Cyber Coordination

```
Ops SEV-1 declared
   → SOC auto-page on auth anomaly
   → Parallel hunt (Crowdstrike / Sentinel)
   → 11:40 clear — no INC cyber elevation
   → Ops retains ownership; SOC monitors 72h heightened
```

Reference: `ANB-ISC-SOP-0003` dual-track protocol.

---

## 13. Metrics (This Incident)

| Metric | Value |
|---|---|
| MTTD (digital) | 3 min from first ALR |
| MTTD (payments path) | ~13 min (suppression gap) |
| MTTR (restore declare) | 5h 35m |
| Bridge staffing peak | 28 |
| Related CHG failure | 1 (`CHG-20260714-0003`) |
| Follow-on PRB | `PRB-20260714-0001` |
| CAPA | See RCA / `CAPA-20260714-0001` et al. |

---

## 14. Workflow — Major Incident

```
Detect (MON/ALR/PagerDuty/User)
   → Triage & SEV
   → Bridge + IC
   → Contain / Communicate
   → Resolve / Monitor
   → PIR
   → Problem + RCA (SEV-1/2)
   → CAPA via CHG
   → Close when CAPA accepted
```

---

## 15. Approval Matrix

| Decision | Authority |
|---|---|
| SEV-1 declare / close | Incident Commander / Head of IT Ops |
| Customer public statement | Comms + Retail leadership + Legal |
| DR invoke | CIO / COO per `ANB-ITO-PLN-0002` |
| Regulatory notice | Legal + Compliance |
| Final report approval | CIO |

---

## 16. Decision Tree — SEV Upgrade

```
CBS impacted OR >100k customers OR payments rails impaired?
   ├─ Yes → SEV-1
   └─ No → Multi-region channel OR material ATM fleet?
              ├─ Yes → SEV-2
              └─ No → Apply SEV-3–5 matrix
Cyber confirmed?
   └─ Apply max(Ops SEV, Cyber SEV)
```

---

## 17. Actions Arising

| ID | Action | Owner | Due |
|---|---|---|---|
| `ACT-OPS-20260714-01` | Complete RCA `ANB-OPS-RCA-0001` | Problem Manager | 2026-07-28 |
| `ACT-OPS-20260714-02` | Ban indefinite Tier-1 alert suppression | Monitoring Lead | 2026-08-15 |
| `ACT-OPS-20260714-03` | Emergency change checklist reinforcement | Change Manager | 2026-08-15 |
| `ACT-OPS-20260714-04` | ATM vendor joint PIR | Vendor Mgmt | 2026-08-30 |
| `CAPA-20260714-0001` | Edge config validation gate in pipeline | Platform Eng | 2026-09-30 |

---

## 18. Related Documents

`ANB-OPS-RCA-0001` · `ANB-OPS-SOP-0001` · `ANB-OPS-SOP-0002` · `ANB-OPS-POL-0001` · `ANB-OPS-RPT-0002` · `ANB-ITO-PLN-0002` · `ANB-ITO-TPL-0004` · `ANB-ISC-SOP-0003` · `ANB-ISC-POL-0001` · `ANB-RTL-MAN-0004` · `ANB-RSK-POL-0001` · `ANB-LEG-SOP-0007` · `ANB-IAD-RPT-0001` · `ANB-ADM-MTX-0001`

---

## 19. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | Major Incident Mgmt | Final after RCA alignment |

---

## Appendix A — Configuration & CMDB References

| ID | Description |
|---|---|
| `CMDB-00077210` | F5 edge cluster NE |
| `CFG-20260714-0099` | Bad iRule / pool member weights |
| `SRV-APEXONLINE` | Digital web |
| `SRV-APEXPAY` | Payments hub |
| `HOST-` pool | App tier hosts scaled during recovery |
| `EVT-20260714-2001` | Correlate retry storm |

---

## Appendix B — Service Catalogue Touchpoints

See `ANB-OPS-SOP-0001` service catalogue: Digital Banking, Domestic Payments, ATM Acquiring — all amber→red→green during event.

---

**End of Document** — `ANB-OPS-INC-0001` v1.0 | `INC-20260714-0001`
