# Apex National Bank — Monthly Operations Review

**Executive Operating Rhythm | July 2026 Operations Review Pack (Template + Completed Example)**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-RPT-0003` |
| **Document Title** | Monthly Operations Review |
| **Version** | 1.0 |
| **Review Period** | 2026-07-01 → 2026-07-31 |
| **Owner** | IT Operations (ITO) with COO Office input for enterprise ops |
| **Custodian** | Head of Service Management (G8) |
| **Chair** | Ravi Subramanian, Head of IT Operations — `EMP-500101` (tech); COO Daniel K. Ortega (`EMP-100003`) for enterprise ORC escalation items |
| **Approver** | CIO Arjun Patel (`EMP-100007`) for technology pack; ORC notes as applicable |
| **Classification** | Confidential (C2) |
| **Meeting Date** | 2026-08-05 |
| **Business Process** | `BP-OPS-SLA`, `BP-OPS-AVAIL`, `BP-OPS-INC`, `BP-OPS-CHG`, `BP-OPS-PRB`, `BP-OPS-CAPA`, `BP-OPS-CAB`, `BP-IAD-AUD` |
| **System of Record** | ApexDocs (this pack) · ApexInsight (metrics) · ApexServe · ApexRisk · ApexAudit |
| **Dashboard Spec** | `ANB-OPS-RPT-0002` |
| **Related Documents** | `ANB-OPS-SOP-0001`, `ANB-OPS-INC-0001`, `ANB-OPS-RCA-0001`, `ANB-OPS-POL-0001`, `ANB-OPS-SOP-0002`, `ANB-IAD-RPT-0001`, `ANB-ISC-SOP-0003`, `ANB-ITO-PLN-0002`, `ANB-RSK-POL-0001`, `ANB-RTL` / CST MI, `ANB-FIN-SOP-0003` freeze calendar |

---

## 2. Purpose

Provide a monthly structured review of operational performance, resilience, customer-impacting technology events, change & problem health, cyber-ops coordination, audit/regulatory remediation, and forward risk — driving decisions, funding, and accountability across First Line technology and business service owners.

---

## 3. Scope

Enterprise technology operations and selected business operational metrics with material technology dependency for the review month. Financial P&L deep-dives remain with Finance forums; AML case quality with Compliance forums — this pack carries **operational** overlays only.

---

## 4. Responsibilities

| Role | Responsibility |
|---|---|
| Service Management | Assemble pack from `ANB-OPS-RPT-0002` |
| Service Owners | Explain RAG; commit actions |
| Major Incident / Problem Mgmt | SEV-1/2 & RCA status |
| Change Manager | Change KPIs & freeze adherence |
| CISO delegate | Cyber ops overlay |
| IAD (observer) | May attend; no management veto of facts |
| Risk | Operational risk appetite alignment |
| Business (Retail/Payments/CMB) | Customer impact confirmation |

---

## 5. Agenda (Standard)

1. Enterprise RAG & CBS scorecard  
2. Incidents (SEV-1/2 deep dive)  
3. Problems / CAPA / KEDB  
4. Change & release performance  
5. Availability / SLO / capacity  
6. Monitoring hygiene & on-call health  
7. Customer / branch / ATM / complaints overlay  
8. Fraud & AML operational tech overlay  
9. Cyber coordination summary  
10. DR/BCP tests & invoke readiness  
11. Internal audit & regulatory actions  
12. Risk heatmap & decisions  
13. AOB / funding asks  

---

## 6. Enterprise Scorecard — July 2026

| Domain | RAG | Summary |
|---|---|---|
| Overall Technology Ops | **Amber** | One SEV-1 (`INC-20260714-0001`); CAPA in flight; otherwise stabilising |
| Digital (Online/Mobile) | Amber | SEV-1 impact 14 Jul; SLO month miss |
| Payments (ApexPay) | Amber | Same incident; latency SLO miss |
| Core (ApexCore) | Green | No SEV-1/2 |
| Identity (ApexID) | Green | Recert backlog improving post-audit focus |
| ATM Acquiring | Amber | NE spike mid-month; residual FLM |
| Change Enablement | Amber | Emergency % elevated MTD |
| Problem Mgmt | Amber | Auto-propose rule not yet live |
| Cyber Ops Overlay | Green | Dual-track clear on SEV-1; no material breach |
| Audit Remediation | Amber | `AUD-2026-0142` actions open on track |

---

## 7. Incident Performance

### 7.1 Volume & Severity

| SEV | Jul Count | Jun Count | Trend |
|---|---|---|---|
| 1 | 1 | 0 | ↑ |
| 2 | 3 | 2 | ↑ |
| 3 | 142 | 128 | ↑ |
| 4–5 | 860 | 910 | ↓ |

### 7.2 Reliability Metrics

| Metric | Jul | Target | Status |
|---|---|---|---|
| MTTD (SEV-1/2 gold signals) | 3–13 min* | ≤ 5 min gold | Amber* |
| MTTR SEV-1 | 5h 35m (`INC-20260714-0001`) | Per CBS | Red event |
| MTTR SEV-2 (avg) | 3.1h | ≤ 4h | Green |
| MTBF (Tier-1 SEV-1) | 45 days prior → reset | ↑ | Amber |

\*Payments path MTTD degraded due to alert suppression — see RCA.

### 7.3 SEV-1 Narrative

Full record: `ANB-OPS-INC-0001`. RCA: `ANB-OPS-RCA-0001`. Root: emergency edge change + monitoring gap. Customer impact digital/payments/ATM symptom. Cyber ruled out. DR not invoked.

**Decisions requested:** Approve continued edge canary mandate funding; note Comms goodwill accruals with Finance.

---

## 8. Problem & CAPA Tracking

| PRB / CAPA | Title | Owner | Due | RAG |
|---|---|---|---|---|
| `PRB-20260714-0001` | Edge routing SEV-1 | Problem Mgr | Closure gated on CAPA | Amber |
| `CAPA-20260714-0001` | F5 pool lint in CI | Platform Eng | 2026-09-30 | Green |
| `CAPA-20260714-0002` | Suppression policy | Monitoring | 2026-08-15 | Green |
| `CAPA-20260714-0003` | Emergency edge dual-approve | Change Mgr | 2026-08-31 | Green |
| `KEDB-202607-0008` | Published workaround | Service Mgmt | Active | Green |
| `PRB-20260720-0004` | Mobile timeout cluster (audit-driven) | Digital Ops | 2026-10-15 | Amber |

---

## 9. Change Management KPIs

| KPI | Jul | Target | RAG |
|---|---|---|---|
| Tier 1 change success rate | 97.2% | ≥ 98% | Amber |
| Emergency change % | 14% | ≤ 10% | Red |
| Emergency PIR on-time | 80% → remediation | 100% | Red |
| Failed CHG causing SEV ≥ 2 | 1 | 0 | Red |
| Freeze breaches (unapproved) | 0 | 0 | Green |

Policy reference: `ANB-OPS-POL-0001` / procedure `ANB-ITO-SOP-0003`. CAB actions: emergency retrospective weekly until PIR ≥ 98% for 2 months.

---

## 10. Availability & SLO Report

| Service | SLO | July Result | Error Budget | RAG |
|---|---|---|---|---|
| `SRV-APEXONLINE` | 99.90% | 99.72% | Exhausted | Red |
| `SRV-APEXMOBILE` | 99.90% | 99.74% | Exhausted | Red |
| `SRV-APEXPAY` | 99.95% | 99.81% | Exhausted | Red |
| `SRV-APEXCORE` | 99.95% | 99.98% | Healthy | Green |
| `SRV-APEXID` | 99.99% | 99.995% | Healthy | Green |
| ATM cash-out success (NE) | 99.5% | 98.9% | — | Amber |

**Reliability backlog prioritisation:** edge validation, alert hygiene, mobile timeout PRB — freeze discretionary feature deploys on digital edge until error budget recovers (CIO endorsed).

---

## 11. Monitoring, On-Call & Backlog

| Metric | Value | Target | RAG |
|---|---|---|---|
| Tier-1 suppressions > 2h unapproved | 1 (pre-CAPA event) | 0 | Amber |
| False positive page rate | 22% | ≤ 15% | Amber |
| Ticket backlog > 30d (SEV-3+) | 4.8% | ≤ 5% | Green |
| PagerDuty pages / on-call-week (digital) | 41 | Band 20–35 | Amber |

---

## 12. Customer, Branch, Complaint Overlay

| Metric | Jul | Commentary |
|---|---|---|
| Digital complaints (tech-attributed) | +180% WoW in incident week | Linkage to `INC-` improved mid-month |
| Branch ApexTeller critical P1 | 2 | Non-related; resolved |
| CST AHT spike | +12% on 14–15 Jul | Surge staffing worked |
| Goodwill / fee waiver accrual | Tracked by Finance | Non-capital material |

Retail references: channel SOPs / CST procedures; complaint MI alignment with `ANB-IAD-RPT-0001` OBS-07.

---

## 13. Fraud & AML Operational Tech Overlay

| Item | Status |
|---|---|
| ApexGuard pipeline availability | Green — no SEV-1 |
| TM rule emergency changes | 2 — dual control evidenced |
| Fraud case tool latency | Amber 2 days (vendor) — OLA escalated |
| Cyber-enabled fraud with ops impact | None material |

Compliance ownership of typology effectiveness unchanged (`ANB-CMP-POL-0001`).

---

## 14. Cyber Incident Coordination Summary

| Item | Status |
|---|---|
| Dual-track with Ops SEV-1 | Executed correctly 14 Jul |
| Ransomware tabletop `SCN-2026-CYB-001` | Scheduled follow-up |
| Critical vulns past SLA | 3 → owned under `BP-SEC-VULN` |
| Privileged recert overdue | Declining after Identity focus |

Reference: `ANB-ISC-SOP-0003`, `ANB-ISC-POL-0001`.

---

## 15. DR / BCP Readiness

| Item | Status |
|---|---|
| DR invoke in July | None (correct non-invoke on 14 Jul) |
| Upcoming DR test | ApexPay failover — scheduled Aug |
| BCP impact tolerances | No permanent change; digital breach logged in ApexRisk |
| Backup restore tests | On plan |

References: `ANB-ITO-PLN-0001`, `ANB-ITO-PLN-0002`.

---

## 16. Internal Audit & Regulatory Findings

| Source | Item | Owner | Due | RAG |
|---|---|---|---|---|
| `ANB-IAD-RPT-0001` / `OBS-2026-0142-01` | Emergency PIR | `EMP-500101` | 2026-09-30 | Green |
| OBS-02 | Deploy SoD | Platform + AppSec | 2026-09-15 | Green |
| OBS-03 | Privileged recert | `EMP-500202` | 2026-09-30 | Green |
| OBS-04 | Problem auto-propose | OPS | 2026-10-15 | Amber |
| OBS-05 | Alert tuning | Monitoring / `EMP-500201` | 2026-09-15 | Green |
| Regulatory tech actions | None new critical in July | — | — | Green |

Validation via `BP-AUD-VAL` when management asserts closure. Charter: `ANB-IAD-CHT-0001`.

---

## 17. Operational Risk Heatmap (Tech Focus)

```
Impact →
↑ Critical │         │ SEV-1 edge change theme
           │         │ (residual until CAPA-0001)
  High     │ ATM NE  │ Emergency CHG %
           │ vendor  │
  Med      │ Page    │ Mobile timeout PRB
           │ noise   │
  Low      │         │
           └─────────┴────────────→ Likelihood
             Low      Med     High
```

Risk entries updated in ApexRisk; appetite per `ANB-RSK-STMT-0001` / `ANB-RSK-POL-0001`.

---

## 18. Decisions & Actions from This Review

| ID | Decision / Action | Owner | Due |
|---|---|---|---|
| `ACT-MOR-202608-01` | Maintain digital edge feature freeze until SLO budget > 50% | Digital Service Owner | Review 2026-08-19 |
| `ACT-MOR-202608-02` | Weekly emergency CHG retrospective until PIR 100% × 8 weeks | Change Manager | Standing |
| `ACT-MOR-202608-03` | Fund load-test harness (CAPA-0005) — proceed | SRE / Finance tech budget | 2026-08-12 |
| `ACT-MOR-202608-04` | Confirm ATM vendor credit for FLM misses | Vendor Mgmt / PRC | 2026-08-20 |
| `ACT-MOR-202608-05` | ORC note on CBS tolerance breach 14 Jul | Risk Ops | 2026-08-08 |

---

## 19. Workflow — Monthly Cycle

```
Day −5: Freeze metrics extract from ApexInsight / Serve
Day −2: Service Owners commentary due
Day 0: Monthly Operations Review meeting
Day +2: Publish ANB-OPS-RPT-0003 + action register
Day +10: ORC / ExCo summary if Red enterprise themes
Continuous: Dashboard ANB-OPS-RPT-0002
```

---

## 20. Approval Matrix

| Item | Approver |
|---|---|
| Technology pack accuracy | Head of IT Ops |
| CBS freeze / reliability override | CIO |
| Customer remediation spend | Business + Finance matrices |
| Risk acceptance residual | `BP-RSK-ACC` path |
| Pack distribution beyond ExCo | COO Office |

---

## 21. Decision Tree — Escalate to ORC / ExCo

```
CBS impact tolerance breached OR SEV-1 with regulatory dimension
OR Critical audit action overdue OR systemic emergency CHG failure?
   ├─ Yes → ORC / ExCo briefing within 5 BD
   └─ No → Retain in Monthly Ops Review; amber watch
```

---

## 22. Forward Look — August

- Implement suppression policy CAPA  
- ApexPay DR test  
- Emergency PIR quality blitz  
- Mobile timeout PRB hypothesis testing  
- Audit mid-point check-ins on `AUD-2026-0142` actions  
- Financial close freeze coordination (`ANB-FIN-SOP-0003`)  

---

## 23. Related Documents

`ANB-OPS-RPT-0002` · `ANB-OPS-SOP-0001` · `ANB-OPS-SOP-0002` · `ANB-OPS-POL-0001` · `ANB-OPS-INC-0001` · `ANB-OPS-RCA-0001` · `ANB-ITO-SOP-0003` · `ANB-ITO-PLN-0001` · `ANB-ITO-PLN-0002` · `ANB-ISC-SOP-0003` · `ANB-ISC-POL-0001` · `ANB-IAD-CHT-0001` · `ANB-IAD-RPT-0001` · `ANB-IAD-CHK-0001` · `ANB-RSK-POL-0001` · `ANB-CMP-POL-0001` · `ANB-FIN-SOP-0003` · `ANB-ADM-MTX-0001` · Retail/CST/ATM MI

---

## 24. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-08-05 | Service Management | July 2026 Monthly Operations Review pack |

---

## Appendix A — Attendance (Example)

Head of IT Ops · CIO · Digital Service Owner · Payments Tech · SRE/Monitoring · Change Manager · Problem Manager · CISO delegate (`EMP-500201`/`EMP-500204`) · Identity · Retail Ops delegate · Risk Ops · Finance Tech (close freeze) · IAD observer

---

## Appendix B — Metric Glossary

MTTD · MTTR · MTBF · SLO · SLA · OLA · RAG · CBS · CAPA · KEDB · SEV · CAB · PIR · OE (audit)

---

## Appendix C — Canonical IDs Referenced This Month

`INC-20260714-0001` · `PRB-20260714-0001` · `PRB-20260720-0004` · `CHG-20260714-0003` · `KEDB-202607-0008` · `CAPA-20260714-0001`…`0005` · `AUD-2026-0142` · `OBS-2026-0142-*` · `ACT-2026-0142-*` · `ACT-MOR-202608-*` · `SRV-APEXONLINE` · `SRV-APEXPAY` · `SRV-APEXCORE` · `SRV-APEXID`

---

**End of Document** — `ANB-OPS-RPT-0003` v1.0 | July 2026 Review
