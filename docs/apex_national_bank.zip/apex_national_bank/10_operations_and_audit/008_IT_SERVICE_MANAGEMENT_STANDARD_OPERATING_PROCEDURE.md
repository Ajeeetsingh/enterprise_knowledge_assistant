# Apex National Bank — IT Service Management Standard Operating Procedure

**Standard Operating Procedure | ITIL v4 Service Operations — Catalogue, Incidents, Requests, Monitoring, Availability, Support Tiers**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-SOP-0001` |
| **Document Title** | IT Service Management Standard Operating Procedure |
| **Version** | 1.0 |
| **Owner** | IT Operations (ITO) — Service Management |
| **Custodian** | Head of Service Management (G8) |
| **Approver** | Ravi Subramanian, Head of IT Operations — `EMP-500101` |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-OPS-INC`, `BP-OPS-MON`, `BP-OPS-SLA`, `BP-OPS-AVAIL`, `BP-OPS-CHG`, `BP-OPS-PRB`, `BP-ITSM-INC`, `BP-ITSM-CMDB` |
| **System of Record** | ApexServe (ServiceNow) · ApexMonitor · CMDB · PagerDuty · ApexDocs |
| **Related Documents** | `ANB-OPS-POL-0001`, `ANB-OPS-SOP-0002`, `ANB-OPS-INC-0001`, `ANB-OPS-RCA-0001`, `ANB-OPS-RPT-0002`, `ANB-OPS-RPT-0003`, `ANB-ITO-SOP-0003`, `ANB-ITO-PLN-0001`, `ANB-ITO-PLN-0002`, `ANB-ITO-TPL-0004`, `ANB-ISC-SOP-0003`, `ANB-ISC-POL-0001`, `ANB-IAD-CHK-0001` |

---

## 2. Purpose

Provide the operating model for IT service management across Apex National Bank — defining the service catalogue, ownership, support tiers, escalation, monitoring, availability/SLO management, incident & request handling, runbooks, and CMDB obligations — consistent with ITIL v4 and Bank risk appetite.

---

## 3. Scope

ITO-delivered and ITO-brokered services supporting Retail, Corporate Banking, Treasury, Finance, HR, Compliance, Risk, Legal, ISC, and enterprise platforms. Business process operations (e.g., teller cash) remain with business SOPs but raise technology incidents here when systems fail.

---

## 4. Responsibilities

| Role | Accountability |
|---|---|
| Service Owner | Outcomes, SLO, improvement for `SRV-` |
| Process Owner — Incident/Problem/Change | Process health & KPIs |
| Support Tier 1/2/3 | Restore & escalate per matrix |
| NOC / SRE | Monitoring, major incident technical lead |
| CMDB Steward | CI accuracy |
| Vendor Manager | Supplier OLAs |
| CIO / Head of IT Ops | Overall ITSM governance |

---

## 5. Service Catalogue (Extract — Tier 1 / Material)

| Service ID | Service | Owner | Tier | Criticality | Major Dependencies |
|---|---|---|---|---|---|
| `SRV-APEXCORE` | Core banking ledger & servicing | Head of Core Platforms | 0/1 | CBS | DB, ApexPay, ApexID |
| `SRV-APEXPAY` | Domestic & wires hub | Head of Payment Ops (tech) | 1 | CBS | Fed/NACHA links, F5 |
| `SRV-APEXONLINE` | Online banking | Digital Platform | 1 | CBS | ApexCore, CDN, F5 |
| `SRV-APEXMOBILE` | Mobile banking | Digital Platform | 1 | CBS | Same |
| `SRV-ATM-ACQ` | ATM acquiring / switch | Channels + Vendor | 1 | CBS | Vendor host, ApexCore |
| `SRV-APEXORIGIN` | Loan origination | Lending Tech | 1 | High | ApexKYC, ApexCredit |
| `SRV-APEX360` | CRM / CST | CST Tech | 2 | High | ApexCore |
| `SRV-APEXGUARD` | AML TM | Compliance Tech | 1 | Regulatory | Data feeds |
| `SRV-APEXID` | Identity / IGA / PAM | Identity `EMP-500202` | 0 | Tier 0 | Entra, AD, CyberArk |
| `SRV-APEXSHIELD` | SOC / SIEM | Cyber Defence | 0/1 | Cyber | Sentinel, CrowdStrike |
| `SRV-APEXLEDGER` | GL / Finance | Finance Tech | 1 | SOX | Close calendar |
| `SRV-APEXPEOPLE` | HRMS | HR Tech | 2 | High | ApexID JML |
| `SRV-APEXSERVE` | ITSM platform | Service Mgmt | 1 | Foundational | — |
| `SRV-APEXMONITOR` | Observability | SRE | 1 | Foundational | Dynatrace, Grafana, etc. |
| `SRV-APEXCLOUD` | Cloud control plane | Cloud Eng | 1 | High | AWS/Azure |

Full catalogue maintained in ApexServe Service Portfolio module; this SOP extract is normative for Tier 0/1 naming.

---

## 6. Support Tiers

| Tier | Scope | Tools | Handle |
|---|---|---|---|
| **L1** | Service Desk / CST tech assist | ApexServe, ApexAssist | Password/reset routing, triage, known KB |
| **L2** | Application / platform ops | Dynatrace, Splunk, runbooks | Diagnose, apply workaround |
| **L3** | Engineering / vendors / architects | GitHub, deep logs | Code/config fix via CHG |
| **Major Incident** | Bridge command | PagerDuty, Zoom/Teams bridge | SEV-1/2 per `BP-OPS-INC` |

Privileged actions: CyberArk only (`ANB-ISC-STD-0002`).

---

## 7. Escalation Matrix

| Condition | Escalate to | Time |
|---|---|---|
| L1 cannot restore via KB | L2 queue | 15–30 min SEV-3+ |
| L2 blocked | L3 / vendor | 30–60 min |
| SEV-2 | Incident Manager + Service Owner | Immediate on declare |
| SEV-1 | Head of IT Ops IC; CIO; COO notify | Per `ANB-OPS-INC-0001` matrix |
| Suspected cyber | SOC / CISO path | Immediate dual-track |
| Customer harm / media | Comms + Business | Immediate |
| Personal data breach suspicion | Privacy + Legal + ISC | Immediate (`ANB-LEG-POL-0004/0005`) |

---

## 8. Incident Management Operating Procedure

### 8.1 Detection Sources

PagerDuty · ApexMonitor · Dynatrace · AppDynamics · Prometheus/Grafana · Splunk · Microsoft Sentinel / ApexShield · F5/Palo Alto · User/CST reports · Branch · Vendor · Synthetic probes `MON-`.

### 8.2 Lifecycle

```
Detect → Log INC-######## → Classify SEV
   → Diagnose (RUN-/KB-/KEDB-)
   → Escalate / Bridge if SEV-1/2
   → Contain & Restore
   → Communicate
   → Resolve & Confirm
   → PIR / link PRB if required
   → Close
```

Severity matrix: see `ANB-OPS-INC-0001` §4 (SEV-1–5). Cyber: `ANB-ISC-SOP-0003`.

### 8.3 SLA / OLA (Acknowledge & Restore Targets)

| SEV | Ack | Restore target (aim) | Communications |
|---|---|---|---|
| 1 | 15 min | Impact tolerance / best effort bridge | Exec + customer as needed |
| 2 | 30 min | ≤ 4h aim | Service Owner + CIO path |
| 3 | 1h | ≤ 8h–1 BD | Users |
| 4 | 4h | ≤ 2 BD | Ticket |
| 5 | Next BD | Backlog | — |

SLO for services (availability) distinct from incident restore — §10.

---

## 9. Request Fulfilment

Service requests (access, laptop, standard change) via ApexServe catalogue. Access requests enforce `ANB-ISC-POL-0003` / ApexID. Not to be used to bypass CAB for non-standard production changes.

---

## 10. Availability & SLO Management (`BP-OPS-AVAIL`)

| Service | Availability SLO (monthly) | Latency SLO (example) |
|---|---|---|
| ApexOnline / Mobile | 99.90% | Login p95 ≤ 3s |
| ApexPay domestic submit | 99.95% | p95 within rail budget |
| ApexCore servicing APIs | 99.95% | Per CBS catalogue |
| ApexID auth | 99.99% | Token issue p95 ≤ 1s |

**Error budget** consumed → change freeze pressure + reliability backlog prioritisation.

MTBF tracked for Tier 1; MTTR/MTTD reported in `ANB-OPS-RPT-0002`.

---

## 11. Monitoring Standard (`BP-OPS-MON`)

| Layer | Tooling |
|---|---|
| APM | Dynatrace, AppDynamics |
| Metrics | Prometheus → Grafana; cloud native |
| Logs | Splunk; Sentinel for security |
| Synthetic | ApexMonitor probes |
| Edge | F5 / Palo Alto telemetry |
| Alerting | PagerDuty (ops); ApexShield (cyber) |
| Correlation | ApexMonitor / SIEM |

**Rules:** Tier 1 alerts must be actionable; suppressions time-bounded (max 2h without Head of Service Mgmt / IC approval) after `CAPA-20260714-0002`. Each alert maps to `RUN-` or triage note. Entities: `MON-########`, `ALR-########`, `EVT-########`.

---

## 12. CMDB & Configuration

| Requirement | Standard |
|---|---|
| CI unique ID | `CMDB-########` / `CFG-########` |
| Service map | Tier 1 relationships ≥ 98% accuracy |
| Discovery | Weekly reconciliation critical network/app |
| Change linkage | CHG must reference CIs |
| Audit | Tested under `ANB-IAD-CHK-0001` Module D |

---

## 13. Runbooks & Knowledge

| Type | ID pattern | Use |
|---|---|---|
| Runbook | `RUN-OPS-*` / `RUN-SEC-*` | Step procedures during INC |
| Knowledge | `KB-OPS-*` | Workarounds, FAQs |
| Known Error | `KEDB-*` | Problem outputs |

Mandatory SEV-1 runbooks: Digital, Payments, ApexID, ApexCore, ATM acquiring, Ransomware coordination pointer to ISC.

---

## 14. Major Incident & DR Interface

```
SEV-1 bridge
   → Assess impact tolerances (ANB-ITO-PLN-0001)
   → DR invoke decision (ANB-ITO-PLN-0002)
   → If cyber → ANB-ISC-SOP-0003
   → PIR → PRB (ANB-OPS-SOP-0002)
```

Example: `INC-20260714-0001` — DR not invoked; rollback preferred (`ANB-OPS-INC-0001`).

---

## 15. Production Support Model

| Shift | Coverage |
|---|---|
| Follow-the-sun L1 | 24×7 |
| L2 digital/payments | 24×7 on-call |
| L3 engineering | Follow-the-sun + pager for Tier 0/1 |
| CAB | Business hours + emergency ECAB |
| SOC | 24×7 ApexSOC |

Handover checklist in ApexServe at each shift.

---

## 16. Workflow — End-to-End Service Operation

```
Monitor (MON/ALR)
   → Incident / Event
   → Restore (RUN/KB)
   → Problem if recurrent/major
   → Change for fix/improve
   → Release via ApexBuild
   → Update CMDB/KB
   → Report SLA/SLO (dashboards)
```

---

## 17. Approval Matrix

| Item | Approver |
|---|---|
| New Tier 1 service catalogue entry | Head of IT Ops + Service Owner + Risk overlay |
| SLO change | Service Owner + CIO for CBS loosening |
| Permanent alert suppress | Forbidden; temporary per §11 |
| Runbook for SEV-1 | Service Owner + Process Owner |

---

## 18. Decision Tree — Ticket Type

```
Service broken / degraded?
   ├─ Yes → Incident (INC-)
   └─ No → Need something new/standard?
              ├─ Yes → Request
              └─ Cause unknown recurring? → Problem (PRB-)
Change to production runtime?
   └─ RFC/CHG per ANB-OPS-POL-0001
```

---

## 19. Metrics

| Metric | Target |
|---|---|
| SEV-1 MTTD | ≤ 5 min (gold signals) |
| SEV-1 MTTR | Per CBS tolerance; trend improve |
| Ticket backlog age > 30d (SEV-3+) | ≤ 5% |
| First-contact resolution L1 | ≥ 60% (requests) |
| CMDB Tier 1 accuracy | ≥ 98% |
| Monitoring coverage Tier 1 | 100% |
| OLA breach vendor | Tracked & escalated |

---

## 20. Cross-Domain Examples

| Scenario | Handling |
|---|---|
| Loan drawdown portal failure (CMB) | INC on `SRV-APEXORIGIN`; notify CMB ops `ANB-CBK-*` |
| AML alert pipeline delay | INC + Compliance; dual-control on rule CHG |
| Payroll ApexPeople outage | INC; HR `ANB-HRM-*`; ApexID dependency check |
| Wire release latency | Payments SEV; Treasury informed if settlement window |
| Phishing-driven BEC | Cyber IR primary; ops supports mailbox restores |

---

## 21. Related Documents

`ANB-OPS-POL-0001` · `ANB-OPS-SOP-0002` · `ANB-OPS-INC-0001` · `ANB-OPS-RCA-0001` · `ANB-OPS-RPT-0002` · `ANB-OPS-RPT-0003` · `ANB-ITO-SOP-0003` · `ANB-ITO-PLN-0001` · `ANB-ITO-PLN-0002` · `ANB-ISC-SOP-0003` · `ANB-ISC-STD-0002` · `ANB-ISC-POL-0003` · `ANB-IAD-CHK-0001` · `ANB-RSK-POL-0001` · Retail/Corporate/Finance/HR/CMP domain SOPs as impacted

---

## 22. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | Service Management | Initial ITSM SOP |

---

## Appendix A — Tooling Map

| Capability | Platform |
|---|---|
| ITSM | ApexServe (ServiceNow) |
| Observability | ApexMonitor, Dynatrace, AppDynamics, Prometheus, Grafana, Splunk |
| Alerting | PagerDuty |
| Security monitoring | Microsoft Sentinel, ApexShield, CrowdStrike |
| Edge | F5, Palo Alto |
| Identity | ApexID, Entra, CyberArk |
| CI/CD | ApexBuild, GitHub, Jenkins |

---

## Appendix B — Entity Prefixes (Ops)

`INC-` `PRB-` `CHG-` `RFC-` `KB-` `RUN-` `OPS-` `CMDB-` `SRV-` `CFG-` `MON-` `EVT-` `ALR-` `KEDB-` `CAPA-` `ACT-`

---

**End of Document** — `ANB-OPS-SOP-0001` v1.0
