# Apex National Bank — Change Management Policy

**Enterprise Policy | ITIL Change Enablement, CAB, Freeze Windows, Emergency Change, and PIR**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-POL-0001` |
| **Document Title** | Change Management Policy |
| **Version** | 1.0 |
| **Owner** | IT Operations (ITO) — Service Management |
| **Custodian** | Ravi Subramanian, Head of IT Operations (G11) — `EMP-500101` |
| **Approver** | CIO Arjun Patel (`EMP-100007`); noted to BTR / ORC as applicable |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-OPS-CHG`, `BP-OPS-CAB`, `BP-OPS-REL`, `BP-ITSM-CHG`, `BP-ITSM-REL` |
| **System of Record** | ApexServe (Change) · ApexBuild · GitHub Enterprise · ApexDocs |
| **Detailed Procedure** | **`ANB-ITO-SOP-0003` Change Management Procedure remains the authoritative operating procedure**; this Policy sets governance requirements that `ANB-ITO-SOP-0003` must implement |
| **Related Documents** | `ANB-ITO-SOP-0003`, `ANB-OPS-SOP-0001`, `ANB-OPS-SOP-0002`, `ANB-ISC-STD-0007`, `ANB-ISC-POL-0001`, `ANB-FIN-SOP-0003`, `ANB-ADM-MTX-0001`, `ANB-IAD-RPT-0001`, `ANB-ITO-PLN-0002` |

---

## 2. Purpose

Establish enterprise governance for assessing, authorising, scheduling, implementing, and reviewing changes to Bank technology services so that benefits are delivered without unacceptable risk to Critical Business Services, customer outcomes, financial reporting integrity, or cyber posture.

---

## 3. Scope

All changes to production and production-like pre-prod controls for Bank systems — applications, infrastructure, network, cloud (`ApexCloud`), data, model scoring endpoints, and material SaaS configurations. Includes vendor-operated changes affecting Bank CBS. Excludes purely documentary edits with no runtime effect (still versioned in ApexDocs).

Entities: `RFC-########` (request) · `CHG-########` (record) · linked `INC-` / `PRB-` / `CFG-` / `CMDB-` / `SRV-`.

---

## 4. Policy Principles

| # | Principle |
|---|---|
| P1 | Every production change is recorded in ApexServe before implementation (except declared BCP with reconciliation ≤ 5 BD) |
| P2 | Risk-based authorisation — higher risk requires broader CAB / executive approval |
| P3 | Segregation of duties between build, approve, and deploy (`ANB-ISC-STD-0007`, `ANB-ISC-POL-0003`) |
| P4 | Backout / remediation plan mandatory for Tier 1 |
| P5 | Security, resilience, and data-classification impacts assessed |
| P6 | Emergency speed never removes accountability or PIR |
| P7 | Failed and emergency changes drive Problem / CAPA where warranted |

---

## 5. Responsibilities

| Role | Responsibility |
|---|---|
| Change Requester / Owner | Accurate RFC; test evidence; implementation |
| Change Manager | Process integrity; CAB agenda; metrics |
| CAB | Risk review & authorisation for Normal/high-risk |
| ECAB / On-call approvers | Emergency path |
| Service Owner | Accept risk to `SRV-`; validate success criteria |
| ISC AppSec / Cyber | Security gate for Tier 1 / internet-facing / IAM |
| CIO / Head of IT Ops | Policy owner; freeze exceptions material |
| Internal Audit | Independent testing (`ANB-IAD-CHK-0001`) |

---

## 6. Change Types (ITIL-Aligned)

| Type | Definition | Auth |
|---|---|---|
| **Standard** | Pre-authorised, low-risk, proven procedure | Auto if checklist match |
| **Normal** | Assessed via CAB / peer path by risk | CAB or delegated |
| **Emergency** | Restore service / urgent security fix | ECAB / dual approve; PIR mandatory |

Model / AI endpoint changes follow Normal+ with `ANB-ISC-STD-0007` AI Security gates.

---

## 7. Risk Assessment Dimensions

| Factor | Higher risk indicators |
|---|---|
| Service tier | Tier 0/1; CBS; payments; identity |
| Data | C2/C3 / Highly Restricted (`ANB-ISC-STD-0004`) |
| Blast radius | Multi-region; edge; core ledger |
| Reversibility | Hard to rollback |
| Timing | Freeze; peak banking hours; month-end |
| Coupling | Shared F5/Palo Alto/ApexPay |

Risk score drives CAB level and evidence depth (load test, canary, security scan).

---

## 8. Change Windows and Freeze Periods

### 8.1 Standard Maintenance Windows

| Environment class | Preferred window (ET) |
|---|---|
| Retail digital | Tue/Wed 01:00–04:00 |
| Payments rails | Coordinated with NACHA/Fed windows; avoid peak RTP |
| Branch/ATM host | Sun 02:00–05:00 regional |
| Corporate portals | Sat 22:00–Sun 02:00 |

Deviations require elevated approval.

### 8.2 Freeze Periods

| Freeze | Trigger | Authority to except |
|---|---|---|
| Financial close | Soft/hard close (`ANB-FIN-SOP-0003`) | Head of IT Ops + GFC |
| Regulatory exam critical week | Compliance/Legal notice | CIO + CCO path |
| Peak events | Fed day / major marketing | CIO |
| Post SEV-1 stabilisation | IC recommendation (e.g., 72h after `INC-20260714-0001`) | Head of IT Ops |

---

## 9. CAB Governance (`BP-OPS-CAB`)

```
RFC raised in ApexServe
   → Risk scoring + CI links (CMDB)
   → Test evidence + backout
   → Security/SRE/Service Owner review
   → CAB (Normal) or Standard auto
   → Schedule window
   → Implement / verify
   → PIR (mandatory Emergency; risk-based Normal)
```

**CAB Chair:** Head of IT Operations or delegate.  
**Standing members:** Change Manager, Service Mgmt, SRE/Platform, ISC representative, Business Service Owners as needed, Finance when SOX-critical.

---

## 10. Emergency Change Process

```
SEV-1/2 active OR urgent security patch
   → Open CHG- type Emergency (+ link INC-)
   → Dual approval: On-call Service Owner + Head of IT Ops / ECAB delegate
   → ISC notify if security-relevant
   → Implement with maximum safe verification
   → Within 10 business days: complete PIR + CAB retrospective
   → If process shortcut caused incident → PRB/RCA (see ANB-OPS-RCA-0001)
```

**Edge / Tier-0 network & identity changes:** require canary or equivalent compensating control after CAPA from July 2026 SEV-1 — see `CAPA-20260714-0003`.

---

## 11. Security and SSDLC Gates

Before Production for Tier 1:

- SAST/SCA/secrets scan clean or excepted (`BP-SEC-EXC`)  
- DAST/risk-based pen as required  
- Privileged credentials via CyberArk only  
- Encryption / TLS standards (`ANB-ISC-STD-0006`)  
- AI/RAG changes: §16 AI Security in `ANB-ISC-STD-0007`

---

## 12. Post-Implementation Review (PIR)

| Change class | PIR required |
|---|---|
| Emergency | Always ≤ 10 BD |
| Normal Tier 1 | Always |
| Failed change | Always + consider Problem |
| Standard | Spot-check / metrics |

PIR contents: outcomes vs plan, incidents caused, customer impact, lessons, follow-up `ACT-`/`CHG-`.

---

## 13. Approval Matrix (Summary)

| Risk / Type | Approvers |
|---|---|
| Standard | Pre-approved model |
| Normal low | Peer + Change Manager |
| Normal Tier 1 | CAB + Service Owner + ISC (security-relevant) |
| Emergency | Dual on-call / ECAB; CIO for repeated emergencies |
| Freeze break | Per §8.2 |
| Material architecture | Architecture Board + CAB |

Consistent with `ANB-ADM-MTX-0001` technology change row.

---

## 14. Decision Tree — Change Type Selection

```
Pre-approved Standard model fits 100%?
   ├─ Yes → Standard
   └─ No → Service down / active exploit / data-loss imminent?
              ├─ Yes → Emergency (+ INC-)
              └─ No → Normal (CAB path by risk score)
```

---

## 15. Metrics (Policy KPIs)

| KPI | Target |
|---|---|
| Change success rate (Tier 1) | ≥ 98% |
| Emergency change % of total | ≤ 10% (trend down) |
| Emergency PIR on-time | 100% |
| Failed deployment causing SEV-1/2 | 0 tolerance theme; RCA mandatory |
| CAB packet completeness | ≥ 95% |
| Unauthorised change detections | 0 |

Reported in `ANB-OPS-RPT-0002` / `0003`.

---

## 16. Realistic Example

`CHG-20260714-0003` (Emergency edge) restored service via rollback but failed PIR completeness and validation gates — root cause in `ANB-OPS-RCA-0001`, observed by IAD `OBS-2026-0142-01`. Policy CAPA: canary + dual approve for edge emergencies.

---

## 17. Related Documents

`ANB-ITO-SOP-0003` · `ANB-OPS-SOP-0001` · `ANB-OPS-SOP-0002` · `ANB-OPS-INC-0001` · `ANB-OPS-RCA-0001` · `ANB-ISC-STD-0007` · `ANB-ISC-POL-0001` · `ANB-ISC-POL-0003` · `ANB-FIN-SOP-0003` · `ANB-ITO-PLN-0002` · `ANB-IAD-CHT-0001` · `ANB-IAD-RPT-0001` · `ANB-ADM-MTX-0001` · `ANB-RSK-POL-0001`

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | R. Subramanian | Initial Change Management Policy (governance over ITO-SOP-0003) |

---

## Appendix A — RFC Minimum Fields

Service `SRV-` · CIs `CMDB-`/`CFG-` · Risk score · Test plan · Backout · Security impact · Data class · Window · Approvals · Links to `INC-`/`PRB-`.

---

**End of Document** — `ANB-OPS-POL-0001` v1.0
