# Apex National Bank — Internal Audit Report

**Assurance Engagement Report | Technology Change, Digital Channels & Privileged Access — FY26 Q2**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-IAD-RPT-0001` |
| **Document Title** | Internal Audit Report — Integrated Technology & Retail Channel Controls (FY26 Q2) |
| **Engagement ID** | `AUD-2026-0142` |
| **Version** | 1.0 Final |
| **Owner** | Internal Audit (IAD) — Technology & Cyber Audit |
| **Engagement Lead** | Head of Audit — Technology (G8), under CAE Thomas Nakamura (`EMP-100009`) |
| **Approver** | Chief Audit Executive — `EMP-100009` |
| **Classification** | Confidential (C2) |
| **Report Date** | 2026-07-28 |
| **Fieldwork Period** | 2026-05-12 → 2026-07-10 |
| **Business Process** | `BP-IAD-AUD`, `BP-AUD-ENG`, `BP-AUD-RPT`, `BP-OPS-CHG`, `BP-OPS-INC`, `BP-SEC-IAM` |
| **System of Record** | ApexAudit · ApexDocs |
| **Distribution** | Audit Committee; CIO (`EMP-100007`); Head of IT Operations (`EMP-500101`); CISO (`EMP-100010`); COO (`EMP-100003`); CRO (`EMP-100004`); Head of Retail Digital; Head of Payment Operations |
| **Related Documents** | `ANB-IAD-CHT-0001`, `ANB-IAD-TPL-0001`, `ANB-IAD-CHK-0001`, `ANB-OPS-POL-0001`, `ANB-ITO-SOP-0003`, `ANB-ISC-POL-0001`, `ANB-ISC-STD-0002`, `ANB-ISC-POL-0003`, `ANB-ISC-SOP-0003`, `ANB-RTL-MAN-0004`, `ANB-ITO-PLN-0002` |
| **Naming Affinity** | Aligns conceptually with profile example `ANB-IAD-RPT-0142_*` retail/ops audit series |

---

## 2. Purpose

Provide the Board Audit Committee and accountable executives with an independent opinion on the design and operating effectiveness of selected controls over production change management, digital channel availability management, privileged access to Tier 1 systems, and operational incident/problem linkage for Retail and Payments platforms during FY26 Q2.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| ApexOnline / ApexMobile production changes & major incidents | Full PCI card-data environment deep dive (covered under separate card programme audit) |
| ApexCore / ApexPay change samples impacting retail payments | Credit underwriting models (`ANB-CBK` / model risk full scope) |
| Privileged access via CyberArk / ApexID for ITO Tier 0/1 | Full AML transaction monitoring model validation |
| Incident → Problem → Known Error linkage for SEV-1/2 | Physical branch cash counts (see cash audit series) |
| DR evidence related to digital CBS for sampled period | Full legal privilege review |

**Entities sampled:** `CHG-202605*`, `CHG-202606*`, `INC-202605*`–`INC-202607*`, `PRB-*`, `IAM-*`, `HOST-*`, `SRV-*`, `CMDB-*`.

---

## 4. Responsibilities

| Role | Responsibility |
|---|---|
| IAD | Independent testing, rating, reporting |
| ITO / OPS | Management response; remediation ownership |
| ISC | Privileged access & cyber control remediation |
| Retail Digital / Payments | Business impact confirmation; customer remediation where applicable |
| Risk | Overlay risk acceptance where used |

---

## 5. Overall Opinion

| Field | Result |
|---|---|
| **Overall Rating** | **Needs Improvement** |
| **Rationale** | Change management policy intent is sound and CAB operates for Normal changes; however, emergency change documentation quality, privileged access recertification timeliness for selected break-glass paths, and incident-to-problem promotion discipline for recurring digital faults require remediation. No Critical-rated observation. One High observation on emergency change evidence; four Medium; two Low. |

```
Control environment snapshot (AUD-2026-0142)

        Design     Operating Effectiveness
Change    ●●●○          ●●○○
Access    ●●●○          ●●○○
Incident  ●●○○          ●●○○
DR link   ●●●○          ●●●○
```

---

## 6. Executive Summary

Internal Audit executed `AUD-2026-0142` under Charter `ANB-IAD-CHT-0001`. Testing applied checklist `ANB-IAD-CHK-0001` (ITGC + channel resilience modules).

**Positive practices observed**

- ApexServe CAB records for Normal changes generally complete; peer review and ISC security gates referenced for Tier 1 releases aligned to `ANB-ISC-STD-0007`.  
- Major incident bridge for `INC-20260714-0001` (see `ANB-OPS-INC-0001`) demonstrated cross-functional command including SOC coordination under `ANB-ISC-SOP-0003`.  
- DR runbook references for ApexOnline were current in CMDB (`CMDB-` / `SRV-` linkage).

**Key themes requiring management attention**

1. Emergency / expedited changes with incomplete post-implementation review (PIR) packages.  
2. Privileged checkout justification quality and delayed quarterly recertification for a subset of `USR-ADM-` accounts.  
3. Recurring SEV-3 digital errors not consistently promoted to Problem (`PRB-`) within SLA.  
4. Monitoring alert noise contributing to delayed MTTD on a sampled payment latency event.

Management has accepted all observations and provided responses in §10.

---

## 7. Methodology

| Element | Approach |
|---|---|
| Standards | IIA Standards; Bank IAD methodology; ITIL v4 change/incident reference |
| Sampling | Risk-based; 40 Normal CHG, 15 Emergency CHG, 25 INC SEV-1–3, 12 PRB, 30 privileged users |
| Evidence | ApexServe, ApexBuild, GitHub Enterprise, CyberArk, ApexID, ApexMonitor, ApexShield, ApexDocs |
| Interviews | Head of IT Operations `EMP-500101`; SOC Manager `EMP-500204`; Identity `EMP-500202`; Digital Ops; Payment Ops |
| Reperformance | Selected CAB approvals; access joiners vs `ANB-HRM-SOP-0007` triggers |

---

## 8. Control Testing Summary

| Control Area | Ref | Design | OE | Result |
|---|---|---|---|---|
| Change authorization (Normal) | `ANB-OPS-POL-0001` / `ANB-ITO-SOP-0003` | Adequate | Mostly Effective | Pass with Medium findings |
| Emergency change | Policy § Emergency | Adequate | Partially Effective | High finding `OBS-2026-0142-01` |
| Segregation of duties deploy | `ANB-ISC-STD-0007` | Adequate | Mostly Effective | Medium `OBS-2026-0142-02` |
| Privileged access review | `ANB-ISC-POL-0003` / STD-0002 | Adequate | Partially Effective | Medium `OBS-2026-0142-03` |
| Incident severity assignment | `BP-OPS-INC` | Adequate | Mostly Effective | Low |
| Problem promotion | `BP-OPS-PRB` | Needs Improvement | Partially Effective | Medium `OBS-2026-0142-04` |
| Monitoring / alerting | `BP-OPS-MON` | Adequate | Partially Effective | Medium `OBS-2026-0142-05` |
| CMDB accuracy Tier 1 | `BP-ITSM-CMDB` | Adequate | Mostly Effective | Low `OBS-2026-0142-06` |
| DR evidence linkage | `ANB-ITO-PLN-0002` | Adequate | Effective | Pass |
| Cyber IR handoff | `ANB-ISC-SOP-0003` | Adequate | Effective for sampled SEV-1 | Pass |

---

## 9. Observations

### OBS-2026-0142-01 — Emergency Change PIR Incomplete (High)

| Attribute | Detail |
|---|---|
| **Condition** | 6 of 15 emergency changes lacked completed PIR within 10 business days; 2 lacked documented risk acceptance when CAB was bypassed after hours |
| **Criteria** | `ANB-OPS-POL-0001`; `ANB-ITO-SOP-0003`; `ANB-ADM-MTX-0001` |
| **Cause** | Weekend bridge pressure; unclear ownership between Change Manager and Service Owner |
| **Effect** | Recurrence risk; weakened audit trail for SOX-relevant ApexPay changes |
| **Risk** | Operational; Financial reporting (ITGC); Regulatory exam readiness |
| **Evidence** | `CHG-20260622-0088`, `CHG-20260701-0012`, ApexServe attachments incomplete |

### OBS-2026-0142-02 — Production Deploy SoD Exception Aged (Medium)

| Attribute | Detail |
|---|---|
| **Condition** | Same engineer approved and deployed in 3 of 40 Normal changes via emergency override flag without same-day secondary review |
| **Criteria** | `ANB-ISC-STD-0007`; Access Control Policy `ANB-ISC-POL-0003` |
| **Evidence** | ApexBuild logs; `CHG-20260518-0041` |

### OBS-2026-0142-03 — Privileged Recertification Delays (Medium)

| Attribute | Detail |
|---|---|
| **Condition** | 11 of 30 sampled `USR-ADM-` accounts exceeded quarterly recertification by 14–38 days |
| **Criteria** | `ANB-ISC-STD-0002`, `ANB-ISC-POL-0003`, `BP-SEC-RECERT` |
| **Evidence** | ApexID / CyberArk reports May–June 2026 |

### OBS-2026-0142-04 — Weak Incident-to-Problem Promotion (Medium)

| Attribute | Detail |
|---|---|
| **Condition** | Recurring ApexMobile timeout cluster (14 SEV-3 in 30 days) not linked to a Problem until IAD inquiry |
| **Criteria** | `ANB-OPS-SOP-0002`; ITIL problem management |
| **Evidence** | `INC-202606*` series; absent `PRB-` until `PRB-20260720-0004` created mid-audit |

### OBS-2026-0142-05 — Alert Tuning Gap (Medium)

| Attribute | Detail |
|---|---|
| **Condition** | Payment latency `ALR-` / `MON-` threshold produced high false positives; on-call suppressed related alerts for 6 hours preceding `INC-20260714-0001` precursor signals |
| **Criteria** | `BP-OPS-MON`; availability management |
| **Evidence** | PagerDuty suppression logs; Grafana / Dynatrace panels; Splunk/Sentinel correlation delay |

### OBS-2026-0142-06 — CMDB Relationship Drift (Low)

| Attribute | Detail |
|---|---|
| **Condition** | 4 Tier 1 service maps missing updated upstream F5 pool members after April network change |
| **Criteria** | CMDB accuracy target ≥ 98% Tier 1 |
| **Evidence** | `CMDB-00088421`, `CFG-` vs Palo Alto / F5 actuals |

### OBS-2026-0142-07 — Customer Complaint Linkage Incomplete (Low)

| Attribute | Detail |
|---|---|
| **Condition** | Digital outage window complaints in Apex360 not always linked back to master `INC-` for MI completeness |
| **Criteria** | `ANB-RTL` / CST complaint handling; ops MI integrity |
| **Evidence** | Sample of 20 complaints 14–15 Jul 2026 |

---

## 10. Management Responses and Action Plan

| Obs | Action ID | CAPA | Management Response | Owner | Due Date | Status |
|---|---|---|---|---|---|---|
| 01 | `ACT-2026-0142-01` | `CAPA-2026-0142-01` | Mandate PIR workflow gate in ApexServe for all Emergency CHG; weekly CAB retrospective | Ravi Subramanian `EMP-500101` | 2026-09-30 | Open |
| 01 | `ACT-2026-0142-01b` | — | Train Change Managers; publish emergency checklist `KB-OPS-CHG-EMER` | Head of Service Management | 2026-08-31 | Open |
| 02 | `ACT-2026-0142-02` | `CAPA-2026-0142-02` | Enforce ApexBuild dual-control; alert on same-user approve+deploy | Platform Engineering + AppSec `EMP-500205` | 2026-09-15 | Open |
| 03 | `ACT-2026-0142-03` | `CAPA-2026-0142-03` | Auto-suspend entitlements on recert overdue > 7 days | Tobias Lindgren `EMP-500202` | 2026-09-30 | Open |
| 04 | `ACT-2026-0142-04` | `CAPA-2026-0142-04` | Auto-propose PRB when ≥5 similar INC in 30 days | Problem Manager / OPS | 2026-10-15 | Open |
| 05 | `ACT-2026-0142-05` | `CAPA-2026-0142-05` | Retune payment latency monitors; ban indefinite suppression | Monitoring Lead / Cyber Defence `EMP-500201` | 2026-09-15 | Open |
| 06 | `ACT-2026-0142-06` | — | Reconcile F5/CMDB; quarterly discovery job | CMDB Steward | 2026-08-31 | Open |
| 07 | `ACT-2026-0142-07` | — | CST playbook update — link complaints to INC | Head of CST | 2026-09-30 | Open |

---

## 11. Workflow — Issue Validation

```
Action due
   → Owner updates ApexAudit evidence
   → Management asserts "Closed"
   → IAD validation (BP-AUD-VAL)
         ├─ Effective → Validated Closed
         └─ Ineffective → Reopen + escalate if High/Critical overdue
```

---

## 12. Approval Matrix (Report)

| Step | Authority |
|---|---|
| Factual accuracy (management) | CIO / Head of IT Ops / CISO (comments only) |
| Final opinion & issue ratings | CAE `EMP-100009` |
| Audit Committee presentation | CAE |

---

## 13. Decision Tree — Rating Escalation

```
Any Critical OBS?
   ├─ Yes → Overall Critical/Unsatisfactory path; immediate Audit Committee Chair notice
   └─ No → Any High OBS?
              ├─ Yes → Needs Improvement minimum (this report)
              └─ No → Multiple Medium thematic?
                         ├─ Yes → Needs Improvement
                         └─ No → Satisfactory
```

---

## 14. Cross-Domain Impact Notes

- **Retail:** Channel availability & complaint MI (`ANB-RTL-*`, CST).  
- **Payments / Corporate:** ApexPay latency affects CMB payment clients.  
- **Security:** Privileged access & alert suppression touch `ANB-ISC-*`.  
- **Risk:** Operational risk event linkage in ApexRisk for SEV-1.  
- **Finance:** ITGC relevance for SOX-critical paths.  
- **DR:** No DR invocation required for sampled SEV-1; standby assessed per `ANB-ITO-PLN-0002`.

---

## 15. Related Documents

`ANB-IAD-CHT-0001` · `ANB-IAD-TPL-0001` · `ANB-IAD-CHK-0001` · `ANB-OPS-INC-0001` · `ANB-OPS-RCA-0001` · `ANB-OPS-POL-0001` · `ANB-OPS-SOP-0001` · `ANB-OPS-SOP-0002` · `ANB-ITO-SOP-0003` · `ANB-ITO-PLN-0002` · `ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-POL-0003` · `ANB-ISC-SOP-0003` · `ANB-ISC-STD-0007` · `ANB-RSK-POL-0001` · `ANB-FIN-SOP-0003` · `ANB-ADM-MTX-0001`

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-28 | IAD Technology Audit | Final report approved by CAE |

---

## Appendix A — Sample Population Summary

| Population | Size | Exceptions |
|---|---|---|
| Normal CHG | 40 | 3 SoD |
| Emergency CHG | 15 | 6 PIR / 2 risk accept |
| INC SEV-1–3 | 25 | Problem linkage gaps |
| Privileged users | 30 | 11 recert late |

---

## Appendix B — Acronyms

CAB · CMDB · ITGC · MTTD · OE · PIR · SEV · SOX · SoD

---

**End of Document** — `ANB-IAD-RPT-0001` v1.0 | Engagement `AUD-2026-0142`
