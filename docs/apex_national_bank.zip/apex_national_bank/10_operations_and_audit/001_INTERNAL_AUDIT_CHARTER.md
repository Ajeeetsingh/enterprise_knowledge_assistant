# Apex National Bank — Internal Audit Charter

**Board-Approved Charter | Independence, Authority, and Assurance Mandate of Internal Audit**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-IAD-CHT-0001` |
| **Document Title** | Internal Audit Charter |
| **Version** | 1.0 |
| **Owner** | Internal Audit (IAD) |
| **Custodian** | Thomas Nakamura, Chief Audit Executive (G11) — `EMP-100009` |
| **Approver** | Board Audit Committee (Chair: Priscilla Vance) |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual (or upon material regulatory / organisational change) |
| **Retention** | `RET-GOV-PERM` |
| **Taxonomy** | `T2` → Internal Audit → `CHT` |
| **Business Process** | `BP-IAD-AUD`, `BP-AUD-PLAN`, `BP-AUD-ENG`, `BP-AUD-RPT`, `BP-AUD-VAL` |
| **System of Record** | ApexAudit · ApexDocs · ApexServe · ApexInsight |
| **Legacy Cross-Reference** | Company Profile §15 reserved `ANB-IAD-REF-0002` for this Charter; **`ANB-IAD-CHT-0001` is the canonical published Document ID**; `ANB-IAD-REF-0002` remains a recognised alias in indexes |
| **Related Documents** | `ANB-IAD-TPL-0001`, `ANB-IAD-RPT-0001`, `ANB-IAD-CHK-0001`, `ANB-ADM-MTX-0001`, `ANB-ADM-REF-0001`, `ANB-RSK-POL-0001`, `ANB-CMP-POL-0001`, `ANB-ISC-POL-0001`, `ANB-OPS-POL-0001`, `ANB-FIN-SOP-0003`, `ANB-LEG-SOP-0007` |

---

## 2. Purpose

This Charter defines the purpose, authority, independence, and responsibility of Internal Audit (IAD) at Apex National Bank. It establishes IAD as the **Third Line of Defence**, providing the Board Audit Committee and senior management with independent, risk-based assurance on the adequacy and effectiveness of governance, risk management, and internal control processes across the Group.

IAD evaluates whether the Bank’s control environment enables:

1. Reliable financial and regulatory reporting  
2. Safeguarding of assets and customer information  
3. Compliance with laws, regulations, and internal policies  
4. Operational resilience of Critical Business Services (`CBS-########`)  
5. Effective remediation of known issues (`OBS-`, `ACT-`, `CAPA-`)

---

## 3. Scope

IAD’s universe covers all legal entities in `ANB-ADM-REF-0001`, all departments (Retail, Corporate Banking, Treasury, Finance, HR, Compliance, Risk, Legal, ISC, ITO, CST, PRC, ADM, MKG), all material third-party arrangements subject to Bank oversight, and all technology platforms including ApexCore, ApexPay, ApexOnline/ApexMobile, ApexGuard, ApexID, ApexCloud, and outsourced processing.

**No activity, location, or legal entity is outside IAD’s remit** solely by virtue of organisational reporting, cost centre, or vendor operation — subject to legal privilege protocols coordinated with Legal (`ANB-LEG` litigation / privilege procedures).

---

## 4. Authority

| Authority | Description |
|---|---|
| **Unrestricted access** | Full and free access to records, personnel, systems (read-only where production integrity requires), premises, and third-party evidence relevant to engagements |
| **Allocate resources** | CAE determines engagement staffing, specialists, and co-sourcing within approved budget |
| **Escalate** | Direct and unfettered access to the Audit Committee Chair; may escalate to full Board |
| **Opinion** | Issues ratings and opinions free from management interference (`ANB-ADM-REF-0001` documented-decision culture) |
| **Follow-up** | Validates remediation (`BP-AUD-VAL`); may reopen inadequate closures |

Management may not approve, amend, or veto IAD opinions, ratings, or reports (Company Profile independence rule).

---

## 5. Independence and Objectivity

```
Board Audit Committee
        │
        ▼
Chief Audit Executive (EMP-100009)
        │
        ├── Audit Practice / Quality
        ├── Business Line Audit (Retail, CMB, Treasury, Finance)
        ├── Technology & Cyber Audit
        ├── Compliance / Financial Crime Audit
        └── Continuous Auditing / Analytics (ApexInsight)
```

| Requirement | Standard |
|---|---|
| Reporting | Functionally to Audit Committee; administratively to CEO for HR/budget logistics only |
| CAE appointment / removal | Audit Committee approval |
| Compensation | Audit Committee oversight; not tied to business P&L targets |
| Impairments | Auditors must declare conflicts; cool-off periods apply when transferring from First/Second Line |
| Consulting | Advisory work permitted if independence preserved; CAE approves; not a substitute for management ownership |

---

## 6. Responsibilities — Chief Audit Executive

**CAE-1.** Maintain this Charter; submit annually to Audit Committee.  
**CAE-2.** Develop risk-based Annual Audit Plan (`BP-AUD-PLAN`) aligned to ERM (`ANB-RSK-POL-0001`), regulatory focus, and operational incidents (`BP-OPS-INC`).  
**CAE-3.** Ensure conformance with IIA Global Internal Audit Standards and Bank methodology.  
**CAE-4.** Report periodically to Audit Committee on plan progress, material issues, overdue actions, and thematic risks.  
**CAE-5.** Coordinate with external auditors and regulators without compromising independence.  
**CAE-6.** Maintain ApexAudit as system of record for `AUD-########`, `OBS-########`, `ACT-########`, `CAPA-########`.

---

## 7. Responsibilities — Management (First Line) and Oversight (Second Line)

| Party | Obligation |
|---|---|
| Department Heads | Provide timely access, factual accuracy review (not opinion veto), remediation ownership |
| Risk / Compliance | Share risk assessments, issue inventories, exam findings; respect Third Line independence |
| ISC / ITO | Provide security/ops evidence; coordinate cyber/incident timelines without limiting audit scope |
| Finance | Support SOX-relevant testing overlays (`ANB-FIN-SOP-0003`) |

---

## 8. Audit Universe and Planning

### 8.1 Risk-Based Plan

```
ERM heat map (ApexRisk)
        + Regulatory commitments / MRAs
        + Incident & problem trends (ApexServe)
        + Prior audit issues overdue
        + Material change / new products (NPAC)
        + Third-party concentration
                ↓
        Annual Audit Plan (AUD-PLAN-FY##)
                ↓
        Audit Committee approval
                ↓
        Engagement scheduling (AUD-########)
```

### 8.2 Engagement Types

| Type | Description |
|---|---|
| Assurance | Formal opinion on control design and operating effectiveness |
| Integrated | Cross-domain (e.g., technology + retail channel) |
| Continuous / advisory analytics | Data-driven monitoring; may trigger full engagement |
| Investigation support | Fact-finding support to Legal/HR/Compliance under protocols |
| Validation | Independent verification of closed issues (`BP-AUD-VAL`) |

---

## 9. Ratings and Issue Taxonomy

### 9.1 Engagement Opinion Scale

| Rating | Meaning |
|---|---|
| **Satisfactory** | Controls adequate; issues minor |
| **Needs Improvement** | Material gaps; remediation required within defined dates |
| **Unsatisfactory** | Significant weakness; elevated Board/ExCo attention |
| **Critical** | Severe control failure; immediate escalation to Audit Committee |

### 9.2 Observation Severity

| Severity | Definition | Typical remediation |
|---|---|---|
| Critical | Systemic failure; customer/regulatory/financial material impact | ≤ 30 days or interim compensating control |
| High | Significant design/OE gap | ≤ 60–90 days |
| Medium | Important deficiency | ≤ 120 days |
| Low | Improvement opportunity | Risk-based |

Entities: Observation `OBS-########` · Action `ACT-########` · Corrective/Preventive Action `CAPA-########` · Engagement `AUD-########`.

---

## 10. Workflow — Engagement Lifecycle

```
Plan (BP-AUD-PLAN)
   → Announce / scoping memo
   → Risk & control assessment
   → Fieldwork (ANB-IAD-CHK-0001 / work programmes)
   → Evidence in ApexAudit / ApexDocs
   → Exit meeting (factual accuracy)
   → Draft report (ANB-IAD-TPL-0001 structure)
   → Management response (owners, dates)
   → CAE approval
   → Final report (e.g., ANB-IAD-RPT-0001)
   → Issue tracking & validation (BP-AUD-VAL)
   → Audit Committee summary
```

---

## 11. Approval Matrix

| Decision | Approver |
|---|---|
| Charter approval / amendment | Board Audit Committee |
| Annual Audit Plan | Board Audit Committee |
| Engagement opinion & final report | CAE (`EMP-100009`) |
| Issue rating dispute (process) | CAE; escalate to Audit Committee Chair |
| Plan deferral of High/Critical-rated area | Audit Committee |
| Co-source selection (material) | CAE with Procurement as needed |

Aligned with `ANB-ADM-MTX-0001` independence principles.

---

## 12. Coordination with Other Domains

| Domain | Coordination |
|---|---|
| Risk | Assurance map; avoid unplanned duplication; IAD remains independent |
| Compliance / AML | Coverage of `ANB-CMP-POL-0001` programme; SAR confidentiality respected |
| ISC | Cyber, IAM, SSDLC, IR (`ANB-ISC-*`); IAD may test SOC evidence |
| ITO / OPS | Change, incident, problem, DR (`ANB-OPS-*`, `ANB-ITO-PLN-0002`, `ANB-ITO-SOP-0003`) |
| Finance | SOX ITGC / business process controls |
| Legal | Privilege, regulatory exams (`ANB-LEG-SOP-0007`) |
| Retail / CMB | Product and channel control audits |
| HR | Access joiner-mover-leaver evidence (`ANB-HRM-SOP-0007`) |

---

## 13. Quality Assurance and Improvement Programme (QAIP)

- Internal quality reviews on engagements  
- Periodic external quality assessment (EQA) per IIA  
- Auditor continuing professional education  
- Methodology updates reflected in `ANB-IAD-CHK-0001` and templates  

Deficiencies in QAIP reported to Audit Committee.

---

## 14. Relationship to External Audit and Regulators

IAD coordinates coverage and may place reliance only where independently assessed. External auditor remains responsible for its opinion. Regulatory examination support follows `ANB-LEG-SOP-0007` / Compliance procedures; IAD may validate management’s remediation of supervisory findings.

---

## 15. Business Processes

| Process ID | Name |
|---|---|
| `BP-IAD-AUD` | Internal Audit end-to-end assurance lifecycle (Domain 10 canonical) |
| `BP-AUD-PLAN` | Audit universe & annual plan |
| `BP-AUD-ENG` | Engagement execution |
| `BP-AUD-RPT` | Reporting & issue rating |
| `BP-AUD-VAL` | Issue remediation validation |

---

## 16. Realistic Example

**FY26 planning:** Following SEV-1 digital/payments incident `INC-20260714-0001` and elevated cyber scenario `SCN-2026-CYB-001`, CAE elevates Technology Change & Channel Resilience into Q2 plan as `AUD-2026-0142`. Results published under `ANB-IAD-RPT-0001`. Overdue High actions report to Audit Committee monthly until validated.

---

## 17. Related Documents

`ANB-IAD-TPL-0001` · `ANB-IAD-REF-0002` (alias) · `ANB-IAD-RPT-0001` · `ANB-IAD-CHK-0001` · `ANB-ADM-REF-0001` · `ANB-ADM-MTX-0001` · `ANB-RSK-POL-0001` · `ANB-RSK-STMT-0001` · `ANB-CMP-POL-0001` · `ANB-ISC-POL-0001` · `ANB-ISC-SOP-0003` · `ANB-OPS-POL-0001` · `ANB-OPS-SOP-0001` · `ANB-ITO-PLN-0001` · `ANB-ITO-PLN-0002` · `ANB-ITO-SOP-0003` · `ANB-FIN-SOP-0003` · `ANB-LEG-SOP-0007` · `ANB-HRM-SOP-0007`

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | T. Nakamura | Board-approved Charter published as CHT-0001 |

---

## Appendix A — Canonical Audit Entities

| Entity | Format | System |
|---|---|---|
| Engagement | `AUD-########` | ApexAudit |
| Observation | `OBS-########` | ApexAudit |
| Action | `ACT-########` | ApexAudit |
| CAPA | `CAPA-########` | ApexAudit / ApexServe |
| Evidence request | via ApexServe | ApexServe |

---

## Appendix B — Annual Attestation

The CAE attests annually to the Audit Committee that IAD has operated in accordance with this Charter, that resource limitations (if any) have been disclosed, and that independence impairments (if any) have been reported.

---

**End of Document** — `ANB-IAD-CHT-0001` v1.0
