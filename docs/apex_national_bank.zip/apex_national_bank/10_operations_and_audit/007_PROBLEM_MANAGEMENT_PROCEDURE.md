# Apex National Bank — Problem Management Procedure

**Standard Operating Procedure | ITIL Problem Management, Known Errors, Workarounds, and Permanent Fixes**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-SOP-0002` |
| **Document Title** | Problem Management Procedure |
| **Version** | 1.0 |
| **Owner** | IT Operations (ITO) — Service Management |
| **Custodian** | Head of Service Management (G8) |
| **Approver** | Ravi Subramanian, Head of IT Operations — `EMP-500101` |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-OPS-PRB`, `BP-OPS-CAPA`, `BP-ITSM-PRB` |
| **System of Record** | ApexServe (Problem, Knowledge) · ApexDocs (RCA) |
| **Related Documents** | `ANB-OPS-INC-0001`, `ANB-OPS-RCA-0001`, `ANB-OPS-POL-0001`, `ANB-OPS-SOP-0001`, `ANB-ITO-SOP-0003`, `ANB-ISC-SOP-0003`, `ANB-IAD-RPT-0001`, `ANB-RTL` ATM/digital SOPs |

---

## 2. Purpose

Define how Apex National Bank identifies, analyses, and permanently resolves the root causes of incidents — reducing recurrence, restoring stable service, and maintaining an accurate Known Error Database (`KEDB-`) with published workarounds (`KB-` / `RUN-`).

---

## 3. Scope

Reactive problems (from incidents) and proactive problems (from trends, monitoring, vendor bulletins, audit findings, chaos tests). Applies to all `SRV-` in the service catalogue. Cyber root causes coordinated with `ANB-ISC-SOP-0003` without delaying service restoration.

---

## 4. Definitions

| Term | Meaning |
|---|---|
| **Problem** | Unknown cause of one or more incidents — `PRB-########` |
| **Known Error** | Problem with documented root cause and workaround — `KEDB-########` |
| **Workaround** | Temporary method to reduce/eliminate impact — `KB-` / `RUN-` |
| **RCA** | Structured root cause analysis — e.g., `ANB-OPS-RCA-0001` |
| **CAPA** | Corrective/Preventive Action — `CAPA-########` |

---

## 5. Responsibilities (RACI Summary)

| Activity | Problem Mgr | SME | Service Owner | Change Mgr | IC (Major) | ISC |
|---|---|---|---|---|---|---|
| Open PRB | A/R | C | C | I | C | C |
| RCA facilitate | A/R | R | C | C | C | C |
| Workaround publish | A | R | A | I | I | C |
| Permanent fix CHG | C | R | A | A/R | I | C |
| Close PRB | A | C | A | I | I | I |

R = Responsible, A = Accountable, C = Consulted, I = Informed

---

## 6. Reactive Problem Management

### 6.1 Triggers (Mandatory)

| Trigger | Action |
|---|---|
| Any SEV-1 | Open `PRB-` within 24h; RCA ≤ 10–15 BD |
| Any SEV-2 | Open `PRB-` within 48h |
| ≥ 5 similar SEV-3 in 30 days | Auto-propose `PRB-` (ApexServe rule; audit CAPA) |
| Failed Major CHG with recurrence risk | Open `PRB-` |
| IAD High observation on ops recurrence | Open/link `PRB-` |

### 6.2 Workflow

```
Incident(s) identified as sharing unknown cause
   → Open PRB-######## in ApexServe
   → Link INC- / CHG- / CMDB- / SRV-
   → Prioritise (impact × urgency)
   → Investigate (timeline, logs, Dynatrace/Splunk/Grafana, vendor)
   → Workaround? → Publish KB-/RUN- ; set KEDB if cause known
   → RCA (5-Whys / fishbone for Major)
   → CAPA + Normal CHG for permanent fix
   → Verify effectiveness
   → Close PRB / resolve KEDB
```

---

## 7. Proactive Problem Management

| Source | Example |
|---|---|
| Trend MI | Rising ATM host timeouts (`ANB-OPS-RPT-0002`) |
| Monitoring | SLO burn without INC yet |
| Vendor | F5/Palo Alto PSIRT; cloud degradation notices |
| Audit | `OBS-` from `ANB-IAD-RPT-0001` |
| Capacity | Prometheus forecasts |
| Security | Recurring vuln class → joint PRB with ISC |

---

## 8. Prioritisation

| Priority | Criteria | Investigation SLA (initial root hypothesis) |
|---|---|---|
| P1 | SEV-1 root / CBS | 5 BD |
| P2 | SEV-2 / major revenue channel | 10 BD |
| P3 | Recurring SEV-3 | 20 BD |
| P4 | Minor / proactive hygiene | 40 BD |

Workarounds for P1/P2 targeted within 48h where feasible.

---

## 9. Known Error Database

| Field | Requirement |
|---|---|
| ID | `KEDB-########` |
| Symptoms | Customer & technical |
| Root cause | Confirmed narrative |
| Workaround | Step-by-step `KB-`/`RUN-` |
| Affected CIs | `CMDB-` / `CFG-` / `SRV-` |
| Permanent fix | Linked `CHG-` / `CAPA-` |
| Residual risk | If accepted via `BP-RSK-ACC` |

Example: `KEDB-202607-0008` from `ANB-OPS-RCA-0001`.

---

## 10. Major Problem Review

Within 15 BD of SEV-1 resolution:

1. Facilitated review (Problem Mgr)  
2. Timeline accuracy check vs `ANB-OPS-INC-0001`  
3. CAPA ratification  
4. Update runbooks `RUN-OPS-SEV1-*`  
5. Feed lessons to CAB & training (ApexLearn)  
6. Report excerpt to Monthly Operations Review `ANB-OPS-RPT-0003`

---

## 11. Integration with Change & Incident

```
INC- (restore NOW)
   ↑↓
PRB- (fix FOREVER)
   ↓
CHG- (implement fix) per ANB-OPS-POL-0001 / ANB-ITO-SOP-0003
   ↓
Validate → Close PRB
```

Never delay incident restoration awaiting full RCA.

---

## 12. Cyber-Related Problems

If root involves malware, intrusion, or credential compromise:

- Maintain dual record: Ops `PRB-` + Cyber `INC-` per `ANB-ISC-SOP-0003`  
- Forensics may constrain log deletion  
- CAPA include detection rules `RULE-SEC-` / `MON-`  

---

## 13. Approval Matrix

| Decision | Authority |
|---|---|
| PRB priority | Problem Manager |
| Major RCA approval | Head of IT Ops |
| Workaround affecting customer fees/comms | Business Service Owner + Comms |
| Close PRB without permanent fix | Head of IT Ops + risk acceptance if residual |

---

## 14. Decision Tree

```
Cause known & workaround only?
   ├─ Yes → KEDB + track CAPA
   └─ No → Continue investigation
Permanent fix deployed & verified 30 days?
   ├─ Yes → Close PRB; retire or mark KEDB resolved
   └─ No → Keep open; escalate aged P1/P2 weekly
```

---

## 15. Metrics

| Metric | Target |
|---|---|
| SEV-1 with PRB opened ≤ 24h | 100% |
| RCA on-time SEV-1 | 100% |
| Recurrence of closed P1 problems ≤ 90d | 0 |
| KEDB articles with stale fixes > 180d | Trend to 0 |
| % incidents linked to PRB when required | ≥ 95% |

---

## 16. Realistic Examples

**Example A — Reactive:** `PRB-20260714-0001` from digital/payments SEV-1; RCA `ANB-OPS-RCA-0001`; KEDB-202607-0008; CAPA lint/canary.

**Example B — Proactive:** Trend of ApexMobile timeouts (June) should have opened PRB earlier — gap recorded as `OBS-2026-0142-04`; auto-propose rule implementing `ACT-2026-0142-04`.

**Example C — ATM:** Recurring cash-out declines at vendor-maintained ATMs → PRB linking Retail ATM SOP, vendor MSA, and host `SRV-` latency.

**Example D — AML:** ApexGuard rule deployment defect causing false-positive surge → Problem with Compliance TM owners; change dual-control reinforcement (`ANB-CMP-POL-0001`).

---

## 17. Related Documents

`ANB-OPS-INC-0001` · `ANB-OPS-RCA-0001` · `ANB-OPS-POL-0001` · `ANB-OPS-SOP-0001` · `ANB-OPS-RPT-0002` · `ANB-OPS-RPT-0003` · `ANB-ITO-SOP-0003` · `ANB-ISC-SOP-0003` · `ANB-IAD-RPT-0001` · `ANB-IAD-CHK-0001` · `ANB-RSK-POL-0001` · `ANB-CMP-POL-0001` · `ANB-RTL-*` · `ANB-ADM-MTX-0001`

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | Service Management | Initial Problem Management Procedure |

---

## Appendix A — ApexServe Problem Record Minimum Fields

Priority · Service · CI list · Linked incidents · Symptoms · Workaround · Root cause · RCA link · CAPA list · Status · Closure code.

---

## Appendix B — Knowledge Naming

`KB-OPS-<DOMAIN>-###` · `RUN-OPS-<SCENARIO>` · `KEDB-YYYYMM-####`

---

**End of Document** — `ANB-OPS-SOP-0002` v1.0
