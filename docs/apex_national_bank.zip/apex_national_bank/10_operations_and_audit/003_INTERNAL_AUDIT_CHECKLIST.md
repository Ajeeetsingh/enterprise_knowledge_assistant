# Apex National Bank — Internal Audit Checklist

**Engagement Fieldwork Checklist | IT General Controls, ITSM, Resilience, Cyber & Operational Overlays**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-IAD-CHK-0001` |
| **Document Title** | Internal Audit Checklist — Technology, Operations & Control Testing |
| **Version** | 1.0 |
| **Owner** | Internal Audit (IAD) — Audit Practice & Quality |
| **Custodian** | Head of Audit Quality (G8), under CAE Thomas Nakamura (`EMP-100009`) |
| **Approver** | Chief Audit Executive — `EMP-100009` |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-IAD-AUD`, `BP-AUD-ENG`, `BP-AUD-VAL` |
| **System of Record** | ApexAudit (workpapers) · ApexServe (evidence requests) · ApexDocs |
| **Related Documents** | `ANB-IAD-CHT-0001`, `ANB-IAD-TPL-0001`, `ANB-IAD-RPT-0001`, `ANB-OPS-POL-0001`, `ANB-OPS-SOP-0001`, `ANB-OPS-SOP-0002`, `ANB-ITO-SOP-0003`, `ANB-ITO-PLN-0001`, `ANB-ITO-PLN-0002`, `ANB-ISC-POL-0001`, `ANB-ISC-STD-0002`, `ANB-ISC-POL-0003`, `ANB-ISC-STD-0004`, `ANB-ISC-STD-0006`, `ANB-ISC-STD-0007`, `ANB-ISC-SOP-0003`, `ANB-FIN-SOP-0003`, `ANB-CMP-POL-0001`, `ANB-RSK-POL-0001`, `ANB-HRM-SOP-0007` |

---

## 2. Purpose

Provide standardised fieldwork steps, sample sizes, evidence expectations, and pass/fail criteria for assurance engagements covering IT general controls (ITGC), ITIL service management, operational resilience, and selected business overlays (payments, digital retail, financial crime technology, identity).

---

## 3. Scope

Applicable to engagements such as `AUD-2026-0142` and successor technology/ops audits. Modules may be scoped in/out in the engagement letter. Not a substitute for specialised AML model validation or credit model audits.

---

## 4. Responsibilities

| Role | Duty |
|---|---|
| Engagement Lead | Select modules; set sample sizes by risk |
| Auditor-In-Charge | Execute steps; cite evidence IDs |
| Reviewer | Challenge conclusions before CAE |
| Auditee | Fulfil ApexServe evidence requests timely |
| CAE | Methodology approval |

---

## 5. How to Use This Checklist

1. Copy module into ApexAudit workpaper set for `AUD-########`.  
2. Record population, sample, exceptions, conclusion.  
3. Raise `OBS-########` when fail/partial; link `ACT-` / `CAPA-`.  
4. Cross-reference operational tickets `INC-` `CHG-` `PRB-` and config `CMDB-` `CFG-` `SRV-`.

**Legend:** P = Pass · F = Fail · N/A = Not applicable · PE = Partial

---

## 6. Module A — Access Management (IAM / PAM)

| Check ID | Test Step | Sample | Evidence | Pass Criteria | Ref |
|---|---|---|---|---|---|
| A-01 | Joiner access provisioned only after HR clearance | 25 joiners | ApexPeople + ApexID + `IAM-` | 0 premature privileged grants | `ANB-HRM-SOP-0007`, `ANB-ISC-STD-0005` |
| A-02 | Leaver disable same day (involuntary immediate) | 25 leavers | ApexID logs | 100% within policy | `ANB-ISC-POL-0003` |
| A-03 | MFA enforced for remote & privileged | 40 users | Entra Conditional Access | 100% privileged phishing-resistant or exception `SEC-EXC-` | `ANB-ISC-STD-0002` |
| A-04 | Quarterly privileged recert complete | 30 `USR-ADM-` | CyberArk / ApexID | ≥ 98% on-time | `BP-SEC-RECERT` |
| A-05 | Break-glass use logged with `INC-` | All in period | CyberArk + ApexServe | 100% linked | `ANB-ISC-STD-0002` |
| A-06 | SoD conflicts mitigated or excepted | Report extract | ApexID SoD | No unmitigated critical conflicts | `ANB-ISC-POL-0003` |

---

## 7. Module B — Change Management

| Check ID | Test Step | Sample | Evidence | Pass Criteria | Ref |
|---|---|---|---|---|---|
| B-01 | Normal CHG has CAB/authorised approval | 40 `CHG-` | ApexServe | 100% | `ANB-OPS-POL-0001`, `ANB-ITO-SOP-0003` |
| B-02 | Backout plan documented for Tier 1 | 40 | RFC/CHG form | 100% Tier 1 | `BP-OPS-CHG` |
| B-03 | Emergency CHG approved per matrix + PIR ≤ 10 BD | 15 | ApexServe | ≥ 95% complete PIR | Policy Emergency |
| B-04 | Production deploy segregation | 40 | ApexBuild / GitHub | No standing same-user approve+deploy without control | `ANB-ISC-STD-0007` |
| B-05 | Security scan gates not bypassed | 20 releases | ApexBuild / Fortify / SonarQube | Critical findings = 0 or `BP-SEC-EXC` | SSDLC |
| B-06 | Freeze period adherence (close / regulatory) | Period population | CAB calendar | Exceptions approved & logged | `ANB-FIN-SOP-0003` |
| B-07 | Failed changes have PIR & problem link if recurring | Failed CHG set | ApexServe | 100% | `BP-OPS-PRB` |

---

## 8. Module C — Incident & Problem Management

| Check ID | Test Step | Sample | Evidence | Pass Criteria | Ref |
|---|---|---|---|---|---|
| C-01 | SEV assigned per matrix within SLA | 25 `INC-` | ApexServe | ≥ 95% | `BP-OPS-INC`, `ANB-OPS-SOP-0001` |
| C-02 | SEV-1 bridge & exec notify evidence | All SEV-1 | Bridge logs / PagerDuty | 100% | `ANB-OPS-INC-0001` pattern |
| C-03 | Cyber handoff when IOC/malware suspected | Relevant INC | ApexShield `ALERT-` / `INC-` | Per `ANB-ISC-SOP-0003` | ISC IR |
| C-04 | Major INC has PIR / RCA | SEV-1/2 | `ANB-OPS-RCA-0001` / PRB | 100% within 15 BD | `BP-OPS-PRB` |
| C-05 | Recurring incidents → Problem | Trend extract | `PRB-` / `KEDB-` | Promotion rules met | `ANB-OPS-SOP-0002` |
| C-06 | Customer complaint linkage for channel outages | 20 complaints | Apex360 + INC | ≥ 90% linked | Retail/CST |

---

## 9. Module D — Monitoring, Availability & CMDB

| Check ID | Test Step | Sample | Evidence | Pass Criteria | Ref |
|---|---|---|---|---|---|
| D-01 | Tier 1 services have gold monitors | All Tier 1 `SRV-` | ApexMonitor, Dynatrace, AppDynamics, Grafana/Prometheus | 100% coverage | `BP-OPS-MON`, `BP-OPS-AVAIL` |
| D-02 | Alert routing to PagerDuty / SOC as designed | 15 `ALR-`/`MON-` | PagerDuty, Sentinel, Splunk | Correct tier & escalation | Runbooks `RUN-` |
| D-03 | Suppression time-bound & approved | Suppressions | PagerDuty audit | No indefinite suppress on Tier 1 | Ops policy |
| D-04 | CMDB CI relationships current | 25 `CMDB-`/`CFG-` | ApexServe CMDB vs discovery | ≥ 98% Tier 1 accuracy | `BP-ITSM-CMDB` |
| D-05 | SLO/SLA reporting complete monthly | 3 months MI | ApexInsight / ops dashboard | Published to ORC pack | `ANB-OPS-RPT-0002` |

---

## 10. Module E — Resilience (BCP/DR)

| Check ID | Test Step | Sample | Evidence | Pass Criteria | Ref |
|---|---|---|---|---|---|
| E-01 | BIA/impact tolerances current for CBS | Scoped CBS | ApexRisk / BCP docs | Within annual review | `ANB-ITO-PLN-0001` |
| E-02 | DR test executed / issues tracked | Last test | DR report | Findings have `ACT-` | `ANB-ITO-PLN-0002` |
| E-03 | Backup restore tested for Tier 1 | Sample apps | Restore logs | Success within RPO/RTO | Vault/backup |
| E-04 | SEV-1 considered DR invoke criteria | SEV-1 file | Incident record | Decision logged | Ops + DR |

---

## 11. Module F — Cyber & Data Protection Overlays

| Check ID | Test Step | Sample | Evidence | Pass Criteria | Ref |
|---|---|---|---|---|---|
| F-01 | Vulnerability Critical SLA | ApexScan extract | Tickets | Within `ANB-ISC` vuln SLA | `BP-SEC-VULN` |
| F-02 | Encryption at rest Tier 1 datastores | 15 stores | Config / KMS | 100% | `ANB-ISC-STD-0006` |
| F-03 | Data classification labels on sampled repos | 20 | Purview / ApexDLP | ≥ 95% | `ANB-ISC-STD-0004` |
| F-04 | SSDLC SAST/SCA gates | 10 releases | ApexBuild | Critical = 0 or excepted | `ANB-ISC-STD-0007` |
| F-05 | IR playbooks referenced for malware/ransomware | Tabletop / real | ApexDocs / INC | Evidence of use | `ANB-ISC-SOP-0003` |

---

## 12. Module G — Business Overlays (Selectable)

| Check ID | Domain | Test Step | Ref |
|---|---|---|---|
| G-01 | Payments | ApexPay change & incident samples; NACHA/wire ops handoff | `BP-PAY-DOM`, `ANB-ITO-SOP-0003` |
| G-02 | Retail ATM | ATM fleet incident & vendor FLM tickets linkage | `ANB-RTL-*` ATM SOPs |
| G-03 | AML Tech | Access to ApexGuard; change over TM rules dual control | `ANB-CMP-POL-0001` |
| G-04 | Corporate Lending Ops | Workflow outages impacting drawdowns | `ANB-CBK-POL-0001` |
| G-05 | Treasury | Settlement window incidents & reconciliations | `ANB-TRY-MAN-0001` |
| G-06 | Finance Close | IT freeze effectiveness during close | `ANB-FIN-SOP-0003` |
| G-07 | HR IAM | JML samples | `ANB-HRM-SOP-0007` |
| G-08 | Legal/Privacy | Breach notification clock evidence if personal data INC | `ANB-LEG-POL-0004/0005` |

---

## 13. Workflow — Evidence Request

```
Auditor creates evidence request in ApexServe
   → Owner fulfils (logs, screenshots, CHG/INC exports)
   → Store hash/link in ApexAudit workpaper
   → Classify per ANB-ISC-STD-0004
   → Retain per engagement retention
```

---

## 14. Approval Matrix

| Item | Approver |
|---|---|
| Checklist methodology changes | CAE |
| Module N/A on engagement | Engagement Lead + Reviewer |
| Sample size reduction below guide | Head of Audit Quality |

---

## 15. Decision Tree — Raise Observation?

```
Exception identified?
   ├─ Isolated / compensating control effective / immaterial → Document PE or coaching point
   ├─ Pattern or Tier 1 impact → OBS- (rate severity)
   └─ Suspected misconduct / fraud → Pause; escalate CAE + Legal/HR protocols
```

---

## 16. Realistic Example

For `AUD-2026-0142`, Module B-03 failed on emergency PIR completeness → `OBS-2026-0142-01` (High) in `ANB-IAD-RPT-0001`. Module C-05 failed on mobile timeout cluster → `OBS-2026-0142-04`. Module E-02 passed with DR test evidence linked to ApexOnline `SRV-`.

---

## 17. Related Documents

`ANB-IAD-CHT-0001` · `ANB-IAD-RPT-0001` · `ANB-IAD-TPL-0001` · `ANB-OPS-*` · `ANB-ITO-*` · `ANB-ISC-*` · `ANB-CMP-POL-0001` · `ANB-RSK-POL-0001` · `ANB-FIN-SOP-0003` · `ANB-RTL-*` · `ANB-CBK-*` · `ANB-TRY-MAN-0001` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-ADM-MTX-0001`

---

## 18. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | Audit Practice | Initial enterprise checklist |

---

## Appendix A — Standard Sample Size Guide (Risk-Based)

| Population risk | Attribute sample | Control frequency daily |
|---|---|---|
| High / Tier 1 | 25–40 | 25–40 days |
| Medium | 15–25 | 15–25 |
| Low | 10–15 | 10–15 |

---

## Appendix B — Workpaper Naming

`AUD-########_WP_<Module>-<CheckID>_v#.pdf` in ApexAudit / ApexDocs.

---

**End of Document** — `ANB-IAD-CHK-0001` v1.0
