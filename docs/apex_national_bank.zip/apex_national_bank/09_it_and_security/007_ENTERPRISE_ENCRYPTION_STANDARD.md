# Apex National Bank — Enterprise Encryption Standard

**Technical Standard | Cryptography, PKI, HSM, Key Management, Tokenization**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-STD-0006` |
| **Document Title** | Enterprise Encryption Standard |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Security Architecture |
| **Custodian** | Omar Farouk, Head of Security Architecture (G8) — `EMP-500206` |
| **Approver** | Nadia Ferreira, CISO (G10) |
| **Classification** | Internal (C1); key-management annexes may be C2 |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-KEY`, `BP-SEC-PKI`, `BP-SEC-CLASS` |
| **System of Record** | ApexVault · HashiCorp Vault · AWS KMS · Azure Key Vault · HSM estate · Bank PKI |
| **Parent Policy** | `ANB-ISC-POL-0001` |
| **Related Documents** | `ANB-ISC-STD-0002`, `ANB-ISC-STD-0004`, `ANB-ISC-STD-0005`, `ANB-ISC-STD-0007`, `ANB-LEG-POL-0005`, `ANB-ITO-PLN-0002` |

---

## 2. Purpose

Mandate approved cryptographic algorithms, key lifecycle controls, and encryption coverage for data at rest, in transit, and in use — protecting customer NPI, payment integrity, and Highly Restricted materials across ApexCore, cloud, and backups.

---

## 3. Scope

All systems processing Bank data, including SaaS under CASB, developer tooling, AI/ML platforms, and third-party connections. Deprecated algorithms must be inventoried and remediated under `BP-SEC-VULN`.

---

## 4. Approved Algorithms

| Use | Approved | Prohibited / Legacy |
|---|---|---|
| Symmetric | **AES-256-GCM** (preferred); AES-256-CBC with HMAC where GCM unavailable | DES, 3DES, RC4 |
| Hashing | SHA-256, SHA-384, SHA-512; SHA-3 where required | MD5, SHA-1 (except constrained legacy HMAC until migrated) |
| Asymmetric | **RSA-2048** minimum (3072 preferred for new CA); **ECC** P-256/P-384 | RSA-1024 |
| Key exchange / TLS | TLS 1.2+ (1.3 preferred); ECDHE | SSL, TLS 1.0/1.1 |
| Password storage | Argon2id / bcrypt / PBKDF2-HMAC-SHA256 per IdP | Reversible encryption of passwords |
| Code signing | Bank-approved RSA/ECC with HSM-backed keys | Self-signed prod signing |

---

## 5. TLS

**ENC-TLS-1.** External and internal Tier 1 services: TLS 1.2+; prefer TLS 1.3.  
**ENC-TLS-2.** Certificate from Bank PKI or approved public CA; track as `CRT-########`.  
**ENC-TLS-3.** Disable weak ciphers; HSTS on public web.  
**ENC-TLS-4.** mTLS for service-to-service where ApexCore / payments / identity Tier 0.  
**ENC-TLS-5.** F5 / reverse proxies terminate only with approved certs; no plaintext backend for C3 without compensating control and exception.

---

## 6. HSM, PKI, Certificate Authority

| Component | Standard |
|---|---|
| **HSM** | FIPS 140-2/3 Level 3 for payment / root CA / master keys `KEY-########` |
| **Bank CA** | Offline root; issuing intermediates online; CRL/OCSP |
| **Public CA** | Approved vendors only; CAA records |
| **Certificate inventory** | ApexMonitor + PKI DB; expiry metric `SEC-M-008` |
| **Private keys** | Never export from HSM without dual control ceremony |

Key IDs: `KEY-########`. Certificates: `CRT-########`. Vault paths: `VAULT-SEC-########`.

---

## 7. Key Lifecycle

```
Generate (HSM/KMS/Vault) → KEY-########
        → Assign owner APP-SEC- / AST-
        → Distribute via Vault/KMS policy
        → Use (encrypt/decrypt/sign)
        → Rotate (schedule / event)
        → Suspend / Revoke
        → Destroy / zeroize (dual control)
```

| Key Type | Rotation |
|---|---|
| TLS certs | ≤ validity; renew ≥ 30 days before expiry |
| Application DEK | ≤ 365 days or volume trigger |
| KEK / master | Ceremony-based ≤ 2 years |
| API / HMAC secrets | ≤ 90 days |
| Code signing | Per release policy; compromise immediate |

---

## 8. Key Escrow and Recovery

Production data encryption keys must support enterprise recovery via dual-control escrow / KMS key policies so that DR (`ANB-ITO-PLN-0002`) can restore. Escrow of **user** personal passphrase keys is prohibited. Break-glass key ceremonies logged; Legal notified if customer data involved.

---

## 9. Encryption by Layer

| Layer | Requirement |
|---|---|
| **Disk / volume** | BitLocker / LUKS / cloud volume encryption on all servers & laptops |
| **Database** | TDE or equivalent for Tier 1 DBs; column/field encryption for PAN, SSN/NIN, auth secrets |
| **Field / application** | Application-level encrypt for Highly Restricted elements; keys in Vault/KMS not app config |
| **Backup** | Encrypted backups; keys separate from backup media; tested restore |
| **Secrets** | HashiCorp Vault / CyberArk / Azure Key Vault / AWS KMS — never plaintext in repos |
| **Email / files** | Purview encryption for ≥ Confidential external |

---

## 10. Cloud KMS

| Platform | Control |
|---|---|
| **AWS KMS** | CMK with key policies; CloudTrail; no unchecked plaintext export |
| **Azure Key Vault** | RBAC; soft-delete; purge protection for prod |
| **ApexVault** | Bank wrapper / policy plane over Vault & KMS |

Cross-cloud key replication only with Architecture + CISO approval.

---

## 11. Tokenization

PAN and selected identifiers tokenized via approved payment/tokenization services. Tokens are not a substitute for access control. Detokenization dual-controlled; logged; restricted roles (`ROLE-`). Aligns with PCI overlays and Retail card processes.

---

## 12. Workflows

### Certificate Renewal

```
Alert T-60/T-30/T-14 → Owner renews CRT-
        → Deploy via automation
        → Validate TLS
        → Revoke old if replaced early
```

### Key Rotation

```
Schedule / INC- compromise → Generate new KEY-
        → Re-encrypt or envelope rotate
        → Retire old key after crypto period
        → Evidence in ApexServe change
```

---

## 13. Metrics

| Metric | Target |
|---|---|
| Encryption coverage Tier 1 data stores | 100% |
| TLS weak protocol findings | 0 |
| Certificate expiry outages | 0 |
| Keys past rotation policy | 0 material |
| Secrets in plaintext code (critical) | 0 |

---

## 14. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-STD-0004` · `ANB-ISC-STD-0005` · `ANB-ISC-STD-0007` · `ANB-ISC-SOP-0003` · `ANB-ITO-PLN-0002` · `ANB-LEG-POL-0005` · `ANB-RTL` card/PCI overlays · `ANB-ADM-MTX-0001`

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | O. Farouk | Initial Enterprise Encryption Standard |

---

## Appendix A — Example Entity Bindings

| Entity | Example |
|---|---|
| `KEY-90010001` | ApexCore TDE KEK (HSM) |
| `CRT-90020001` | apexonline.anb.com TLS |
| `VAULT-SEC-90030001` | Payments HMAC secret path |

---

**End of Document** — `ANB-ISC-STD-0006` v1.0
