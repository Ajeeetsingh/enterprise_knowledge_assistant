# Apex National Bank — Password and Authentication Standard

**Technical Standard | Passwords, MFA, Passkeys, Secrets, PAM, and Break-Glass**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-STD-0002` |
| **Document Title** | Password and Authentication Standard |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Identity |
| **Custodian** | Tobias Lindgren, Head of Identity & Access (G8) — `EMP-500202` |
| **Approver** | Nadia Ferreira, CISO (G10) — `EMP-100010` |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-IAM`, `BP-CST-AUTH`, `BP-DIG-ENRL` |
| **System of Record** | ApexID · Microsoft Entra ID · CyberArk · HashiCorp Vault |
| **Parent Policy** | `ANB-ISC-POL-0001` |
| **Related Documents** | `ANB-ISC-POL-0003`, `ANB-ISC-STD-0005`, `ANB-ISC-STD-0006`, `ANB-LEG-POL-0005` |

---

## 2. Purpose

Define authentication assurance requirements for workforce, privileged, service, API, and customer-facing channels so that credentials are resistant to phishing, stuffing, and insider abuse.

---

## 3. Scope

All identities `USR-########`, service accounts, API keys, certificates `CRT-########`, SSH keys, and vault secrets `VAULT-SEC-########` / `KEY-########`. Customer authentication overlays in digital/CST standards remain aligned to this baseline.

---

## 4. Password Requirements (Human Interactive)

| Control | Requirement |
|---|---|
| Length | ≥ 14 characters (passphrase preferred) |
| Complexity | Block known-breached passwords (Entra banned list) |
| Rotation | Not forced periodically if MFA + no compromise; **forced on compromise / 365 days max for non-MFA legacy** |
| History | Last 24 passwords |
| Lockout | 10 failures / 15 minutes (adaptive risk may tighten) |
| Storage | Salted hash only; never reversible |
| Sharing | **Prohibited** — Code of Conduct violation |

Local admin passwords on endpoints managed via LAPS / CyberArk; users must not set standing local admin.

---

## 5. MFA and Passkeys

**AUTH-MFA-1.** MFA mandatory for: all remote access; all privileged access; all Tier 1 application interactive login; VPN/ZTNA; email web access.

**AUTH-MFA-2.** Preferred factors: phishing-resistant — **FIDO2 / passkeys**, certificate-based, or number matching authenticator app. SMS OTP is **legacy restricted** (exception `BP-SEC-EXC` only).

**AUTH-MFA-3.** Customer MFA for ApexMobile/ApexOnline per digital standards; step-up for wires/payees (`ANB-RTL-GDL-0002`, `BP-CST-AUTH`).

---

## 6. Service Accounts and Machine Identities

| Rule | Requirement |
|---|---|
| Ownership | Named human owner + application `APP-SEC-` |
| Password | ≥ 32 chars random; stored only in CyberArk / Vault |
| Interactive logon | Disabled where technically feasible |
| Rotation | ≤ 90 days automated |
| Kerberos / gMSA | Prefer over static passwords |
| Monitoring | Non-owner use → `ALERT-` |

Identity: `USR-SVC-########` pattern in ApexID.

---

## 7. API Keys, Secrets, Credential Vault

**AUTH-SEC-1.** Secrets never in source code, tickets, or chat. Pre-commit / ApexBuild secrets scanning mandatory (`ANB-ISC-STD-0007`).

**AUTH-SEC-2.** Store in **CyberArk**, **HashiCorp Vault**, **Azure Key Vault**, or **AWS KMS**-backed stores — path ID `VAULT-SEC-########`.

**AUTH-SEC-3.** API keys: scoped, short-lived where possible, rotatable; dual control for production retrieval.

**AUTH-SEC-4.** CI/CD injects secrets at runtime; no plaintext in Jenkins/GitHub logs.

---

## 8. Admin Accounts and PAM

| Account Type | Control |
|---|---|
| Named privileged (`USR-ADM-`) | Separate from standard `USR-`; MFA phishing-resistant |
| Domain/Enterprise Admin | Break-glass + JIT via CyberArk; standing membership prohibited |
| Cloud Global Admin | PIM eligible; approval + MFA |
| Database sa / root | Vaulted; checkout recorded |
| Session | CyberArk recording; `RULE-SEC-` anomaly detection |

---

## 9. Break-Glass Accounts

| Attribute | Standard |
|---|---|
| Purpose | Entra / AD / ApexCore emergency only |
| Count | Minimal documented set |
| Storage | Offline + CyberArk dual control |
| MFA | Hardware key where possible |
| Use | Incident `INC-########` required within 1 hour of use |
| Review | Quarterly by `EMP-500202` + CISO |
| Monitoring | Real-time `ALERT-` to SOC |

---

## 10. Certificates, SSH, Developer Auth

| Method | Standard |
|---|---|
| Certificate auth | Bank PKI `CRT-########`; lifecycle `ANB-ISC-STD-0005` / `0006` |
| SSH keys | Ed25519/RSA-4096; registered; no shared keys; rotate on leaver |
| Developer | SSO to GitHub Enterprise via Entra; PAT least privilege + expiry ≤ 90 days |
| Code signing | Approved certs only; private keys in HSM/Vault |

---

## 11. Authentication Policies (Entra Conditional Access)

Baseline policies: require MFA; block legacy auth; require compliant/hybrid-joined device for Tier 1 apps; risk-based block/challenge; named locations for break-glass only.

Exceptions: `IAM-########` + `BP-SEC-EXC`.

---

## 12. Workflows

### Password Reset (Workforce)

```
User → Entra SSPR (MFA gated) OR Service Desk identity proofing
        → Reset → Force MFA re-registration if compromise suspected
        → ApexShield watchlist 72h
```

### Credential Compromise

```
ALERT- / report → Disable/reset credentials → Revoke sessions/tokens
        → INC- (ANB-ISC-SOP-0003) → Hunt IOC- → User coaching
```

### Emergency Access

```
Request IAM-######## → Dual approval Identity + CISO-on-call
        → CyberArk checkout → Time-bound → Auto revoke → Post-use review
```

---

## 13. Metrics

| Metric | Target |
|---|---|
| MFA coverage workforce | 100% |
| Phishing-resistant MFA for privileged | ≥ 95% by FY26 YE |
| Secrets in code findings critical open | 0 |
| Break-glass use without INC- | 0 |
| Service account password age > 90d | 0 |

---

## 14. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-POL-0003` · `ANB-ISC-STD-0005` · `ANB-ISC-STD-0006` · `ANB-ISC-STD-0007` · `ANB-ISC-SOP-0003` · `ANB-HRM-POL-0004` · `ANB-LEG-POL-0005` · `ANB-RTL-MAN-0004` · `ANB-ADM-MTX-0001`

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | T. Lindgren | Initial password & authentication standard |

---

## Appendix A — Banned Practices

Shared passwords; password in email; SMS MFA for privileged; long-lived PATs without expiry; embedding secrets in mobile apps; disabling MFA “temporarily” without exception record.

---

**End of Document** — `ANB-ISC-STD-0002` v1.0
