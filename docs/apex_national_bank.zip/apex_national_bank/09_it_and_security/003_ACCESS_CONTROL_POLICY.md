# Apex National Bank — Access Control Policy

**Enterprise Policy | RBAC, ABAC, SoD, JML, Privileged and Third-Party Access**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-POL-0003` |
| **Document Title** | Access Control Policy |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Identity |
| **Custodian** | Tobias Lindgren, Head of Identity & Access (G8) — `EMP-500202` |
| **Approver** | Nadia Ferreira, CISO (G10) |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-IAM`, `BP-SEC-RECERT`, `BP-HR-ONB`, `BP-HR-EXIT` |
| **System of Record** | ApexID · ApexServe · ApexPeople · CyberArk |
| **Parent Policy** | `ANB-ISC-POL-0001` |
| **Related Documents** | `ANB-ISC-STD-0002`, `ANB-ISC-STD-0005`, `ANB-HRM-SOP-0007`, `ANB-LEG-AGR-0002` |

---

## 2. Purpose

Ensure access to systems and data is authorized, proportionate, reviewed, and revoked timely — enforcing least privilege, need-to-know, and segregation of duties across the Bank.

---

## 3. Scope

All logical access to Bank systems and data by workforce `USR-########`, vendors, and non-human identities. Physical badge access governed with ADM (`ApexAccess`) under this Policy’s principles.

---

## 4. Access Models

| Model | Use |
|---|---|
| **RBAC** | Default — roles `ROLE-########` / groups `GRP-########` |
| **ABAC** | Attribute rules (department, clearance, device posture, location) via Conditional Access |
| **PBAC** | Policy-based for cloud admin (Entra PIM) |

Standing access beyond role requires documented exception.

---

## 5. Least Privilege and Need-to-Know

**AC-1.** Grant minimum rights for job function.  
**AC-2.** C2/C3 data access requires business justification and classification awareness (`ANB-ISC-STD-0004`).  
**AC-3.** Production data access for support is JIT / break-glass where feasible.  
**AC-4.** Read vs write vs approve separated for SOX-relevant processes (`ANB-FIN-SOP-0003`).

---

## 6. Segregation of Duties (SoD)

| Conflict Example | Control |
|---|---|
| Request + approve same access | Workflow dual control |
| Developer + production deploy alone | CAB + gated pipeline (`ANB-ISC-STD-0007`) |
| AP create vendor + approve payment | Finance SoD matrix |
| Credit analyst + unilaterally approve above limit | Credit authority (`ANB-CBK-POL-0001`) |
| Trade Ops issue LC + release payment without control | Dual control |

SoD conflicts detected in ApexID; must be mitigated or exception-approved.

---

## 7. Privileged Access

Governed by `ANB-ISC-STD-0002` PAM section. Privileged = admin, root, data-exfil capable, security tool admin, or ability to alter financial ledgers.

Quarterly recertification 100% (`BP-SEC-RECERT`, metric `SEC-M-006`).

---

## 8. Joiner–Mover–Leaver (JML)

### Joiner

```
Offer accepted → ApexPeople EMP-
        → Background clear (ANB-HRM-SOP-0007)
        → ApexID creates USR-########
        → Birthright ROLE- + manager-requested IAM-
        → No access before start date / clearance
```

### Mover

```
Position change in ApexPeople
        → Auto-remove prior role entitlements (delta)
        → New ROLE- provisioning
        → Manager certification within 14 days
```

### Leaver

```
Termination / resignation flagged
        → Same-day disable USR- (immediate for involuntary)
        → Revoke tokens, VPN, badges, CyberArk
        → Mailbox / data disposition per HR/Legal
        → Privileged checkout kill
```

Branch cash roles: dual-control reassignment per `ANB-RTL-SOP-0006` / Leave Policy consecutive absence.

---

## 9. Access Reviews

| Population | Frequency | Reviewer |
|---|---|---|
| Privileged | Quarterly | Owner + Identity |
| SOX / financial apps | Quarterly | Control owner |
| Standard business apps | Semi-annual | Manager |
| Vendor accounts | Quarterly | Sponsor + TPRM |
| C3 repositories | Quarterly | Named ACL owner |

Non-response → access suspended after escalation.

---

## 10. Emergency Access

Time-bound elevated access via CyberArk / PIM:

1. `IAM-########` emergency request  
2. Dual approve (Identity on-call + system owner or CISO on-call)  
3. Max 4–24 hours by severity  
4. Auto-expire; session recorded  
5. Post-incident review if used during `INC-`

---

## 11. Shared Accounts

**Prohibited** for interactive human use. Technical shared IDs only if vaulted, monitored, and approved exception. Branch teller IDs are **named** `TEL-####` mapped to `USR-` — not shared drawers credentials.

---

## 12. Remote Access

ZTNA / VPN with MFA device compliance. Copy/paste and local download controls for C2/C3 apps. Remote work per `ANB-HRM-POL-0003`.

---

## 13. Vendor and Third-Party Access

| Requirement | Standard |
|---|---|
| Identity | Named vendor users or JIT vendor PAM |
| Contract | `ANB-LEG-AGR-0002` + NDA |
| TPRM | `VRA-########` cleared |
| Network | Segmented; no flat access to ApexCore |
| Duration | Match SOW; auto-disable on exit |
| Monitoring | ApexShield UEBA |

Example: ATM FLM vendor under `MSA-202605-0088` — limited `HOST-` access, no customer PII export.

---

## 14. Decision Tree — Access Grant

```
Access request IAM-
        │
        ├─ Birthright role? ──► Auto if JML trigger
        ├─ SoD conflict? ──► Block / mitigate
        ├─ Privileged? ──► Extra approver + phishing-resistant MFA
        ├─ C3 data? ──► Data Owner approve
        └─ Vendor? ──► Sponsor + TPRM + expiry
```

---

## 15. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-STD-0005` · `ANB-ISC-STD-0004` · `ANB-ISC-SOP-0003` · `ANB-HRM-SOP-0007` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0003` · `ANB-FIN-SOP-0003` · `ANB-CBK-POL-0001` · `ANB-RSK-FRM-0002` · `ANB-LEG-AGR-0002` · `ANB-ADM-MTX-0001`

---

## 16. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | T. Lindgren | Initial Access Control Policy |

---

## Appendix A — Role Examples

| ROLE ID | Description |
|---|---|
| `ROLE-TEL-BRANCH` | Branch teller ApexTeller |
| `ROLE-RM-CMB` | Commercial RM ApexOrigin/Apex360 |
| `ROLE-SOC-T1` | SOC Tier 1 analyst |
| `ROLE-PAM-CHECKOUT` | Eligible CyberArk user |

---

**End of Document** — `ANB-ISC-POL-0003` v1.0
