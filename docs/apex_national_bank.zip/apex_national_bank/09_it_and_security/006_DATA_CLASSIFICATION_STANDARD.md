# Apex National Bank — Data Classification Standard

**Technical Standard | Classification Tiers, Handling, Labeling, Retention Mapping**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-STD-0004` |
| **Document Title** | Data Classification Standard |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Data Protection |
| **Custodian** | Aisha Rahman, ISO — Business Engagement / Data Classification Lead (G8) — `EMP-500203` |
| **Approver** | Nadia Ferreira, CISO (G10) |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-CLASS`, `BP-SEC-DLP`, `BP-LEG-PRIV`, `BP-REC-RET` |
| **System of Record** | Microsoft Purview · ApexDLP · ApexDocs · ApexData |
| **Parent Policy** | `ANB-ISC-POL-0001` |
| **Related Documents** | `ANB-LEG-POL-0004` (Privacy), `ANB-LEG-POL-0005` (Data Protection), `ANB-ADM-POL-0001` / `ANB-ADM-STD-0002` (Records Retention), Company Profile § classification model |

> **Canonical ID.** Reserved in Company Profile §15 as `ANB-ISC-STD-0004`. Five descriptive tiers below map to enterprise sensitivity codes **C0–C3** (and Highly Restricted as C3+).

---

## 2. Purpose

Establish a single Bank-wide language for data sensitivity so that handling, encryption, access, retention, and disclosure controls are applied consistently across Retail, Corporate, Finance, HR, Legal, Risk, and Technology.

---

## 3. Scope

All information created, received, processed, stored, or transmitted by or for Apex National Bank — electronic and physical — including AI training/RAG corpora and embeddings.

---

## 4. Classification Tiers

| Tier | Sensitivity Code | Definition | Examples |
|---|---|---|---|
| **Public** | C0 | Approved for unrestricted public release | Marketing web copy; published annual report excerpts; public product rates |
| **Internal** | C1 | Bank business use; not for public | Org charts; internal policies (most); non-sensitive ops metrics |
| **Confidential** | C2 | Restricted to need-to-know; harm if disclosed | Customer non-public financials; credit memos; contracts; SOC playbooks summary |
| **Restricted** | C3 | Strict need-to-know; regulatory/customer harm | Full KYC files; account numbers + identity; HR medical; M&A; privileged legal |
| **Highly Restricted** | C3+ | Extreme sensitivity; named ACL / vault | Cryptographic keys material; biometric templates; board strategy packs; large-scale breach datasets; production model weights with C3 training data |

Default for unmarked Bank documents: treat as **Internal (C1)** until classified. Customer data defaults to **Restricted (C3)** unless proven otherwise.

---

## 5. Classification Rules

**CLS-1.** Data Owner (business) assigns classification; Custodian implements controls.  
**CLS-2.** Aggregate/composite datasets take the **highest** constituent class.  
**CLS-3.** Derived data (reports, embeddings, model outputs) inherit source class unless formally declassified.  
**CLS-4.** Reclassification requires Data Owner + Privacy if personal data.  
**CLS-5.** Cross-border transfer must satisfy `ANB-LEG-POL-0004` / `0005` and encryption standard.

---

## 6. Handling Matrix (Summary)

| Control | Public | Internal | Confidential | Restricted | Highly Restricted |
|---|---|---|---|---|---|
| Access | Open | Authenticated staff | RBAC need-to-know | Named ACL / role + justification | Named dual-control ACL |
| Encryption at rest | Best practice | Required enterprise | Required | Required + key isolation | HSM / dedicated keys |
| Encryption in transit | TLS | TLS | TLS 1.2+ | TLS 1.2+ mTLS preferred | mTLS / dedicated channel |
| Email | OK | OK internal | Purview label + encrypt | Encrypt + DLP block external unless approved | No email; vault only |
| Printing | OK | Watermark recommended | Watermark + secure print | Secure print + retrieve | Prohibited unless CISO exception |
| USB / removable | N/A | Blocked by default | Blocked | Blocked | Blocked |
| Cloud | Approved public CDN | Approved SaaS | Approved with DLP | Residencies + CASB | Private enclaves / prohibited SaaS |
| Sharing external | N/A | NDA if needed | NDA + DLP | Legal + TPRM + DLP | CISO + Legal |

---

## 7. Storage, Email, Printing, Sharing

- **Storage:** ApexDocs / SharePoint with Purview labels; databases per `ANB-ISC-STD-0006`; no C3 in personal OneDrive unsanctioned.  
- **Email:** Auto-labeling where possible; ApexDLP blocks policy violations.  
- **Printing:** Follow Physical Security / clear desk (`ANB-HRM` / ADM).  
- **Sharing:** External shares expire; watermark; no public links for ≥ Confidential.  
- **USB / Physical media:** Exception `BP-SEC-EXC` only; encrypted media; chain of custody.  
- **Cloud:** ApexCloud landing zones; CASB; no shadow IT (`ANB-ISC-POL-0001`).

---

## 8. Labeling and Metadata

| Channel | Method |
|---|---|
| Office / PDF | Microsoft Purview sensitivity label |
| Email | Label + header/footer |
| Structured data | Column/table tags in catalog (ApexData) |
| Source code / secrets | Never commit C3; secrets in Vault |
| AI corpora | Dataset register + label; see `ANB-ISC-STD-0007` § AI Security |
| Physical | Cover sheet / stamp |

Metadata must include: classification, Data Owner, retention class, personal-data flag.

---

## 9. Retention Mapping

| Classification | Retention guidance |
|---|---|
| Public | Per Records Retention schedule for content type |
| Internal | Per `ANB-ADM-POL-0001` / `ANB-ADM-STD-0002` retention schedule |
| Confidential | Business + legal minimum; often 7 years financial |
| Restricted | Regulatory retention (KYC, credit, HR) — **Legal Records** owns schedule |
| Highly Restricted | Minimum necessary; destroy securely when retention ends |

Classification does **not** override legal hold. See Records Retention and Litigation Hold (`ANB-LEG` litigation SOP).

---

## 10. Relationship with Legal Privacy Policy

Personal data is classified **at least Confidential**, typically **Restricted**. Processing lawful bases, DPIA, and data subject rights follow Privacy Policy `ANB-LEG-POL-0004` and Data Protection Policy `ANB-LEG-POL-0005`. ISC implements technical controls; Legal/Privacy own legal interpretation.

---

## 11. Relationship with Records Retention

Retention periods are defined in Records Retention Policy `ANB-ADM-POL-0001` and schedule `ANB-ADM-STD-0002`. This Standard defines **how** to protect data while retained; Records defines **how long**. Conflict → Legal + CISO resolution.

---

## 12. Workflow — Classification Decision

```
Create/receive data
        → Identify Data Owner
        → Apply tier (highest wins)
        → Purview label / catalog tag
        → Access ACL aligned to ANB-ISC-POL-0003
        → DLP policies enforce
        → Retention schedule linked
```

---

## 13. Metrics

| Metric | Target |
|---|---|
| Label coverage Office 365 sensitive repos | ≥ 95% |
| DLP high-severity incidents trend | Declining |
| Unlabeled C3 data stores (audit) | 0 material |
| External share exceptions aged > 90d | 0 |

---

## 14. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-POL-0003` · `ANB-ISC-STD-0006` · `ANB-ISC-STD-0007` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-ADM-POL-0001` · `ANB-ADM-STD-0002` · `ANB-CMP-POL-0001` · `ANB-HRM-POL-0002` · Company Profile

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | A. Rahman | Initial Data Classification Standard |

---

## Appendix A — Quick Examples

| Data | Class |
|---|---|
| Branch hours on website | Public |
| Internal Wiki how-to | Internal |
| Commercial credit approval memo | Confidential |
| Customer CIF + ID images | Restricted |
| HSM master key backup | Highly Restricted |
| RAG chunk of KYC PDF | Restricted (inherits) |

---

**End of Document** — `ANB-ISC-STD-0004` v1.0
