# Apex National Bank — Identity and Access Management Standard

**Technical Standard | Identity Lifecycle, Federation, SSO, and Machine Identities**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-STD-0005` |
| **Document Title** | Identity and Access Management Standard |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Identity |
| **Custodian** | Tobias Lindgren, Head of Identity & Access (G8) — `EMP-500202` |
| **Approver** | Nadia Ferreira, CISO (G10) |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-IAM`, `BP-SEC-RECERT`, `BP-HR-ONB`, `BP-HR-EXIT` |
| **System of Record** | ApexID (SailPoint) · Microsoft Entra ID · Active Directory · CyberArk |
| **Parent Policy** | `ANB-ISC-POL-0001`, `ANB-ISC-POL-0003` |
| **Related Documents** | `ANB-ISC-STD-0002`, `ANB-ISC-STD-0006`, `ANB-HRM-SOP-0007`, `ANB-LEG-POL-0005` |

> **Note.** Company Profile §15 reserves `ANB-ISC-STD-0004` for **Data Classification**. This IAM Standard is published as **`ANB-ISC-STD-0005`**.

---

## 2. Purpose

Specify how identities are proofed, provisioned, federated, and deprovisioned across directory services, cloud IdP, applications, and non-human identities — forming the operational backbone of Zero Trust.

---

## 3. Scope

Workforce, contractor, vendor, service, and machine identities. Customer identities (ApexOnline/ApexMobile) follow digital IAM annex aligned to this Standard’s assurance principles.

---

## 4. Identity Lifecycle

```
Plan → Proof → Create USR- → Provision ROLE-/GRP-
        → Authenticate (SSO/MFA)
        → Recertify
        → Modify (mover)
        → Suspend / Deprovision
        → Archive identity record
```

Authoritative HR source: **ApexPeople** → **ApexID** (SailPoint) → **Entra ID** / **AD**.

---

## 5. Identity Proofing

| Population | Proofing |
|---|---|
| Employee | HR screening `ANB-HRM-SOP-0007`; government ID |
| Contractor | Vendor attestation + screening overlay |
| Vendor user | Sponsor validation + MSA user schedule |
| Privileged | In-person or approved video proofing + manager |

Impersonation-resistant binding before phishing-resistant MFA registration.

---

## 6. Provisioning and Deprovisioning

| Event | Automation |
|---|---|
| Hire | Create `USR-########`; birthright `ROLE-`; mailbox; MFA enroll |
| Transfer | Entitlement delta via SailPoint |
| Terminate | Disable ≤ 4 hours routine / **immediate** involuntary |
| Vendor end | Expiry date enforced; sponsor alert T-14 |

Manual provisioning only via `IAM-########` with audit trail when connector absent.

---

## 7. SSO, SAML, OIDC, OAuth

| Protocol | Use |
|---|---|
| **SAML 2.0** | Enterprise apps SSO |
| **OIDC** | Modern apps / APIs interactive |
| **OAuth 2.0** | Delegated API access; PKCE for public clients |
| Forbidden | Resource-owner password grant; long-lived bearer without rotation |

App registrations owned by application `APP-SEC-########` owner; Entra admin consent gated.

---

## 8. Directory Services

| Directory | Role |
|---|---|
| **Active Directory** | On-prem authN/authZ; Tier 0 hardening |
| **Microsoft Entra ID** | Cloud IdP; Conditional Access; PIM |
| **LDAP** | Legacy apps — migrate plan required |
| **SCIM** | Automated app user provisioning where supported |

Tier 0 (AD/Entra identity systems) access tightly PAM-controlled.

---

## 9. Identity Federation

Federation to approved partners only (e.g., cloud SaaS, regulated utilities). Inbound federation requires security review. B2B guest accounts: sponsor, expiry ≤ 12 months, MFA, periodic review.

---

## 10. Service and Machine Identities

| Type | Pattern | Control |
|---|---|---|
| Service account | `USR-SVC-*` | Vaulted; no interactive |
| Workload identity | Entra managed identity / AWS IAM role | Prefer over keys |
| Certificate identity | `CRT-########` | Auto-renew; monitor expiry `SEC-M-008` |
| API client | OAuth client credentials | Secret in Vault; rotate ≤ 90d |

---

## 11. Certificate Lifecycle

1. Request via PKI portal / ACME where approved  
2. Approve (app owner)  
3. Issue `CRT-########`  
4. Deploy via automation  
5. Monitor expiry (ApexMonitor / PKI alerts at 60/30/14 days)  
6. Revoke on compromise / decommission  

Public TLS and internal mTLS covered; see `ANB-ISC-STD-0006`.

---

## 12. Workflow — Identity Provisioning

```
ApexPeople hire event
        → SailPoint cube USR-
        → Birthright + requested access
        → Approvals (manager / SoD / Data Owner)
        → Connectors: Entra, AD, ApexCore entitlements, GitHub, etc.
        → Joiner checklist complete
```

---

## 13. Metrics

| Metric | Target |
|---|---|
| Joiner access ready by start date | ≥ 95% |
| Leaver disable same day | 100% involuntary; ≥ 99% voluntary |
| Orphan accounts | 0 privileged; ≤ 0.1% standard |
| SSO coverage Tier 1 apps | ≥ 98% |
| Certificate expiry incidents | 0 |

---

## 14. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-POL-0003` · `ANB-ISC-STD-0002` · `ANB-ISC-STD-0004` · `ANB-ISC-STD-0006` · `ANB-ISC-STD-0007` · `ANB-HRM-SOP-0007` · `ANB-HRM-POL-0003` · `ANB-LEG-POL-0005` · `ANB-DIG` API (`BP-DIG-API`)

---

## 15. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | T. Lindgren | Initial IAM standard (STD-0005) |

---

## Appendix A — Identity Types

| Prefix | Meaning |
|---|---|
| `USR-` | Human |
| `USR-SVC-` | Service |
| `USR-VEN-` | Vendor |
| `USR-ADM-` | Privileged human |

---

**End of Document** — `ANB-ISC-STD-0005` v1.0
