# Apex National Bank — Cyber Incident Response Plan

**Standard Operating Procedure | CSIRT, SOC, Containment, Forensics, Regulator Notification**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-SOP-0003` |
| **Document Title** | Cyber Incident Response Plan |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Cyber Defence |
| **Custodian** | Marta Bauer, Head of Cyber Defence (G8) — `EMP-500201` |
| **Operational Lead** | Kevin Zhao, SOC Manager (G7) — `EMP-500204` |
| **Approver** | Nadia Ferreira, CISO (G10) — `EMP-100010` |
| **Classification** | Confidential (C2) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-IR`, `BP-SEC-SOC`, `BP-LEG-REG`, `BP-RSK-INC` |
| **System of Record** | ApexSOC · ApexSIEM · ApexShield · ApexServe · ApexDocs |
| **Parent Policy** | `ANB-ISC-POL-0001` |
| **Related Documents** | `ANB-RSK-POL-0001`, `ANB-RSK-FRM-0001`, `ANB-ITO-PLN-0002`, `ANB-LEG-SOP-0007`, `ANB-LEG-POL-0004`, `ANB-LEG-POL-0005`, `ANB-CMP-POL-0001` |
| **Linked Scenario** | `SCN-2026-CYB-001` (ransomware tabletop) |

---

## 2. Purpose

Define how Apex National Bank prepares for, detects, analyses, contains, eradicates, and recovers from cyber security incidents — including forensics, communications, executive escalation, and regulatory notification — while preserving evidence and customer trust.

---

## 3. Scope

All cyber security events affecting Bank systems, data, personnel, third parties, or customers — including malware, ransomware, insider threat, data breach, credential compromise, DDoS, supply-chain compromise, and AI/LLM abuse against Bank platforms.

---

## 4. Roles

| Role | Responsibility |
|---|---|
| **SOC (ApexSOC)** | 24×7 detect, triage, escalate; own `ALERT-########` |
| **CSIRT** | Lead investigation; declare incident `INC-########`; coordinate containment |
| **Forensics** | Evidence acquisition; chain of custody; malware analysis |
| **CISO** | Severity SEV-1/2 authority; Board/EXCO briefing |
| **ITO / Platform** | Technical recovery; DR activation (`ANB-ITO-PLN-0002`) |
| **Legal** | Privilege; regulator counsel (`ANB-LEG-SOP-0002`) |
| **Privacy / DPO** | Personal data breach assessment (`ANB-LEG-POL-0005`) |
| **Comms / Marketing** | External messaging approval |
| **Compliance** | Regulatory mapping; SAR/MLRO if crime proceeds |
| **Business Owner** | Customer impact; product decisions |

---

## 5. Severity Matrix

| Severity | Definition | Examples | SOC SLA (ack) | Exec notify |
|---|---|---|---|---|
| **SEV-1 Critical** | Material customer/market impact; ransomware; large C3 breach; core payment outage cyber-caused | `SCN-2026-CYB-001`; ApexCore integrity attack | 15 min | CISO + COO + CEO within 1h |
| **SEV-2 High** | Significant system/data impact; confirmed intrusion Tier 1 | Credential dump AD; vendor remote exploit | 30 min | CISO within 2h |
| **SEV-3 Medium** | Contained malware; limited data exposure; phishing campaign success | Workstation ransomware blocked mid-encrypt | 1h | Cyber Defence Head |
| **SEV-4 Low** | Policy violation / suspicious activity closed as benign after analysis | Failed brute force blocked | Next business day | As needed |
| **SEV-5 Info** | Intel / hunt finding no confirmed incident | New IOC watchlist | Per hunt schedule | N/A |

Severity may escalate/de-escalate with evidence.

---

## 6. Incident Lifecycle (NIST-Aligned)

### 6.1 Preparation

- Playbooks in ApexDocs / Confluence  
- Runbooks in ApexSOC  
- Tools: Microsoft Sentinel, Splunk (ApexSIEM), CrowdStrike, Palo Alto, Defender, CyberArk  
- Tabletop ≥ 2×/year including `SCN-2026-CYB-001`  
- Out-of-band contact trees; break-glass accounts (`ANB-ISC-STD-0002`)  
- Evidence kits; legal hold procedures with Legal  

### 6.2 Detection

Sources: ApexSIEM correlation `RULE-SEC-########`; CrowdStrike; email security; DLP ApexDLP; identity UEBA; threat intel `IOC-########`; user reports; vendor notices.

All detections create `ALERT-########` → triage → promote to `INC-########` when confirmed or high confidence.

### 6.3 Analysis

CSIRT determines: scope, TTPs, assets `HOST-`/`AST-`/`APP-SEC-`, data classification impact, customer impact, persistence, attribution (working hypothesis only).

Preserve logs (≥ 12 months SIEM retention for Tier 0/1). Engage forensics before destructive remediation when SEV-1/2.

### 6.4 Containment

| Short-term | Long-term |
|---|---|
| Isolate `HOST-` via CrowdStrike / NAC | Credential reset / golden ticket remediation |
| Block IOC at Palo Alto / F5 / email gateway | Segment redesign; patch |
| Disable `USR-` / revoke tokens | Kill C2; remove persistence |
| Freeze privileged checkouts | Vendor kill-switch |

**Ransomware:** Do **not** pay without EXCO + Legal + Cyber Insurance coordination; preserve backups; activate IR + DR.

### 6.5 Eradication

Remove malware, backdoors, rogue accounts, malicious apps, poisoned artifacts (including poisoned RAG documents — see `ANB-ISC-STD-0007` AI Security). Validate with hunt.

### 6.6 Recovery

Restore from known-good backups; staged reconnect; enhanced monitoring 30–90 days; business verification with product owners (Retail/Corporate/Payments). Link DR if applicable (`ANB-ITO-PLN-0002`).

### 6.7 Lessons Learned

Within 15 business days of closure: PIR in ApexServe; update playbooks; risk entry if control gap (`ANB-RSK-POL-0001`); training if human factor.

---

## 7. Playbooks (Mandatory Minimum Set)

| Playbook ID | Scenario |
|---|---|
| `PB-SEC-MAL` | Malware / endpoint compromise |
| `PB-SEC-RAN` | Ransomware |
| `PB-SEC-PHISH` | Credential phishing success |
| `PB-SEC-BEC` | Business email compromise |
| `PB-SEC-INS` | Insider threat / data exfil |
| `PB-SEC-BRCH` | Data breach / privacy |
| `PB-SEC-DDOS` | DDoS |
| `PB-SEC-SUP` | Supply-chain / CI-CD compromise |
| `PB-SEC-PRIV` | Privilege escalation |
| `PB-SEC-AI` | LLM/prompt abuse / knowledge leakage |

Each playbook: detection signatures, containment steps, evidence list, comms templates, regulator tags.

---

## 8. Communication and Escalation

```
ALERT- → SOC T1 → SOC T2/CSIRT → INC- declared
        → Severity set
        → SEV-1/2: CISO bridge; Legal; Privacy; Comms; ITO
        → ORC / EXCO / Board per materiality (ANB-RSK / Governance)
        → Customer notification if required (Legal + Privacy + Retail/CB)
        → Regulator notification (ANB-LEG-SOP-0002)
```

**Regulator notification:** Per jurisdiction (e.g., material cyber incident to supervisory authority; GDPR/UK GDPR 72-hour personal data breach where applicable). Legal owns filing under `ANB-LEG-SOP-0007`; Compliance tracks; CISO owns technical facts.

**Do not** publicly disclose without Legal/Comms approval.

---

## 9. Forensics and Evidence

- Write-block / snapshot before remediation when feasible  
- Chain of custody log in INC- record  
- Malware samples handled in isolated lab  
- Legal privilege asserted on investigation work product when counsel directs  
- Coordinate with Law Enforcement only via Legal  

---

## 10. Specific Scenario Controls

### Ransomware (`PB-SEC-RAN` / `SCN-2026-CYB-001`)

Isolate; identify encryption scope; assess backup integrity offline; engage EXCO; consider insurance; customer payment continuity plan with COO/ITO.

### Insider Threat (`PB-SEC-INS`)

Coordinate HR (`ANB-HRM-POL-0004`), Legal, Privacy; avoid tipping subject if investigation active; preserve mailbox/endpoint; access freeze.

### Data Breach (`PB-SEC-BRCH`)

Classify data (`ANB-ISC-STD-0004`); Privacy DPIA/breach assessment; customer/regulatory letters; credit monitoring if approved; link `ANB-LEG-POL-0005`.

### Credential Compromise

Immediate disable/reset; session revocation; hunt lateral movement; PAM review (`ANB-ISC-STD-0002`).

---

## 11. Metrics

| Metric | Target |
|---|---|
| MTTD (critical) | ≤ 15 min from high-fidelity alert |
| MTTR SEV-1 containment | ≤ 4 hours |
| SOC SLA ack SEV-1 | ≥ 99% within 15 min |
| PIR completion | 100% SEV-1/2 within 15 BD |
| False positive rate (tuned rules) | Trend down QoQ |

---

## 12. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-POL-0003` · `ANB-ISC-STD-0004` · `ANB-ISC-STD-0007` · `ANB-RSK-POL-0001` · `ANB-RSK-FRM-0001` · `ANB-ITO-PLN-0002` · `ANB-LEG-SOP-0007` · `ANB-LEG-POL-0004` · `ANB-LEG-POL-0005` · `ANB-CMP-POL-0001` · `ANB-HRM-POL-0004` · `ANB-ADM-MTX-0001`

---

## 13. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | M. Bauer / K. Zhao | Initial Cyber IR Plan |

---

## Appendix A — Incident Record Fields (Minimum)

`INC-########` · Severity · Start/Detect time · Systems · Data classes · Customers impacted · IOCs · Containment actions · Notified parties · Regulator filings · Closure code · PIR link

---

## Appendix B — On-Call Bridge

Primary: ApexSOC hotline · Secondary: CISO on-call · Tertiary: COO (`EMP-100003`) for SEV-1 business continuity · Legal regulatory desk for notification clock.

---

**End of Document** — `ANB-ISC-SOP-0003` v1.0
