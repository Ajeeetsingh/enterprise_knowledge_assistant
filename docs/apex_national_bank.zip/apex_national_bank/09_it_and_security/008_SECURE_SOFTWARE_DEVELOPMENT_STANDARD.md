# Apex National Bank — Secure Software Development Standard

**Technical Standard | SSDLC, AppSec, Supply Chain, CI/CD, and AI / LLM / RAG Security**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-STD-0007` |
| **Document Title** | Secure Software Development Standard |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) — Application Security |
| **Custodian** | Priya Nair, Head of Application Security (G8) — `EMP-500205` |
| **Approver** | Nadia Ferreira, CISO (G10); CIO Arjun Patel (`EMP-100007`) for engineering applicability |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Business Process** | `BP-SEC-SSDLC`, `BP-SEC-VULN`, `BP-SEC-PEN`, `BP-ITO-CHG`, `BP-DIG-API` |
| **System of Record** | GitHub Enterprise · Jenkins · ApexBuild · SonarQube · Fortify · ApexScan · Jira · ServiceNow |
| **Parent Policy** | `ANB-ISC-POL-0001` |
| **Related Documents** | `ANB-ISC-STD-0002`, `ANB-ISC-STD-0004`, `ANB-ISC-STD-0005`, `ANB-ISC-STD-0006`, `ANB-ISC-SOP-0003`, `ANB-LEG-POL-0005`, `ANB-RSK-FRM-0002` |

> **Benchmark note.** Section 16 (AI Security) is a canonical evaluation corpus for knowledge systems (e.g., Knowra) regarding LLM, RAG, vector DB, and model governance controls at Apex National Bank.

---

## 2. Purpose

Ensure software and models delivering banking services are designed, built, tested, deployed, and operated securely — preventing injection, supply-chain compromise, secrets leakage, and AI-specific abuse that could harm customers or Critical Business Services.

---

## 3. Scope

All custom and configured software: ApexCore modules, digital channels, APIs, RPA, infrastructure-as-code, containers, mobile, and **AI/ML systems including RAG assistants, embedding pipelines, and evaluation harnesses**. Third-party and open-source components in the Bank SBOM are in scope.

Application identity: `APP-SEC-########`.

---

## 4. SSDLC Overview

```
Requirements → Threat Model → Secure Design
        → Implement → Code Review → SAST/SCA/Secrets
        → Build (signed) → DAST/Container scan
        → Security test / Pen (risk-based)
        → Change CAB → Deploy → Operate / Monitor
        → Vulnerability manage → Retire
```

Gate failures block promotion to Production unless risk-accepted (`BP-SEC-EXC` + CRO/CISO path for material).

---

## 5. Threat Modeling

Mandatory for Tier 1 / internet-facing / payment / identity / new AI systems. Methods: STRIDE or Bank threat-model template in Confluence. Outputs linked to Jira `SEC-` stories. Revisit on major architecture change.

---

## 6. OWASP and Secure Coding

| Baseline | Requirement |
|---|---|
| OWASP Top 10 | Design & test coverage |
| OWASP ASVS | Risk-based target level by tier |
| OWASP API Security | All external/partner APIs |
| Input validation | Server-side; parameterized queries |
| AuthN/Z | Central IdP; no custom crypto (`ANB-ISC-STD-0002` / `0006`) |
| Error handling | No stack traces to clients; correl IDs |

---

## 7. Security Testing Toolchain

| Control | Tooling | Gate |
|---|---|---|
| **SAST** | SonarQube · Fortify | Block Critical on main |
| **DAST** | Approved DAST in pre-prod | Tier 1 before go-live |
| **Dependency / SCA** | ApexScan / GitHub Dependabot | No Critical CVE without exception |
| **Container** | Image scan in ApexBuild | Base images approved only |
| **Secrets scanning** | Pre-commit + pipeline + GitHub | Block; rotate if leaked (`INC-`) |
| **IaC** | Policy-as-code | Misconfig Critical block |
| **Pen test** | `BP-SEC-PEN` annual / major release | Findings in vuln SLAs |

---

## 8. Code Review and Branch Protection

- PR required; ≥ 1 reviewer; CODEOWNERS for sensitive paths  
- No direct commit to `main`/`release`  
- Status checks: SAST, SCA, unit tests, secrets scan  
- Privileged bypass only via documented break-glass + audit  

---

## 9. Supply Chain Security and SBOM

**SSDLC-SC-1.** Generate **SBOM** (CycloneDX/SPDX) per production release; store with artifact.  
**SSDLC-SC-2.** Signed builds; provenance attestations where supported.  
**SSDLC-SC-3.** Pin versions; verify checksums for critical deps.  
**SSDLC-SC-4.** Vendor / OSS risk via TPRM when material.  
**SSDLC-SC-5.** Compromised package response: `PB-SEC-SUP` under `ANB-ISC-SOP-0003`.

---

## 10. CI/CD Security

| Control | Standard |
|---|---|
| Runners | Hardened; no shared unclean state |
| Secrets | Vault / OIDC federated; never in logs |
| Separations | Build ≠ deploy credentials; SoD with prod access |
| Environments | Dev / Test / Pre-Prod / Prod isolation |
| Deployment | Change record ApexServe; CAB for Tier 1 |
| Rollback | Tested; signed prior artifact |

Platforms: **GitHub Enterprise**, **Jenkins**, **ApexBuild**.

---

## 11. API Security

- Auth via OAuth2/OIDC; mTLS for high-risk  
- Rate limits; schema validation; least-privilege scopes  
- No excessive data in errors; PII minimization (`ANB-ISC-STD-0004`, `ANB-LEG-POL-0005`)  
- Partner APIs under MSA security schedule (`ANB-LEG-AGR-0002`)  

---

## 12. Container and Runtime

Approved base images; non-root; read-only FS where possible; network policies; runtime detection (CrowdStrike / Defender for Containers). Secrets via Vault sidecar/CSI — not env plaintext in prod.

---

## 13. Vulnerability Remediation SLAs

| Severity | Remediate Prod |
|---|---|
| Critical | ≤ 7 days (or mitigate/isolate sooner) |
| High | ≤ 30 days |
| Medium | ≤ 90 days |
| Low | Risk-based |

Tracked in ApexScan / Jira / ServiceNow; metrics feed `BP-SEC-VULN` / `SEC-M` patch compliance.

---

## 14. AI-Generated Code

Developers remain accountable. AI coding assistants: no C2/C3 data in prompts to **unapproved** public LLMs; use Bank-approved enterprise AI only. AI-suggested code requires same review, SAST, and license scanning. Do not paste secrets, customer data, or MNPI into prompts.

---

## 15. Secure Deployment Workflow

```
Merge gated PR → Signed artifact + SBOM
        → Deploy non-prod → DAST / UAT
        → Security sign-off (risk-based)
        → CAB / change IAM-
        → Prod deploy → ApexMonitor / ApexShield watch
        → Post-deploy verification
```

---

## 16. AI Security (Mandatory Dedicated Section)

This section governs Bank AI systems including assistants, copilots, RAG knowledge services (e.g., enterprise knowledge assistants), embedding pipelines, vector databases, evaluation harnesses, and model hosting — whether built in-house or procured.

### 16.1 AI Governance

| Control | Requirement |
|---|---|
| Ownership | Named Product Owner + Model Owner + `APP-SEC-########` |
| Inventory | Register in AI System Inventory (ApexRisk / ISC register) |
| Risk tier | Assess per `ANB-RSK-FRM-0002` + Privacy DPIA if personal data |
| Human oversight | Material customer decisions require human accountability |
| Acceptable use | Align Code of Conduct; no covert customer profiling beyond policy |
| Third-party AI | TPRM + Legal + ISC review; data processing terms |

### 16.2 LLM Security

| Control | Requirement |
|---|---|
| Model allowlist | Only approved models/endpoints |
| System prompts | Protected; change-controlled; not customer-writable |
| Output filtering | Block secrets, injection payloads, disallowed advice (e.g., unauthorized credit decisions) |
| Jailbreak resistance | Red-team ≥ annually for Tier 1 assistants |
| Rate / abuse | Quotas; anomaly detection `RULE-SEC-` / `ALERT-` |
| Multi-tenant isolation | Strict partition by entitlement |

### 16.3 RAG Security

| Control | Requirement |
|---|---|
| Corpus classification | Every source doc labeled (`ANB-ISC-STD-0004`); RAG inherits max class |
| Access-controlled retrieval | Vector/keyword retrieval **must enforce** caller entitlements (no “search then filter only in prompt”) |
| Citation | Prefer grounded answers with document IDs for audit |
| Freshness | Stale/revoked docs removed from index on leaver/classification change |
| Separation | HR / Legal privilege / MNPI corpora in isolated indexes |

### 16.4 Vector Database Security

| Control | Requirement |
|---|---|
| AuthN/Z | SSO/service identity; no anonymous query |
| Encryption | At rest + TLS (`ANB-ISC-STD-0006`) |
| Network | Private endpoints; no public vector DB |
| Tenancy | Namespace per sensitivity domain; C3 isolated |
| Admin access | PAM; session logged |
| Backups | Encrypted; access-controlled restore |

### 16.5 Prompt Injection

**Direct prompt injection:** Hostile user text attempts to override system instructions.

Controls: instruction hierarchy; input size limits; delimiters; output allowlists for tool calls; deny unconstrained “ignore previous instructions” tool use; SOC playbook `PB-SEC-AI`.

### 16.6 Indirect Prompt Injection

Hostile content **inside retrieved documents**, emails, or tickets that the model follows when grounded.

Controls: treat retrieved text as untrusted data; sanitize; disable automatic tool execution from retrieved content; content security scanning of corpora; separate “instructions” from “data” in prompt layout; human approval for high-risk tools (payments, wires, access changes).

### 16.7 Document Poisoning

Adversary plants malicious or misleading documents into SharePoint/Wiki/Confluence/knowledge stores to manipulate RAG.

Controls: contributor authZ; DLP; malware scan; corpus admission review for Highly Restricted indexes; integrity monitoring; rollback of index versions; incident `INC-` + forensics if suspected.

### 16.8 Model Supply Chain

| Control | Requirement |
|---|---|
| Provenance | Signed model artifacts; checksum verify |
| Base models | Approved registry only |
| Fine-tunes | Training data lineage + classification |
| Dependencies | SBOM for ML pipelines / serving images |
| Compromise response | `PB-SEC-SUP` + model revoke |

### 16.9 Embedding Security

Embeddings may leak sensitive semantics. Do not embed Highly Restricted plaintext without Architecture approval. Store embeddings at corpus classification level. Restrict similarity search APIs. Prevent bulk export of embedding tables.

### 16.10 Model Access Control

Interactive and API model access via ApexID / Entra: `ROLE-` / `GRP-`; MFA; environment separation (dev models ≠ prod). Service identities `USR-SVC-*` with least privilege. No shared API keys in notebooks — Vault `VAULT-SEC-########`.

### 16.11 Inference Logging

Log: request ID, user/service ID, timestamp, model version, tool calls, retrieval doc IDs, safety filter outcomes. **Minimize** raw prompt/response retention of C3; if retained for abuse investigation, apply retention + access controls and Legal hold rules. Logs feed ApexSIEM for `ALERT-` correlation.

### 16.12 Knowledge Leakage

Prevent model/RAG from disclosing another customer’s data, employee HR data, or MNPI across entitlement boundaries. Controls: retrieval ACL, output DLP, canary documents, red-team leakage tests, metric on cross-tenant access denials. Suspected leakage → `ANB-ISC-SOP-0003` + Privacy (`ANB-LEG-POL-0005`).

### 16.13 Synthetic Data

Synthetic datasets for test/train must not be reversible to real customers. Generation pipelines reviewed by Privacy + AppSec. Label synthetic vs production. Do not treat synthetic as Public if derived from C3 without formal assessment.

### 16.14 Model Evaluation

Pre-production evaluation: security (injection, leakage), fairness/compliance overlays where applicable, hallucination rate on golden sets, entitlement tests (user A cannot retrieve B). Results stored with release package. Regression evaluate on model or corpus change.

### 16.15 AI Governance Linkage

Escalation: Model Owner → Head of AppSec `EMP-500205` → CISO → ORC/BTR for material AI risk. Align with Enterprise Governance committees and Risk appetite. Exceptions: `BP-SEC-EXC`. Training data subject to Records Retention and Legal holds.

---

## 17. Metrics

| Metric | Target |
|---|---|
| Critical SAST/SCA open in Prod | 0 beyond SLA |
| Secrets scan escape to default branch | 0 |
| SBOM coverage Tier 1 releases | 100% |
| Pen test high findings overdue | 0 |
| RAG entitlement test pass rate | 100% before prod |
| Prompt-injection red-team findings Critical open | 0 |
| Patch compliance (apps) | ≥ 95% within SLA |

---

## 18. Related Documents

`ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-POL-0003` · `ANB-ISC-STD-0004` · `ANB-ISC-STD-0005` · `ANB-ISC-STD-0006` · `ANB-ISC-SOP-0003` · `ANB-RSK-FRM-0002` · `ANB-LEG-POL-0005` · `ANB-LEG-AGR-0002` · `ANB-ITO` change/DR · Digital API processes · `ANB-ADM-MTX-0001`

---

## 19. Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | P. Nair | Initial SSDLC standard including AI/LLM/RAG security corpus |

---

## Appendix A — Application Security Entities

| ID | Meaning |
|---|---|
| `APP-SEC-########` | Application / AI system |
| `SEC-########` | Security requirement / finding ticket |
| `RULE-SEC-########` | Detection or policy rule |
| `HOST-########` | Build/runtime host |

---

## Appendix B — Approved Tooling Snapshot

GitHub Enterprise · Jenkins · ApexBuild · SonarQube · Fortify · ApexScan · CrowdStrike · Microsoft Defender · HashiCorp Vault · CyberArk · Jira · ServiceNow · Confluence · ApexDocs

---

**End of Document** — `ANB-ISC-STD-0007` v1.0
