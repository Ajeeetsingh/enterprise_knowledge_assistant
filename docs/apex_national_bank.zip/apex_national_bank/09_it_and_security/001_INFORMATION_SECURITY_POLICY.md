# Apex National Bank — Information Security Policy

**Enterprise Policy | Security Governance, Zero Trust, SOC, and Control Accountability**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-ISC-POL-0001` |
| **Document Title** | Information Security Policy |
| **Version** | 1.0 |
| **Owner** | Information Security (ISC) |
| **Custodian** | Nadia Ferreira, Chief Information Security Officer (G10) — `EMP-100010` |
| **Approver** | CISO (`EMP-100010`) and COO Daniel K. Ortega (G11) — `EMP-100003`; Board Technology & Operational Resilience Committee (BTR) for Board-level ratification |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Effective Date** | 2026-08-01 |
| **Review Cycle** | Annual |
| **Retention** | `RET-POL-10Y` |
| **Taxonomy** | `T6` → Information Security → `POL` |
| **Business Process** | `BP-SEC-IAM`, `BP-SEC-SOC`, `BP-SEC-IR`, `BP-SEC-VULN`, `BP-SEC-EXC`, `BP-SEC-DLP` |
| **System of Record** | ApexDocs · ApexShield · ApexID · ApexRisk |
| **Related Documents** | See §18 |

> **Authority.** Apex instrument for information security. Subordinate standards (`ANB-ISC-STD-*`) and procedures (`ANB-ISC-SOP-*`) shall not weaken this Policy. Canonical security entities for Domain 9 are in Appendix A.

---

## 2. Purpose

Protect confidentiality, integrity, and availability of Apex National Bank information and technology assets supporting 41M daily ApexCore transactions, customer NPI, MNPI, and Critical Business Services (`CBS-########`), consistent with FFIEC, NIST CSF, GLBA Safeguards, and Board risk appetite (`RAM-0012` cyber Severity 1).

---

## 3. Scope

All legal entities in `ANB-ADM-REF-0001`; all employees, contractors, and vendors with system or data access; on-premises, cloud (`ApexCloud`), SaaS, and third-party connections. OT/branch devices and ATM estate (`ATM-####`) included.

---

## 4. Security Principles

| # | Principle |
|---|---|
| P1 | **Defense in Depth** — layered preventive, detective, responsive controls |
| P2 | **Zero Trust** — never trust, always verify; continuous authentication/authorization |
| P3 | **Least Privilege / Need-to-Know** — minimum access for role (`ANB-ISC-POL-0003`) |
| P4 | **Secure by Design** — security in SSDLC (`ANB-ISC-STD-0007`) |
| P5 | **Assume Breach** — detect, contain, recover (`ANB-ISC-SOP-0003`) |
| P6 | **Accountability** — named asset owners; logged privileged actions |
| P7 | **Risk-Based** — controls proportionate; exceptions via `BP-SEC-EXC` |

---

## 5. Security Governance

| Body / Role | Responsibility |
|---|---|
| BTR | Board oversight of cyber & resilience (`ANB-LEG-REF-0003`) |
| CISO `EMP-100010` | Accountable executive; policy owner |
| Head of Cyber Defence `EMP-500201` Marta Bauer | SOC, EDR, vuln, threat intel |
| Head of Identity `EMP-500202` Tobias Lindgren | IAM, PAM, recertification |
| CIO `EMP-100007` / Head of IT Ops `EMP-500101` | Secure operations; patching execution |
| CRO `EMP-100004` | Technology risk in ERM; risk acceptance path |
| ORC / FCC | Operational / financial-crime tech overlays |
| Asset Owner | Accountability for `AST-########` / `APP-SEC-########` |

---

## 6. Zero Trust Architecture

| Pillar | Bank Implementation |
|---|---|
| Identity | Entra ID + ApexID; MFA (`ANB-ISC-STD-0002`) |
| Device | CrowdStrike / Defender compliance posture |
| Network | Segmentation; Palo Alto; ZTNA for remote |
| Application | SSO (SAML/OIDC); API auth |
| Data | Classification (`ANB-ISC-STD-0004`); DLP ApexDLP; encryption (`ANB-ISC-STD-0006`) |
| Analytics | ApexShield (Sentinel) + CrowdStrike; UEBA |

Implicit trust based solely on network location is prohibited for Tier 1 systems (`AST-00000001` ApexCore and peers).

---

## 7. Asset Ownership

Every information asset and application shall have:

| Attribute | Requirement |
|---|---|
| Asset ID | `AST-########` (CMDB / ApexServe) |
| App Security ID | `APP-SEC-########` where application-scoped |
| Owner | Named G6+ |
| Classification floor | Per `ANB-ISC-STD-0004` |
| Criticality | Tier 1–4 aligned DR (`ANB-ITO-PLN-0002`) |

---

## 8. Security Responsibilities

| Population | Duty |
|---|---|
| All staff | Complete training (`ANB-HRM-POL-0008`); report incidents; no credential sharing |
| Managers | Ensure joiner-mover-leaver; approve access |
| Developers | SSDLC; no secrets in code |
| Vendors | MSA security schedules (`ANB-LEG-AGR-0002`); TPRM (`ANB-RSK-FRM-0002`) |
| CISO org | Monitor, respond, advise, assure |

---

## 9. Security Awareness

Annual mandatory cyber module; phishing simulations; role-based modules for privileged users, developers, and branch staff. Failure to complete blocks privileged recertification.

---

## 10. Domain Control Requirements (Summary)

| Domain | Requirement | Detail Standard |
|---|---|---|
| Third-party | Security due diligence; contractual controls | `ANB-RSK-FRM-0002`, MSA |
| Cloud | Shared-responsibility; CASB/CSPM; approved regions | ApexCloud standards |
| Endpoint | EDR; disk encryption; admin rights restricted | CrowdStrike / Defender |
| Email | Anti-phish; DLP; encryption for C2/C3 | M365 + ApexDLP |
| Network | Segmentation; IDS/IPS; no flat Tier 1 | Palo Alto / F5 |
| Logging / Monitoring | Centralize to ApexShield; retain per policy | §11 |
| SOC | 24×7 monitoring | `BP-SEC-SOC` |
| Threat intelligence | Consume & action IOCs `IOC-########` | Cyber Defence |

---

## 11. Logging, Monitoring, and SOC

**ISC-LOG-1.** Security-relevant events from Tier 1/2 systems forward to **ApexShield** (Microsoft Sentinel) / **ApexSIEM** correlation layer.

**ISC-LOG-2.** Privileged sessions recorded via CyberArk.

**ISC-LOG-3.** SOC (`ApexSOC` operating model under ApexShield) operates 24×7; alerts `ALERT-########`; rules `RULE-SEC-####`.

**ISC-LOG-4.** Log retention minimum 12 months online / 36 months archive unless Legal Hold `LHD-########`.

---

## 12. Risk Acceptance and Exceptions

Security exceptions via `BP-SEC-EXC` in ApexServe / ApexRisk:

| Severity | Approver | Max Duration |
|---|---|---|
| Low | Head of Cyber Defence / Identity | 180 days |
| Medium | CISO | 90 days |
| High | CISO + CRO | 60 days |
| Critical | CISO + CRO + BTR notification | 30 days exceptional |

Documented compensating controls mandatory. Links `RSK-########` / `RASS-########`.

---

## 13. Security Metrics and Executive Reporting

| Metric ID | Metric | Target |
|---|---|---|
| `SEC-M-001` | MTTD (Severity 1) | ≤ 15 minutes |
| `SEC-M-002` | MTTR (Severity 1 contain) | ≤ 4 hours |
| `SEC-M-003` | Critical vuln patch SLA | ≤ 7 days (internet-facing ≤ 48h) |
| `SEC-M-004` | Patch compliance Tier 1 | ≥ 98% |
| `SEC-M-005` | Phishing fail rate | ≤ 4% |
| `SEC-M-006` | Privileged access review completion | 100% quarterly |
| `SEC-M-007` | Encryption coverage Tier 1 data stores | 100% |
| `SEC-M-008` | Certificate expiry incidents | 0 |
| `SEC-M-009` | SOC SLA Sev1 acknowledge | ≤ 15 minutes |
| `SEC-M-010` | Open Critical exceptions | 0 sustained > 30 days |

Reported monthly to ORC; quarterly to BTR; cyber appetite `RAM-0012` to BRC as required.

---

## 14. Policy Statements

**ISP-1.** All access authenticated and authorized.  
**ISP-2.** Production changes via CAB (`ANB-ITO-SOP-0003`).  
**ISP-3.** Incidents handled per `ANB-ISC-SOP-0003`; notify Legal/Privacy for personal data (`ANB-LEG-POL-0004`/`0005`).  
**ISP-4.** No unsanctioned shadow IT connecting to Bank Data.  
**ISP-5.** AI/LLM use of Bank Data per `ANB-LEG-POL-0005` and `ANB-ISC-STD-0007` AI Security section.

---

## 15. Workflow — Security Exception

```
Request in ApexServe
        → Risk assessment RASS-
        → Compensating controls
        → Approver per §12
        → SEC-EXC-######## recorded
        → Expiry / revalidation calendar
```

---

## 16. Examples

**Zero Trust remote:** Employee `EMP-300105` accesses Apex360 via ZTNA; device CrowdStrike healthy; MFA via Entra; session continuous access evaluation.

**SOC detect:** ApexShield `ALERT-20260818-0044` ransomware indicators on `HOST-########`; playbook `SCN-2026-CYB-001`; CSIRT invokes `ANB-ISC-SOP-0003`.

---

## 17. Related Documents

| ID | Title |
|---|---|
| `ANB-ISC-STD-0002` | Password & Authentication Standard |
| `ANB-ISC-POL-0003` | Access Control Policy |
| `ANB-ISC-STD-0005` | Identity & Access Management Standard |
| `ANB-ISC-SOP-0003` | Cyber Incident Response Plan |
| `ANB-ISC-STD-0004` | Data Classification Standard |
| `ANB-ISC-STD-0006` | Enterprise Encryption Standard |
| `ANB-ISC-STD-0007` | Secure Software Development Standard |
| `ANB-RSK-POL-0001` / `STMT-0001` / `POL-0007` | ERM / Appetite / BCP |
| `ANB-ITO-PLN-0002` | Disaster Recovery Plan |
| `ANB-LEG-POL-0004` / `0005` / `AGR-0002` | Privacy / Data Protection / MSA |
| `ANB-CMP-POL-0001` | AML (cyber-enabled crime nexus) |
| `ANB-HRM-POL-0004` / `0008` | Conduct / Training |
| `ANB-ADM-REF-0001` / `MTX-0001` | Profile / Authority |

---

## 18. Review Cycle / Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 1.0 | 2026-07-31 | N. Ferreira | Initial published Information Security Policy |

---

## Appendix A — Canonical Security Entity Register

| Entity | Format | Example | System |
|---|---|---|---|
| User Identity | `USR-########` | `USR-000300106` | ApexID / Entra |
| Role | `ROLE-########` | `ROLE-TEL-BRANCH` | ApexID |
| Group | `GRP-########` | `GRP-SOC-TIER1` | Entra / AD |
| Security Control | `SEC-########` | `SEC-202608-0044` | ApexRisk / ISC |
| Asset | `AST-########` | `AST-00000001` | CMDB |
| Application Security Object | `APP-SEC-########` | `APP-SEC-00000088` | ApexServe |
| Cryptographic Key | `KEY-########` | `KEY-202608-0012` | HSM / KMS |
| Certificate | `CRT-########` | `CRT-202607-4412` | PKI |
| Secrets Vault Path | `VAULT-SEC-########` | `VAULT-SEC-00000012` | CyberArk / HashiCorp Vault |
| IAM Request | `IAM-########` | `IAM-20260818-0099` | ApexServe / ApexID |
| Incident | `INC-########` | `INC-20260818-0044` | ApexServe / ApexShield |
| Indicator of Compromise | `IOC-########` | `IOC-20260818-0007` | ApexShield |
| Security Alert | `ALERT-########` | `ALERT-20260818-0044` | ApexShield |
| Detection Rule | `RULE-SEC-####` | `RULE-SEC-1101` | ApexShield |
| Host | `HOST-########` | `HOST-00088421` | CMDB / CrowdStrike |

### A.1 Platform Mapping (Canonical)

| Capability | Bank Name | Underlying |
|---|---|---|
| Identity IGA / SSO / PAM | **ApexID** | SailPoint, Entra ID, CyberArk |
| SIEM / SOC | **ApexShield** / **ApexSOC** / **ApexSIEM** | Microsoft Sentinel, CrowdStrike |
| Vulnerability | **ApexScan** | Qualys/Tenable stack |
| DLP | **ApexDLP** | Microsoft Purview + DLP |
| ITSM | **ApexServe** | ServiceNow |
| Secrets (app) | HashiCorp Vault / Azure Key Vault / AWS KMS | under ApexCloud |
| Build | **ApexBuild** | GitHub Enterprise + Jenkins |
| Code scan | SonarQube / Fortify | via ApexBuild |

### A.2 Extended Security Personnel

| ID | Name | Role |
|---|---|---|
| `EMP-100010` | Nadia Ferreira | CISO |
| `EMP-500201` | Marta Bauer | Head of Cyber Defence |
| `EMP-500202` | Tobias Lindgren | Head of Identity & Access |
| `EMP-500203` | Aisha Rahman | ISO — Business Engagement |
| `EMP-500204` | Kevin Zhao | SOC Manager |
| `EMP-500205` | Priya Nair | Head of Application Security |
| `EMP-500206` | Omar Farouk | Head of Security Architecture |

---

**End of Document** — `ANB-ISC-POL-0001` v1.0
