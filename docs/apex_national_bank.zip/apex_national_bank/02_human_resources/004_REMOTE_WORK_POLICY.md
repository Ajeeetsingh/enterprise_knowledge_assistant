# Apex National Bank — Remote Work Policy

**Human Resources Policy | Hybrid Working, Eligibility, Home Office Standards, and Data Protection**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-POL-0003` |
| **Document Title** | Apex National Bank — Remote Work Policy |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) — HR Operations |
| **Joint Owner** | Information Security (ISC) for technical and data controls |
| **Custodian** | Owen Bradshaw, Head of HR Operations (G8) — `EMP-200102` |
| **Approver** | Yvonne Carter, Chief Human Resources Officer (G11) — `EMP-100008` |
| **Secondary Approvers** | Nadia Ferreira, Chief Information Security Officer; Samuel A. Okonkwo, Chief Compliance Officer; Margaret Sullivan, General Counsel |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-08 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24) |
| **Supersedes** | None — initial published policy |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.1` Employment → Working Arrangements → `POL` |
| **Business Process** | `BP-HR-FLEX` Flexible & Remote Working Administration |
| **Governing Body** | Executive Committee; Information Security Council (technical controls) |
| **System of Record** | ApexPeople (work pattern) · ApexServe (approvals and attestations) · ApexDocs (this policy) |
| **Keywords** | remote work, hybrid, work from home, VPN, home office, cross-border, confidentiality, monitoring, equipment |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-FIN-POL-0002` · `ANB-HRM-POL-0004` · `ANB-HRM-POL-0006` · `ANB-ISC-POL-0001` · `ANB-ADM-MTX-0001` |

> **Authority.** This Policy implements the hybrid working model stated in `ANB-ADM-REF-0001` §1.7 and the remote work scope in §6. It is summarised in `ANB-HRM-HBK-0001` §13.3. Technical controls referenced here are owned by Information Security; where this Policy and an Information Security standard differ on a security control, the security standard prevails.

---

## 2. Purpose

Apex National Bank permits remote working because it improves retention, widens the talent pool, and — properly governed — costs nothing in control quality. It does not permit remote working as an entitlement, because a substantial part of the Bank's work cannot be performed away from a supervised, physically controlled environment without breaching a regulatory obligation.

This Policy therefore:

1. Determines **eligibility by role**, using a documented test rather than manager discretion.
2. Sets the **default hybrid pattern** and the circumstances in which it varies.
3. Establishes the **home office, equipment, and connectivity** standards that make remote work safe.
4. Defines the **confidentiality and data protection** controls that apply outside Bank premises.
5. Prohibits **cross-border remote working** without prior tax, immigration, and regulatory clearance.
6. States what is and is not **monitored**, so that supervision is transparent rather than covert.

---

## 3. Scope

### 3.1 Applies To

All employees of all Apex legal entities, all grades G1–G12, in every jurisdiction. It applies to regular hybrid arrangements, ad hoc remote days, temporary remote work for medical or caring reasons, and permanent fully-remote appointments.

### 3.2 Applies With Modification To

| Population | Modification |
|---|---|
| Contractors and agency workers | Remote working is governed by the engagement contract and `ANB-PRC-POL-0002`. Sections 10–13 (equipment, security, confidentiality, data protection) apply in full. |
| New joiners in probation | On-site for the first 4 weeks minimum (§7.4) |
| Employees on a Performance Improvement Plan | Remote eligibility suspended (§7.5) |
| Employees on international assignment | Governed by the assignment letter and Global Mobility |

### 3.3 Does Not Apply To

Business travel, which is governed by `ANB-FIN-POL-0002`; leave of any kind, governed by `ANB-HRM-POL-0002`; and permanent relocation, governed by the Global Mobility framework.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Eligibility decisions are consistent and evidenced | 100% of arrangements recorded in ApexPeople with a documented eligibility category |
| O-2 | Regulatory on-site requirements are met without exception | Zero instances of a supervision-required role working remotely without approval |
| O-3 | Remote environments are secure | 100% annual home-office attestation; zero material data incidents attributable to remote working |
| O-4 | Cross-border exposure is controlled | Zero unapproved cross-border remote working days |
| O-5 | Hybrid attendance is real | Site attendance data supports the agreed pattern for ≥ 90% of eligible employees |
| O-6 | Remote workers are not disadvantaged | No statistically significant rating differential between remote and on-site populations at equivalent grade |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Remote Working** | Performing contracted duties from an approved location other than an Apex site. |
| **Hybrid Working** | A pattern combining approved remote days with a minimum number of on-site days. |
| **Designated Office** | The Apex site recorded against the employee in ApexPeople, determining their base, allowances, and tax position. |
| **Approved Remote Location** | The specific address registered in ApexPeople from which the employee is authorised to work. |
| **Ad Hoc Remote Day** | A single remote day outside the agreed pattern, approved by the line manager. |
| **Fully Remote** | An arrangement with no minimum on-site attendance, approved only under §7.6. |
| **Cross-Border Remote Working** | Working from a country other than the country of employment. |
| **Home Office Attestation** | The annual self-declaration in ApexServe confirming compliance with §11. |
| **Supervision-Required Role** | A role that must be performed on Bank premises to satisfy a regulatory, licensing, or control obligation. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Employee** | Work only from the approved location; maintain a compliant home office; complete the annual attestation; protect Bank and customer information; be contactable during agreed hours; report any incident immediately. |
| **Line Manager** | Apply the eligibility test consistently; approve and record patterns in ApexPeople; ensure on-site coverage; manage by output rather than presence; monitor that the pattern is actually followed. |
| **Department Head (G9–G11)** | Approve fully-remote arrangements, departmental pattern variations, and permanent exceptions. |
| **HR Business Partner (G6)** | Advise on eligibility disputes, medical and caring adjustments, and pattern changes; maintain fairness across the department. |
| **Head of HR Operations (`EMP-200102` Owen Bradshaw, G8)** | Own the policy, the eligibility taxonomy, attestation administration, and reporting. |
| **Head of Global Mobility (`EMP-200108` Ekaterina Volkova, G7)** | Assess and clear all cross-border requests with Tax, Legal, and Compliance. |
| **Chief Information Security Officer (`EMP-100010` Nadia Ferreira, G10)** | Own the technical control set; approve any deviation. |
| **Head of Identity & Access (`EMP-500202` Tobias Lindgren, G8)** | Provision VPN and remote access; enforce MFA and conditional access; revoke on change or exit. |
| **Information Security Officer — Business Engagement (`EMP-500203` Aisha Rahman, G6)** | Assess remote arrangements for higher-risk roles; deliver remote-working security guidance. |
| **IT Operations (`EMP-500101` Ravi Subramanian, G11)** | Issue, maintain, and recover equipment; provide remote support. |
| **Compliance (`EMP-400103` Priyanka Iyer, G6)** | Confirm regulated-role supervision and recording requirements. |
| **Administration — Physical Security (`EMP-600201` Aurélie Dubois, G7)** | Advise on home-office physical security; investigate loss of Bank property. |
| **Employment Legal (`EMP-600301` Beatriz Cardoso, G8)** | Advise on employment status, health and safety duty, and jurisdictional obligations. |

---

## 7. Standards — Eligibility and Patterns

### 7.1 The Eligibility Test

A role is assessed against five questions. A "no" to any one of the first three makes the role ineligible for remote working.

1. Can the duties be performed to the same standard without physical presence?
2. Can the role's supervision, recording, and control obligations be met remotely?
3. Can customer, employee, and Bank information be protected at the remote location?
4. Does remote working degrade service to customers or colleagues?
5. Does the team retain sufficient on-site presence for collaboration, supervision, and training?

Eligibility attaches to the **role**, not the individual. It is assessed by the line manager, confirmed by the HRBP, and recorded against the position in ApexPeople.

### 7.2 Eligibility Categories

| Category | Pattern | Typical Roles |
|---|---|---|
| **Category A — Fully On-Site** | 5 days on-site; no remote working | Branch staff, tellers, vault custodians, cash operations, trading floor and dealing roles, physical security, facilities, print and mail, teller platform support on-site, registered advisers required to be supervised in person |
| **Category B — On-Site Majority** | 4 days on-site, 1 remote | Branch management, contact centre team leaders, payment operations supervisors, credit approvers with in-person committee obligations, front-office support requiring floor presence |
| **Category C — Standard Hybrid (default)** | 3 days on-site, 2 remote | Corporate Centre professional roles: HR, Finance, Risk, Compliance, Legal, Marketing, Procurement, Administration, most Technology roles, Internal Audit (outside fieldwork) |
| **Category D — Remote Majority** | 1–2 days on-site | Roles with limited collaboration dependency and no supervision requirement, approved individually by the Department Head — for example specialist engineering, data science, technical writing |
| **Category E — Fully Remote** | 0 required on-site days | Approved only under §7.6 |

**Default.** Category C is the default for any role not otherwise categorised. Managers may not downgrade an employee below their role's category as an informal sanction, nor upgrade above it without HRBP endorsement.

### 7.3 Category A — Why Certain Roles Cannot Be Remote

These restrictions are regulatory and control-driven, not cultural.

| Role Family | Reason |
|---|---|
| Branch and teller | Cash custody, dual control, customer identification, physical security of the premises |
| Trading and dealing | Communications recording, supervision, market abuse surveillance, `BP-MKT-TRADE` control environment |
| Payment release and wire operations | Dual control at cut-off, restricted network zone access, `BP-PAY-XB` sanctions interlock |
| Cash and vault operations | Physical custody and joint-count controls |
| Certain registered roles | Supervisory obligations under securities and insurance registration requiring in-person oversight |
| Privileged infrastructure administration in restricted zones | Jump-host and physical segregation requirements under `ANB-ISC-POL-0001` |

### 7.4 New Joiners

New joiners work on-site for a minimum of **4 weeks**, and for the whole probation period in Category A and B roles. This exists so that identity verification, equipment issue, access provisioning, mandatory training, and — most importantly — supervision and cultural induction happen properly. The HRBP may reduce this for a documented medical, caring, or accessibility reason.

### 7.5 Suspension of Remote Eligibility

Remote eligibility is suspended where:

- The employee is on a Performance Improvement Plan (`ANB-HRM-POL-0006` §13), for the duration of the plan.
- The employee is subject to an active conduct investigation where remote working would prejudice it.
- A security or data incident is attributable to the employee's remote environment, pending assessment.
- The employee has failed the annual home-office attestation and has not remediated within 15 business days.
- Mandatory training is overdue by more than 30 days (`ANB-HRM-POL-0008` §11.3).

Suspension is recorded in ApexPeople with a reason and a review date. It is a management action, not a disciplinary sanction, and does not itself appear on the employee's conduct record.

### 7.6 Fully Remote Appointments

Category E is approved only where: the role has been advertised as fully remote through `ANB-HRM-SOP-0007`; the Department Head has approved; the employee's location is within a jurisdiction where the Bank has an employing entity; the eligibility test is met on all five questions; and Information Security has assessed the arrangement. Fully remote employees attend their designated office at least quarterly for team, training, and supervision purposes, at Bank cost, under `ANB-FIN-POL-0002`.

### 7.7 Working Hours While Remote

Remote working changes location, not hours. The employee works their contracted hours, is contactable during core hours, keeps their calendar current, and records absence in ApexPeople exactly as they would on-site. Remote working is not a substitute for leave: an employee who is ill takes sick leave, and an employee with a caring emergency takes emergency leave (`ANB-HRM-POL-0002` §8.3, §8.4). Working while unwell from home is not encouraged and is not credited.

### 7.8 Ad Hoc Remote Days

A Category A employee may not take ad hoc remote days. All other employees may request ad hoc remote days beyond their pattern — for a delivery, a medical appointment, or focused work — with line manager approval recorded in ApexPeople. More than 6 ad hoc days in a rolling quarter triggers a pattern review with the HRBP rather than continued ad hoc approval.

---

## 8. Standards — Approval and Change

### 8.1 Establishing an Arrangement

| Step | Action | Owner | System |
|---|---|---|---|
| 1 | Employee raises a work-pattern request | Employee | ApexPeople |
| 2 | Manager applies the eligibility test and confirms the category | Line Manager | ApexPeople |
| 3 | Team coverage checked against departmental minimum on-site presence | Line Manager | ApexPeople |
| 4 | Home office attestation completed for the registered address | Employee | ApexServe |
| 5 | Equipment requested and issued | IT Operations | ApexServe |
| 6 | Remote access, VPN, and conditional access provisioned | Identity & Access | ApexID |
| 7 | Security briefing for Category D and E, and for any role handling C3 data | Information Security | ApexLearn |
| 8 | Pattern recorded and effective | Line Manager | ApexPeople |

### 8.2 Changing or Withdrawing an Arrangement

The Bank may vary or withdraw a remote arrangement with **20 business days' notice** where business need, regulatory change, performance, or control requirements make it necessary. Immediate withdrawal is permitted where there is a security incident, a supervision failure, or a suspected conduct breach. The reason is recorded in ApexPeople and communicated in writing. An employee who disagrees escalates to the Department Head and then the HRBP; the grievance route in `ANB-HRM-HBK-0001` §14.2 remains available.

### 8.3 Formal Flexible Working Requests

Where a jurisdiction provides a statutory right to request flexible working — for example the United Kingdom, Ireland, the Netherlands, and several US states for caring reasons — the statutory process applies, with statutory timescales and appeal rights, administered by the HRBP with Employment Legal. Statutory requests are decided on their own merits and are not limited by the categories in §7.2, although any grant must still satisfy §7.1 questions 1–3.

### 8.4 Accessibility and Medical Adjustments

Remote working as a disability accommodation or medical adjustment is assessed by the HRBP with Occupational Health, not by the line manager, and is granted where it is a reasonable adjustment. The manager is told the adjustment, never the medical reason. Such arrangements are not counted against departmental hybrid targets.

---

## 9. Standards — Cross-Border Remote Working

### 9.1 The Prohibition

**Working from a country other than the country of employment is prohibited without prior written clearance.** This is not an administrative preference. Unapproved cross-border working can create a permanent establishment for the Bank, breach the employee's immigration status, trigger personal and employer tax liabilities, violate data localisation requirements, and — for regulated roles — constitute performing a regulated activity from an unauthorised jurisdiction.

### 9.2 Clearance Requirement

| Duration in another country | Requirement |
|---|---|
| Any period, any purpose (including "working while visiting family") | Prior request in ApexServe; Global Mobility assessment |
| Up to 10 working days per year, low-risk jurisdiction, non-regulated role | Global Mobility clearance; line manager approval |
| 11–30 working days | Global Mobility, Tax, and Employment Legal clearance; Department Head approval |
| Over 30 working days | Treated as an international assignment; full mobility, tax, immigration, and regulatory review; CHRO approval |
| Any period in a regulated role | Compliance clearance mandatory, irrespective of duration |
| Any period in a sanctioned or high-risk jurisdiction | Refused; refer to `ANB-FIN-POL-0002` §12 |

### 9.3 Assessment Factors

Global Mobility assesses: immigration status and right to work; corporate tax and permanent establishment exposure; personal income tax and social security; employment law of the host country, including whether local employment rights attach; regulatory authorisation for the activity performed; data protection and localisation, including whether accessing customer data from that jurisdiction is lawful; information security posture and network restrictions; and the Bank's ability to discharge its duty of care.

### 9.4 What Is Never Permitted

Accessing customer personal data from a jurisdiction where that access is unlawful or unassessed; performing a regulated activity from an unauthorised jurisdiction; working from a comprehensively sanctioned jurisdiction; using personal or public networks in a high-surveillance jurisdiction with a standard Bank device (loaner devices apply per `ANB-FIN-POL-0002` §12.2); and extending business travel into remote working days without a separate clearance.

### 9.5 Consequence

Unapproved cross-border working is a policy breach handled under `ANB-HRM-POL-0004` §14. Where it creates a tax or regulatory exposure for the Bank, it is treated as serious misconduct. Employees are not penalised for a genuine, promptly self-reported error; they are penalised for concealment.

---

## 10. Standards — Equipment and Connectivity

### 10.1 Bank-Issued Equipment

| Item | Provision |
|---|---|
| Laptop | Standard corporate build with full-disk encryption, EDR agent (ApexShield), DLP agent, and managed patching. Issued to all employees. |
| Second monitor | Issued on request to all hybrid and remote employees |
| Keyboard, mouse, headset | Issued on request |
| Mobile phone | Issued to G6 and above, on-call roles, and customer-facing roles; otherwise BYOD with managed container |
| Docking station | Issued to Category D and E employees |
| Ergonomic chair or desk | Provided where an ergonomic or occupational health assessment identifies a need |
| Privacy screen | Mandatory for all roles handling Confidential (C2) or Restricted (C3) data |
| Shredder | Provided to Category D and E employees authorised to print |
| Hardware token | Where the role requires it under `ANB-ISC-STD-0002` |

**Home office allowance.** A one-time $500 allowance is available to Category C, D, and E employees for desk, lighting, and ergonomic accessories, claimed through ApexLedger with receipts. It is not available for internet service, furniture already provided, or personal technology.

### 10.2 Personal Equipment

Personal computers may **not** be used for Bank work under any circumstances. Personal printers and scanners may not be used for Bank documents. Personal cloud storage, personal email, and personal messaging applications may not be used for any Bank information — this is an absolute rule under `ANB-ADM-POL-0001` §10.3 and `ANB-ISC-POL-0001`.

Personal mobile devices may be used only through the managed container provisioned by ApexID, which segregates Bank data and permits selective remote wipe.

### 10.3 Connectivity

| Requirement | Standard |
|---|---|
| Minimum bandwidth | 25 Mbps down / 5 Mbps up sustained |
| Home router | WPA3 or WPA2-AES encryption; default administrator password changed; firmware current |
| Public Wi-Fi | Permitted only through the corporate VPN; never for Restricted (C3) data |
| Mobile hotspot | Permitted as a backup; personal hotspot tethering is preferred over public Wi-Fi |
| Internet cost | Not reimbursed; treated as a personal cost, except where local statute requires reimbursement |
| Network sharing | Bank devices must not be connected to networks the employee does not control, such as shared co-working networks, without VPN |

### 10.4 Equipment Care and Recovery

Equipment remains Bank property. It must not be modified, shared with family members, used for personal business, or taken outside the country of employment without clearance under §9. Loss or theft is reported to IT Operations and Information Security **within 1 hour of discovery**, through the ApexServe Severity 1 route. Equipment is returned at exit clearance (`ANB-HRM-HBK-0001` §15, item 4); unreturned equipment is recovered from final pay where local law permits.

---

## 11. Standards — Home Office Requirements

Every remote worker attests annually in ApexServe that their approved location meets the following. False attestation is a conduct matter.

### 11.1 Physical Environment

| Requirement | Standard |
|---|---|
| Dedicated workspace | A defined area where work materials and screens are not visible to others |
| Screen privacy | Screen not visible from windows, doorways, or shared areas; privacy filter where C2/C3 data is handled |
| Audio privacy | Calls involving customer, employee, or Confidential information conducted where they cannot be overheard, including by household members |
| Door | For roles handling Restricted (C3) data, a lockable room or lockable storage for materials |
| Lockable storage | For any physical Bank document or hardware token |
| Smart speakers and voice assistants | Disabled or removed from the workspace |
| Household cameras | Not directed at the workspace |
| Ergonomics | Adjustable seating, screen at eye level, adequate lighting; self-assessment completed at setup and annually |
| Health and safety | Working area free of trip and electrical hazards; the Bank's duty of care extends to the approved location |

### 11.2 Household and Visitors

Household members, guests, and cohabitants must not have access to Bank equipment, screens, or documents. An employee sharing accommodation with someone employed by a competitor, a regulator, a customer, or a supplier must declare this as a potential conflict under `ANB-HRM-POL-0004` §8 — declaration is not a prohibition, but it allows a control to be applied.

### 11.3 Printing and Physical Documents

Printing at home is prohibited by default. Where a role requires it, the Department Head approves, a shredder is provided, and the employee logs printed Confidential and Restricted documents. Documents must be shredded when no longer needed and never placed in domestic waste or recycling. Original Bank records must never be stored at home; the record copy always resides in ApexDocs.

### 11.4 Insurance and Premises

Employees should confirm that home contents insurance and, where applicable, a tenancy agreement or mortgage terms permit home working. The Bank's cover applies to Bank equipment; it does not cover the employee's property or premises.

---

## 12. Standards — Security and Data Protection

### 12.1 Baseline Technical Controls

All apply automatically to Bank-issued devices and are enforced by Information Security. Employees must not attempt to disable or circumvent them.

| Control | Standard |
|---|---|
| Full-disk encryption | Mandatory, enforced at build |
| Multi-factor authentication | Mandatory for all remote access (`ANB-ISC-STD-0002`) |
| VPN | Always-on for corporate resource access; split tunnelling disabled for C2/C3 workloads |
| Conditional access | Device compliance, location, and risk-based access enforced through ApexID |
| Endpoint detection and response | ApexShield agent, 24×7 SOC monitoring |
| Data loss prevention | Egress monitoring for customer and Confidential data |
| Screen lock | Automatic at 5 minutes; manual lock whenever the employee leaves the device |
| Patching | Managed; a device more than 14 days behind loses network access until remediated |
| Removable media | Blocked by default; exception requires CISO approval |
| Remote wipe | Enabled on all devices and managed containers |

### 12.2 Handling Classified Information Remotely

| Classification | Remote Handling |
|---|---|
| **Public (C0)** | No restriction |
| **Internal (C1)** | Standard controls; no printing at home without approval |
| **Confidential (C2)** | Privacy screen mandatory; audio privacy mandatory; no printing; no access over public Wi-Fi without VPN |
| **Restricted (C3)** | Lockable room or equivalent; VPN mandatory; no public networks under any circumstances; no mobile-device access; some C3 workloads are restricted to on-site access only, enforced by conditional access |

Classification definitions are in `ANB-ADM-STD-0006` and `ANB-ISC-STD-0004`.

### 12.3 Confidentiality Obligations

The confidentiality obligations in `ANB-HRM-POL-0004` §6 apply identically at home. Specifically: customer names, balances, and circumstances must not be audible to anyone in the household; a video call must not show customer information, a whiteboard, or documents; screen sharing must be from a single application window, never the full desktop, where Confidential data may be present; and no recording of a meeting may be made without the consent of all participants and a documented business reason.

### 12.4 Incident Reporting

Any of the following is reported through ApexServe **immediately**, and in any event within 1 hour of discovery: loss or theft of a device, token, or document; a household member or visitor viewing Confidential information; a suspected compromise of the home network; a phishing or social-engineering attempt; unintended disclosure on a call or in a shared screen; or a device left unattended and unlocked in a public place. Prompt reporting is expected and is never itself a disciplinary matter; concealment is.

---

## 13. Standards — Monitoring and Supervision

### 13.1 Transparency Principle

The Bank monitors what it must monitor to meet its regulatory and security obligations, and it says so. It does not conduct covert surveillance of employees at home.

### 13.2 What Is Monitored

| Monitored | Purpose | Basis |
|---|---|---|
| Corporate email and chat | Surveillance for market abuse, conduct, and financial crime; e-discovery | `ANB-CMP-POL-0008`; journaled to ApexArchive |
| Recorded lines for regulated roles | Regulatory recording obligation | Applies wherever the role is performed |
| Network and endpoint telemetry | Security monitoring by ApexShield | `ANB-ISC-POL-0001` |
| VPN and system access logs | Access control and audit | `ANB-ISC-POL-0001` |
| Data egress (DLP) | Prevention of customer data loss | `ANB-ISC-POL-0001` |
| Building access records | Physical security and hybrid attendance | ApexAccess |
| Application activity in core systems | Transaction and control audit | Per system |

### 13.3 What Is Not Monitored

The Bank does not use webcam monitoring, screenshot capture, keystroke logging, mouse-movement or "activity level" tracking, or continuous location tracking of employees. It does not monitor personal devices outside the managed container, nor personal accounts, nor home networks.

### 13.4 Regulated Roles Working Remotely

Where a regulated role is permitted to work remotely, the recording, supervision, and attestation obligations follow the person. The employee must use recorded channels for all regulated communications, must not use personal devices for any customer or market communication, and is subject to the same surveillance as on the floor. A regulated employee who conducts business on an unrecorded channel commits a serious conduct breach under `ANB-HRM-POL-0004` §14.

### 13.5 Managing Remote Employees

Managers supervise by output, not presence. Specifically: objectives and deliverables are documented in ApexPeople; check-ins are at least fortnightly for remote-majority employees; remote employees are given equal access to development, projects, and visibility; and rating outcomes are reviewed by the HRBP for any pattern that disadvantages remote workers (§4, O-6). Requiring an employee to justify their whereabouts minute by minute is not supervision and is not permitted.

---

## 14. Process Flow

### 14.1 Establishing a Hybrid Arrangement

```
EMPLOYEE           LINE MANAGER          HRBP / ISC / ITO           SYSTEMS
   │                     │                        │                    │
   ├─ Request pattern ──►│                        │                    │
   │                     ├─ Apply eligibility     │                    │
   │                     │  test (§7.1)           │                    │
   │                     ├─ Confirm category      │                    │
   │                     ├─ Check team coverage   │                    │
   │                     │                        │                    │
   │              ┌──────┴──────┐                 │                    │
   │         Category C     Category D/E          │                    │
   │              │              └───────────────►│ Dept Head approval │
   │              │                               │ ISC assessment     │
   │              │◄──────────────────────────────┘                    │
   │              │                                                    │
   ├─ Home office attestation ─────────────────────────────────────────► ApexServe
   ├─ Equipment request ───────────────────────────────────────────────► ApexServe → ITO
   │                                                                     ApexID: VPN, MFA,
   │                                                                     conditional access
   │◄─ Pattern effective; recorded in ApexPeople ───────────────────────►│
   │
   └─ Annual: re-attest home office · re-certify access · review pattern
```

### 14.2 Cross-Border Request

```
Employee raises cross-border request in ApexServe
        │
        ├─ Global Mobility: immigration, right to work, duration
        ├─ Tax: PE exposure, personal tax, social security
        ├─ Employment Legal: host employment rights
        ├─ Compliance: regulated activity authorisation (mandatory for regulated roles)
        ├─ Information Security: data localisation, network, device
        │
        ├─ ≤10 days, low risk, non-regulated ──► Line manager approves
        ├─ 11–30 days ─────────────────────────► Department Head approves
        ├─ >30 days ───────────────────────────► CHRO approves; assignment framework applies
        └─ Sanctioned / high-risk ─────────────► REFUSED
```

### 14.3 Annual Cycle

| Timing | Activity | Owner |
|---|---|---|
| January | Role eligibility categories reconfirmed against the position register | Line managers with HRBP |
| March | Home office attestation window opens for all remote workers | HR Operations |
| April | Attestation closes; non-completers escalated; eligibility suspended after 15 business days | HR Operations |
| Quarterly | Remote access recertification through ApexID | Identity & Access |
| Semi-annual | Hybrid attendance reporting to Department Heads | HR Operations |
| Annually | Policy review; incident and exception analysis to the Information Security Council | Head of HR Operations with CISO |

---

## 15. Decision Tables

### 15.1 Approval Authority

| Request | Approver | Second Approver | Reference |
|---|---|---|---|
| Category C standard hybrid within the role's category | Line manager (G5+) | — | §7.2 |
| Ad hoc remote day | Line manager | — | §7.8 |
| Category D (remote majority) | Line manager | Department Head (G9) | §7.2 |
| Category E (fully remote) | Department Head (G9) | CHRO (G11) with CISO assessment | §7.6 |
| Change of approved remote address | Line manager | New attestation required | §11 |
| Temporary remote for medical or caring reasons | HRBP (G6) | — | §8.4 |
| Statutory flexible working request | HRBP (G6) | Department Head | §8.3 |
| Cross-border up to 10 days | Line manager | Head of Global Mobility (G7) | §9.2 |
| Cross-border 11–30 days | Department Head (G9) | Global Mobility, Tax, Employment Legal | §9.2 |
| Cross-border over 30 days | CHRO (G11) | Head of Global Mobility, Head of Tax | §9.2 |
| Remote working in a regulated role | Line manager | Compliance (G6+) | §13.4 |
| Home printing authorisation | Department Head (G9) | Information Security | §11.3 |
| Removable media exception | CISO (G10) | — | `ANB-ADM-MTX-0001` §11 |
| Deviation from a technical control | CISO (G10) | Operational Risk Committee for material deviations | `ANB-ADM-MTX-0001` §8 |
| Withdrawal of an arrangement for cause | Line manager | HRBP notified | §8.2 |

### 15.2 Scenario Table

| Scenario | Outcome |
|---|---|
| Teller asks to work one day a week from home | Refused — Category A. Cash custody and dual control cannot be performed remotely. |
| Branch Manager asks for two remote days | Category B permits one. A second requires Department Head approval and evidence that branch supervision is unaffected. |
| Compliance Officer wants to work from her parents' home in another state, same country | Permitted if the address is registered in ApexPeople and attested; no cross-border issue; check state tax registration with Payroll. |
| Technology engineer wants to work six weeks from Portugal | Cross-border over 30 days. CHRO approval, full mobility, tax, and regulatory review. Likely refused unless an employing entity or assignment structure exists. |
| Employee joins a customer call from a coffee shop over public Wi-Fi | Breach — C2 data over public Wi-Fi without VPN, and no audio privacy. Reported and remediated; repeated instances are a conduct matter. |
| Employee's laptop is stolen from a car | Report within 1 hour through ApexServe Severity 1. Remote wipe executed; access suspended; Physical Security investigates; no disciplinary consequence for the theft itself if promptly reported and the device was not left visibly unattended in breach of guidance. |
| Employee on a PIP asks to keep hybrid working | Remote eligibility is suspended for the PIP duration (§7.5). |
| Trader asks to work from home on a quiet market day | Refused — Category A. Recording and supervision obligations require the floor. |
| Employee's partner works for a competitor and shares the home office | Declare under `ANB-HRM-POL-0004` §8. Likely outcome: separate workspace required, privacy screen mandatory, possible restriction on C3 material at home. |
| Employee wants to extend a business trip to Singapore by working four days remotely | Cross-border request required separately from the travel approval; §9.2 applies even though the traveller is already there. |

---

## 16. Approval Matrix — Policy Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| Policy Major version | Head of HR Operations (G8) | CISO, Compliance, Employment Legal, Global Mobility, works councils where applicable | CHRO (G11) **and** CISO (G10) | ExCo; Information Security Council |
| Policy Minor version | Head of HR Operations | Information Security | HR Director (G9) | All staff |
| Eligibility category change for a role family | Department Head (G9) | HRBP, Compliance | Head of HR Operations (G8) | Affected employees |
| Departmental pattern variation | Department Head (G9) | HRBP | HR Director (G9) | Department |
| Technical control change | CISO (G10) | HR Operations | CISO | Information Security Council |
| Cross-border framework change | Head of Global Mobility (G7) | Tax, Employment Legal, Compliance | CHRO **and** CFO | ExCo |
| Home office standard change | Head of HR Operations | Physical Security, Information Security, Occupational Health | HR Director (G9) | All remote workers |

---

## 17. Records and Retention

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Work pattern and eligibility category | `EMP-######` | ApexPeople | C2 | `RET-HRM-7Y` |
| Home office attestation | `CAS-########` | ApexServe | C2 | `RET-HRM-7Y` |
| Equipment issue and return record | `CAS-########` | ApexServe | C1 | `RET-HRM-7Y` |
| Cross-border request and clearance | `CAS-########` | ApexServe, ApexDocs | C2 | `RET-TAX-10Y` |
| Statutory flexible working request and decision | `CAS-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Accessibility or medical adjustment | `CAS-########` | ApexServe (restricted) | C3 | `RET-HRM-7Y` |
| Remote access recertification | Quarterly | ApexID | C2 | `RET-SEC-7Y` |
| Security incident at a remote location | `INC-########` | ApexServe, ApexShield | C2/C3 | `RET-SEC-7Y` |
| Eligibility suspension record | `EMP-######` | ApexPeople | C2 | `RET-HRM-7Y` |

---

## 18. Examples

### 18.1 Standard Hybrid — Corporate Centre

`EMP-600103` Sandeep Bhatt (G6, Finance Manager, New York) is Category C.

Pattern: on-site Tuesday, Wednesday, Thursday; remote Monday and Friday, recorded in ApexPeople. Home office attested in March 2026 for his registered Brooklyn address: dedicated room, privacy screen, no smart speaker, lockable drawer for the hardware token. Equipment: laptop, second monitor, docking station, privacy screen, headset; $500 allowance claimed for a desk and lamp. During the January close blackout (`ANB-HRM-POL-0002` §11.4) he works on-site five days a week for the close window, which is a scheduled variation, not a withdrawal of the arrangement.

### 18.2 Cross-Border Request — Refused Then Restructured

`EMP-500203` Aisha Rahman (G6, Information Security Officer, Charlotte) requests six weeks working from Dubai while a family member recovers from surgery.

| Step | Outcome |
|---|---|
| Request raised in ApexServe, 42 working days | Over the 30-day threshold — CHRO approval route |
| Global Mobility | Visitor status does not permit working; a work permit would be required |
| Tax | Six weeks of security work is unlikely to create PE but personal tax registration would be triggered |
| Employment Legal | UAE employment rights may attach after a period; the employing entity is US |
| Information Security | Access to C3 security tooling from a non-approved jurisdiction is not permitted |
| Outcome | **Refused as requested.** Restructured: 4 weeks of leave under `ANB-HRM-POL-0002` (annual plus emergency plus unpaid), followed by 2 weeks working from the Apex Dubai office as a temporary host-site arrangement, cleared by Global Mobility with the Dubai entity, with access provisioned locally |

The record is retained under `RET-TAX-10Y`, and the outcome — accommodation achieved through a compliant route rather than a refusal — is the intended result of the process.

### 18.3 Incident — Overheard Customer Call

`EMP-300202` Michael Thornton (G6, Customer Service Manager) takes a complaint escalation call from his kitchen while a contractor is working in the house. Customer name and account details are audible.

He reports it in ApexServe within 20 minutes. Information Security and the HRBP assess: no data left the household, no evidence of misuse, prompt self-report. Outcome: no disciplinary action; the arrangement is amended to require calls from the dedicated room only; a refreshed remote-working security module is assigned in ApexLearn; the incident is logged and included in the semi-annual remote-working incident analysis to the Information Security Council. Had he concealed it and it emerged later, the outcome would have been a conduct matter under `ANB-HRM-POL-0004` §14.

---

## 19. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Hybrid model; departments; systems |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Remote work summary; canonical employee register |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Remote work is not a substitute for leave; blackout periods |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Quarterly on-site travel for remote employees; loaner devices; PE thresholds |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Confidentiality; conflicts; disciplinary consequences |
| `ANB-HRM-POL-0006` | Performance Management Policy | `02_human_resources/006_PERFORMANCE_MANAGEMENT_POLICY.md` | PIP suspends remote eligibility; output-based supervision |
| `ANB-HRM-SOP-0007` | Recruitment SOP | `02_human_resources/007_RECRUITMENT_STANDARD_OPERATING_PROCEDURE.md` | Advertising fully-remote roles; on-site probation requirement |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | Remote-working security training; overdue training suspends eligibility |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Security exception authorities |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Prohibition on personal storage; retention codes |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.1` classification; C0–C3 definitions |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-FLEX` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Information Security Council |
| `ANB-ISC-POL-0001` | Information Security Policy | *(planned)* | Baseline technical controls |
| `ANB-ISC-STD-0002` | Password & Authentication Standard | *(planned)* | MFA and token requirements |
| `ANB-ISC-STD-0004` | Data Classification Standard | *(planned)* | C0–C3 handling rules |
| `ANB-CMP-POL-0008` | Communications Surveillance Policy | *(planned)* | Monitoring basis for regulated roles |

---

## 20. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review and re-approval | Head of HR Operations with CISO | Annually by 31 July |
| Regulatory change affecting supervision | Reassess Category A and B role families | Compliance with HR Operations | 30 days |
| Material remote-working security incident | Control review and policy amendment | CISO | 30 days |
| Tax or immigration change in an operating jurisdiction | Update §9 thresholds | Head of Global Mobility with Head of Tax | 30 days |
| Attestation cycle completion | Exception analysis and reporting | HR Operations | Annually in May |
| Rating differential detected between remote and on-site populations | Investigate and remediate | HRBP with Head of Talent & Performance | Next performance cycle |

Next scheduled review: **2027-07-24**.

---

## 21. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-08 | HR Operations | Initial draft from `ANB-ADM-REF-0001` §1.7 hybrid model and §6 scope | — |
| 0.3 | 2026-06-24 | HR Operations | Eligibility categories A–E defined with Compliance input on supervision-required roles | — |
| 0.5 | 2026-07-02 | HR Operations | Technical control set and classification handling added by Information Security | — |
| 0.7 | 2026-07-11 | HR Operations | Cross-border section added following Global Mobility, Tax, and Legal review | — |
| 0.9 | 2026-07-20 | HR Operations | Monitoring transparency section added; explicit statement of what is not monitored, after works council consultation | — |
| 1.0 | 2026-07-24 | HR Operations | First published version | Y. Carter / N. Ferreira |

---

## 22. Appendices

### Appendix A — Employee Quick Reference

| Question | Answer |
|---|---|
| How many days must I be on-site? | Depends on your role category — see §7.2. The default is three. |
| Can I choose which days? | Within the team pattern agreed by your manager. Coverage comes first. |
| Can I work from my parents' house? | Yes, if the address is registered in ApexPeople and attested, and it is in your country of employment. |
| Can I work from another country? | Not without clearance. See §9. This includes working during a holiday abroad. |
| Can I use my own laptop? | No. Never. |
| Can I print at home? | No, unless your Department Head has approved it and you have a shredder. |
| Can I use public Wi-Fi? | Only through the VPN, and never for Restricted (C3) data. |
| Does the Bank watch my screen or webcam? | No. See §13.3 for exactly what is and is not monitored. |
| What if I lose my laptop? | Report through ApexServe within one hour. Prompt reporting is never punished. |
| I'm ill — can I just work from home? | Take sick leave. Remote work is not a substitute for leave. |
| Will remote working affect my rating? | It must not, and the HRBP reviews the data for exactly that. |

### Appendix B — Home Office Attestation Content

The annual ApexServe attestation requires confirmation of each of the following:

1. The address at which I work remotely is the address registered in ApexPeople.
2. I have a dedicated workspace where my screen and materials are not visible to others.
3. My screen cannot be seen from a window, doorway, or shared area, and I use a privacy filter where required.
4. I conduct calls involving Confidential information where they cannot be overheard, including by household members.
5. My home network uses WPA2-AES or WPA3, the default router password has been changed, and firmware is current.
6. No smart speaker or voice assistant is active in my workspace, and no household camera is directed at it.
7. I use only Bank-issued equipment for Bank work, and no personal cloud storage, email, or messaging for Bank information.
8. I do not print Bank documents at home, or I hold a documented authorisation and a shredder.
9. Bank equipment, documents, and tokens are stored securely and are not accessible to household members or visitors.
10. I have completed the ergonomic self-assessment and my workspace is free of hazards.
11. I will report any loss, theft, or disclosure through ApexServe within one hour of discovery.
12. I understand that a false attestation is a conduct matter under `ANB-HRM-POL-0004`.

### Appendix C — Manager Checklist

**When approving an arrangement:** confirm the role's eligibility category rather than the individual's preference; check team coverage on every weekday; confirm the attestation is current; confirm equipment and access are provisioned; confirm the employee is not in probation, on a PIP, or overdue on mandatory training.

**Ongoing:** compare recorded pattern against ApexAccess attendance quarterly; hold check-ins at least fortnightly for remote-majority reports; give remote reports equal access to projects and visibility; escalate any suspected cross-border working immediately to Global Mobility; withdraw the arrangement in writing with a reason, never informally.

### Appendix D — Category Assignment by Department (Indicative)

| Department | Predominant Category | Notable Exceptions |
|---|---|---|
| Human Resources (HRM) | C | Employee Relations casework requiring in-person hearings |
| Finance (FIN) | C | Cash and payment operations (A); close-period on-site requirement |
| Retail Banking (RTL) | A | Regional and central teams (C) |
| Corporate Banking (CBK) | B | Credit administration and portfolio (C); coverage bankers (B) |
| Treasury (TRY) | A | Non-dealing ALM analysts (C) |
| Legal (LEG) | C | Corporate secretariat during Board cycles (B) |
| Compliance (CMP) | C | Branch monitoring officers (B); surveillance analysts (B) |
| Risk (RSK) | C | On-site credit committee obligations (B) |
| Information Security (ISC) | C | SOC shift analysts in restricted zones (A) |
| IT Operations (ITO) | C | Data centre and restricted-zone administration (A); command centre (B) |
| Customer Support (CST) | B | Contact centre agents (B); team leaders (B); workforce management (C) |
| Internal Audit (IAD) | C | On-site fieldwork periods (B) |
| Marketing (MKT) | C | Studio and events (B) |
| Procurement (PRC) | C | — |
| Administration (ADM) | B | Facilities, physical security, print and mail, records handling (A); EKMO (C) |

Indicative only. The authoritative category is recorded against the position in ApexPeople.

---

**End of Document**

`ANB-HRM-POL-0003` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) with Information Security (ISC) · Approver: Yvonne Carter, Chief Human Resources Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
