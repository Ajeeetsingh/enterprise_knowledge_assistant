# Apex National Bank — Recruitment Standard Operating Procedure

**Human Resources SOP | Requisition to Confirmation**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-SOP-0007` |
| **Document Title** | Apex National Bank — Recruitment Standard Operating Procedure |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) — Talent Acquisition |
| **Custodian** | Anjali Deshmukh, Head of Talent Acquisition (G8) — `EMP-200103` |
| **Approver** | Yvonne Carter, Chief Human Resources Officer (G11) — `EMP-100008` |
| **Secondary Approvers** | Samuel A. Okonkwo, Chief Compliance Officer (screening and fitness); Margaret Sullivan, General Counsel (employment law) |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-14 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24) |
| **Supersedes** | None — initial published procedure |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Procedures |
| **Taxonomy** | `T7` People & Workplace → `T7.1` Employment → Hiring → `SOP` |
| **Business Process** | `BP-HR-HIRE` Recruitment & Selection; `BP-HR-SCRN` Employment Screening & Background Verification; `BP-HR-ONB` Employee Onboarding & Access Provisioning |
| **Governing Body** | Executive Committee |
| **System of Record** | ApexPeople (requisitions, candidates, offers, onboarding) · ApexServe (screening cases, access provisioning) · ApexDocs (contracts and verification evidence) |
| **Keywords** | recruitment, requisition, hiring, interview, background verification, screening, offer, onboarding, probation, confirmation |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0004` · `ANB-HRM-POL-0006` · `ANB-HRM-POL-0008` · `ANB-ADM-MTX-0001` |

> **Standing.** This is an operating procedure, not a policy. It prescribes *how* hiring is executed. Where it references an entitlement or standard, the governing policy prevails. No employment offer may be made outside this procedure.

---

## 2. Purpose

Hiring is the single control that determines who the Bank lets inside its perimeter. A weak recruitment process does not produce a mediocre hire; it produces an unscreened person with access to customer data, payment systems, or credit authority.

This procedure therefore:

1. Requires every hire to begin with an **approved, funded requisition** tied to a position in ApexPeople.
2. Standardises **structured, evidenced selection** so that decisions are defensible and equitable.
3. Mandates **background verification proportionate to the role's risk**, completed before access is granted.
4. Controls **offer approval** within the enterprise authority matrix.
5. Makes **onboarding a control event**: identity verified, access provisioned from the position, mandatory training assigned, probation objectives set.
6. Closes the loop with a **decided probation** — confirmed or not, never drifting.

---

## 3. Scope

### 3.1 In Scope

All hiring into an Apex employment contract in any legal entity: permanent, fixed-term, part-time, intern, apprentice, and returner. Internal moves, promotions into a new role, and rehires. Executive hiring at G10 and above, with the additional steps in §11.5.

### 3.2 Out of Scope

Engagement of contractors, agency workers, and outsourced service personnel, which follows `ANB-PRC-POL-0001` and `ANB-PRC-POL-0002`. Such engagements still require identity verification, screening proportionate to access, and ApexID provisioning — but they are not employment and must never be processed as such. Converting a contractor to an employee requires a full requisition and the complete procedure below, including fresh screening.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | No hire without an approved requisition | 100% of hires traceable to an approved `REQ-` |
| O-2 | No access before verification | Zero instances of system access granted before screening clearance |
| O-3 | Selection is structured and evidenced | 100% of hiring decisions with scored, documented interviews |
| O-4 | Time to hire is competitive | Median 45 calendar days requisition approval to offer acceptance (G1–G6); 75 days (G7+) |
| O-5 | Hiring is equitable | Diverse shortlists for all G6+ roles; adverse-impact analysis at each stage annually |
| O-6 | Onboarding is complete before productive work | 100% of joiners with day-one training and access complete within 10 business days |
| O-7 | Probation is decided, not drifted | 100% of probations closed with a documented decision on or before the due date |
| O-8 | Early attrition is low | Voluntary leavers within 12 months below 8% |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Requisition** | The approved authorisation to fill a position, identified `REQ-######` in ApexPeople. |
| **Position** | The established seat in the organisation structure, carrying a grade, department, cost centre, and eligibility attributes. |
| **Candidate** | An applicant, identified `CND-########` in ApexPeople. |
| **Structured Interview** | An interview using a defined competency framework, consistent questions, and a scoring rubric. |
| **Background Verification (BGV)** | The screening performed before employment commences, proportionate to role risk. |
| **Regulatory Reference** | A reference in the prescribed regulatory format covering conduct history, required for regulated roles. |
| **Fitness and Propriety (F&P)** | The assessment of honesty, integrity, competence, and financial soundness for regulated roles. |
| **Enhanced Screening Role** | A role requiring extended verification per §10.5. |
| **Probation** | The initial assessment period following joining. |
| **Confirmation** | Formal completion of probation, recorded in ApexPeople. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Hiring Manager** | Define the role and requirements; raise the requisition; participate in every interview stage; make the selection recommendation; own onboarding and probation. |
| **Department Head (G9–G11)** | Approve requisitions within headcount and budget; approve offers within authority; confirm probation for G7+. |
| **Head of Talent Acquisition (`EMP-200103` Anjali Deshmukh, G8)** | Own the procedure, recruiter capacity, sourcing channels, agency panel, and hiring quality metrics. |
| **Recruiter (`EMP-200301` Emeka Achebe, `EMP-200302` Laura Kowalski, `EMP-200303` Nathan Boateng)** | Source, screen, manage the candidate experience, coordinate panels, and construct the offer. |
| **Recruitment Operations Officer (`EMP-200304` Meera Krishnan, G4)** | Initiate and track background verification, references, and right-to-work; escalate discrepancies. |
| **HR Business Partner (G6)** | Confirm grade and package; approve exceptions within band; advise on organisational design and hiring risk. |
| **Head of Reward (`EMP-200104` Stefan Feldman, G8)** | Approve offers outside the salary band and all sign-on and buy-out awards. |
| **Head of HR Operations (`EMP-200102` Owen Bradshaw, G8)** | Own contract issue, joiner data integrity, onboarding execution, and probation tracking. |
| **Compliance (`EMP-400103` Priyanka Iyer, G6)** | Confirm fitness and propriety for regulated roles; assess adverse screening findings; own regulatory reference requests and responses. |
| **Information Security (`EMP-500202` Tobias Lindgren, G8)** | Provision access from the position record; enforce no-access-before-clearance. |
| **Employment Legal (`EMP-600301` Beatriz Cardoso, G8)** | Own contract templates; advise on restrictive covenants, immigration, and adverse-action processes. |
| **Head of Global Mobility (`EMP-200108` Ekaterina Volkova, G7)** | Own visa sponsorship, relocation, and cross-border hiring. |
| **Head of Learning & Development (`EMP-200106` Hiroshi Tanabe, G8)** | Assign the mandatory curriculum on joining. |
| **Administration — Physical Security (`EMP-600201` Aurélie Dubois, G7)** | Issue badges after identity verification. |

---

## 7. Procedure Overview

```
STAGE 1  REQUISITION            Hiring Manager → Dept Head → Finance → HRBP
STAGE 2  SOURCING               Recruiter: internal first, then external
STAGE 3  SCREENING              Recruiter: CV screen, phone screen, right to work
STAGE 4  INTERVIEWS             Structured panel by grade (§9.4)
STAGE 5  SELECTION              Panel debrief, scored decision, diverse-slate check
STAGE 6  BACKGROUND VERIFICATION Recruitment Ops → Compliance for findings
STAGE 7  OFFER                  Constructed by Recruiter, approved per §11.2
STAGE 8  CONTRACT & ACCEPTANCE  HR Operations; e-signature; pre-boarding
STAGE 9  JOINING                Identity, badge, equipment, ApexID, Handbook
STAGE 10 ONBOARDING             Mandatory curriculum, declarations, 30-day check
STAGE 11 PROBATION              Objectives, reviews, decision
STAGE 12 CONFIRMATION           Recorded in ApexPeople; enters the annual cycle
```

---

## 8. Stage 1 — Job Requisition

### 8.1 Preconditions

A requisition may be raised only where: a position exists or has been created in ApexPeople with an evaluated grade; headcount is approved in the department's plan or a replacement is being made within 90 days of a leaver; funding is confirmed against a cost centre; and the hiring manager has confirmed that the work cannot be absorbed, automated, or met by internal redeployment.

### 8.2 Requisition Content

| Field | Requirement |
|---|---|
| Position and grade | From the evaluated position record; grade is not negotiable at requisition |
| Department, business unit, cost centre | Canonical codes per `ANB-ADM-REF-0001` §2.4 |
| Reporting line | Named manager, `EMP-######` |
| Replacement or incremental | Replacement requires the leaver's `EMP-######` |
| Job description | Purpose, accountabilities, competencies, qualifications, experience |
| Remote eligibility category | A–E per `ANB-HRM-POL-0003` §7.2 |
| Sensitive role designation | Per `ANB-HRM-HBK-0001` §11.4 |
| Regulated role indicator | Registration, certification, or approved-person requirement |
| Screening level | Standard or Enhanced, per §10.5 |
| Delegated authority attached | Credit, payment, or approval authority per `ANB-ADM-MTX-0001` |
| Salary band and total package range | From the Reward schedule |
| Justification | Business case; why the work cannot be absorbed |
| Target start date | — |
| Visa sponsorship | Whether the role is open to sponsorship |

A requisition missing the screening level, regulated indicator, or delegated authority is returned. These fields drive controls downstream and cannot be added later.

### 8.3 Requisition Approval

| Grade | Approver | Second | Third |
|---|---|---|---|
| G1–G3 replacement | Hiring Manager (G5+) | Department Head (G9) | — |
| G1–G3 incremental | Department Head (G9) | Finance (cost centre owner) | HRBP |
| G4–G6 replacement | Department Head (G9) | HRBP | — |
| G4–G6 incremental | Department Head (G9) | Finance | CHRO delegate |
| G7–G9 (any) | Department Head (G9–G11) | CHRO (G11) | CFO for incremental |
| G10–G11 | Group CEO (G12) | CHRO | Board Compensation & Human Capital Committee for ExCo |
| G12 | Board of Directors | — | — |
| Any role in a hiring freeze | Adds ExCo exception approval | — | — |

Approvals execute in ApexPeople workflow and are the authoritative record (`ANB-ADM-MTX-0001` §13).

### 8.4 Requisition Validity

A requisition is valid for **90 calendar days** from approval. Expiry requires re-approval, because headcount and budget conditions may have changed. A requisition may not be repurposed for a different position, grade, or department.

---

## 9. Stages 2–5 — Sourcing, Screening, and Selection

### 9.1 Internal First

Every requisition is posted internally for a minimum of **5 business days** before external sourcing, except where a genuine skill does not exist internally and the Head of Talent Acquisition has recorded that assessment. Internal candidates meeting the eligibility criteria in `ANB-HRM-POL-0006` §12.5 are interviewed before external candidates are shortlisted. Managers must not obstruct an internal application; obstruction is assessed under the M-4 leadership objective.

### 9.2 External Sourcing Channels

Direct sourcing by the Talent Acquisition team; the Apex careers site; the employee referral scheme (§12.4); approved job boards and professional networks; university and apprenticeship partnerships; approved agencies from the panel contracted by Procurement, used only where direct sourcing has not produced a viable slate after 20 business days; and executive search for G9 and above.

Agency use requires a signed panel agreement, agreed fee terms, and a recorded introduction; unsolicited CVs from non-panel agencies create no fee liability and are handled by Talent Acquisition, never by the hiring manager.

### 9.3 Screening

| Step | Standard |
|---|---|
| CV screen | Against documented essential criteria only; conducted by the recruiter; scored |
| Right to work | Established before interview scheduling for the jurisdiction concerned; documentary check per local law |
| Phone screen | 20–30 minutes; motivation, experience, package expectation, notice period, mobility |
| Conflict pre-check | Candidate asked to declare any Apex employee relationship, competitor restriction, or regulatory matter |
| Restrictive covenants | Candidate asked to disclose any non-compete or non-solicit; assessed by Employment Legal before offer where present |
| Diverse slate | For G6 and above, the shortlist presented to the panel must include candidates from under-represented groups; a non-diverse slate is widened, not waived |

### 9.4 Interview Stages by Grade

| Grade | Stages | Panel |
|---|---|---|
| G1–G3 | 2 | Hiring manager; one peer or team member |
| G4–G6 | 3 | Hiring manager; functional expert; cross-functional interviewer from another department |
| G7–G8 | 4 | Hiring manager; Department Head; cross-functional peer; HRBP values interview |
| G9 | 5 | As above plus an ExCo member |
| G10–G11 | 6+ | As above plus Group CEO; ExCo panel; Board Compensation & Human Capital Committee for ExCo appointments |
| Regulated roles (any grade) | Adds one | Compliance fitness and propriety interview |
| Control function roles | Adds one | Independence interview by the control function head |
| Technology roles G4+ | Adds one | Technical assessment, practical rather than puzzle-based |

Every panel includes at least one interviewer from outside the hiring department, and for G6 and above at least one interviewer from an under-represented group where reasonably practicable.

### 9.5 Structured Interviewing

| Requirement | Standard |
|---|---|
| Competency framework | Interviewers assess against the defined competencies for the grade, plus the seven Core Values |
| Question consistency | The same core questions are asked of every candidate for the role |
| Scoring | 1–5 per competency with written evidence, recorded in ApexPeople within 24 hours of the interview |
| Independence | Scores recorded before the panel debrief; interviewers do not discuss candidates beforehand |
| Prohibited questions | Age, marital or family status, pregnancy or family plans, health or disability (other than reasonable adjustments for the process), religion, sexual orientation, political affiliation, and — where local law prohibits it — current or prior salary |
| Adjustments | Reasonable adjustments offered proactively to every candidate |
| Interviewer training | Mandatory before serving on a panel; refreshed every two years (`ANB-HRM-POL-0008` §8.4) |
| Notes | Factual and role-related; interview notes are disclosable to the candidate on request under data protection law and are retained under `RET-REC-2Y` |

### 9.6 Selection Decision

The panel debriefs with all scores visible. The decision is recorded with the rationale in ApexPeople. Where the panel does not reach consensus, the hiring manager decides and records why, with the HRBP noting any dissent. A candidate may not be selected on "fit" alone; fit must be expressed as a specific, assessed competency or value. If no candidate meets the bar, the role is not filled — Talent Acquisition re-sources.

---

## 10. Stage 6 — Background Verification

### 10.1 Principle

**No employment commences and no system access is granted before verification is cleared.** Where a genuine commercial need requires a start before completion of a non-critical element, the Head of Talent Acquisition and Compliance may approve a conditional start with restricted access, recorded in ApexServe with a completion deadline. Identity, right to work, and criminal record checks may **never** be deferred.

### 10.2 Standard Screening — All Roles

| Check | Standard |
|---|---|
| Identity | Government photo identification verified in person or by approved digital verification |
| Right to work | Documentary verification per jurisdiction; sponsorship confirmed where applicable |
| Employment history | Last 5 years, or 3 previous employers, whichever is longer; gaps over 30 days explained |
| Education and professional qualification | Highest relevant qualification verified with the awarding institution |
| Professional membership and licence | Verified with the body; status and any disciplinary history |
| Criminal record | To the extent lawful in the jurisdiction, with fair-chance and ban-the-box rules observed where they apply |
| Regulatory register | Verified against applicable registers; disciplinary and enforcement history |
| Global sanctions and PEP screening | Against ApexKYC screening sources |
| Adverse media | Proportionate search |
| References | Two, at least one from the most recent employer's line manager (§10.4) |
| Directorship search | Disclosed and undisclosed directorships checked for conflicts |

### 10.3 Enhanced Screening — Additional Checks

Applies to roles listed in §10.5.

| Check | Standard |
|---|---|
| Employment history | Full 10 years, all gaps explained |
| Credit and financial soundness | Bankruptcy, insolvency, county court or equivalent judgments, and material adverse credit — assessed for relevance to the role's financial authority, never used as a blanket disqualifier |
| Regulatory reference | Requested in the prescribed format from all regulated employers in the last 6 years |
| Fitness and propriety | Compliance assessment of honesty, integrity, competence, and financial soundness |
| Litigation search | Civil litigation relevant to honesty or professional conduct |
| Additional references | Three, including a professional peer or client where the role is client-facing |
| Social media check | Only where role-relevant, conducted by a third party against defined criteria, with results limited to conduct that would breach `ANB-HRM-POL-0004`; never conducted by the hiring manager |

### 10.4 References

References are requested by Recruitment Operations, never by the hiring manager, and only after the candidate has consented and — for the current employer — after the offer is accepted, unless the candidate agrees earlier. A reference must be provided by the employer's HR function or the named line manager, from a corporate email domain, and is verified by call-back to a switchboard number the Bank has independently obtained. Personal references from friends or family are not accepted.

The Bank's own outbound references confirm role, dates, and grade as standard; regulatory references for regulated roles disclose conduct findings in the prescribed format and are given by Compliance, not by the former manager.

### 10.5 Enhanced Screening Roles

| Category | Examples |
|---|---|
| All roles at G7 and above | Any department |
| Payment release and wire operations | `ITO` payment operations |
| Cash and vault custody | Branch and cash centre roles |
| Credit authority holders | Any grade with delegated credit authority |
| Trading, dealing, and treasury operations | `TRY` |
| Registered and certified roles | Investment advisers, brokers, mortgage originators, insurance-licensed staff |
| Privileged technology access | Infrastructure and database administration, ApexID administrators |
| Customer data administration | Any role with bulk export or administrative access to customer data |
| Financial crime and fraud investigation | `CMP` |
| Internal Audit | All roles |
| Human Resources with access to personnel or pay data | `HRM` |
| Roles with procurement or vendor authority | `PRC` and category managers |
| Executive assistants and support to G10+ | Incidental access to MNPI |

Enhanced screening roles are re-screened every **3 years**, and immediately on promotion into an enhanced role, on assumption of delegated authority, or on a conduct concern.

### 10.6 Handling Adverse Findings

| Step | Action |
|---|---|
| 1 | Recruitment Operations logs the discrepancy in ApexServe; the case is classified Restricted (C3) |
| 2 | Compliance assesses relevance to the specific role — a finding is never automatically disqualifying |
| 3 | The candidate is told what has been found and given a genuine opportunity to explain, in writing, before any decision (pre-adverse action notice where FCRA or equivalent applies) |
| 4 | Assessment considers: relevance to the role and its authority; time elapsed; seriousness; pattern; candour in disclosure; and evidence of rehabilitation |
| 5 | Decision recorded with reasons: proceed; proceed with conditions such as restricted authority or enhanced supervision; or withdraw |
| 6 | Where the offer is withdrawn, adverse action notice is issued per FCRA or the local equivalent, with the report and dispute rights |
| 7 | Withdrawal above G6, or any withdrawal on the basis of criminal or credit history, is approved by the Head of Talent Acquisition with Compliance and Employment Legal |

**The single most serious finding is not the adverse item itself — it is a material misrepresentation by the candidate.** Concealment of a dismissal, a regulatory finding, a qualification, or an employment gap is a withdrawal ground in its own right, and if discovered after joining is gross misconduct under `ANB-HRM-POL-0004` §14.

---

## 11. Stage 7 — Offer

### 11.1 Offer Construction

The recruiter constructs the offer using: the evaluated grade and its salary band; the candidate's assessed level within the band based on experience and interview evidence; internal relativity checked against the existing team, which is the primary control against pay inequity; the market data provided by Reward; and any sign-on or buy-out award, which requires Head of Reward approval and, above defined thresholds, CHRO approval.

Offers are made at or below the band midpoint unless justified by evidenced experience. An offer that would create an internal inequity is not made; the band or the position is re-evaluated instead.

### 11.2 Offer Approval

| Offer | Approver | Second | Third |
|---|---|---|---|
| G1–G3, within band | Hiring Manager (G5+) | Recruiter validates | — |
| G4–G6, within band | Department Head (G9) | HRBP (G6) | — |
| G7–G8, within band | Department Head (G9–G11) | CHRO delegate | — |
| G9, within band | Department Head (G11) | CHRO (G11) | — |
| G10–G11 | Group CEO (G12) | CHRO | Board Compensation & Human Capital Committee for ExCo |
| Any offer above band | Adds Head of Reward (G8) | CHRO for >10% above band | — |
| Sign-on award up to $50,000 | Head of Reward (G8) | Department Head | — |
| Sign-on award above $50,000 | CHRO (G11) | CFO | — |
| Buy-out of deferred awards | CHRO **and** CFO | Board Compensation & Human Capital Committee for Material Risk Takers | — |
| Guaranteed variable pay | **Prohibited**, except a first-year guarantee approved by the Board Compensation & Human Capital Committee | — | — |
| Relocation package | Head of Global Mobility (G7) | Department Head | Head of Reward above $75,000 |
| Visa sponsorship | Head of Global Mobility (G7) | Department Head | — |
| Non-standard contract terms | Employment Legal (G8) | CHRO | — |

### 11.3 Offer Issue and Conditions

Every offer is conditional on: satisfactory background verification; documentary right to work; satisfactory references; where applicable, regulatory approval, registration, or fitness and propriety confirmation; and confirmation that the candidate is not subject to a restrictive covenant preventing performance of the role.

The offer letter is generated from the approved template, issued through ApexPeople for e-signature, and states role, grade, entity, location, remote eligibility category, start date, notice period, salary, variable pay eligibility and its discretionary nature, benefits, probation period, and the conditions above. Verbal offers are not permitted; a verbal indication is not an offer and must be stated as such.

### 11.4 Offer Validity and Withdrawal

Offers are valid for **10 business days**. Withdrawal before acceptance requires Head of Talent Acquisition approval and a recorded reason. Withdrawal after acceptance requires, in addition, Employment Legal review — the candidate may have resigned in reliance on the offer, and the Bank's exposure is assessed before the decision, not after.

### 11.5 Executive Hiring — Additional Steps

For G10 and above: executive search firm engaged through Procurement; candidate assessment supplemented by external psychometric and leadership assessment; referencing extended to five sources including a former direct report and a former peer; regulatory pre-approval obtained where the role is an approved or controlled function; Board Compensation & Human Capital Committee approval for ExCo appointments; announcement coordinated with Marketing and Investor Relations; and a documented 100-day onboarding plan owned by the Group CEO.

---

## 12. Stages 8–10 — Contract, Joining, and Onboarding

### 12.1 Contract and Pre-Boarding

| Timing | Action | Owner |
|---|---|---|
| Acceptance + 1 day | Employment contract issued for e-signature | HR Operations |
| Acceptance + 1 day | `EMP-######` created in ApexPeople; position linked; start date set | HR Operations |
| Acceptance + 2 days | Employee Handbook and Code of Conduct issued for pre-reading | HR Operations |
| Acceptance + 3 days | Equipment ordered against the position's standard build | IT Operations |
| Acceptance + 5 days | ApexID provisioning staged from the position — **not activated** | Identity & Access |
| Start − 10 days | Verification clearance confirmed; conditional-start exceptions escalated | Recruitment Operations |
| Start − 5 days | Manager confirms workspace, first-week schedule, and a named buddy | Hiring Manager |
| Start − 2 days | Joining instructions issued | HR Operations |

### 12.2 Day One

| Sequence | Action | Owner | Control |
|---|---|---|---|
| 1 | Identity verified in person against the documents used at screening | HR Operations | Prevents substitution between offer and start |
| 2 | Right-to-work originals inspected and recorded | HR Operations | Statutory |
| 3 | Badge issued | Physical Security | ApexAccess |
| 4 | Equipment issued and asset record signed | IT Operations | ApexServe |
| 5 | ApexID credentials activated with MFA enrolment | Identity & Access | Only after steps 1–2 |
| 6 | Access provisioned from the position's role profile only | Identity & Access | No manual entitlement grants on day one |
| 7 | Welcome and orientation; Handbook attestation | HRBP | ApexLearn |
| 8 | Mandatory day-one curriculum assigned | Training Coordinator | ApexLearn |
| 9 | Team introduction; buddy assigned | Hiring Manager | — |

### 12.3 First 30 Days

| Timing | Action | Owner |
|---|---|---|
| Days 1–5 | Day-one mandatory curriculum: Code of Conduct, Information Security Awareness, Data Privacy, AML/KYC Foundation, Health & Safety | Employee |
| Days 1–10 | Conflict of interest declaration; outside business activity declaration; personal account registration where a Covered Person | Employee, Compliance |
| Days 1–14 | Probation objectives set in ApexPeople | Hiring Manager |
| Days 1–20 | Role-based curriculum assigned and started (`ANB-HRM-POL-0008` §9) | Training Coordinator |
| Days 1–30 | Remote work arrangement established, if eligible, after the on-site minimum (`ANB-HRM-POL-0003` §7.4) | Hiring Manager |
| Day 30 | First formal check-in recorded | Hiring Manager |
| By day 45 | Regulatory registration completed where required | Compliance |

**Enforcement.** Day-one curriculum incomplete after 10 business days suspends non-essential system access until completed (`ANB-HRM-POL-0008` §11.3).

---

## 13. Stages 11–12 — Probation and Confirmation

### 13.1 Probation Periods

| Grade | Standard Probation | Maximum with Extension |
|---|---|---|
| G1–G3 | 3 months | 6 months |
| G4–G6 | 6 months | 9 months |
| G7–G9 | 6 months | 12 months |
| G10–G12 | 6 months | 12 months |

Notice during probation is shortened per the contract, typically 1 week at G1–G3 and 4 weeks at G4 and above, subject to local statutory minima.

### 13.2 Probation Management

| Milestone | Action | Owner |
|---|---|---|
| Day 14 | Objectives set, covering delivery, capability, behaviour, and mandatory training | Hiring Manager |
| Day 30 | First check-in; any concern raised now, not later | Hiring Manager |
| Midpoint | Formal review recorded; explicit statement of whether the employee is on track | Hiring Manager |
| Minus 30 days | Decision review with the HRBP; where the outcome is in doubt, a written improvement note is issued with at least 30 days to respond | Hiring Manager, HRBP |
| Due date | Decision recorded: confirm, extend, or terminate | Hiring Manager, Department Head |

**A probation that lapses without a decision confirms the employee by default.** This is a control failure attributable to the manager and is reported in the monthly HR Operations exception pack.

### 13.3 Confirmation Criteria

Delivery of the probation objectives; demonstrated competence for the grade; behaviour consistent with the Core Values; **completion of the entire mandatory curriculum** — no confirmation is permitted with training outstanding; conflict and outside activity declarations complete; regulatory registration complete where required; attendance and reliability satisfactory; and no unresolved conduct concern.

### 13.4 Extension and Termination

Extension requires: a specific reason; defined objectives for the extension period; written notice before the original due date; and Department Head and HRBP approval. Only one extension is permitted.

Termination during probation requires: documented evidence that concerns were raised and support given; HRBP review; Employment Legal review at G7 and above or where any discrimination or whistleblowing sensitivity exists; Department Head approval; and adherence to any statutory process. Termination during probation for conduct follows `ANB-HRM-POL-0004` §14, not this section.

### 13.5 On Confirmation

Recorded in ApexPeople and confirmed in writing. Full notice periods apply from the confirmation date. The employee enters the annual performance cycle under `ANB-HRM-POL-0006`, with objectives pro-rated for the remainder of the year. Remote eligibility beyond the on-site minimum is established. Benefit eligibility that is service-linked commences.

---

## 14. Decision Tables

### 14.1 Screening Level Determination

| Role Attribute | Screening Level |
|---|---|
| G7 and above | Enhanced |
| Holds delegated credit, payment, or expenditure authority | Enhanced |
| Cash or vault custody | Enhanced |
| Registered, certified, or approved person | Enhanced |
| Privileged technology or identity administration | Enhanced |
| Bulk customer data access | Enhanced |
| Internal Audit, Financial Crime, or Employee Relations | Enhanced |
| HR with personnel or pay data access | Enhanced |
| Procurement or vendor authority | Enhanced |
| All other roles | Standard |
| Intern or apprentice with no customer data access | Standard, with references reduced to one academic and one other |

### 14.2 Adverse Finding Scenarios

| Finding | Typical Outcome |
|---|---|
| Undisclosed 7-month employment gap, explained as caring responsibility, verified | Proceed |
| Employment dates differ by two months from the CV, candidate acknowledges an error | Proceed; note recorded |
| Employment dates materially misstated and a dismissal concealed | Withdraw — misrepresentation |
| Spent minor conviction from 14 years ago, unrelated to the role, disclosed voluntarily | Proceed |
| Recent conviction for dishonesty, role involves cash custody | Withdraw, with adverse action process |
| Recent conviction for dishonesty, role has no financial authority | Assessed on relevance; may proceed with conditions |
| Adverse credit following a documented medical bankruptcy, role has no financial authority | Proceed |
| Adverse credit, role holds payment release authority | Assessed by Compliance; may proceed with restricted authority and enhanced supervision |
| Regulatory reference discloses a conduct finding for a mis-selling matter | Compliance F&P assessment; often withdrawal for a client-facing regulated role |
| Professional qualification claimed but not held | Withdraw — misrepresentation |
| Candidate is subject to an enforceable non-compete covering the role | Employment Legal assessment; likely deferred start or role adjustment |
| Candidate's partner is an Apex employee in the same reporting chain | Proceed with a reporting-line change; declared under `ANB-HRM-POL-0004` §8 |

### 14.3 Common Scenarios

| Scenario | Outcome |
|---|---|
| Hiring manager wants to start a candidate before BGV completes | Conditional start only with Head of Talent Acquisition and Compliance approval, restricted access, and a completion deadline. Identity, right to work, and criminal checks are never deferred. |
| Manager has "already promised the job" to someone | The requisition, sourcing, and structured process still apply. A promise made outside the process is not an offer and is a management issue. |
| Only one candidate applied and they are adequate | Do not hire. Re-source. "Adequate because they were the only one" is how a hiring bar decays. |
| Shortlist for a G7 role contains no under-represented candidates | Slate widened before panel; not waived. |
| Internal candidate and stronger external candidate for the same role | Both interviewed; the better candidate is selected on evidence. Internal-first means considered first, not preferred regardless. |
| Candidate requests a reasonable adjustment for interview | Provided without question and without affecting assessment; no explanation required. |
| Candidate declines to disclose current salary in a jurisdiction where asking is prohibited | Not asked in the first place. Offer built from the band, not the candidate's history. |
| Agency submits a CV directly to the hiring manager, not on the panel | No fee liability; routed to Talent Acquisition; the manager does not engage. |
| Referred candidate is a family member of the hiring manager | Referral permitted; the manager is removed from the entire selection process and the referral award is not payable. |
| Employee referred a candidate who is hired then leaves in month 4 | Referral award not payable — the 6-month condition in §12.4 is not met. |

### 14.4 Employee Referral Scheme

Any employee may refer a candidate through ApexPeople. The award is paid after the referred employee completes **6 months** of service and is confirmed. Awards scale by grade band and are higher for roles designated hard-to-fill. Awards are not payable where: the referrer is in the hiring chain or on the panel; the referrer is a member of Human Resources; the candidate is a family member or partner of the referrer without full recusal; or the candidate was already in the Bank's active candidate pool. Referrals do not bypass any stage of this procedure.

---

## 15. Approval Matrix — Procedure Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| SOP Major version | Head of Talent Acquisition (G8) | Compliance, Employment Legal, Information Security, HR Operations, Global Mobility | CHRO (G11) | ExCo |
| SOP Minor version | Head of Talent Acquisition | Employment Legal | HR Director (G9) | Hiring managers |
| Screening standard change | Head of Talent Acquisition | Compliance, Employment Legal, Information Security | CHRO **and** CCO | ExCo; Operational Risk Committee |
| Enhanced screening role list change | Head of Operational Risk (G8) | Compliance, HR Operations | CHRO **and** CCO | Affected departments |
| Interview stage or panel change | Head of Talent Acquisition | HRBPs | HR Director (G9) | Hiring managers |
| Agency panel appointment | Head of Category Management (G8) | Talent Acquisition, Legal | Chief Procurement Officer (G10) | `ANB-ADM-MTX-0001` §9.1 |
| Contract template change | Employment Legal (G8) | HR Operations | General Counsel (G11) | HR Operations |
| Referral scheme change | Head of Reward (G8) | Finance | CHRO | All staff |
| Hiring freeze | CFO **and** CHRO | ExCo | Group CEO (G12) | All departments |

---

## 16. Records and Retention

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Requisition and approvals | `REQ-######` | ApexPeople | C1 | `RET-REC-2Y` |
| Job description | `REQ-######` | ApexPeople, ApexDocs | C1 | `RET-HRM-7Y` |
| Candidate application and CV | `CND-########` | ApexPeople | C2 | `RET-REC-2Y` (unsuccessful) / `RET-HRM-7Y` (hired) |
| Interview scores and notes | `CND-########` | ApexPeople | C2 | `RET-REC-2Y` / `RET-HRM-7Y` |
| Selection decision and rationale | `REQ-######` | ApexPeople | C2 | `RET-REC-2Y` / `RET-HRM-7Y` |
| Background verification report | `CND-########` | ApexServe, ApexDocs | C3 | `RET-HRM-7Y` |
| Adverse finding assessment | `CAS-########` | ApexServe | C3 | `RET-HRM-7Y` |
| References received and given | `CND-########` / `EMP-######` | ApexDocs | C2 | `RET-HRM-7Y` |
| Regulatory reference | `EMP-######` | ApexDocs | C2 | `RET-HRM-7Y` |
| Offer letter and acceptance | `REQ-######` | ApexPeople, ApexDocs | C2 | `RET-HRM-7Y` |
| Employment contract | `EMP-######` | ApexDocs | C2 | `RET-HRM-7Y` |
| Right-to-work evidence | `EMP-######` | ApexPeople (restricted) | C3 | `RET-HRM-7Y` |
| Onboarding and training completion | `EMP-######` | ApexLearn | C1 | `RET-TRN-5Y` |
| Probation objectives, reviews, decision | `PRF-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Adverse-impact analysis | Annual | ApexInsight, ApexDocs | C2 | `RET-HRM-7Y` |

Unsuccessful candidate data is retained for **2 years** (`RET-REC-2Y`) to support discrimination-claim defence and regulatory review, then deleted unless the candidate has consented to talent-pool retention. Deletion follows the defensible destruction process in `ANB-ADM-POL-0001` §13.

---

## 17. Metrics

| Metric | Target | Reported To |
|---|---|---|
| Time to hire — requisition approval to acceptance | Median 45 days (G1–G6); 75 days (G7+) | Department Heads monthly |
| Time to fill — requisition approval to start | Median 75 days (G1–G6); 110 days (G7+) | Department Heads monthly |
| Offer acceptance rate | ≥ 85% | Head of Talent Acquisition |
| Direct sourcing share | ≥ 70% of external hires | Head of Talent Acquisition |
| Agency cost per hire | Tracked against budget | Finance |
| Diverse shortlist compliance (G6+) | 100% | CHRO; ExCo quarterly |
| Adverse-impact ratio at each stage | Within accepted thresholds | CHRO; annual review with Employment Legal |
| Screening completed before start | 100% | Operational Risk Committee |
| Day-one training complete within 10 business days | ≥ 98% | Head of Learning & Development |
| Probation decisions made on time | 100% | HR Operations monthly exception pack |
| 12-month voluntary attrition of new hires | < 8% | CHRO; ExCo |
| Internal fill rate | ≥ 35% of all hires | CHRO |
| Candidate experience score | ≥ 4.0 / 5.0 | Head of Talent Acquisition |

---

## 18. Examples

### 18.1 Full Cycle — Branch Manager, Charlotte Uptown

Replacement hire for `SIT-0412` following an internal promotion.

| Day | Stage | Action | Actor |
|---|---|---|---|
| 0 | 1 | `REQ-114820` raised: G5, RTL, Charlotte, Category A remote eligibility, sensitive role (vault custody), Enhanced screening, delegated cash authority | `EMP-300102` Victor Salazar |
| 2 | 1 | Approved: Department Head and HRBP | `EMP-100014` Gregory Lin, `EMP-200201` Fiona Gallagher |
| 3 | 2 | Posted internally for 5 business days | `EMP-200302` Laura Kowalski |
| 8 | 2 | Two internal applicants; external sourcing opened in parallel | Recruiter |
| 12–20 | 3 | CV screens, right-to-work checks, phone screens; shortlist of 5, diverse slate confirmed | Recruiter |
| 22–30 | 4 | Three stages: hiring manager; functional (Head of Retail Operations `EMP-300101` Patricia Nwankwo); cross-functional (Compliance Officer `EMP-400104` Oluwaseun Bakare) | Panel |
| 31 | 5 | Debrief; scored decision recorded; internal candidate second, feedback given within 5 days | Panel |
| 32 | 6 | Enhanced BGV initiated: 10-year history, credit, criminal, regulatory register, three references | `EMP-200304` Meera Krishnan |
| 39 | 6 | Finding: a 2018 county court judgment, satisfied 2019. Compliance assesses relevance to cash custody | `EMP-400103` Priyanka Iyer |
| 40 | 6 | Candidate given the opportunity to explain in writing: medical debt, satisfied in full, no pattern. Cleared | Compliance |
| 41 | 7 | Offer constructed at 46th percentile of band; internal relativity checked against two peer Branch Managers | Recruiter |
| 42 | 7 | Approved: Department Head and HRBP | `EMP-100014`, `EMP-200201` |
| 43 | 7 | Offer issued; accepted day 46 | Candidate |
| 47 | 8 | Contract e-signed; `EMP-300107` created; ApexID staged, not activated | HR Operations |
| 76 | 9 | Day one: identity verified against screening documents; badge; equipment; ApexID activated; Handbook attested | HR Operations, Physical Security, Identity & Access |
| 76–80 | 10 | Day-one curriculum completed | Employee |
| 90 | 10 | Probation objectives set (day 14 of employment) | `EMP-300102` |
| 106 | 10 | 30-day check-in recorded | `EMP-300102` |
| 256 | 11 | Midpoint review: on track | `EMP-300102` |
| 256 | 11 | Mandatory consecutive absence scheduled for the following year per `ANB-HRM-POL-0002` §9 | Employee |
| 259 | 12 | Confirmed at 6 months; full mandatory curriculum complete; enters the annual cycle | `EMP-300102`, `EMP-100014` |

Time to hire: 46 days. Time to fill: 76 days.

### 18.2 Withdrawal for Misrepresentation

A candidate for a G6 Compliance Officer role states on their CV that they hold CAMS certification and that they left their previous employer by resignation.

Verification with ACAMS shows the certification lapsed three years ago. The regulatory reference from the previous employer discloses that employment ended following a disciplinary process for failing to escalate a suspicious activity concern.

The candidate is given the opportunity to explain both. They acknowledge the lapsed certification as an "oversight" and do not address the dismissal. The Head of Talent Acquisition, with Compliance and Employment Legal, withdraws the offer: not because of the lapsed certification, which is remediable, and not solely because of the disciplinary outcome, which would have been assessed on its facts — but because both were misrepresented. Adverse action notice is issued with dispute rights. The decision and its reasoning are recorded under `RET-HRM-7Y`.

### 18.3 Conditional Start

A Severity 1 remediation programme requires a specialist engineer to start within 5 business days. All screening is complete except one employment verification with a former employer that has been acquired and is slow to respond.

The Head of Talent Acquisition and Compliance approve a conditional start recorded in ApexServe: identity, right to work, criminal record, and regulatory checks all complete; access restricted to the non-production environment only; no customer data access; supervision by a named engineer; completion deadline of 20 business days. The outstanding verification returns clean on day 14, and full access is provisioned. Had it not returned, employment would have terminated under the conditional offer terms.

---

## 19. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Grades, departments, entities, systems |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Lifecycle stages 1–7; joining; canonical employee register |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Entitlement from day one; sensitive-role mandatory absence |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Candidate travel; relocation travel |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | Remote eligibility category on the requisition; on-site probation minimum |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Declarations at joining; misrepresentation as gross misconduct |
| `ANB-HRM-POL-0006` | Performance Management Policy | `02_human_resources/006_PERFORMANCE_MANAGEMENT_POLICY.md` | Probation-to-cycle transition; internal mobility; promotion re-screening |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | Day-one and role-based curriculum; interviewer training |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Requisition, offer, and package authorities |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | `RET-REC-2Y`, `RET-HRM-7Y`, defensible destruction |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.1` Hiring; Employee entity |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | `HRRQ`, `HRCV`, `HRBG`, `HROF` naming |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-HIRE`, `BP-HR-SCRN`, `BP-HR-ONB` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Board Compensation & Human Capital Committee |
| `ANB-HRM-POL-0005` | Compensation & Incentive Governance Policy | *(planned)* | Bands, sign-on, buy-out, guarantees |
| `ANB-PRC-POL-0001` / `ANB-PRC-POL-0002` | Procurement / Third-Party Risk Management Policy | *(planned)* | Agency panel; contractor engagement |
| `ANB-ISC-POL-0001` | Information Security Policy | *(planned)* | Access provisioning; joiner controls |

---

## 20. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review and re-approval | Head of Talent Acquisition | Annually by 31 July |
| Screening regulation change (FCRA, ban-the-box, GDPR, regulatory references) | Targeted amendment | Employment Legal with Compliance | 30 days |
| Adverse-impact analysis showing a differential | Process review and remediation | Head of Talent Acquisition with Employment Legal | 60 days |
| Screening failure or unscreened access | Root cause to the Operational Risk Committee | Head of Talent Acquisition | 15 days |
| New operating jurisdiction | Local screening and right-to-work annex published before first hire | Head of Global Mobility | Before first hire |
| Audit finding on hiring controls | Remediation plan | Head of Talent Acquisition | 30 days |

Next scheduled review: **2027-07-24**.

---

## 21. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-14 | Talent Acquisition | Initial draft; requisition-to-confirmation flow defined | — |
| 0.3 | 2026-06-30 | Talent Acquisition | Screening levels and enhanced role list added with Compliance and Operational Risk | — |
| 0.5 | 2026-07-08 | Talent Acquisition | Adverse-finding handling and FCRA adverse action process added by Employment Legal | — |
| 0.7 | 2026-07-16 | Talent Acquisition | Structured interviewing, diverse slates, and adverse-impact analysis added | — |
| 0.9 | 2026-07-22 | Talent Acquisition | Day-one control sequence agreed with Information Security; no-access-before-clearance rule made explicit | — |
| 1.0 | 2026-07-24 | Talent Acquisition | First published version | Y. Carter |

---

## 22. Appendices

### Appendix A — Hiring Manager Checklist

**Before raising a requisition:** Can the work be absorbed, automated, or filled internally? Is the position evaluated and funded? Do I know the screening level, regulated status, remote category, and delegated authority for this role?

**Before interviewing:** Have I completed interviewer training in the last two years? Do I have the competency framework and the same core questions for every candidate? Is my panel diverse and cross-functional?

**During:** Score independently before the debrief. Record evidence, not impressions. Never ask a prohibited question. Offer adjustments proactively.

**After selection:** Give unsuccessful candidates specific feedback within 5 business days. Do not contact the candidate about start dates until verification clears.

**Before day one:** Workspace, first-week schedule, buddy assigned, equipment confirmed.

**In the first 30 days:** Probation objectives by day 14. Check-in by day 30. Chase the mandatory curriculum — an incomplete curriculum at day 10 costs your new joiner their access.

**Before the probation due date:** Decide 30 days early. A lapsed probation confirms by default and is recorded as your control failure.

### Appendix B — Candidate Journey and Service Levels

| Stage | Candidate Experience Commitment |
|---|---|
| Application | Acknowledged within 2 business days |
| CV screen outcome | Communicated within 10 business days |
| Interview scheduling | Offered within 5 business days of screen pass |
| Adjustments | Offered proactively at every stage |
| Interview outcome | Communicated within 5 business days of the final stage |
| Feedback | Specific and role-related for anyone who reached interview |
| Offer | Issued within 3 business days of the decision |
| Verification | Progress communicated weekly |
| Adverse finding | Candidate told and given a genuine opportunity to explain before any decision |
| Pre-boarding | Contact at least weekly between acceptance and start |

### Appendix C — Interview Stage Map

| Stage | Purpose | Typical Interviewer | Assesses |
|---|---|---|---|
| Phone screen | Qualify | Recruiter | Experience, motivation, package, mobility, availability |
| Hiring manager | Capability | Hiring manager | Role competencies, technical depth, judgment |
| Functional expert | Technical depth | Peer or specialist | Domain skill, practical problem solving |
| Cross-functional | Collaboration and enterprise fit | Interviewer from another department | Working across boundaries, challenge, escalation instinct |
| HRBP values interview | Behaviour | HRBP | Core Values, inclusion, conduct instincts |
| Compliance F&P | Regulatory suitability | Compliance officer | Honesty, integrity, competence, financial soundness |
| Control function independence | Independence | Control function head | Willingness to hold a position under pressure |
| Executive panel | Leadership | ExCo member | Strategic judgment, enterprise leadership |

### Appendix D — Right to Work and Local Annexes

Right-to-work verification is jurisdiction-specific and is executed against the local annex maintained by Global Mobility. Annexes exist for: United States (Form I-9 and E-Verify where applicable), United Kingdom, Ireland, Germany, France, Netherlands, Spain, Italy, Poland, Canada, India, United Arab Emirates, Singapore, Hong Kong SAR, Japan, Australia, Brazil, Mexico, and Switzerland. Each annex specifies acceptable documents, timing, re-verification triggers, retention, and the local screening constraints — including jurisdictions where criminal record or credit checks are restricted or prohibited for certain roles.

Where an annex does not exist for a jurisdiction, hiring may not proceed until one is published by the Head of Global Mobility with local employment counsel.

---

**End of Document**

`ANB-HRM-SOP-0007` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) · Approver: Yvonne Carter, Chief Human Resources Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
