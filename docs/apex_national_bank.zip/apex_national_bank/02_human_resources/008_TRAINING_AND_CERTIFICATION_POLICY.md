# Apex National Bank — Training and Certification Policy

**Human Resources Policy | Mandatory Curriculum, Role Certification, and Learning Governance**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-POL-0008` |
| **Document Title** | Apex National Bank — Training and Certification Policy |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) — Learning & Development |
| **Custodian** | Hiroshi Tanabe, Head of Learning & Development (G8) — `EMP-200106` |
| **Approver** | Yvonne Carter, Chief Human Resources Officer (G11) — `EMP-100008` |
| **Secondary Approvers** | Samuel A. Okonkwo, Chief Compliance Officer; Helena Brandt, Chief Risk Officer; Nadia Ferreira, Chief Information Security Officer |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-16 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24); curriculum reviewed semi-annually |
| **Supersedes** | None — initial published policy |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.3` Learning → Mandatory Training · Certification → `POL` |
| **Business Process** | `BP-HR-TRN` Learning, Mandatory Training & Certification |
| **Governing Body** | Executive Committee; Public Responsibility & Compliance Committee (mandatory curriculum assurance) |
| **System of Record** | ApexLearn (delivery, completion, attestation, certification) · ApexPeople (role and grade drivers) · ApexDocs (this policy) |
| **Keywords** | training, mandatory training, certification, AML, KYC, information security, fraud, risk, leadership, learning management, refresher |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-FIN-POL-0002` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0004` · `ANB-HRM-POL-0006` · `ANB-HRM-SOP-0007` |

> **Authority.** Mandatory training is a **condition of employment**, stated in `ANB-ADM-REF-0001` §1.7. Completion evidence is produced to regulators and external auditors. Nothing in this Policy permits an exemption from a legally or regulatorily mandated module.

---

## 2. Purpose

Training in a bank is not development. It is evidence. When a supervisor asks how the Bank ensures its staff understand their anti-money-laundering obligations, the answer is a completion record with a name, a date, an assessment score, and an attestation — for every person in scope, with no gaps.

This Policy therefore:

1. Defines the **mandatory enterprise curriculum** every employee completes, and its frequency.
2. Defines **role-based curricula and certifications** triggered by position, grade, authority, and system access.
3. Establishes **completion enforcement** with consequences that are automatic, not discretionary.
4. Governs **certification validity, renewal, and lapse**.
5. Sets out the **development and leadership offer** that sits above the mandatory floor.
6. Makes training records **auditable, retained, and produced on demand**.

---

## 3. Scope

### 3.1 Applies To

| Population | Coverage |
|---|---|
| All employees, all grades G1–G12, all Apex legal entities | Full enterprise and role-based curricula |
| Board members | Directors' induction and annual governance, financial crime, cyber, and conduct briefings |
| Contractors, agency workers, and vendor personnel with Bank system access | Enterprise curriculum modules relevant to their access, assigned in ApexLearn and contracted under `ANB-PRC-POL-0002` |
| Interns and apprentices | Enterprise curriculum in full |
| Employees on long-term absence | Curriculum deferred and reassigned on return (§11.4) |

### 3.2 System of Record

**ApexLearn (Cornerstone OnDemand) is the sole system of record for training completion and attestation evidence.** Training delivered by any channel — e-learning, classroom, virtual classroom, external provider, on-the-job assessment — must be recorded in ApexLearn. Training completed but not recorded in ApexLearn did not, for governance purposes, occur.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Regulatory training obligations are met without gaps | 100% enterprise mandatory completion by due date; zero regulatory findings on training evidence |
| O-2 | Role certification is current | 100% of certification-required roles held by currently certified individuals |
| O-3 | Non-completion has consequence | 100% of overdue cases escalated per §11 with no manual override |
| O-4 | Training changes behaviour | Assessment pass rates, phishing simulation failure rates, and control incident correlation tracked and reported |
| O-5 | Evidence is producible on demand | Complete evidence pack available to any regulator or auditor within 2 business days |
| O-6 | Capability is built, not just compliance | ≥ 85% of employees with an active development plan; leadership programme completion targets met |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Mandatory Training** | A module every employee in scope must complete by a defined date, as a condition of employment. |
| **Enterprise Curriculum** | The set of mandatory modules applying to all employees regardless of role. |
| **Role-Based Curriculum** | Modules assigned by position, grade, authority, department, or system access. |
| **Certification** | A formal credential — internal or external — required to hold a role or exercise an authority. |
| **Refresher** | The periodic repeat of a module to maintain currency. |
| **Attestation** | A recorded personal confirmation carrying the weight of a signature. |
| **Due Date** | The date by which completion must be recorded in ApexLearn. |
| **Overdue** | Any day after the due date with completion not recorded. |
| **Lapsed Certification** | A certification whose validity period has expired without renewal. |
| **Continuing Education (CE)** | Ongoing learning hours required to maintain an external credential. |
| **Assignment Trigger** | The event in ApexPeople that causes ApexLearn to assign a curriculum. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Employee** | Complete every assigned module by its due date; maintain role certifications; log CE hours; declare any barrier to completion in advance, not after. |
| **Line Manager** | Ensure the team's completion; a report's overdue training is the manager's compliance failure as much as the employee's; approve time to complete; escalate genuine barriers. |
| **Department Head (G9–G11)** | Own departmental completion; receive escalation at 15 days overdue; approve deferrals. |
| **Head of Learning & Development (`EMP-200106` Hiroshi Tanabe, G8)** | Own the curriculum architecture, ApexLearn, delivery quality, evidence integrity, and reporting. |
| **Training Coordinator — Compliance Curriculum (`EMP-200401` Bianca Ferraro, G4)** | Administer and monitor the AML, KYC, conduct, and regulatory curricula; produce evidence packs. |
| **Training Coordinator — Technology & Security Curriculum (`EMP-200402` Kwame Asante, G4)** | Administer security, privacy, and technology curricula; coordinate phishing simulation follow-up. |
| **Chief Compliance Officer (`EMP-100005` Samuel A. Okonkwo, G11)** | Own the content and adequacy of financial crime, conduct, and regulatory modules; attest to their sufficiency to the Board. |
| **Head of Financial Crime (`EMP-400101` Adeline Mercier, G9)** | Own AML, KYC, sanctions, and fraud curriculum content. |
| **Chief Risk Officer (`EMP-100004` Helena Brandt, G11)** | Own risk management, credit, and operational risk curriculum content. |
| **Chief Information Security Officer (`EMP-100010` Nadia Ferreira, G10)** | Own information security and cyber curriculum content; own phishing simulation. |
| **Chief Data Officer (`EMP-100011` Elena Vasquez, G10)** | Own data privacy, data governance, and responsible AI curriculum content. |
| **Head of Employee Relations (`EMP-200105` Grace Mwangi, G8)** | Own conduct escalation for persistent non-completion. |
| **Internal Audit (`EMP-400301` Imani Cole, G8)** | Test training completion and evidence integrity as a control. |
| **Head of Talent & Performance (`EMP-200107` Camille Duforest, G8)** | Link completion to performance ratings under `ANB-HRM-POL-0006` §9.4. |

**Content ownership rule.** Learning & Development owns delivery, tracking, and evidence. The relevant second-line function owns **content**. L&D may not amend the substance of a compliance, risk, security, or privacy module without the owning function's approval.

---

## 7. Policy Statements

**TR-1.** Mandatory training is a condition of employment. Non-completion is not a scheduling problem; it is a compliance failure with defined consequences.

**TR-2.** Time to complete mandatory training is working time and is provided. A manager who declines to release an employee for mandatory training has themselves breached this Policy.

**TR-3.** ApexLearn is the sole system of record. No spreadsheet, email confirmation, or departmental tracker constitutes evidence.

**TR-4.** No individual may complete a module on another's behalf, share assessment answers, or bypass content. Doing so falsifies a regulatory record and is gross misconduct under `ANB-HRM-POL-0004` §14.

**TR-5.** No role requiring certification may be held by an uncertified individual. Where a certification lapses, the authority attaching to the role is suspended until it is restored.

**TR-6.** Escalation and access consequences for overdue training are **automatic and system-driven**. No manager may waive them; only the defined approvers may grant a deferral, and only in advance.

**TR-7.** Training assignment is driven by the position record in ApexPeople. A change of role, grade, authority, or system access reassigns the curriculum automatically.

**TR-8.** Completion evidence is retained under `RET-TRN-5Y` and produced to regulators and auditors on demand.

**TR-9.** Content is reviewed at least annually and immediately following a regulatory change, an enforcement action in the industry, or a material internal incident. Training that has not changed in three years is presumed stale.

**TR-10.** Training effectiveness is measured by behaviour, not completion. Completion at 100% with a rising phishing failure rate is a failure, not a success.

---

## 8. Standards — Enterprise Mandatory Curriculum

Assigned to every employee, contractor, and Board member in scope. Frequency is from the last completion date, not the calendar year, except where stated.

| # | Module | Frequency | Duration | Owner | Assessment |
|---|---|---|---|---|---|
| E-1 | **Code of Conduct and Ethics** — with annual attestation per `ANB-HRM-POL-0004` §16 | Annual | 60 min | CHRO / General Counsel | 80% pass; attestation |
| E-2 | **Anti-Money Laundering and Counter-Terrorist Financing** | Annual | 90 min | Head of Financial Crime | 85% pass |
| E-3 | **Know Your Customer and Customer Due Diligence** | Annual | 60 min | Head of Financial Crime | 85% pass |
| E-4 | **Sanctions and OFAC Compliance** | Annual | 45 min | Head of Sanctions | 85% pass |
| E-5 | **Information Security Awareness** | Annual | 60 min | CISO | 80% pass |
| E-6 | **Phishing and Social Engineering** — plus continuous simulation | Annual + continuous | 30 min | Head of Cyber Defence | Simulation-based |
| E-7 | **Data Privacy and Protection** — GDPR, GLBA, CCPA and equivalents | Annual | 45 min | Chief Data Officer | 80% pass |
| E-8 | **Fraud Awareness and Prevention** | Annual | 45 min | Head of Fraud | 80% pass |
| E-9 | **Anti-Bribery and Corruption** — FCPA, UK Bribery Act | Annual | 45 min | Chief Compliance Officer | 85% pass |
| E-10 | **Operational Risk and the Three Lines of Defence** | Annual | 45 min | Head of Operational Risk | 80% pass |
| E-11 | **Speak-Up, Whistleblowing, and Non-Retaliation** | Annual | 30 min | Head of Employee Relations | Attestation |
| E-12 | **Respect at Work** — harassment, discrimination, inclusion | Annual | 60 min | CHRO | 80% pass |
| E-13 | **Records Management and Retention** | Every 2 years | 30 min | Head of Records Management | 80% pass |
| E-14 | **Business Continuity and Incident Response** | Annual | 30 min | Head of Business Continuity | Attestation |
| E-15 | **Health, Safety, and Wellbeing** | Every 2 years | 30 min | Head of Physical Security | Attestation |
| E-16 | **Responsible Use of Artificial Intelligence** | Annual | 30 min | Chief Data Officer | 80% pass |
| E-17 | **Consumer Fair Treatment and UDAAP** | Annual | 45 min | Chief Compliance Officer | 85% pass — customer-facing and product roles |
| E-18 | **Remote and Hybrid Working Security** | Annual | 20 min | CISO | Attestation — remote-eligible employees |

### 8.1 Day-One Curriculum

New joiners complete a subset within their first 5 business days, before productive work in most roles: **E-1** Code of Conduct, **E-5** Information Security Awareness, **E-7** Data Privacy, **E-2/E-3** AML and KYC Foundation, and **E-15** Health & Safety. Failure to complete within 10 business days suspends non-essential system access (§11.3).

### 8.2 Annual Scheduling

The enterprise curriculum runs in three windows to avoid a single peak: financial crime modules (E-2, E-3, E-4, E-8, E-9) in Q1; security, privacy, and technology modules (E-5, E-6, E-7, E-16, E-18) in Q2; and conduct, risk, and workplace modules (E-1, E-10, E-11, E-12, E-13, E-14, E-15, E-17) in Q3. Q4 is reserved for remediation, role-based curricula, and development. Due dates are 30 calendar days from assignment.

### 8.3 Board and Executive Curriculum

Board members complete a formal induction covering the Bank's business model, risk profile, regulatory environment, and governance framework within 90 days of appointment, followed by annual briefings on financial crime, cyber risk, conduct, consumer outcomes, and regulatory change. ExCo members complete the full enterprise curriculum plus an annual executive accountability and regulatory-expectations session. Completion is reported to the Board Audit Committee and the Public Responsibility & Compliance Committee.

### 8.4 Manager and Specialist Modules

| Module | Population | Frequency |
|---|---|---|
| Managing People at Apex — policy, approval authority, documentation | All new managers within 60 days | Once, then every 3 years |
| Structured Interviewing and Inclusive Selection | Anyone serving on an interview panel | Before first panel; every 2 years |
| Performance Management and Calibration | All people managers | Annual, before the cycle |
| Handling a Speak-Up Report | All people managers | Every 2 years |
| Recognising and Supporting Vulnerable Customers | Customer-facing managers | Annual |
| Insider Risk and Joiner–Mover–Leaver Obligations | All people managers | Annual |
| Investigation Skills | Employee Relations, Internal Audit, Financial Crime investigators | Every 2 years |

---

## 9. Standards — Role-Based Curriculum and Certification

### 9.1 Assignment Triggers

ApexLearn assigns curricula automatically from ApexPeople on: hire; role change; grade change; department transfer; grant of delegated credit, payment, or expenditure authority; grant of privileged or customer-data system access; designation as a sensitive role, Covered Person, or Material Risk Taker; promotion into a people-management role; and appointment to a committee.

### 9.2 Role-Based Curricula by Department

| Department | Additional Mandatory Modules |
|---|---|
| **Retail Banking (RTL)** | Branch cash handling and dual control; account opening and CIP; consumer lending and Reg B/Z; deposit regulations (Reg D/E/CC); sales practices and suitability; elder financial abuse; robbery and duress procedures; safe deposit; complaint handling |
| **Corporate Banking (CBK)** | Credit policy and delegated authority; credit documentation and security perfection; covenant monitoring; trade finance and sanctions in trade; correspondent banking risk; large exposure rules |
| **Treasury (TRY)** | Market conduct and abuse; benchmark integrity; dealing mandates and limits; IRRBB and liquidity regulation; trade capture and confirmation control |
| **Finance (FIN)** | SOX controls and certification; regulatory reporting accuracy; revenue recognition and accounting policy; expense governance; tax and transfer pricing awareness |
| **Risk (RSK)** | Risk appetite framework; model risk management; RCSA and KRI methodology; stress testing; credit rating methodology; loss data collection |
| **Compliance (CMP)** | Financial crime investigation and SAR/CTR filing; regulatory change management; surveillance and market abuse; compliance testing methodology; consumer regulation deep-dives |
| **Information Security (ISC)** | Secure architecture; threat detection and response; identity and access governance; vulnerability management; incident forensics |
| **IT Operations (ITO)** | Change management and CAB; privileged access; secure development lifecycle; production support and incident management; cloud security; data centre controls |
| **Customer Support (CST)** | Complaint handling and root cause; dispute and chargeback rules (Reg E); authentication and social engineering resistance; vulnerable customer support; call quality and recording obligations |
| **Human Resources (HRM)** | Employment law by jurisdiction; personnel data handling; interviewing and selection; investigation skills; reward governance |
| **Legal (LEG)** | Privilege management; legal hold administration; contract standards; regulatory engagement protocol |
| **Internal Audit (IAD)** | IIA standards; audit methodology; data analytics in audit; issue writing and validation |
| **Procurement (PRC)** | Third-party risk and due diligence; contract standards; anti-bribery in sourcing; concentration and exit planning |
| **Marketing (MKT)** | Advertising and disclosure rules; UDAAP in marketing; social media governance; brand and trademark |
| **Administration (ADM)** | Records management and retention (advanced); physical security; facilities safety; document classification and handling |

### 9.3 Internal Certifications

Internal certifications are Apex credentials required to exercise a specific authority. Each requires a course, an assessment at 85% or above, and — where marked — a supervised practical assessment.

| Certification | Required For | Validity | Renewal |
|---|---|---|---|
| **Apex KYC Certification** | Anyone performing customer due diligence, onboarding, or periodic refresh | 2 years | Refresher plus assessment |
| **Apex AML Investigator Certification** | Alert triage, case investigation, SAR drafting | 2 years | Refresher plus case-quality review |
| **Apex Credit Authority Certification** | Any holder of delegated credit authority; level matched to the authority tier | 2 years | Refresher plus portfolio quality review |
| **Apex Payment Release Certification** | Wire and payment release operators | Annual | Refresher plus supervised practical |
| **Apex Cash Custody Certification** | Vault custodians, cash centre operators, tellers with vault access | Annual | Refresher plus supervised practical |
| **Apex Privileged Access Certification** | Privileged infrastructure, database, and identity administrators | Annual | Refresher plus access recertification |
| **Apex Data Steward Certification** | Data owners and stewards under the Data Governance Council | 2 years | Refresher |
| **Apex Model Owner Certification** | Model owners and validators | 2 years | Refresher |
| **Apex Complaint Handler Certification** | Anyone with authority to close a complaint | 2 years | Refresher plus quality review |
| **Apex Interviewer Certification** | Anyone serving on an interview panel | 2 years | Refresher |
| **Apex Investigator Certification** | Conduct and fraud investigators | 2 years | Refresher plus case review |
| **Apex Records Custodian Certification** | Departmental records custodians | 2 years | Refresher |

### 9.4 External Certifications and Registrations

| Credential | Required For | Bank Support | Maintenance |
|---|---|---|---|
| **CAMS** (Certified Anti-Money Laundering Specialist) | Financial Crime roles at G5 and above | Fees, study leave, one re-sit | 60 CE credits per 3 years |
| **CFE** (Certified Fraud Examiner) | Fraud investigation leadership | Fees, study leave | 20 CPE hours annually |
| **CFA** | Investment and portfolio management roles | Fees, study leave, exam-day leave | Membership |
| **CPA / ACA / ACCA** | Qualified accountant roles in Finance | Fees, study leave | Per body |
| **CIA / CISA** | Internal Audit and IT Audit | Fees, study leave | Per body |
| **CISSP / CISM** | Senior Information Security roles | Fees, study leave | CPE per body |
| **CRCM** (Certified Regulatory Compliance Manager) | Consumer compliance roles | Fees, study leave | Per body |
| **FRM / PRM** | Market and credit risk roles at G6 and above | Fees, study leave | Per body |
| **Securities registrations** (e.g. Series 7, 63, 24, 79 and equivalents) | Registered representatives, supervisors, and investment banking roles | Fees, sponsored study time | Continuing education per regulator; annual compliance meeting |
| **Mortgage loan originator registration** (NMLS) | Mortgage originators | Fees, study time | Annual CE; annual renewal |
| **Insurance licences** | Insurance-licensed staff | Fees, study time | Per state |
| **Local equivalents** | Regulated roles in UK, EU, APAC, and Middle East entities | Fees, study time | Per regulator |

**Registration is a condition of holding the role.** A registration that lapses suspends the employee from the regulated activity immediately, with the line manager and Compliance notified automatically.

### 9.5 Sponsorship Terms

Sponsorship of an external qualification requires: role relevance; line manager and Department Head approval; a study plan; and a written commitment to remain with the Bank for 12 months after completion, with pro-rata repayment of fees if the employee resigns within that period. The Bank funds registration, examination, and one re-sit; further attempts are at the employee's cost. Study leave is provided under `ANB-HRM-POL-0002` §8.11.

---

## 10. Standards — Certification Validity and Lapse

### 10.1 Validity Management

ApexLearn tracks the validity period of every internal certification and, through Compliance, every external registration. Notifications issue at 90, 60, 30, and 7 days before expiry to the employee and, from 30 days, to the line manager.

### 10.2 Lapse Consequences

| Days Past Expiry | Consequence |
|---|---|
| 1 | Certification marked lapsed; the associated **authority is suspended** in the source system — credit authority in ApexOrigin, payment release in ApexPay, vault access in ApexAccess, privileged access in ApexID |
| 1 | Line manager and Department Head notified automatically |
| 5 | HRBP notified; cover arrangements required |
| 15 | Escalated to the Department Head as a control exception; reported to the Operational Risk Committee |
| 30 | Role suitability review with the HRBP; performance rating cap applies (`ANB-HRM-POL-0006` §9.4) |
| 60 | Redeployment or formal action considered |

A lapsed **external registration** for a regulated activity suspends the employee from that activity on day 1 without exception, and may require regulatory notification.

### 10.3 Grace and Deferral

There is no grace period for a certification that gates an authority. A deferral of a **renewal** may be granted in advance — never retrospectively — by the Department Head with the content-owning function, for a maximum of 30 days, where a documented barrier exists such as extended sickness, a scheduling failure by the Bank, or an external body's examination availability. The deferral is recorded in ApexServe and reported in the monthly exception pack.

---

## 11. Standards — Completion Enforcement

### 11.1 Due Dates

| Curriculum | Due Date |
|---|---|
| Day-one modules | 5 business days from start; hard stop at 10 |
| Enterprise annual modules | 30 calendar days from assignment |
| Role-based modules on role change | 30 calendar days from the effective date |
| Certification before authority use | Before the authority is granted — never after |
| Refreshers | On or before the certification expiry date |
| Post-incident remedial training | 10 business days from assignment |

### 11.2 Escalation Ladder

Escalation is automatic and system-driven. No manager may suppress it.

| Overdue | Action | Notified |
|---|---|---|
| −7 days (before due) | Reminder | Employee |
| −1 day | Final reminder | Employee, line manager |
| +1 day | Overdue flag raised in ApexLearn | Employee, line manager |
| +5 days | Escalation | Line manager's manager |
| +10 days | Escalation; non-essential system access review initiated | Department Head; HRBP |
| +15 days | Non-essential system access suspended | Department Head; Information Security |
| +30 days | Performance rating capped at 3 (`ANB-HRM-POL-0006` §9.4); formal conduct conversation | HRBP; Employee Relations |
| +45 days | Disciplinary process under `ANB-HRM-POL-0004` §14.2 as misconduct | Employee Relations |
| Year end incomplete | Rating capped at 2; variable pay consequence | Head of Reward; Department Head |

### 11.3 Access Suspension

Suspension removes access to non-essential applications while preserving ApexPeople self-service, ApexLearn, and Apex Mail so that the employee can complete the training. Access is restored automatically within 4 hours of recorded completion. For roles where suspension would create an operational or customer risk, the Department Head arranges cover — the suspension is not waived, the work is moved.

### 11.4 Legitimate Barriers

Deferral is granted for: long-term sickness, parental leave, sabbatical, jury service, and military service; the curriculum is reassigned with a fresh 30-day due date on return (`ANB-HRM-POL-0002`). Deferral is also granted where the Bank has failed to make the module available, where a documented accessibility need requires an alternative format, or where an examination is unavailable through no fault of the employee. Deferral is approved by the Department Head, recorded in ApexServe, and reported. **Workload is not a legitimate barrier**; a manager whose team cannot complete mandatory training because of workload has a resourcing problem to escalate, not a training exception to request.

### 11.5 Manager Accountability

Team completion is an explicit component of the M-4 people objective in `ANB-HRM-POL-0006` §8.2. A manager whose team completion falls below 95% at any escalation point is reviewed by the HRBP. A manager who instructs, encourages, or permits an employee to bypass content or share answers commits gross misconduct.

---

## 12. Standards — Development and Leadership Programmes

### 12.1 Development Framework

Every employee has a development plan in ApexPeople, reviewed at the mid-year and year-end points of the performance cycle. Development follows a 70:20:10 approach: 70% through role experience, stretch assignments, and rotation; 20% through coaching, mentoring, and feedback; 10% through formal learning.

### 12.2 Leadership Programmes

| Programme | Population | Duration | Content |
|---|---|---|---|
| **Foundations of Management** | New managers at any grade | 3 days plus 6 months of coaching | Policy, approval authority, documentation, difficult conversations, performance, inclusion |
| **Emerging Leaders Programme** | High-potential G5–G6 | 9 months | Business acumen, cross-department rotation, enterprise project, mentoring |
| **Leadership Development Programme** | G7–G8, identified talent | 12 months | Strategy, risk leadership, financial acumen, external business school module, executive mentor |
| **Executive Development Programme** | G9–G10, succession candidates | 18 months | Board exposure, regulatory engagement, external coaching, enterprise-wide assignment |
| **Control Function Leadership** | Risk, Compliance, Audit, Security at G7+ | 6 months | Independence under pressure, regulatory engagement, influencing without authority |
| **Branch Leadership Programme** | Branch Managers and Regional Directors | 6 months | Cash and control, customer outcomes, community banking, people leadership |
| **Technology Leadership Programme** | Engineering and operations leaders G7+ | 9 months | Resilience, architecture governance, vendor and cloud, delivery at scale |

Nomination is through talent review under `ANB-HRM-POL-0006` §14.4, approved by the Department Head and the Head of Learning & Development. Programme slates are reviewed for diversity before confirmation.

### 12.3 Other Development Provision

Tuition assistance up to $10,000 per year for approved qualifications; professional membership fees for role-relevant bodies; internal mentoring and reverse-mentoring programmes; cross-department rotations of 3–12 months; an internal secondment marketplace; conference attendance with a written knowledge-share obligation; and self-directed learning through the ApexLearn content library.

### 12.4 Knowledge Sharing

Employees attending external conferences or completing sponsored qualifications at Bank cost produce a knowledge-share artefact — a session, a briefing note, or a contribution to the departmental knowledge base in ApexDocs — within 30 days. This is a condition of funding and reflects the principle in `ANB-ADM-REF-0001` §1.8 that knowledge is an institutional asset.

---

## 13. Standards — Delivery, Quality, and Effectiveness

### 13.1 Delivery Channels

E-learning in ApexLearn for enterprise modules; virtual and in-person classroom for skills, leadership, and scenario-based content; on-the-job supervised assessment for cash, payment, and privileged-access certifications; simulation for phishing, incident response, and crisis exercises; and external providers for accredited qualifications, contracted through Procurement.

### 13.2 Content Quality Standards

Every module states its learning objectives, its regulatory basis where applicable, and its assessment threshold; uses Apex scenarios and canonical systems and roles rather than generic examples; is accessible, meeting WCAG 2.2 AA; is available in the operating languages required by the population; and states its content owner and last review date. Modules are not simply repeated year on year — content owners must evidence what changed and why at each annual review.

### 13.3 Effectiveness Measurement

| Level | Measure |
|---|---|
| Reaction | Post-module rating and free-text feedback; target ≥ 4.0/5.0 |
| Learning | Assessment pass rate and first-attempt rate; question-level analysis to identify weak content |
| Behaviour | Phishing simulation failure rate; declaration timeliness; escalation quality; complaint and control outcomes |
| Results | Correlation of training completion with control incidents, audit findings, and conduct cases, analysed annually |

Where behaviour measures do not improve despite high completion, the content is redesigned — completion is not accepted as evidence of effectiveness (TR-10).

### 13.4 Phishing Simulation

Continuous simulation is run by Cyber Defence. Reporting a simulated phish is the desired outcome and is tracked positively. A first failure assigns a 10-minute remedial module within 5 business days. A second failure within 12 months assigns extended training and notifies the line manager. A third failure within 12 months triggers an HRBP conversation and, for privileged-access holders, a review of that access. Simulation results are never used punitively for a first failure and are never used to rank individuals publicly.

---

## 14. Decision Tables

### 14.1 What Applies to Whom

| Situation | Curriculum Assigned |
|---|---|
| New joiner, any role | Day-one subset within 5 days, then full enterprise curriculum |
| Contractor with ApexCore read access | E-1, E-5, E-7, and role-relevant modules |
| Employee moves from Retail Banking to Compliance | Compliance role-based curriculum within 30 days; retains enterprise curriculum |
| Employee granted delegated credit authority | Apex Credit Authority Certification **before** the authority is activated |
| Employee becomes a people manager | Foundations of Management within 60 days; manager modules assigned |
| Employee joins an interview panel | Apex Interviewer Certification before the first interview |
| Employee designated a Covered Person | Personal account dealing module within 10 business days |
| Employee assigned a sensitive role | Mandatory absence briefing plus role certification |
| Employee returns from 9 months' parental leave | Full curriculum reassigned with a 30-day due date from return |
| Board member appointed | Directors' induction within 90 days |
| Employee involved in a control incident | Remedial training within 10 business days |

### 14.2 Approval Authority

| Decision | Approver | Second | Reference |
|---|---|---|---|
| Enterprise curriculum content change | Content-owning function head | Head of Learning & Development | §6 |
| Adding a module to the enterprise curriculum | CHRO (G11) | CCO for regulatory modules | §8 |
| Removing a module from the enterprise curriculum | CHRO **and** CCO | Public Responsibility & Compliance Committee noting | §8 |
| Role-based curriculum change | Department Head (G9) | Head of Learning & Development | §9.2 |
| New internal certification | Content-owning function head | CHRO | §9.3 |
| External qualification sponsorship | Department Head (G9) | Head of Learning & Development | §9.5 |
| Sponsorship above $15,000 | Department Head | CHRO | §9.5 |
| Deferral of a mandatory module | Department Head (G9) | Recorded in ApexServe | §11.4 |
| Deferral of a certification renewal | Department Head (G9) | Content-owning function | §10.3 |
| Waiver of a regulatory mandatory module | **Not permitted** | — | TR-1 |
| Access suspension exception | **Not permitted**; cover arranged instead | Department Head arranges cover | §11.3 |
| Leadership programme nomination | Department Head (G9) | Head of Learning & Development | §12.2 |
| Executive Development Programme nomination | ExCo member (G11) | CHRO | §12.2 |
| External training provider appointment | Head of Learning & Development | Head of Category Management (G8) | `ANB-ADM-MTX-0001` §9.1 |

### 14.3 Scenario Table

| Scenario | Outcome |
|---|---|
| Manager asks to defer the team's AML training because of a system release | Refused. Workload is not a legitimate barrier (§11.4). Cover is arranged. |
| Employee completes AML training in 6 minutes on a 90-minute module | Flagged by ApexLearn engagement analytics; completion voided; module reassigned; pattern reviewed by Compliance |
| Two employees have identical assessment answers and timestamps | Investigated as falsification of a regulatory record — gross misconduct (TR-4) |
| Credit officer's Apex Credit Authority Certification expires on a Friday | Authority suspended in ApexOrigin on Saturday; deals in progress reassigned; renewal completed the following week restores it |
| Mortgage originator's NMLS registration lapses | Suspended from regulated activity immediately; regulatory notification assessed by Compliance |
| Employee fails the phishing simulation three times in a year | HRBP conversation; privileged access reviewed; extended training assigned |
| Employee with a documented accessibility need cannot use the standard module | Alternative format provided; deferral granted while it is produced; never counted as overdue |
| Employee at 46 days overdue on the Code of Conduct module | Access suspended at day 15; conduct process begins at day 45; rating capped |
| Department Head requests a blanket extension for 200 staff after a merger integration | Assessed by CHRO and CCO; a scheduling exception may be granted in advance for non-regulatory modules only; regulatory modules cannot be waived |
| Employee completes CAMS at Bank cost then resigns after 5 months | Pro-rata repayment per the sponsorship agreement (§9.5) |

---

## 15. Approval Matrix — Policy Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| Policy Major version | Head of Learning & Development (G8) | CCO, CRO, CISO, CDO, Employment Legal | CHRO (G11) | ExCo; Public Responsibility & Compliance Committee |
| Policy Minor version | Head of Learning & Development | Compliance | HR Director (G9) | All managers |
| Curriculum architecture change | Head of Learning & Development | Content-owning functions | CHRO | Department Heads |
| Enforcement ladder change (§11.2) | Head of Learning & Development | Compliance, Information Security, Employee Relations | CHRO **and** CCO | ExCo |
| Certification validity period change | Content-owning function head | Operational Risk | CHRO | Operational Risk Committee |
| Leadership programme portfolio change | Head of Learning & Development | Head of Talent & Performance | CHRO | ExCo |
| ApexLearn platform change | Head of Learning & Development | IT Operations, Information Security | Head of IT Operations (G11) | Change Advisory Board |

---

## 16. Records, Reporting, and Retention

### 16.1 Records

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Module completion and score | `TRN-########` | ApexLearn | C1 | `RET-TRN-5Y` |
| Attestation record | `TRN-########` | ApexLearn | C1 | `RET-TRN-5Y` |
| Internal certification and validity | `TRN-########` | ApexLearn | C1 | `RET-TRN-5Y` |
| External certification and CE log | `TRN-########` | ApexLearn, ApexDocs | C1 | `RET-TRN-5Y` |
| Regulatory registration record | `EMP-######` | ApexDocs, ApexLearn | C2 | `RET-HRM-7Y` |
| Deferral approval | `CAS-########` | ApexServe | C1 | `RET-TRN-5Y` |
| Sponsorship agreement | `CAS-########` | ApexDocs | C2 | `RET-HRM-7Y` |
| Phishing simulation result | `EMP-######` | ApexShield, ApexLearn | C2 | `RET-SEC-7Y` |
| Curriculum content and version history | Module ID | ApexLearn, ApexDocs | C1 | `RET-POL-10Y` |
| Effectiveness analysis | Annual | ApexInsight, ApexDocs | C1 | `RET-TRN-5Y` |
| Regulator or auditor evidence pack | `CAS-########` | ApexDocs | C2 | `RET-AUD-7Y` |

Naming follows `ANB-HRM-HBK-0001` Appendix B — for example `HRTR_TRN-88104220_AML-Annual-FY26-Certificate_20260930.pdf`.

### 16.2 Reporting

| Report | Frequency | Audience |
|---|---|---|
| Completion dashboard by department and module | Weekly during a window; monthly otherwise | Department Heads, line managers |
| Overdue and escalation exception pack | Monthly | Department Heads, HRBPs, CHRO |
| Certification expiry and lapse report | Monthly | Department Heads, Operational Risk Committee |
| Mandatory curriculum assurance report | Quarterly | Public Responsibility & Compliance Committee |
| Training effectiveness analysis | Annual | ExCo; Board Audit Committee |
| Regulatory evidence pack | On demand, within 2 business days | Regulators, external auditors, Internal Audit |
| Leadership programme outcomes and diversity | Annual | Board Compensation & Human Capital Committee |

---

## 17. Examples

### 17.1 Annual AML Cycle

The Q1 financial crime window opens on 6 January 2026.

| Date | Action | Actor |
|---|---|---|
| 2026-01-06 | E-2, E-3, E-4, E-8, E-9 assigned to 78,400 employees and 2,100 in-scope contractors; due 2026-02-05 | ApexLearn, `EMP-200401` Bianca Ferraro |
| 2026-01-06 | Content confirmed as updated for the FinCEN beneficial ownership rule changes and two industry enforcement actions | `EMP-400101` Adeline Mercier |
| 2026-01-20 | Completion at 61%; departmental dashboards issued | Training Coordinator |
| 2026-02-04 | Final reminders; completion at 94% | ApexLearn |
| 2026-02-05 | Due date; 3,140 overdue | — |
| 2026-02-10 | Escalation to skip-level managers; 1,180 remain | ApexLearn |
| 2026-02-15 | Escalation to Department Heads; access review initiated for 640 remaining | ApexLearn |
| 2026-02-20 | Non-essential access suspended for 210 remaining; branch and payment cover arranged by Department Heads | Information Security |
| 2026-02-22 | 198 complete within 48 hours of suspension; access restored automatically | ApexLearn, ApexID |
| 2026-03-07 | 12 remain at 30 days overdue; ratings capped; HRBP conversations held | HRBPs |
| 2026-03-22 | 2 remain at 45 days; conduct process initiated | `EMP-200105` Grace Mwangi |
| 2026-04-15 | Assurance report to the Public Responsibility & Compliance Committee: 100% completion achieved; 2 conduct cases; question-level analysis identifies weak comprehension of source-of-wealth requirements, content redesigned for FY27 | `EMP-200106` Hiroshi Tanabe |

### 17.2 Certification Lapse — Payment Release

`EMP-500103` Andrés Villalobos's team includes a payment release operator whose Apex Payment Release Certification expires on 2026-11-14.

Notifications issue at 90, 60, 30, and 7 days. The operator is on approved leave for the final two weeks and the renewal is not completed. On 2026-11-15, ApexPay suspends the operator's release authority automatically. The line manager is notified the same morning and reassigns the day's release queue to a certified colleague — dual control is maintained throughout, and no payment is delayed. The operator completes the refresher and supervised practical on 2026-11-18; authority is restored the same day.

The case is reported in the November exception pack. Root cause: leave was approved without checking the certification expiry. Remediation: the manager checklist in `ANB-HRM-POL-0002` Appendix C is amended to include a certification expiry check before approving leave of more than 10 days.

### 17.3 Sponsored Qualification

`EMP-400104` Oluwaseun Bakare (G5, Compliance Officer — Branch Network Monitoring) applies for CAMS sponsorship.

Role relevance confirmed by `EMP-400103` Priyanka Iyer; Department Head approval from `EMP-400101` Adeline Mercier; study plan agreed; sponsorship agreement signed including the 12-month retention commitment with pro-rata repayment. The Bank funds registration, materials, examination, and one re-sit. Study leave of 5 days is granted under `ANB-HRM-POL-0002` §8.11, plus examination-day leave. On passing, the credential is recorded in ApexLearn with its CE requirement of 60 credits per 3 years tracked automatically, and the employee delivers a knowledge-share session to the branch monitoring team within 30 days per §12.4.

---

## 18. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Learning obligation; departments; systems; regulatory landscape |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Training summary; canonical employee register; record naming |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Study leave; curriculum deferral during long absence |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Travel security briefings; anti-bribery training |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | Remote working security module; overdue training suspends remote eligibility |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Annual attestation; falsification as gross misconduct |
| `ANB-HRM-POL-0006` | Performance Management Policy | `02_human_resources/006_PERFORMANCE_MANAGEMENT_POLICY.md` | M-3 learning objective; rating caps for non-completion; leadership programmes |
| `ANB-HRM-SOP-0007` | Recruitment SOP | `02_human_resources/007_RECRUITMENT_STANDARD_OPERATING_PROCEDURE.md` | Day-one curriculum; interviewer certification; confirmation requires full curriculum |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Certification gating of delegated authority |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | `RET-TRN-5Y`, `RET-AUD-7Y` |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.3` Learning classification |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | `HRTR` record naming |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-TRN` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Public Responsibility & Compliance Committee; Operational Risk Committee |
| `ANB-CMP-POL-0001` | Anti-Money Laundering (AML) Policy | *(planned)* | Regulatory basis for E-2 |
| `ANB-CMP-POL-0002` | Know Your Customer (KYC) Policy | *(planned)* | Regulatory basis for E-3 |
| `ANB-ISC-POL-0001` | Information Security Policy | *(planned)* | Regulatory basis for E-5 and E-6 |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy | *(planned)* | Contractor training obligations |

---

## 19. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full policy review and re-approval | Head of Learning & Development | Annually by 31 July |
| Semi-annual curriculum review | Content currency, regulatory alignment, effectiveness data | Content owners with L&D | January and July |
| Regulatory change | Affected module updated and redeployed | Content owner | 60 days, or sooner if the regulator specifies |
| Industry enforcement action in a covered area | Content gap assessment and scenario refresh | Compliance with L&D | 60 days |
| Material internal incident | Remedial module developed and assigned | Content owner | 30 days |
| Completion below target at a window close | Root cause and process change | Head of Learning & Development | 30 days |
| Effectiveness measures not improving | Content redesign | Content owner | Next semi-annual review |
| Audit finding on training controls | Remediation plan | Head of Learning & Development | 30 days |

Next scheduled review: **2027-07-24**.

---

## 20. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-16 | Learning & Development | Initial draft; enterprise curriculum defined from `ANB-ADM-REF-0001` §1.7 | — |
| 0.3 | 2026-07-01 | Learning & Development | Role-based curricula and internal certification register added with content owners | — |
| 0.5 | 2026-07-09 | Learning & Development | Certification lapse consequences agreed with Operational Risk; authority suspension made automatic | — |
| 0.7 | 2026-07-17 | Learning & Development | Enforcement ladder agreed with Information Security and Employee Relations; access suspension mechanics defined | — |
| 0.9 | 2026-07-22 | Learning & Development | Effectiveness measurement and phishing simulation handling added by the CISO | — |
| 1.0 | 2026-07-24 | Learning & Development | First published version | Y. Carter |

---

## 21. Appendices

### Appendix A — Enterprise Curriculum Calendar

| Quarter | Modules | Population |
|---|---|---|
| **Q1** | E-2 AML/CTF · E-3 KYC/CDD · E-4 Sanctions · E-8 Fraud · E-9 Anti-Bribery | All |
| **Q2** | E-5 Information Security · E-6 Phishing · E-7 Data Privacy · E-16 Responsible AI · E-18 Remote Working Security | All (E-18 remote-eligible) |
| **Q3** | E-1 Code of Conduct + attestation · E-10 Operational Risk · E-11 Speak-Up · E-12 Respect at Work · E-13 Records (biennial) · E-14 Business Continuity · E-15 Health & Safety (biennial) · E-17 Fair Treatment | All (E-17 customer-facing) |
| **Q4** | Remediation · role-based curricula · certification renewals · leadership programmes · development | As assigned |
| **Continuous** | Phishing simulation · new joiner day-one curriculum · role-change assignments | As triggered |

### Appendix B — Employee Quick Reference

| Question | Answer |
|---|---|
| How do I know what I have to do? | ApexLearn shows every assigned module with its due date. Check it weekly. |
| Is training working time? | Yes. Your manager must give you time. If they do not, raise it with your HRBP. |
| What happens if I miss a due date? | Escalation starts on day 1 and your access is suspended at day 15. See §11.2. |
| Can my manager give me an extension? | No. Only a Department Head, only in advance, and only for a legitimate barrier (§11.4). |
| I have been on parental leave — am I overdue? | No. Your curriculum is deferred and reassigned with 30 days from your return. |
| My certification expires next month. What happens? | Renew before expiry. On the day after expiry your authority is suspended automatically. |
| Can I get the Bank to pay for CAMS? | Yes, if it is relevant to your role and approved. There is a 12-month retention commitment (§9.5). |
| I failed a phishing test. Am I in trouble? | No. Complete the 10-minute remedial module. Repeated failures lead to a conversation, not a sanction. |
| Someone offered to send me the assessment answers. | Report it. Sharing answers falsifies a regulatory record and is gross misconduct. |
| Does training affect my rating? | Yes. Late completion caps your rating at 3; incomplete at year end caps it at 2. |

### Appendix C — Manager Checklist

**Monthly:** review the team's ApexLearn dashboard; chase anything approaching a due date; check upcoming certification expiries for anyone with delegated authority.

**Before approving leave over 10 days:** check whether a certification expires during the absence, and whether a mandatory due date falls in it.

**On any team change:** confirm the position record in ApexPeople is correct — the curriculum assigns from the position, so a wrong position means a wrong curriculum.

**Before granting or requesting an authority:** confirm the certification is held and current. Authority without certification will be suspended.

**At escalation:** arrange cover rather than seeking a waiver. Access suspension is not waivable.

**At year end:** confirm 100% team completion before calibration — team training compliance is part of your own M-4 objective.

### Appendix D — Certification-to-Authority Map

| Authority | Gating Certification | Suspension System |
|---|---|---|
| Delegated credit approval | Apex Credit Authority Certification | ApexOrigin, ApexCredit |
| Payment and wire release | Apex Payment Release Certification | ApexPay |
| Vault and cash custody | Apex Cash Custody Certification | ApexAccess, ApexTeller |
| Privileged system administration | Apex Privileged Access Certification | ApexID |
| Customer due diligence sign-off | Apex KYC Certification | ApexKYC |
| SAR/CTR filing | Apex AML Investigator Certification | ApexGuard |
| Complaint closure | Apex Complaint Handler Certification | Apex360, ApexServe |
| Data steward decisions | Apex Data Steward Certification | ApexInsight |
| Model ownership sign-off | Apex Model Owner Certification | ApexModel |
| Interview panel participation | Apex Interviewer Certification | ApexPeople |
| Conduct and fraud investigation | Apex Investigator Certification | ApexServe |
| Records disposal authorisation | Apex Records Custodian Certification | ApexVault |
| Regulated advice and dealing | External registration (Series, NMLS, insurance, local equivalent) | ApexOrigin, Apex360, ApexTreasury |

Where an authority appears in `ANB-ADM-MTX-0001` and here, the certification is a precondition of the authority, not an alternative to it.

---

**End of Document**

`ANB-HRM-POL-0008` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) · Approver: Yvonne Carter, Chief Human Resources Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
