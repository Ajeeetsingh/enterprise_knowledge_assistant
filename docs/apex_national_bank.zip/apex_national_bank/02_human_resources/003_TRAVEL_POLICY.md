# Apex National Bank — Travel Policy

**Corporate Policy | Business Travel Authorisation, Entitlement, Duty of Care, and Expense Settlement**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FIN-POL-0002` |
| **Document Title** | Apex National Bank — Travel Policy |
| **Version** | 1.0 |
| **Owner** | Finance Department (FIN) — Financial Operations |
| **Joint Owner** | Human Resources (HRM) for grade entitlement and duty of care; Administration (ADM) for travel security |
| **Custodian** | Rosa Delgado, Corporate Travel & Expense Manager (G6) — `EMP-600104` |
| **Approver** | Priya Raghunathan, Chief Financial Officer (G11) — `EMP-100002` |
| **Secondary Approvers** | Yvonne Carter, Chief Human Resources Officer; Samuel A. Okonkwo, Chief Compliance Officer |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-06 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24); allowance schedules reviewed semi-annually |
| **Supersedes** | None — initial published policy |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.5` Workplace Services → Travel Administration → `POL` |
| **Business Process** | `BP-FIN-TRVL` Business Travel Authorisation & Duty of Care; `BP-FIN-EXP` Expense Management & Reimbursement |
| **Governing Body** | Executive Committee |
| **System of Record** | ApexServe (travel requests and approvals) · ApexLedger (expense and settlement) · ApexDocs (this policy) |
| **Keywords** | travel, business travel, expense, per diem, travel risk, duty of care, advance, foreign exchange, reimbursement |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0004` · `ANB-FIN-POL-0001` · `ANB-ADM-MTX-0001` · `ANB-PRC-POL-0001` |

> **Ownership note.** `ANB-ADM-REF-0001` §6 attributes Travel Policy scope to Human Resources while §15 reserves the identifier `ANB-FIN-POL-0002` to Finance. This Policy is issued as a **jointly owned instrument**: Finance owns expenditure control and settlement, Human Resources owns grade entitlement and duty of care, and Administration owns travel security. The reserved identifier and the CFO approval line are retained as published in `ANB-ADM-REF-0001` §15.

---

## 2. Purpose

Apex National Bank spends approximately $186 million a year moving people between nineteen countries. Every one of those journeys carries three exposures at once: a cost the Bank must control, a duty of care the Bank owes the traveller, and a compliance surface — sanctions, tax permanent establishment, immigration, anti-bribery — that a badly planned trip can breach in a single afternoon.

This Policy therefore:

1. Requires **authorisation before booking**, so travel is a decision rather than a fait accompli.
2. Sets **entitlement by grade and journey**, removing negotiation from every individual trip.
3. Establishes **duty of care** through destination risk rating, traveller tracking, and mandatory briefings.
4. Governs **advances, foreign exchange, and settlement** so that money leaving the Bank is reconciled and evidenced.
5. Defines the **records** that make a trip auditable years later.

---

## 3. Scope

### 3.1 In Scope

| Category | Detail |
|---|---|
| Domestic travel | Any business journey requiring an overnight stay or air travel within the country of employment |
| International travel | Any business journey crossing a national border |
| Executive travel | Travel by G10 and above, including Board members travelling on Bank business |
| Client entertainment while travelling | Governed jointly with `ANB-HRM-POL-0004` §9 |
| Relocation and international assignment travel | Initial and repatriation travel; ongoing arrangements sit with Global Mobility |
| Travel by candidates and interviewees | Booked and settled under this Policy by Talent Acquisition |
| Travel by contractors billed to the Bank | Entitlement capped at Apex standard; booked through the contractor's employer unless the contract states otherwise |

### 3.2 Out of Scope

- Daily commuting between home and the employee's designated office (covered by the commuter benefit in `ANB-HRM-HBK-0001` §10.2)
- Travel between Apex sites in the same metropolitan area not requiring air travel or an overnight stay — claimed as local expense under `ANB-FIN-POL-0001`
- Personal travel, including personal extensions to business trips beyond the provisions of §14.3
- Relocation packages, which are governed by the Global Mobility framework owned by `EMP-200108` Ekaterina Volkova

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | No travel without prior authorisation | ≥ 99% of trips with an approved `TRV-` request before booking |
| O-2 | Duty of care is discharged | 100% of travellers to Amber/Red destinations briefed and tracked |
| O-3 | Cost is controlled | ≥ 95% of bookings through the appointed Travel Management Company; average ticket cost within budget |
| O-4 | Expenses are settled promptly and accurately | ≥ 95% of claims submitted within 30 days; exception rate < 3% |
| O-5 | Compliance exposures are prevented | Zero unauthorised travel to sanctioned jurisdictions; zero unapproved tax-triggering assignments |
| O-6 | Advances are recovered | 100% of advances settled within 15 business days of return |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Business Travel** | Travel undertaken at the Bank's request or with its approval in the performance of duties. |
| **Travel Request** | The pre-approval record in ApexServe, identified `TRV-########`. |
| **TMC** | The appointed Travel Management Company, contracted through Procurement under `ANB-PRC-POL-0001` and monitored under `ANB-PRC-POL-0002`. |
| **Destination Risk Rating** | The Green / Amber / Red / Prohibited classification assigned by Physical Security with Compliance. |
| **Per Diem** | A fixed daily meal and incidentals allowance paid without receipts, by city tier. |
| **Travel Advance** | A pre-trip cash payment against anticipated costs, recovered at settlement. |
| **Expense Claim** | The settlement record in ApexLedger, identified `EXP-##########`. |
| **Corporate Card** | The Apex Corporate Card issued to eligible employees, with central billing to ApexLedger. |
| **Permanent Establishment (PE) Risk** | The tax exposure created when an employee's activity in a jurisdiction constitutes a taxable presence for the Bank. |
| **Key-Person Concentration** | The risk of multiple senior executives travelling together on the same conveyance. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Traveller** | Obtain approval before booking; book through the TMC; travel within entitlement; complete the security briefing where required; keep the itinerary current in ApexServe; submit the claim within 30 days; behave in accordance with `ANB-HRM-POL-0004` throughout. |
| **Line Manager** | Confirm business necessity and that the objective cannot be met remotely; approve within entitlement and budget; verify destination risk rating; never approve their own travel. |
| **Department Head (G9–G11)** | Approve international travel, Amber-rated destinations, travel exceeding standard entitlement, and departmental travel budgets. |
| **Corporate Travel & Expense Manager (`EMP-600104` Rosa Delgado, G6)** | Own the TMC relationship, allowance schedules, booking compliance reporting, and traveller support escalation. |
| **Head of Financial Operations (`EMP-600102` Marcel Delacroix, G8)** | Own expense control, claim audit, late-claim exceptions, and advance recovery. |
| **Head of Physical Security (`EMP-600201` Aurélie Dubois, G7)** | Own destination risk ratings, security briefings, traveller tracking, and crisis response for travellers. |
| **Head of Global Mobility (`EMP-200108` Ekaterina Volkova, G7)** | Own immigration and visa compliance, PE risk assessment, and the boundary between travel and assignment. |
| **Compliance (`EMP-400101` Adeline Mercier, G9)** | Clear travel involving sanctioned jurisdictions, public officials, or regulated entertainment. |
| **Head of Tax (FIN, G8)** | Assess PE and personal tax exposure for extended or repeated travel. |
| **Finance Manager — Corporate Centre Cost Control (`EMP-600103` Sandeep Bhatt, G6)** | Monitor travel spend against budget and report variances. |
| **Internal Audit (IAD)** | Test travel and expense controls within scheduled audits and continuous monitoring. |

---

## 7. Policy Statements

**T-1.** No business travel may be booked without an approved `TRV-` request in ApexServe. Booking first and seeking approval afterwards is a policy breach, regardless of outcome or cost.

**T-2.** Travel is authorised only where the business objective cannot reasonably be achieved by video conference. The requester must state why in the request. "Relationship building" is an acceptable reason; it is not an unexamined one.

**T-3.** All bookings are made through the appointed TMC. Bookings made directly are not reimbursed unless the TMC was unreachable during a genuine emergency, evidenced in the claim.

**T-4.** Entitlement is set by grade and journey duration, not by seniority of the people being met, personal preference, or loyalty-programme status.

**T-5.** The lowest logical fare and rate must be selected within entitlement. Where a traveller selects a higher-cost option for a personal reason, the difference is borne personally.

**T-6.** Loyalty programme points and airline or hotel status earned on Bank travel may be retained personally. They may **never** influence carrier, route, or hotel selection. Doing so is a conflict of interest under `ANB-HRM-POL-0004` §8.

**T-7.** The Bank's duty of care is not optional. A traveller who declines a required security briefing, or who travels without a current itinerary in ApexServe, travels without the Bank's support and is in breach of policy.

**T-8.** Travel to a Prohibited destination is refused. Travel to a Red destination requires the approvals in §12.3 and may be refused irrespective of business case.

**T-9.** No two members of the Executive Committee, and no more than three employees at G10 and above, may travel on the same aircraft. Exceptions require Group CEO approval and are notified to the Board.

**T-10.** Expense claims are personal statements. Submitting a claim for expenditure not incurred, inflating a claim, or claiming a personal cost as business is fraud against the Bank and is treated as gross misconduct under `ANB-HRM-POL-0004` §14.

**T-11.** Travel that would create permanent establishment, immigration, or regulated-activity exposure requires Global Mobility, Tax, and Compliance clearance before approval.

**T-12.** Anything of value provided to or received from a public official during travel requires prior approval from the General Counsel and the Chief Compliance Officer, without exception (`ANB-ADM-MTX-0001` §7.2).

---

## 8. Standards — Booking and Transportation

### 8.1 Booking Channel and Advance Purchase

| Requirement | Standard |
|---|---|
| Channel | Appointed TMC via the ApexServe travel request; self-booking tool for simple domestic itineraries |
| Advance purchase — domestic | 14 calendar days minimum |
| Advance purchase — international | 21 calendar days minimum |
| Late booking | Permitted for genuine urgency; the approver must record the reason, which is reported in the monthly compliance pack |
| Changes | Made through the TMC; change fees are reimbursable where the change is business-driven, personal where not |
| Cancellation | Unused tickets must be returned to the TMC for reuse or refund within 5 business days |

### 8.2 Air Travel Class Entitlement

| Journey | G1–G5 | G6 | G7–G9 | G10–G12 |
|---|---|---|---|---|
| Domestic, any duration | Economy | Economy | Economy; Premium Economy above 4 hours | Economy; Premium Economy above 4 hours |
| International under 6 hours | Economy | Economy | Economy | Premium Economy |
| International 6–8 hours | Economy | Premium Economy | Premium Economy | Business |
| International over 8 hours | Premium Economy | Premium Economy | Business | Business |
| Overnight flight with work commencing within 12 hours of landing | Premium Economy | Premium Economy | Business | Business |

**First Class is not permitted at any grade, on any route, for any employee or Board member.**

**Medical and accessibility upgrades.** A documented medical or accessibility need is accommodated as of right. The employee provides evidence to HR — never to the line manager — and HR authorises the upgrade without disclosing the reason.

**Buy-ups.** A traveller may upgrade personally at their own cost, booked through the TMC, provided the Bank pays only the entitled fare.

### 8.3 Rail and Road

| Mode | Entitlement |
|---|---|
| Rail — journeys under 2 hours | Standard class, all grades |
| Rail — journeys over 2 hours | Standard class G1–G6; First class G7 and above |
| Rail vs. air | Rail is the required mode where door-to-door time is comparable and cost is lower |
| Rental car | Mid-size or below, all grades; full insurance mandatory; premium/luxury classes not reimbursable |
| Personal vehicle | Reimbursed at the prevailing statutory mileage rate; business insurance cover is the employee's responsibility |
| Taxi and rideshare | Standard service class. Premium tiers reimbursable only for late-night travel (22:00–06:00), airport transfers with baggage, safety concerns, or Amber/Red destinations |
| Car service with driver | G9 and above; or any grade where Physical Security requires it for a risk-rated destination |
| Airport parking | Long-stay reimbursed; short-stay and valet only where the cost is lower than the alternative |

### 8.4 Accommodation

Hotels are booked through the TMC from the negotiated programme. City tiers are published semi-annually by the Corporate Travel & Expense Manager.

| City Tier | Examples | Nightly Cap (room + tax) |
|---|---|---|
| **Tier A** | New York, London, San Francisco, Hong Kong SAR, Singapore, Tokyo, Zurich, Dubai | $450 |
| **Tier B** | Chicago, Charlotte, Dallas, Toronto, Frankfurt, Sydney, Boston, Los Angeles | $300 |
| **Tier C** | Other US and European cities; São Paulo, Mexico City | $220 |
| **Tier D** | Mumbai, Hyderabad, and comparable markets | $150 |

**Standards.** Business-standard hotels within the negotiated programme; four-star equivalent maximum. Suites and club floors are not reimbursable except where they are the lowest available rate or where Physical Security specifies a secured property. Where a conference rate exceeds the cap, the conference rate applies with the approver's note. Personal stays appended to business travel are booked and paid personally.

**Alternative accommodation.** Serviced apartments are permitted and encouraged for stays exceeding 14 nights where the cost is lower. Peer-to-peer short-let platforms are **not permitted** — they fall outside the Bank's duty-of-care and insurance arrangements.

---

## 9. Standards — Allowances and Meals

### 9.1 Per Diem or Actuals

A traveller elects **either** per diem **or** reimbursement of actual meal costs against receipts for the whole trip. The two may not be mixed within a single trip. Per diem is the default and requires no receipts.

### 9.2 Meal and Incidentals Per Diem

| City Tier | Full Day | Partial Day (departure/return) | Incidentals Included |
|---|---|---|---|
| Tier A | $95 | $55 | Laundry after 4 nights, tips, local calls, in-room internet |
| Tier B | $75 | $45 | As above |
| Tier C | $60 | $35 | As above |
| Tier D | $40 | $25 | As above |

Where a meal is provided — by the hotel rate, a conference, a client, or a Bank event — the corresponding portion is deducted: breakfast 20%, lunch 30%, dinner 50%.

### 9.3 Actual-Cost Meal Caps

Where the traveller elects actuals, per-meal caps are: Tier A $35 / $45 / $85 (breakfast / lunch / dinner); Tier B $25 / $35 / $65; Tier C $20 / $28 / $50; Tier D $12 / $18 / $32. Itemised receipts are mandatory; card slips alone are insufficient.

### 9.4 Alcohol

Alcohol is not reimbursable on individual meals. It is reimbursable within reasonable limits at client entertainment, subject to `ANB-HRM-POL-0004` §9 and the entertainment limits in `ANB-ADM-MTX-0001` §7.2. Alcohol is never reimbursable where the traveller will drive, is on-call, or holds a designated safety-sensitive role.

### 9.5 Other Reimbursable Costs

Visa and consular fees; travel vaccinations and prophylaxis; passport renewal where required solely for business travel; excess baggage where business-necessary; airport lounge access for G9 and above or for connections exceeding 4 hours; business calls and data roaming; currency conversion fees; TSA PreCheck or Global Entry equivalent once every 5 years for employees travelling internationally 4 or more times per year.

### 9.6 Never Reimbursable

Fines and penalties of any kind, including traffic and parking; personal entertainment, minibar, films, and spa; travel insurance purchased separately (the Bank's corporate cover applies); loss or damage to personal property (subject to the Bank's business travel cover); costs for accompanying family or partners; upgrades beyond entitlement; personal grooming; charitable or political donations; anything that would breach `ANB-HRM-POL-0004`.

---

## 10. Standards — Foreign Exchange and Travel Advances

### 10.1 Payment Hierarchy

1. **Corporate Card** — the required payment method for all reimbursable travel expenditure where accepted.
2. **Central billing** — air and hotel billed directly to the Bank through the TMC where available.
3. **Personal payment and reimbursement** — where the Corporate Card is not accepted.
4. **Cash advance** — only where the destination is genuinely cash-based.

### 10.2 Corporate Card

Issued to G4 and above and to any employee travelling internationally more than twice a year. The card is for business expenditure only; personal use is a conduct matter. Statements are reconciled in ApexLedger within 30 days; unreconciled balances beyond 60 days trigger card suspension by Financial Operations. Cards are cancelled at exit clearance (`ANB-HRM-HBK-0001` §15, item 7).

### 10.3 Travel Advances

| Rule | Detail |
|---|---|
| Eligibility | International travel exceeding 7 days, or any travel to a destination where card acceptance is limited, or Amber/Red destinations |
| Maximum | 80% of estimated out-of-pocket cost, or $2,500 equivalent, whichever is lower |
| Approval | Line manager plus Financial Operations |
| Currency | Local currency or USD, at the ApexCore corporate rate on the date of issue |
| Settlement | Within **15 business days** of return |
| Non-settlement | Recovered from payroll after 30 days, with the employee notified in writing |
| Concurrent advances | Only one outstanding advance per employee; a second requires Head of Financial Operations approval |

### 10.4 Foreign Exchange

Conversions use the ApexCore corporate rate on the transaction date, or the Corporate Card issuer's rate where the card was used. Cash converted at an airport or hotel bureau is reimbursed at the corporate rate, not the bureau rate — the difference is a personal cost. **No employee may profit from a foreign exchange movement on Bank funds.** Any gain on an advance is returned at settlement. Unused foreign currency is returned or converted at settlement, evidenced in the claim.

---

## 11. Standards — Expense Claims and Settlement

### 11.1 Submission

Claims are submitted in ApexLedger against the `TRV-` request, producing an `EXP-##########` record. Each line carries: date, category, amount, currency, business purpose, and — for entertainment — the names and employers of all attendees.

### 11.2 Evidence

| Amount | Evidence |
|---|---|
| Under $25, per diem items | None required |
| $25 and above | Itemised receipt or invoice |
| Any entertainment | Itemised receipt plus attendee list |
| Any accommodation | Folio showing nightly rate and taxes |
| Any air or rail ticket | TMC invoice or e-ticket |
| Lost receipt | Missing-receipt declaration signed by the employee and countersigned by the line manager; permitted for a maximum of three items or $250 per claim |

Receipts are captured by mobile image at the point of spend. Scanned evidence is named per `ANB-ADM-STD-0007` §9.1 and retained under `RET-FIN-10Y`.

### 11.3 Deadlines

| Milestone | Deadline |
|---|---|
| Claim submission | 30 calendar days from trip end |
| Manager approval | 10 business days from submission |
| Financial Operations review | 5 business days from approval |
| Reimbursement | Next payroll cycle following approval |
| Claims 31–60 days late | Head of Financial Operations approval required |
| Claims 61–90 days late | Head of Financial Operations **and** Department Head approval |
| Claims over 90 days | Forfeited, unless approved as an exception by the CFO delegate; forfeiture is reported to the Department Head |

### 11.4 Review and Audit

Financial Operations reviews 100% of claims above $5,000 and a risk-weighted sample below that threshold. Continuous monitoring flags: duplicate submissions, round-number patterns, weekend and holiday spend without a corresponding itinerary, entertainment without an attendee list, spend at merchant categories inconsistent with travel, and claims by employees with prior exceptions. Findings feed `BP-FIN-EXP` control testing and are reported to the Operational Risk Committee where a pattern emerges.

---

## 12. Standards — Travel Risk and Duty of Care

### 12.1 Destination Risk Ratings

Ratings are set by the Head of Physical Security with Compliance, informed by government advisories and the Bank's security intelligence provider, reviewed monthly and on event, and published in ApexServe.

| Rating | Meaning | Approval Required | Additional Controls |
|---|---|---|---|
| **Green** | Standard conditions | Line manager | Itinerary in ApexServe |
| **Amber** | Elevated crime, civil unrest, health, or infrastructure risk | Line manager **and** Department Head (G9) | Mandatory security briefing; 24×7 assistance registration; check-in protocol |
| **Red** | Serious risk to personal safety; significant unrest, conflict, or health emergency | Department Head (G9) **and** Head of Physical Security | Journey management plan; secured transport and accommodation; named emergency contact; daily check-in; medical evacuation cover confirmed |
| **Prohibited** | Comprehensively sanctioned jurisdictions and active conflict zones | **Travel refused.** Exceptional business necessity requires the Chief Compliance Officer **and** General Counsel, with Group CEO notification | Case-by-case; presumption is refusal |

### 12.2 Sanctions and Compliance Clearance

Any travel to, through, or involving meetings with entities connected to a sanctioned jurisdiction requires Compliance clearance before approval, obtained through ApexServe and assessed against `ANB-CMP-POL-0005`. This applies to transit and layovers, not only destinations. Devices taken to high-surveillance jurisdictions must be clean loaner devices issued by IT Operations, per `ANB-ISC-POL-0001`; the traveller's standard laptop and phone remain at home.

### 12.3 Traveller Tracking and Emergency Response

All itineraries booked through the TMC feed the traveller-tracking platform automatically. Physical Security maintains a live view of who is where. In a crisis — natural disaster, terrorist incident, civil unrest, pandemic escalation — Physical Security initiates a mandatory accountability check; travellers must respond within 4 hours. Non-response escalates to the line manager, Department Head, and emergency contact. Crisis response is coordinated with the Crisis Management Team under `ANB-ITO-PLN-0001`.

### 12.4 Medical, Insurance, and Wellbeing

Corporate business travel accident, medical, and evacuation cover applies to all employees on approved travel. Travellers to Amber and Red destinations receive a pre-travel medical briefing and confirmed evacuation cover. Travel-related medical costs are reimbursed through the insurer, not as an expense claim. Long-haul travel guidance applies: no critical meetings within 4 hours of landing from a flight exceeding 10 hours where avoidable, and a rest day after any trip involving more than eight time zones and a stay of less than 72 hours.

### 12.5 Emergency and Unplanned Travel

Where travel must begin before approval can be obtained — a customer crisis, a regulatory summons, a Severity 1 incident, a bereavement recall — the traveller notifies the line manager and Physical Security by telephone, books through the TMC emergency line, and submits the retrospective `TRV-` request within **2 business days**. Retrospective approval is granted at the level that would have been required, or one level higher where the destination is Amber or above.

---

## 13. Standards — Executive and Board Travel

| Requirement | Detail |
|---|---|
| Approval | G10 travel approved by the reporting ExCo member; G11 travel approved by the Group CEO; Group CEO travel approved by the Independent Chair of the Board |
| Key-person concentration | No two ExCo members and no more than three G10+ employees on the same aircraft (T-9). The Corporate Secretary maintains the check for Board travel |
| Board member travel | Booked through the TMC by the Corporate Secretariat; entitlement equivalent to G11; settled through ApexLedger against the Board cost centre |
| Security | Executive protection assessed by the Head of Physical Security for all Amber and above destinations, and for any publicly announced appearance |
| Private aviation | Permitted only where commercial options cannot meet a genuine business need or where security requires it. Requires Group CEO approval and is reported to the Board Audit Committee in the annual expense governance report |
| Spousal or partner accompaniment | Not reimbursable. Where a spouse's attendance is required at a formal Bank function, costs require Group CEO approval and are reported as a taxable benefit |

---

## 14. Process Flow

### 14.1 Standard Travel Authorisation

```
TRAVELLER            LINE MANAGER         DEPT HEAD / SECURITY        TMC            FINANCE
    │                      │                        │                   │                │
    ├─ Raise TRV- request  │                        │                   │                │
    │   business case,     │                        │                   │                │
    │   dates, destination │                        │                   │                │
    │   estimated cost ───►│                        │                   │                │
    │                      ├─ Verify necessity,     │                   │                │
    │                      │  budget, entitlement,  │                   │                │
    │                      │  risk rating           │                   │                │
    │                      │                        │                   │                │
    │              ┌───────┴────────┐               │                   │                │
    │          Green/domestic   Amber+/international│                   │                │
    │              │                └──────────────►│                   │                │
    │              │                                ├─ Dept Head approve│                │
    │              │                                ├─ Security briefing│                │
    │              │                                ├─ Compliance clear │                │
    │              │◄───────────────────────────────┘  (if applicable)  │                │
    │◄─ APPROVED ──┘                                                    │                │
    │                                                                   │                │
    ├─ Book through TMC ───────────────────────────────────────────────►│                │
    │◄─ Itinerary; feeds traveller tracking ────────────────────────────┤                │
    │                                                                   │                │
    ├─ TRAVEL ─────────────────────────────────────────────────────────────────────────► │
    │                                                                                    │
    ├─ Submit EXP- claim within 30 days ────────────────────────────────────────────────►│
    │                      ├─ Approve within 10 business days ──────────────────────────►│
    │◄─ Reimbursed next payroll ──────────────────────────────────────────────────────────┘
```

### 14.2 Travel Request Content Requirements

A `TRV-` request is incomplete, and must be rejected, without: business purpose and why it cannot be achieved remotely; destination(s) including transit points; dates; estimated total cost by category; cost centre; names of any other Apex employees travelling on the same itinerary; whether entertainment is anticipated; and whether any meeting involves a public official or a sanctioned-jurisdiction nexus.

### 14.3 Personal Extension to Business Travel

Permitted where the Bank's cost is not increased. The traveller books the business portion through the TMC and the personal portion personally; the TMC evidences the notional business-only fare, and the Bank pays that amount only. Accommodation, meals, and per diem for personal days are not reimbursed. Corporate insurance cover **does not extend** to personal days — the traveller must arrange their own. Personal days are recorded as annual leave in ApexPeople under `ANB-HRM-POL-0002`.

---

## 15. Decision Tables

### 15.1 Approval Authority

| Journey | Approver | Second Approver | Additional |
|---|---|---|---|
| Domestic, Green, under $2,500 | Line manager (G5+) | — | — |
| Domestic, Green, $2,500–$10,000 | Line manager | Department Head (G9) | — |
| International, Green | Line manager | Department Head (G9) | Global Mobility if over 30 days |
| Any destination rated Amber | Line manager | Department Head (G9) | Security briefing mandatory |
| Any destination rated Red | Department Head (G9) | Head of Physical Security (G7) | Journey management plan |
| Prohibited destination | Chief Compliance Officer (G11) | General Counsel (G11) | Group CEO notified; presumption of refusal |
| Sanctioned-jurisdiction nexus (including transit) | Line manager | Compliance | Clearance recorded in ApexServe |
| Travel by G10 | Reporting ExCo member (G11) | — | Key-person check |
| Travel by G11 | Group CEO (G12) | — | Key-person check |
| Travel by Group CEO | Independent Chair of the Board | — | Board notified |
| Board member travel | Corporate Secretary | Independent Chair for international | — |
| Private aviation | Group CEO (G12) | — | Board Audit Committee reporting |
| Travel exceeding 30 consecutive days in one jurisdiction | Department Head | Head of Global Mobility **and** Head of Tax | PE assessment mandatory |
| Emergency travel already commenced | Retrospective, within 2 business days | Level that would have applied, or one higher for Amber+ | Reported monthly |

### 15.2 Expense Approval

Travel expenditure sits within the financial authority grid in `ANB-ADM-MTX-0001` §7.1 and the expense thresholds in §7.2. In summary:

| Claim Value | Approver |
|---|---|
| Up to $1,000 | Line manager (G4+) |
| $1,000 – $10,000 | G6 and above |
| Above $10,000 | G8 and above, with Financial Operations review |
| Client entertainment up to $500 per head | G6 and above; attendee list mandatory |
| Client entertainment above $500 per head | G9 and above; Compliance pre-clearance |
| Anything involving a public official | General Counsel **and** CCO, any value |

### 15.3 Common Scenarios

| Scenario | Treatment |
|---|---|
| G6 flying New York to London for a two-day client meeting | Economy or Premium Economy per §8.2 (6–8 hours: Premium Economy); Tier A hotel cap $450; per diem $95/day |
| G3 driving 140 miles to a branch review, returning same day | Statutory mileage rate; no per diem (no overnight); meals at actuals under `ANB-FIN-POL-0001` |
| G9 flying New York to Singapore, 18 hours | Business class; Tier A cap; lounge access reimbursable; rest day on return |
| G5 traveller declines the mandatory Amber briefing | Travel authorisation withdrawn; escalated to Department Head |
| Traveller upgrades to Business personally on an entitled Economy fare | Permitted; Bank pays the Economy fare only, evidenced by the TMC |
| Traveller books directly on a consumer website, cheaper than TMC | Not reimbursed; policy breach recorded; repeat instances escalate to the HRBP |
| Corporate Card used for a personal dinner while travelling | Repaid to the Bank within the statement cycle; repeated use is a conduct matter |
| Trip cancelled after non-refundable booking | Cost absorbed by the requesting cost centre; no personal liability unless the cancellation was for personal convenience |
| Employee stranded by an airport closure | Additional accommodation and meals reimbursed at policy rates; Physical Security notified; itinerary updated in ApexServe |
| Employee asked by a foreign official to pay an unofficial "processing fee" | Refuse. Report immediately to Compliance and Global Mobility. Never pay. Facilitation payments are prohibited absolutely (`ANB-HRM-POL-0004` §9) |

---

## 16. Approval Matrix — Policy Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| Policy Major version | Corporate Travel & Expense Manager (G6) | Head of Financial Operations, HR, Physical Security, Compliance, Tax, Legal | CFO (G11) **and** CHRO (G11) | ExCo |
| Policy Minor version | Corporate Travel & Expense Manager | Head of Financial Operations | Head of Financial Operations (G8) | Travellers via enterprise notice |
| City tier or allowance schedule change | Corporate Travel & Expense Manager | Finance cost control | Head of Financial Operations (G8) | Department Heads |
| Class-of-travel entitlement change | Head of Reward (G8) | Finance, HR | CFO **and** CHRO | ExCo |
| Destination risk rating change | Head of Physical Security (G7) | Compliance | Head of Physical Security | All travellers to that destination; Operational Risk Committee for Red/Prohibited |
| TMC appointment or change | Head of Category Management (G8) | Finance, Legal, Physical Security, Information Security | Chief Procurement Officer (G10) | ExCo; `ANB-ADM-MTX-0001` §9.1 |
| Late-claim exception above 90 days | Traveller's Department Head | Head of Financial Operations | CFO delegate | Monthly exception report |

---

## 17. Records and Retention

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Travel request and approval | `TRV-########` | ApexServe | C1 (C2 where itinerary is security-sensitive) | `RET-FIN-10Y` |
| Itinerary and TMC invoice | `TRV-########` | ApexServe, ApexLedger | C1 | `RET-FIN-10Y` |
| Expense claim and receipts | `EXP-##########` | ApexLedger | C2 | `RET-FIN-10Y` |
| Travel advance and settlement | `EXP-##########` | ApexLedger | C2 | `RET-FIN-10Y` |
| Security briefing record | `TRV-########` | ApexServe | C2 | `RET-SEC-7Y` |
| Destination risk assessment | `TRV-########` | ApexServe, ApexDocs | C2 | `RET-SEC-7Y` |
| Compliance/sanctions clearance | `CAS-########` | ApexServe | C2 | `RET-AML-5Y` |
| Entertainment attendee record | `EXP-##########` | ApexLedger | C2 | `RET-FIN-10Y` |
| Gifts & Entertainment Register entry | `CAS-########` | ApexServe | C2 | `RET-HRM-7Y` |
| PE / tax assessment | `CAS-########` | ApexDocs | C2 | `RET-TAX-10Y` |

Naming follows `ANB-HRM-HBK-0001` Appendix B — for example `TRVL_TRV-00218844_Singapore-ClientVisit-Approval_20260812.pdf` and `EXPN_EXP-9928014471_TravelSettlement-Singapore_20260901.pdf`.

---

## 18. Examples

### 18.1 International Client Visit — Amber Destination

`EMP-300301` Henry Bakshi (G6, Relationship Manager, Chicago) must visit a commercial client in São Paulo, rated **Amber**.

| Date | Action | Actor | Reference |
|---|---|---|---|
| 2026-08-04 | `TRV-00218844` raised: business case, dates 2026-09-08 to 09-12, estimated $6,400, cost centre CMB-Midwest | `EMP-300301` | §14.2 |
| 2026-08-05 | Necessity and budget confirmed; Amber rating identified | `EMP-100015` Alicia Moreau (line) | §15.1 |
| 2026-08-06 | Department Head approval recorded | `EMP-100015` | §15.1 |
| 2026-08-07 | Security briefing delivered; secured airport transfer arranged; 24×7 assistance registration confirmed | `EMP-600201` Aurélie Dubois | §12.1 |
| 2026-08-08 | Booked through TMC: Economy (7h 40m — G6 entitlement is Premium Economy on 6–8h; Premium Economy selected), Tier C hotel at $198 | TMC | §8.2, §8.4 |
| 2026-09-08–12 | Travel; daily check-in per Amber protocol; entertainment dinner for 3 at $146 per head with attendee list captured | `EMP-300301` | §12.1, §9.4 |
| 2026-09-16 | `EXP-9928014471` submitted with itemised receipts and attendee list | `EMP-300301` | §11.1 |
| 2026-09-19 | Approved | `EMP-100015` | §15.2 |
| 2026-09-24 | Reviewed and released for payment | `EMP-600102` Marcel Delacroix | §11.4 |
| 2026-09-30 | Reimbursed in payroll | Payroll | §11.3 |

### 18.2 Emergency Travel Following a Severity 1 Incident

At 03:10 a Severity 1 incident affects the Charlotte operations centre. `EMP-500103` Andrés Villalobos (G8, Head of Service Management, Hyderabad) is required on site.

| Time | Action |
|---|---|
| 03:40 | Telephones `EMP-500101` Ravi Subramanian; verbal authorisation given under the emergency provision |
| 03:55 | TMC emergency line books the first available routing; Physical Security notified |
| 04:10 | Itinerary lodged in the traveller-tracking platform |
| Day 2 | Retrospective `TRV-` request submitted with the incident reference `INC-########` |
| Day 2 | Approved retrospectively by `EMP-500101` at the level that would otherwise have applied |
| Day 3 | Late booking recorded in the monthly booking-compliance pack as a legitimate emergency |

### 18.3 Refused Travel — Prohibited Destination

A Corporate Banking team requests travel to a comprehensively sanctioned jurisdiction to meet a prospective counterparty. Compliance identifies the jurisdiction as **Prohibited**. The request is refused at first review; the presumption of refusal is not displaced by the size of the opportunity. Compliance advises that the counterparty relationship itself requires assessment under `ANB-CMP-POL-0005` before any engagement, in any location. The refusal and its rationale are recorded in ApexServe and reported to the Financial Crime Committee.

### 18.4 Permanent Establishment Trigger

`EMP-300302` Naomi Castellanos travels to Frankfurt repeatedly through 2026, accumulating 96 days in-country and negotiating terms with clients on the Bank's behalf. The 30-day threshold in §15.1 triggered a Global Mobility and Tax review at the fourth trip. Tax concludes that continued negotiation activity risks creating a permanent establishment for Apex National Bank, N.A. in Germany. Travel is suspended pending restructuring: the activity is transferred to Apex Bank Europe SE staff, and the employee's remaining trips are limited to non-negotiating support. The assessment is filed under `RET-TAX-10Y`.

---

## 19. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Grades, geographies, reserved identifier |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Travel summary; canonical employee register; record naming |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Personal extensions recorded as annual leave |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | Cross-border working prohibition; device controls |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Gifts, entertainment, anti-bribery, conflicts, loyalty points |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | Travel security and anti-bribery training |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Expense and entertainment authorities |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | `RET-FIN-10Y`, `RET-SEC-7Y`, `RET-TAX-10Y` |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.5` classification |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | `TRVL` and `EXPN` naming; OCR receipt capture |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-FIN-TRVL`, `BP-FIN-EXP` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | ORC and Board Audit Committee reporting |
| `ANB-FIN-POL-0001` | Expense Policy | *(planned)* | Non-travel expense categories |
| `ANB-CMP-POL-0005` | Sanctions & OFAC Screening Policy | *(planned)* | Sanctioned-jurisdiction clearance |
| `ANB-ISC-POL-0001` | Information Security Policy | *(planned)* | Loaner devices; data protection while travelling |
| `ANB-PRC-POL-0001` / `ANB-PRC-POL-0002` | Procurement / Third-Party Risk Management Policy | *(planned)* | TMC appointment and monitoring |
| `ANB-ITO-PLN-0001` | Business Continuity Plan | *(planned)* | Crisis response for travellers |

---

## 20. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review and re-approval | Corporate Travel & Expense Manager | Annually by 31 July |
| Semi-annual allowance review | City tiers, per diem, hotel caps benchmarked | Corporate Travel & Expense Manager | January and July |
| Destination risk change | Rating updated and travellers notified | Head of Physical Security | Immediate |
| Sanctions programme change | Prohibited list updated | Compliance | 5 business days |
| TMC contract change | Booking process and channels updated | Head of Category Management | Before go-live |
| Tax or immigration rule change | PE thresholds and clearance triggers updated | Head of Tax with Global Mobility | 30 days |
| Audit finding on travel and expense | Remediation plan | Head of Financial Operations | 30 days |

Next scheduled review: **2027-07-24**.

---

## 21. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-06 | Corporate Travel & Expense | Initial draft from `ANB-ADM-REF-0001` §6 travel scope | — |
| 0.3 | 2026-06-22 | Corporate Travel & Expense | Class entitlement, city tiers, and per diem schedule added | — |
| 0.5 | 2026-07-01 | Corporate Travel & Expense | Travel risk ratings and duty-of-care controls added after Physical Security review | — |
| 0.7 | 2026-07-10 | Corporate Travel & Expense | Sanctions clearance, loaner devices, and PE thresholds added after Compliance and Tax review | — |
| 0.9 | 2026-07-21 | Corporate Travel & Expense | Executive and Board travel section added; key-person concentration rule introduced | — |
| 1.0 | 2026-07-24 | Corporate Travel & Expense | First published version | P. Raghunathan |

---

## 22. Appendices

### Appendix A — Traveller Quick Card

| Before you book | |
|---|---|
| 1 | Raise a `TRV-` request in ApexServe. Never book first. |
| 2 | Check the destination risk rating. Amber or above needs a Department Head and a briefing. |
| 3 | Check for a sanctions or public-official nexus — including transit points. |
| 4 | Book through the TMC only. |
| 5 | Confirm your entitlement in §8.2 before selecting a fare. |

| While you travel | |
|---|---|
| 6 | Keep your itinerary current in ApexServe — it is how we find you. |
| 7 | Pay with the Corporate Card. |
| 8 | Capture receipts at the point of spend. |
| 9 | Record attendees for any entertainment, at the time. |
| 10 | Respond to an accountability check within 4 hours. |

| After you return | |
|---|---|
| 11 | Submit your `EXP-` claim within 30 days. |
| 12 | Settle any advance within 15 business days. |
| 13 | Return unused foreign currency. |
| 14 | Record any personal days as annual leave. |

### Appendix B — Entitlement Summary by Grade

| Grade | Long-Haul Air | Hotel | Per Diem | Ground | Lounge | Corporate Card | Advance |
|---|---|---|---|---|---|---|---|
| G1–G3 | Premium Economy (>8h) | City cap | City tier rate | Standard | No | On request for travel | Eligible |
| G4–G5 | Premium Economy (>8h) | City cap | City tier rate | Standard | No | Yes | Eligible |
| G6 | Premium Economy | City cap | City tier rate | Standard | No | Yes | Eligible |
| G7–G8 | Business (>8h) | City cap | City tier rate | Standard; premium for late-night | Connections >4h | Yes | Eligible |
| G9 | Business (>8h) | City cap | City tier rate | Car service permitted | Yes | Yes | Eligible |
| G10–G12 | Business | City cap | City tier rate | Car service permitted | Yes | Yes | Eligible |

First Class: never. Private aviation: Group CEO approval only.

### Appendix C — Manager Approval Checklist

1. Is the business objective stated, and could it be met by video conference?
2. Is the destination risk rating checked, and does the approval level match it?
3. Is there a sanctions or public-official nexus, including transit?
4. Is the estimated cost within the cost centre's travel budget?
5. Is the class of travel within the traveller's entitlement, not their preference?
6. Are other Apex employees on the same itinerary — and does that breach the key-person rule?
7. Will the trip take the traveller past 30 days in one jurisdiction this year?
8. Is entertainment anticipated, and does it need Compliance pre-clearance?
9. Is my approval recorded in ApexServe rather than agreed by email or chat?

### Appendix D — Non-Reimbursable Quick List

Fines and penalties · Traffic and parking tickets · Minibar · In-room films and entertainment · Spa and gym day passes · Personal grooming · Separately purchased travel insurance · Loss or damage to personal property · Companion and family costs · Upgrades beyond entitlement · Peer-to-peer short-let accommodation · Airline club memberships (except approved lounge access) · Alcohol on individual meals · Charitable or political donations · Any expense that would breach `ANB-HRM-POL-0004`.

---

**End of Document**

`ANB-FIN-POL-0002` · Version 1.0 · Classification: Internal (C1) · Owner: Finance (FIN) with Human Resources (HRM) and Administration (ADM) · Approver: Priya Raghunathan, Chief Financial Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
