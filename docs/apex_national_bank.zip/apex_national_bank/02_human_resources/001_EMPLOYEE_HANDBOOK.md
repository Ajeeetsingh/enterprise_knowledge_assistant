# Apex National Bank — Employee Handbook

**Human Resources Handbook | The Employment Relationship, Obligations, and Enterprise Reference**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-HBK-0001` |
| **Document Title** | Apex National Bank — Employee Handbook |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) |
| **Custodian** | Rebecca Lindqvist, HR Director — Group Human Resources (G9) |
| **Approver** | Yvonne Carter, Chief Human Resources Officer (G11) |
| **Secondary Approvers** | Margaret Sullivan, General Counsel; Samuel A. Okonkwo, Chief Compliance Officer |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-02 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24) |
| **Supersedes** | None — initial published handbook |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.1` Employment → Onboarding → `HBK` |
| **Business Process** | `BP-HR-ONB` Employee Onboarding & Access Provisioning |
| **Governing Body** | Executive Committee; Board Compensation & Human Capital Committee (noting) |
| **System of Record** | ApexDocs |
| **Keywords** | employee handbook, employment, working hours, conduct, benefits, onboarding, probation, exit, employee lifecycle |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-POL-0002` · `ANB-FIN-POL-0002` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0004` · `ANB-HRM-POL-0005` · `ANB-HRM-POL-0006` · `ANB-HRM-SOP-0007` · `ANB-HRM-POL-0008` |

> **Authority.** This Handbook is a **summary and navigation instrument**. Where it summarises a policy, the underlying policy prevails. It does not create contractual entitlements beyond those in the employment contract and applicable law. It is issued under the enterprise document framework defined in `ANB-ADM-REF-0001` and classified per `ANB-ADM-STD-0006`.

---

## 2. Purpose

Apex National Bank employs 78,400 people across nineteen countries. Every one of them needs the same three things on day one and every day after: to know what is expected of them, to know where the rules live, and to know who to ask.

This Handbook provides:

1. A single statement of the **employment relationship** — philosophy, hours, conduct expectations, and mutual obligations.
2. A **navigation layer** over the eight-document HR governance framework, so an employee never has to guess which policy governs a question.
3. The **employee lifecycle** end to end, from requisition to exit clearance, with the accountable role named at each stage.
4. The **enterprise systems** an employee will use and what each is authoritative for.

It is issued to every new joiner before their start date and re-attested annually in ApexLearn.

---

## 3. Scope

### 3.1 Applies To

| Population | Coverage |
|---|---|
| Permanent employees, all grades G1–G12 | Full |
| Fixed-term and temporary employees | Full, except where entitlement is service-linked |
| Interns and apprentices | Sections 6–9, 11, 13, 15 |
| Contractors and agency workers | Sections 9 (conduct), 11 (security), 15 (systems) — engaged under `ANB-PRC-POL-0002`, not employed |
| All legal entities | Apex National Bank, N.A.; Apex National Bank (UK) plc; Apex Bank Europe SE; Apex Securities LLC; Apex Asset Management, Inc.; Apex Trust Company, N.A.; Apex Global Services |

### 3.2 Jurisdictional Precedence

Where local statute, collective agreement, or works council arrangement provides an entitlement more favourable to the employee than this Handbook, **local law prevails**. Where local law imposes a stricter obligation on the employee, the stricter obligation applies. Local addenda are maintained by the regional HR Business Partner and registered in ApexDocs as child documents of this Handbook.

### 3.3 Not a Contract

This Handbook is not an employment contract and does not alter the at-will nature of US employment where applicable. The Bank may amend it, subject to consultation obligations in jurisdictions where those apply.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Every employee understands the employment relationship | 100% handbook attestation within 14 days of joining; annual re-attestation ≥ 98% |
| O-2 | No employee is unable to locate the governing policy | Handbook navigation index covers 100% of HR policy topics |
| O-3 | Onboarding is complete before productive work begins | 100% of joiners with mandatory day-one training and access complete |
| O-4 | Conduct expectations are unambiguous | Code of Conduct attestation 100% annually |
| O-5 | Exit is controlled | 100% of leavers with completed exit clearance before final pay release |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Employee** | An individual employed under a contract of employment with an Apex legal entity, holding an `EMP-######` identifier in ApexPeople. |
| **Grade** | The job level G1–G12 defined in `ANB-ADM-REF-0001` §5.1, determining authority, entitlement, and eligibility. |
| **Line Manager** | The employee's direct supervisor recorded in ApexPeople; the first point of approval for most requests. |
| **HR Business Partner (HRBP)** | The named HR professional (G6) aligned to a department, accountable for advisory, casework, and policy application. |
| **Probation** | The initial assessment period following joining, during which employment may be ended on shortened notice. |
| **Confirmation** | Formal completion of probation, recorded in ApexPeople. |
| **Sensitive Role** | A role designated as requiring mandatory two-week consecutive absence and enhanced screening (see §11.4). |
| **Material Risk Taker (MRT)** | An employee whose activity has a material impact on the Bank's risk profile, subject to regulatory certification and deferred remuneration. |
| **Attestation** | A recorded personal confirmation, captured in ApexLearn or ApexPeople, that carries the same weight as a signature. |
| **Exit Clearance** | The controlled process confirming return of assets, revocation of access, and settlement of obligations before final pay. |

---

## 6. Employment Philosophy

### 6.1 The Bargain

Apex National Bank is a regulated institution. The employment bargain reflects that:

| The Bank Commits To | The Employee Commits To |
|---|---|
| Fair, market-informed reward governed by `ANB-HRM-POL-0005` | Performing the role competently and within delegated authority |
| Clear expectations, set annually and reviewed formally | Meeting objectives and behavioural standards |
| Investment in capability through `ANB-HRM-POL-0008` | Completing mandatory training on time, every time |
| Protection from retaliation for speaking up | Escalating concerns rather than absorbing them |
| A safe, inclusive, and respectful workplace | Treating colleagues and customers accordingly |
| Transparent process in difficulty — performance, grievance, discipline | Honesty in dealings with the Bank, its customers, and its regulators |

### 6.2 Cultural Commitments

These are drawn directly from `ANB-ADM-REF-0001` §1.6–§1.7 and are assessed in performance reviews under `ANB-HRM-POL-0006`.

| Value | What It Means at Work |
|---|---|
| **Integrity First** | The regulated obligation precedes the commercial opportunity. Escalate concerns before deadlines; never suppress adverse information. |
| **Client Stewardship** | Recommend the suitable product, not the profitable one. |
| **Disciplined Risk** | No undocumented exceptions; every limit has an owner. |
| **Operational Excellence** | Root-cause every incident; measure against SLA, not intent. |
| **Respect and Inclusion** | Challenge is invited; retaliation is a terminable offence. |
| **Accountability** | Every decision has a named owner and a written record. |
| **Enduring Value** | Optimise for the next decade, not the next quarter. |

### 6.3 The Documented-Decision Culture

The Bank operates a **documented-decision culture**. Informal approval — verbal, chat-based, or implied — is not recognised by Internal Audit or Compliance and does not constitute a control. If a manager approves something that matters, it must exist in ApexPeople, ApexServe, ApexDocs, or ApexLedger. An employee who acts on a verbal approval carries the exposure personally.

### 6.4 Three Lines of Defence

Every employee must know which line they sit in.

| Line | Who | Accountability |
|---|---|---|
| **First** | Business and operational departments (HRM, FIN, RTL, CBK, TRY, ITO, CST, MKT, PRC, ADM) | Own and manage the risks they create |
| **Second** | Risk (RSK), Compliance (CMP), Legal (LEG), Information Security (ISC) | Set the framework and independently challenge the First Line |
| **Third** | Internal Audit (IAD) | Independent assurance to the Board Audit Committee |

Business management may not approve, amend, or veto Risk, Compliance, or Internal Audit opinions, ratings, or reports (`ANB-ADM-MTX-0001` R-5).

### 6.5 Speak-Up

Employees at any grade may escalate directly to Compliance, Risk, or Internal Audit **without line-manager consent**. The Group operates a confidential Ethics Line administered by an independent third party, available 24×7 in all operating languages. Retaliation against anyone who raises a concern in good faith is gross misconduct. Full protections are set out in `ANB-HRM-POL-0004` §12.

---

## 7. Working Hours and Attendance

### 7.1 Standard Hours

| Population | Standard Pattern | Notes |
|---|---|---|
| Corporate Centre and non-branch professional roles (US) | 40 hours/week; core 09:00–16:00 local, typically 08:30–17:30 with a one-hour unpaid meal break | Flexible start/finish within core-hours coverage, agreed with the line manager |
| Corporate Centre (UK, EU) | 35–37.5 hours/week per local contract | Working Time Regulations / EU Working Time Directive apply |
| Branch network | Rostered to branch opening hours plus opening and closing controls | Dual-control opening and closing per `ANB-RTL-MAN-0003` |
| Contact centre (Customer Support) | Shift rosters published 4 weeks in advance; 24×5 coverage with weekend rotation | Shift changes require 48 hours' notice or mutual agreement |
| Treasury & Markets trading floor | 06:30–17:30 ET or local market hours | Dealing-room attendance is on-site by regulatory necessity |
| Payment and cash operations | Cut-off-driven shifts including early and late runs | Mandatory dual control at all cut-offs |
| Apex Global Services (Mumbai, Hyderabad) | Follow-the-sun shifts aligned to supported region | Night-shift allowance per local reward schedule |

### 7.2 Overtime and Compensatory Time

| Grade Band | Treatment |
|---|---|
| G1–G3 (non-exempt in the US; equivalent classification elsewhere) | Overtime paid at statutory rates for approved hours beyond the standard week. Pre-approval by the line manager is mandatory. |
| G4 | Compensatory leave for approved work beyond scheduled hours on business need (see `ANB-HRM-POL-0002` §8.9) |
| G5 and above | Exempt / salaried. No overtime or compensatory leave. Sustained excessive hours are a wellbeing and operational risk matter to be raised with the HRBP. |

Working hours must be recorded accurately. Misrecording time, or instructing another employee to misrecord time, is a disciplinary matter under `ANB-HRM-POL-0004` §14.

### 7.3 Attendance and Punctuality

Unplanned absence must be notified to the line manager before the start of the working day, by telephone or Apex Mail, and logged in ApexPeople within 24 hours. Three or more instances of unnotified absence in a rolling twelve months triggers a formal attendance conversation with the HRBP. For branch, contact centre, and operations roles, unnotified absence has direct customer and control impact and is treated more seriously.

### 7.4 Hybrid Attendance

Most non-branch, non-trading roles operate a hybrid model of **three days on-site**. Branch, trading floor, cash operations, and certain supervised roles are **fully on-site by regulatory necessity**. Full arrangements, eligibility, and approval are in `ANB-HRM-POL-0003`.

### 7.5 Public Holidays

Employees observe the public holidays of their country and, in the United States, of their state of employment, up to the entity holiday calendar published annually by HR Operations in ApexPeople. Employees required to work a public holiday for operational reasons receive a substitute day or premium payment per local practice.

---

## 8. Dress Code and Workplace Presentation

The Bank operates a **role-appropriate dress standard** rather than a single uniform rule. The test is whether a customer, regulator, or counterparty encountering the employee would find their presentation consistent with a Tier-1 financial institution.

| Setting | Standard |
|---|---|
| Branch, customer-facing, and cash-handling roles | Business professional. Apex-issued name badge visible at all times. Corporate scarf/tie where the branch format specifies. |
| Client-facing corporate, wealth, and advisory meetings | Business professional |
| Corporate offices, non-client-facing days | Business casual |
| Trading floor | Business casual; business professional when clients or regulators are on the floor |
| Technology and operations centres | Business casual |
| Working from home on video calls with customers, regulators, or external counterparties | Business casual minimum; neutral or blurred background; no confidential material visible |
| Designated dress-down days and volunteering days | Smart casual; announced by the site lead |

**Always prohibited:** clothing with political, religious-proselytising, or offensive slogans; visible logos of competitor financial institutions; footwear unsafe for the workplace; anything obstructing required PPE or physical access badges.

**Accommodation.** Religious dress, cultural dress, and adjustments for disability or medical need are accommodated as of right. Employees do not need to justify a request; they raise it with their HRBP, who records the accommodation in ApexPeople.

---

## 9. Employee Conduct

This section is a summary. The full standard is `ANB-HRM-POL-0004` Code of Conduct, which every employee attests to annually.

| Obligation | Summary | Full Reference |
|---|---|---|
| **Confidentiality** | Customer, employee, and Bank information is disclosed only on a need-to-know basis and only to those entitled to it. Confidentiality survives employment indefinitely. | `ANB-HRM-POL-0004` §6 |
| **Personal account dealing** | Pre-clearance required for all personal securities transactions; minimum holding periods; restricted list applies. | `ANB-HRM-POL-0004` §10 |
| **Insider information** | Material non-public information (MNPI) may not be traded on, tipped, or disclosed. Information barriers are absolute. | `ANB-HRM-POL-0004` §10 |
| **Conflicts of interest** | Declared in ApexServe at onboarding, annually, and within 5 business days of any change. | `ANB-HRM-POL-0004` §8 |
| **Outside employment and directorships** | Require written pre-approval. Competing employment is prohibited without exception. | `ANB-HRM-POL-0004` §11 |
| **Gifts and entertainment** | Recorded above threshold; pre-cleared above limits; anything involving a public official requires General Counsel and CCO approval. | `ANB-HRM-POL-0004` §9 |
| **Anti-bribery and corruption** | Zero tolerance. Facilitation payments are prohibited in every jurisdiction regardless of local practice. | `ANB-HRM-POL-0004` §9 |
| **Fair treatment of customers** | Suitability before sale; no pressure selling; no exploitation of vulnerability. | `ANB-HRM-POL-0004` §7 |
| **Social media** | No representation of the Bank without authorisation; no disclosure of Bank or customer information; no commentary on live regulatory or legal matters. | `ANB-HRM-POL-0004` §13 |
| **Substance use** | Being unfit for duty through alcohol or drugs is misconduct. Zero tolerance in cash-handling, trading, and driving roles. |`ANB-HRM-POL-0004` §14 |
| **Harassment and bullying** | Zero tolerance. Investigated by Employee Relations under a formal protocol. | `ANB-HRM-POL-0004` §7 |

---

## 10. Compensation and Benefits

### 10.1 Compensation Framework

Compensation is governed by `ANB-HRM-POL-0005` Compensation & Incentive Governance Policy, approved by the Board Compensation & Human Capital Committee. Key principles:

- Fixed pay reflects the grade, role, market, and geography.
- Variable pay is discretionary, funded from an enterprise pool approved by ExCo and ratified by the Board Compensation & Human Capital Committee, and **risk-adjusted** before distribution.
- Control function staff (Risk, Compliance, Internal Audit, Information Security) have compensation determined independently of the business areas they oversee, to protect independence.
- Material Risk Takers are subject to deferral, malus, and clawback.
- Pay is reviewed annually with an effective date of 1 April.

Individual pay is confidential. Employees may discuss their own pay; disclosing another employee's pay data obtained through a Bank system is a data breach and a conduct matter.

### 10.2 Core Benefits (Summary)

Benefits vary by country and legal entity. The table below is the United States core provision; equivalent local schedules are published in ApexPeople by the regional HR Business Partner.

| Benefit | Provision |
|---|---|
| Retirement | 401(k) with Bank match of 100% of the first 5% of eligible pay; immediate vesting; administered via Apex Retirement Services |
| Medical, dental, vision | Choice of three plan tiers; Bank contributes 75–85% of premium by tier; coverage for spouse/domestic partner and dependants |
| Health savings / flexible spending | HSA with Bank seed contribution on the high-deductible plan; FSA for medical and dependent care |
| Life and AD&D | 3× base salary Bank-paid; additional voluntary cover to 5× |
| Short-term disability | 100% of base pay for 13 weeks, then 60% to 26 weeks |
| Long-term disability | 60% of base pay from week 27, Bank-paid |
| Parental support | Paid parental leave per `ANB-HRM-POL-0002` §8.5–§8.6; fertility, adoption, and surrogacy assistance up to $25,000 lifetime |
| Employee Assistance Programme | 24×7 confidential counselling for employee and household; independent provider; no reporting to the Bank |
| Wellbeing | Annual wellbeing allowance $750; on-site or subsidised fitness at flagship sites; mental health first aiders at every site above 200 FTE |
| Banking benefits | Preferential rates on Apex mortgages, personal loans, and deposit products, subject to `ANB-HRM-POL-0004` §8 conflict rules and normal credit underwriting — employees receive **no** underwriting concession |
| Education | Tuition assistance up to $10,000 per year for approved qualifications; professional membership fees for role-relevant bodies |
| Commuter and travel | Pre-tax commuter benefit; business travel accident and medical cover per `ANB-FIN-POL-0002` |
| Volunteering | Two paid days per year |
| Referral | Employee referral award per `ANB-HRM-SOP-0007` §12 |

Employee credit applications are underwritten by the standard process in `ANB-CBK-POL-0001` with the file marked for enhanced review; no employee may participate in a credit decision affecting themselves, a family member, or a colleague reporting to them.

---

## 11. The Employee Lifecycle

### 11.1 Lifecycle Map

```
RECRUITMENT ──► BACKGROUND VERIFICATION ──► OFFER ──► JOINING ──► PROBATION ──► CONFIRMATION
                                                                                      │
        ┌─────────────────────────────────────────────────────────────────────────────┘
        ▼
   PERFORMANCE ──► PROMOTION ──► TRAINING ──► TRAVEL ──► LEAVE ──► REMOTE WORK
        │
        ├──► DISCIPLINARY ACTION (where standards are not met)
        │
        ▼
   RESIGNATION / TERMINATION ──► EXIT CLEARANCE ──► ALUMNI
```

### 11.2 Stage-by-Stage Ownership

| # | Stage | Accountable Role | System | Governing Document | Process |
|---|---|---|---|---|---|
| 1 | Requisition and approval | Hiring Manager; Department Head (G9) | ApexPeople | `ANB-HRM-SOP-0007` §8 | `BP-HR-HIRE` |
| 2 | Sourcing, screening, interviews | Recruiter (G4–G5); Head of Talent Acquisition (G8) | ApexPeople | `ANB-HRM-SOP-0007` §9 | `BP-HR-HIRE` |
| 3 | Background verification | Recruitment Operations Officer (G4) | ApexPeople, ApexServe | `ANB-HRM-SOP-0007` §10 | `BP-HR-SCRN` |
| 4 | Offer and approval | HRBP (G6); approver per grade | ApexPeople | `ANB-HRM-SOP-0007` §11; `ANB-ADM-MTX-0001` §13 | `BP-HR-HIRE` |
| 5 | Joining and onboarding | Head of HR Operations (G8) with ITO and ISC | ApexPeople → ApexID → ApexLearn | `ANB-HRM-SOP-0007` §13 | `BP-HR-ONB` |
| 6 | Probation | Line Manager; HRBP | ApexPeople | `ANB-HRM-SOP-0007` §14 | `BP-HR-ONB` |
| 7 | Confirmation | Line Manager; Department Head | ApexPeople | `ANB-HRM-SOP-0007` §14 | `BP-HR-ONB` |
| 8 | Objective setting and review | Line Manager; Employee | ApexPeople | `ANB-HRM-POL-0006` §7–§9 | `BP-HR-PERF` |
| 9 | Calibration and rating | Department Head; HRBP | ApexPeople | `ANB-HRM-POL-0006` §10 | `BP-HR-PERF` |
| 10 | Promotion | Promotion Panel; Department Head | ApexPeople | `ANB-HRM-POL-0006` §12 | `BP-HR-PERF` |
| 11 | Training and certification | Head of Learning & Development (G8) | ApexLearn | `ANB-HRM-POL-0008` | `BP-HR-TRN` |
| 12 | Business travel | Line Manager; Finance; Physical Security | ApexServe, ApexLedger | `ANB-FIN-POL-0002` | `BP-FIN-TRVL` |
| 13 | Leave | Line Manager; HR Operations | ApexPeople | `ANB-HRM-POL-0002` | `BP-HR-LEAVE` |
| 14 | Remote and hybrid working | Line Manager; Department Head; ISC | ApexPeople, ApexServe | `ANB-HRM-POL-0003` | `BP-HR-FLEX` |
| 15 | Performance improvement | Line Manager; HRBP | ApexPeople | `ANB-HRM-POL-0006` §13 | `BP-HR-PERF` |
| 16 | Disciplinary and grievance | Head of Employee Relations (G8) | ApexServe, ApexDocs | `ANB-HRM-POL-0004` §14–§15 | `BP-HR-COND` |
| 17 | Resignation | Employee; Line Manager; HRBP | ApexPeople | §13 of this Handbook | `BP-HR-EXIT` |
| 18 | Exit clearance | Head of HR Operations with ITO, ISC, ADM, FIN | ApexPeople → ApexID | §14 of this Handbook | `BP-HR-EXIT` |

### 11.3 Joining — Your First 30 Days

| Timing | What Happens | Owner |
|---|---|---|
| Offer + 1 day | Background verification initiated; contract issued for e-signature | Recruitment Operations |
| Pre-start | `EMP-######` created in ApexPeople; ApexID provisioning triggered; equipment shipped; Handbook and Code of Conduct issued for pre-reading | HR Operations, ITO |
| Day 1 | Identity verification and right-to-work check completed in person or by approved remote process; badge issued (ApexAccess); laptop collected; ApexID credentials activated with MFA | HR Operations, ADM, ISC |
| Day 1 | Welcome and orientation; Handbook attestation | HRBP |
| Days 1–5 | Day-one mandatory curriculum in ApexLearn: Code of Conduct, Information Security Awareness, Data Privacy, AML/KYC Foundation, Health & Safety | Training Coordinator |
| Days 1–10 | Conflict of interest declaration; personal account dealing registration where applicable; outside employment declaration | Employee, Compliance |
| Days 1–14 | Manager sets probation objectives in ApexPeople | Line Manager |
| Day 30 | First formal check-in recorded | Line Manager |

An employee whose day-one mandatory curriculum is incomplete after 10 business days has non-essential system access suspended until completion (`ANB-HRM-POL-0008` §11.3).

### 11.4 Sensitive Roles and Enhanced Requirements

Certain roles carry heightened obligations because of the access, authority, or customer exposure they hold.

| Designation | Example Roles | Additional Requirements |
|---|---|---|
| **Mandatory two-week absence** | Traders and dealers; treasury operations; wire and payment release operators; cash and vault custodians; privileged IT administrators; credit approvers above delegated limits | Two consecutive weeks of leave each calendar year with all system access suspended (`ANB-HRM-POL-0002` §9) |
| **Registered / certified roles** | Investment advisers, licensed brokers, mortgage loan originators, insurance-licensed staff | Registration maintained; continuing education tracked in ApexLearn (`ANB-HRM-POL-0008` §9) |
| **Material Risk Takers** | Roles designated annually by Risk and HR | Deferral, malus and clawback; enhanced conduct review (`ANB-HRM-POL-0005`) |
| **High-confidentiality roles** | Corporate finance and advisory; Internal Audit; Employee Relations; Financial Crime Investigations; Executive support | Information barrier obligations; restricted-list monitoring; heightened personal dealing restrictions (`ANB-HRM-POL-0004` §10) |
| **Enhanced screening roles** | All G7+; anyone with payment release, credit authority, privileged access, or customer-data administration | Extended background verification and periodic re-screening (`ANB-HRM-SOP-0007` §10.5) |

Sensitive-role designation is recorded against the position in ApexPeople and reviewed annually by the HRBP with the Department Head.

---

## 12. Performance, Development, and Progression

### 12.1 Performance Summary

The performance year runs **1 January – 31 December**. Full detail is in `ANB-HRM-POL-0006`.

| Milestone | Timing |
|---|---|
| Objective setting | By 31 January (within 14 days for new joiners) |
| Mid-year review | June–July |
| Continuous check-ins | At least quarterly, recorded in ApexPeople |
| Self-assessment | By 15 January following |
| Manager assessment | By 31 January following |
| Calibration | February |
| Rating release and reward communication | March; effective 1 April |

Every employee is assessed on **what** they delivered (objectives) and **how** they delivered it (values and conduct). A strong result achieved through poor conduct cannot produce a strong overall rating.

### 12.2 Ratings

| Rating | Label | Approximate Distribution Guide |
|---|---|---|
| 5 | Exceptional | 5–10% |
| 4 | Strong | 20–30% |
| 3 | Effective | 50–60% |
| 2 | Developing | 5–15% |
| 1 | Unsatisfactory | 0–5% |

Distribution is a guide for calibration discussion, not a quota. Full definitions are in `ANB-HRM-POL-0006` §9.

### 12.3 Promotion

Promotion is a change of grade reflecting sustained performance at the next level, not a reward for tenure. Promotions to G7 and above require a **Promotion Panel**. Approval authority follows `ANB-ADM-MTX-0001` §13. Detail is in `ANB-HRM-POL-0006` §12.

### 12.4 Development and Training

Every employee has a development plan in ApexPeople and a mandatory curriculum in ApexLearn. Mandatory training is a condition of employment; repeated non-completion is a disciplinary matter. See `ANB-HRM-POL-0008`.

---

## 13. Leave, Travel, and Working Arrangements — Summary

### 13.1 Leave (Summary of `ANB-HRM-POL-0002`)

| Leave Type | Headline Entitlement (US) | Approval |
|---|---|---|
| Annual leave | 20–30 days by grade band | Line manager |
| Public holidays | Per entity holiday calendar | Automatic |
| Sick leave | 10 paid days, then short-term disability | Line manager; HR after 3 consecutive days |
| Emergency / personal leave | 3 days per year | Line manager |
| Bereavement | 10 days immediate family; 3 days extended | Line manager |
| Parental — primary caregiver | 16 weeks paid | HRBP |
| Parental — secondary caregiver | 8 weeks paid | HRBP |
| Marriage leave | 5 days (jurisdictions where provided) | Line manager |
| Compensatory leave | G1–G4 only, for approved additional hours | Line manager |
| Sabbatical | Up to 12 weeks after 10 years' service | Department Head and CHRO |
| Jury duty, military, volunteering | Per statute; 2 volunteering days | Line manager |

Carry-forward is capped at **5 days**, must be used by 31 March, and is otherwise forfeited except where statute prohibits forfeiture.

### 13.2 Travel (Summary of `ANB-FIN-POL-0002`)

All business travel requires an approved travel request in ApexServe **before** booking. Bookings are made only through the appointed Travel Management Company. Destinations are risk-rated Green, Amber, Red, or Prohibited; Amber and above require additional approval and a security briefing from Physical Security. Expenses are claimed in ApexLedger within 30 calendar days of trip end.

### 13.3 Remote and Hybrid Work (Summary of `ANB-HRM-POL-0003`)

Eligibility is determined by role, not preference. The default for eligible roles is three days on-site. Home working requires a compliant home office, Bank-issued equipment, VPN, and adherence to the confidentiality controls in `ANB-ISC-POL-0001`. **Cross-border remote working is prohibited** without prior tax, immigration, and regulatory clearance.

---

## 14. Disciplinary, Grievance, and Resignation

### 14.1 Disciplinary Framework (Summary)

The full framework, including the definitions of misconduct and gross misconduct, is in `ANB-HRM-POL-0004` §14.

| Stage | Trigger | Outcome | Record Retention |
|---|---|---|---|
| Informal counselling | Minor, first-instance issue | File note by manager | 12 months |
| First written warning | Misconduct or repeated minor issues | Warning live 12 months | `RET-HRM-7Y` |
| Final written warning | Serious misconduct or repetition during a live warning | Warning live 24 months | `RET-HRM-7Y` |
| Dismissal | Gross misconduct, or misconduct during a live final warning | Termination, with or without notice | `RET-HRM-7Y` |

**Universal safeguards.** The employee is told the allegations in writing before any hearing; may be accompanied by a colleague or, where local law provides, a representative; receives the outcome in writing with reasons; and may appeal to a manager not previously involved. Suspension is a neutral act, on full pay, used only where continued attendance would prejudice an investigation or pose risk.

Investigations are conducted by Employee Relations under the protocol in `ANB-HRM-POL-0004` §15, with Legal and, where the matter involves regulated conduct, Compliance engaged. Termination for conduct is approved by the Department Head (G9–G11) with Legal and Compliance consulted and the CHRO informed (`ANB-ADM-MTX-0001` §13).

### 14.2 Grievance

An employee with a workplace concern raises it first with their line manager. Where that is inappropriate or unsuccessful, the grievance is raised in writing with the HRBP and is heard by a manager at least one grade above the respondent. Grievances alleging discrimination, harassment, retaliation, or regulatory breach are escalated immediately to Employee Relations and, where applicable, to Compliance. Concerns about regulatory or financial misconduct may also be raised through the Ethics Line with whistleblower protection (`ANB-HRM-POL-0004` §12).

### 14.3 Resignation

| Step | Requirement |
|---|---|
| Notice | Submitted in writing to the line manager and recorded in ApexPeople |
| Notice period | G1–G4: 4 weeks · G5–G6: 8 weeks · G7–G9: 12 weeks · G10–G12: 6 months, unless the contract specifies otherwise |
| Acknowledgement | Line manager acknowledges within 2 business days; HRBP confirms leaving date |
| Garden leave | May be applied at the Bank's discretion for regulated, client-facing, and sensitive roles |
| Restrictive covenants | Non-solicitation and confidentiality obligations continue after employment per the contract |
| Retraction | A resignation may be retracted only with the written agreement of the Department Head and HRBP |
| Exit interview | Conducted by the HRBP (or an independent HR colleague where the concern relates to the manager); themes reported quarterly to the CHRO and to ExCo annually |

Regulated-role leavers require a regulatory reference and, where applicable, deregistration filed by Compliance before the last working day.

---

## 15. Exit Clearance

No final payment is released until exit clearance is complete. The clearance record is retained under `RET-HRM-7Y`.

| # | Clearance Item | Accountable | System | Deadline |
|---|---|---|---|---|
| 1 | Handover document accepted by the line manager | Employee | ApexDocs | 5 business days before last day |
| 2 | Delegated authorities revoked; approvals reassigned | Line Manager | ApexServe | Last working day |
| 3 | Open cases, tickets, and audit actions reassigned | Line Manager | ApexServe, ApexAudit | Last working day |
| 4 | Bank equipment returned (laptop, phone, tokens, keys) | Employee | ApexServe asset record | Last working day |
| 5 | Physical badge and site access surrendered | ADM — Physical Security | ApexAccess | Last working day |
| 6 | System access revoked across all platforms | ISC / ITO, triggered from ApexPeople | ApexID | Within 4 hours of termination in ApexPeople; immediate for involuntary exits |
| 7 | Corporate card cancelled; outstanding expenses settled | FIN | ApexLedger | 10 business days |
| 8 | Outstanding travel advances recovered | FIN | ApexLedger | Final payroll |
| 9 | Employee loans and staff banking obligations addressed | FIN with RTL | ApexCore | Final payroll |
| 10 | Leave balance settled per `ANB-HRM-POL-0002` §10 | HR Operations | ApexPeople | Final payroll |
| 11 | Personal account dealing positions and restricted-list status closed | CMP | ApexWatch | Last working day |
| 12 | Regulatory deregistration and reference filed | CMP | ApexDocs | Per regulatory deadline |
| 13 | Confidentiality and post-employment obligations reconfirmed in writing | HRBP | ApexPeople | Last working day |
| 14 | Personnel file closed and archived | HR Operations | ApexDocs → ApexVault | 30 days after last day |
| 15 | Exit interview completed | HRBP | ApexPeople | Within 5 business days of last day |

**Involuntary exits.** For dismissal, redundancy, or exits with any conduct or security concern, access revocation (item 6) is executed **before** the employee is informed, coordinated by the HRBP with Information Security. This is a control requirement, not a statement about the individual.

---

## 16. Employee Responsibilities

Every employee, at every grade, is personally responsible for:

1. Working within their delegated authority and never exceeding it (`ANB-ADM-MTX-0001`).
2. Completing all mandatory training by its due date (`ANB-HRM-POL-0008`).
3. Attesting annually to the Code of Conduct and declaring conflicts of interest promptly.
4. Protecting customer, employee, and Bank information; classifying and handling documents per `ANB-ISC-STD-0004` and `ANB-ADM-STD-0006`.
5. Filing records in the correct system of record — never in personal drives, personal email, or unapproved cloud storage (`ANB-ADM-POL-0001` §10.3).
6. Reporting incidents, errors, near misses, suspected fraud, and security events immediately.
7. Escalating concerns rather than absorbing them, without fear of retaliation.
8. Recording leave, absence, travel, and expense accurately and on time.
9. Keeping personal data in ApexPeople current — address, emergency contact, banking details, right-to-work documentation.
10. Cooperating fully and honestly with audits, investigations, and regulatory enquiries.

---

## 17. Manager Responsibilities

A manager carries every employee responsibility plus the following. These are assessed in the "how" component of the performance review.

1. **Set and document expectations.** Objectives in ApexPeople by 31 January and within 14 days for new joiners.
2. **Approve deliberately.** Every approval is personal, evidenced, and within authority. Never approve to clear a queue.
3. **Manage attendance and leave actively.** Ensure sensitive-role holders take their mandatory two-week consecutive absence.
4. **Enforce training compliance.** A team member's overdue mandatory training is the manager's compliance failure as much as the employee's.
5. **Address underperformance early.** A rating of 2 or below must never be a surprise at year end.
6. **Escalate conduct concerns immediately** to the HRBP and, where regulated conduct is involved, to Compliance. Managers must not investigate conduct allegations themselves.
7. **Maintain segregation of duties.** No employee should be able to originate, approve, and execute the same transaction.
8. **Execute joiner–mover–leaver promptly.** Access must follow the role, and must be removed when the role changes.
9. **Protect the speak-up culture.** Retaliation, or tolerating it, is gross misconduct.
10. **Model the values.** Managers are assessed on the conduct of their teams, not only their own.

---

## 18. Enterprise Systems an Employee Will Use

| System | What It Is Authoritative For | Employee Uses It To |
|---|---|---|
| **ApexPeople** (Workday) | Worker master data, grade, position, absence, performance, compensation | Book leave, view payslips, set objectives, update personal data, submit resignation |
| **ApexLearn** (Cornerstone) | Training completion and attestation evidence | Complete mandatory and elective training; hold certification records |
| **ApexServe** (ServiceNow) | Approvals executed via workflow; HR cases, access requests, travel requests | Raise HR cases, request access, submit travel and conflict declarations |
| **ApexID** (SailPoint, Entra ID, CyberArk) | Identity and entitlements, driven from ApexPeople | Authenticate with MFA; request and recertify access |
| **ApexDocs** (OpenText) | Enterprise system of record for controlled documents | Find policies and procedures; file controlled documents |
| **ApexVault** (InfoArchive) | Long-term archive, legal hold, defensible disposal | Retrieve archived records via an authorised request |
| **ApexLedger** (SAP S/4HANA) | General ledger, accounts payable, procure-to-pay, expense | Submit expense claims and travel settlements |
| **Apex Mail** (Microsoft 365) | Corporate email, chat, meetings — **not** a system of record | Communicate; never store the record copy of a decision here |
| **ApexAccess** | Physical access control and badging | Enter Bank premises |
| **ApexInsight** (Snowflake / Power BI) | Certified enterprise data and reporting | Access approved management information |
| **Role-specific platforms** | ApexCore, ApexOrigin, ApexCredit, Apex360, ApexTeller, ApexPay, ApexGuard, ApexKYC, ApexRisk, ApexAudit, ApexTreasury, ApexTrade, ApexSource/ApexVendor | Per role entitlement, granted through ApexID |

**Rule.** Email is not an approved system of record. Controlled documents reside in ApexDocs; approvals reside in ApexServe, ApexPeople, or ApexLedger. A decision that exists only in Apex Mail is, for governance purposes, a decision that did not happen.

---

## 19. Approval Matrix — Handbook Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| Handbook Major version | HR Director (G9) | Legal, Compliance, Employee Relations, Works Councils where applicable | CHRO (G11) | ExCo; Board Compensation & Human Capital Committee |
| Handbook Minor version | HR Director (G9) | Legal | CHRO | All staff via ApexReach notice |
| Local jurisdictional addendum | Regional HRBP (G6) | Local employment counsel, Head of Employee Relations | HR Director (G9) | Local employees |
| Benefit change — material | Head of Reward (G8) | Finance, Legal | CHRO **and** CFO | Board Compensation & Human Capital Committee |
| Dress code or workplace standard change | Head of HR Operations (G8) | Head of Employee Relations, ADM | HR Director (G9) | Site leads |
| Notice period change | Head of Reward (G8) | Legal | CHRO | Affected populations, with consultation where required |

Approval is recorded in ApexDocs workflow per `ANB-ADM-MTX-0001` §5 (Enterprise Policy) and `ANB-ADM-STD-0007` §11.3.

---

## 20. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of grades, departments, systems, culture |
| `ANB-ADM-STD-0005` | Enterprise Metadata Standard | `01_enterprise_governance/002_ENTERPRISE_METADATA_STANDARD.md` | Metadata applied to HR documents and records |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | Taxonomy node `T7` and Employee entity definition |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | Naming of HR records |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | `RET-HRM-7Y` personnel retention |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | People decision authorities |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Board Compensation & Human Capital Committee |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-*` process definitions |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Leave entitlements summarised in §13.1 |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Travel summarised in §13.2 |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | Working arrangements summarised in §13.3 |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Conduct summarised in §9; discipline in §14 |
| `ANB-HRM-POL-0006` | Performance Management Policy | `02_human_resources/006_PERFORMANCE_MANAGEMENT_POLICY.md` | Performance summarised in §12 |
| `ANB-HRM-SOP-0007` | Recruitment Standard Operating Procedure | `02_human_resources/007_RECRUITMENT_STANDARD_OPERATING_PROCEDURE.md` | Lifecycle stages 1–7 |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | Training obligations |
| `ANB-HRM-POL-0005` | Compensation & Incentive Governance Policy | *(planned)* | Reward framework |
| `ANB-ISC-POL-0001` · `ANB-ISC-STD-0002` · `ANB-ISC-STD-0004` | Information Security Policy · Password & Authentication Standard · Data Classification Standard | *(planned)* | Security obligations of every employee |

---

## 21. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review and re-approval | HR Director | Annually by 31 July |
| Employment law change | Assess and issue addendum or Major version | Employment Legal with HRBP | 60 days |
| Benefit plan change | Update §10.2 and notify | Head of Reward | Before plan effective date |
| Organisational restructure | Update lifecycle ownership and roster | HR Operations | 30 days |
| Underlying HR policy Major version | Update the corresponding summary section | HR Director | 15 business days |
| Audit or regulatory finding | Targeted amendment | HR Director | 30 days |

Next scheduled review: **2027-07-24**.

---

## 22. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-02 | HR Director | Initial draft consolidating employment framework from `ANB-ADM-REF-0001` §1 and §5 | — |
| 0.4 | 2026-06-19 | HR Director | Lifecycle map and stage ownership added; canonical employee register drafted | — |
| 0.6 | 2026-07-02 | HR Director | Exit clearance and sensitive-role sections added following Information Security and Compliance review | — |
| 0.8 | 2026-07-14 | HR Director | Benefits schedule and dress standard finalised; UK and EU works council consultation completed | — |
| 0.9 | 2026-07-20 | HR Director | Legal review amendments: non-contractual status; jurisdictional precedence | — |
| 1.0 | 2026-07-24 | HR Director | First published version | Y. Carter |

---

## 23. Appendices

### Appendix A — Canonical Employee Register

This register is the **authoritative people reference for all Apex National Bank documentation**. Every HR, operational, audit, investigation, and governance document must use these identities, grades, and departments. New identities are added only through HR Operations, which allocates the `EMP-######` identifier from ApexPeople.

#### A.1 Executive Leadership and Department Heads

| Employee ID | Name | Grade | Role | Dept | Business Unit | Location |
|---|---|---|---|---|---|---|
| `EMP-100001` | Marcus D. Whitfield | G12 | Group Chief Executive Officer | CC | CC | New York |
| `EMP-100002` | Priya Raghunathan | G11 | Chief Financial Officer | FIN | CC | New York |
| `EMP-100003` | Daniel K. Ortega | G11 | Chief Operating Officer | CC | CC | New York |
| `EMP-100004` | Helena Brandt | G11 | Chief Risk Officer | RSK | CC | New York |
| `EMP-100005` | Samuel A. Okonkwo | G11 | Chief Compliance Officer | CMP | CC | New York |
| `EMP-100006` | Margaret Sullivan | G11 | General Counsel & Corporate Secretary | LEG | CC | New York |
| `EMP-100007` | Arjun Patel | G11 | Chief Information Officer | ITO | ETO | San Francisco |
| `EMP-100008` | Yvonne Carter | G11 | Chief Human Resources Officer | HRM | CC | New York |
| `EMP-100009` | Thomas Nakamura | G11 | Chief Audit Executive | IAD | Independent | New York |
| `EMP-100010` | Nadia Ferreira | G10 | Chief Information Security Officer | ISC | ETO | San Francisco |
| `EMP-100011` | Elena Vasquez | G10 | Chief Data Officer | ITO | ETO | New York |
| `EMP-100012` | Rachel Osei | G10 | Chief Marketing Officer | MKT | CC | New York |
| `EMP-100013` | Ian McAllister | G10 | Chief Procurement Officer | PRC | CC | Charlotte |
| `EMP-100014` | Gregory Lin | G10 | Head of Consumer & Retail Banking | RTL | CRB | Charlotte |
| `EMP-100015` | Alicia Moreau | G10 | Head of Commercial Banking | CBK | CMB | Chicago |
| `EMP-100016` | Jonathan Reeves | G10 | Head of Corporate & Investment Banking | CBK | CIB | New York |
| `EMP-100017` | Sofia Almeida | G10 | Head of Wealth & Asset Management | WAM | WAM | New York |
| `EMP-100018` | David Chen | G10 | Group Treasurer; Head of Treasury & Markets | TRY | TM | New York |
| `EMP-100019` | Claire Bennett | G9 | Head of Administration | ADM | CC | Charlotte |
| `EMP-100020` | Marcus Adeyemi | G9 | Head of Customer Support | CST | CRB | Charlotte |

#### A.2 Human Resources

| Employee ID | Name | Grade | Role | Dept | Location | Reports To |
|---|---|---|---|---|---|---|
| `EMP-200101` | Rebecca Lindqvist | G9 | HR Director — Group Human Resources | HRM | New York | `EMP-100008` |
| `EMP-200102` | Owen Bradshaw | G8 | Head of HR Operations | HRM | Charlotte | `EMP-200101` |
| `EMP-200103` | Anjali Deshmukh | G8 | Head of Talent Acquisition | HRM | New York | `EMP-200101` |
| `EMP-200104` | Stefan Feldman | G8 | Head of Reward | HRM | New York | `EMP-100008` |
| `EMP-200105` | Grace Mwangi | G8 | Head of Employee Relations | HRM | London | `EMP-200101` |
| `EMP-200106` | Hiroshi Tanabe | G8 | Head of Learning & Development | HRM | Charlotte | `EMP-200101` |
| `EMP-200107` | Camille Duforest | G8 | Head of Talent & Performance | HRM | New York | `EMP-200101` |
| `EMP-200108` | Ekaterina Volkova | G7 | Head of Global Mobility & International Assignments | HRM | London | `EMP-200102` |
| `EMP-200201` | Fiona Gallagher | G6 | HR Business Partner — Retail Banking & Customer Support | HRM | Charlotte | `EMP-200101` |
| `EMP-200202` | Rajiv Menon | G6 | HR Business Partner — Technology & Information Security | HRM | San Francisco | `EMP-200101` |
| `EMP-200203` | Zara Haddad | G6 | HR Business Partner — Risk, Compliance & Internal Audit | HRM | New York | `EMP-200101` |
| `EMP-200204` | Tomás Rivera | G6 | HR Business Partner — Corporate & Commercial Banking | HRM | New York | `EMP-200101` |
| `EMP-200205` | Ingrid Solberg | G6 | HR Business Partner — Finance, Treasury & Corporate Centre | HRM | New York | `EMP-200101` |
| `EMP-200301` | Emeka Achebe | G5 | Senior Recruiter — Technology & Information Security | HRM | San Francisco | `EMP-200103` |
| `EMP-200302` | Laura Kowalski | G5 | Senior Recruiter — Retail & Branch Network | HRM | Charlotte | `EMP-200103` |
| `EMP-200303` | Nathan Boateng | G4 | Recruiter — Corporate Centre | HRM | New York | `EMP-200103` |
| `EMP-200304` | Meera Krishnan | G4 | Recruitment Operations Officer — Screening & Background Verification | HRM | Hyderabad | `EMP-200103` |
| `EMP-200401` | Bianca Ferraro | G4 | Training Coordinator — Mandatory Compliance Curriculum | HRM | Charlotte | `EMP-200106` |
| `EMP-200402` | Kwame Asante | G4 | Training Coordinator — Technology & Security Curriculum | HRM | Hyderabad | `EMP-200106` |
| `EMP-200501` | Sarah Whitmore | G3 | HR Operations Analyst — Leave & Absence Administration | HRM | Hyderabad | `EMP-200102` |
| `EMP-200502` | Ahmed Al-Rashid | G3 | HR Operations Analyst — Payroll & Benefits | HRM | Dubai | `EMP-200102` |

#### A.3 Business Lines — Retail, Customer Support, Corporate Banking

| Employee ID | Name | Grade | Role | Dept | Location | Reports To |
|---|---|---|---|---|---|---|
| `EMP-300101` | Patricia Nwankwo | G8 | Head of Retail Operations | RTL | Charlotte | `EMP-100014` |
| `EMP-300102` | Victor Salazar | G7 | Regional Retail Director — Southeast | RTL | Charlotte | `EMP-100014` |
| `EMP-300103` | Amara Okoye | G5 | Branch Manager — Charlotte Uptown Flagship (`SIT-0412`) | RTL | Charlotte | `EMP-300102` |
| `EMP-300104` | Brendan Kelly | G5 | Branch Manager — Chicago Loop Community (`SIT-0873`) | RTL | Chicago | `EMP-300102` |
| `EMP-300105` | Lucia Marchetti | G2 | Personal Banker | RTL | Charlotte | `EMP-300103` |
| `EMP-300106` | Jamal Robertson | G1 | Teller | RTL | Charlotte | `EMP-300103` |
| `EMP-300107` | Dara Ekwueme | G5 | Branch Manager — Charlotte Uptown Flagship (`SIT-0412`), appointed 2026 | RTL | Charlotte | `EMP-300102` |
| `EMP-300201` | Katarina Novak | G8 | Head of Contact Centre Operations | CST | Charlotte | `EMP-100020` |
| `EMP-300202` | Michael Thornton | G6 | Customer Service Manager — Disputes & Complaints | CST | Charlotte | `EMP-300201` |
| `EMP-300301` | Henry Bakshi | G6 | Relationship Manager — Commercial Banking Midwest | CBK | Chicago | `EMP-100015` |
| `EMP-300302` | Naomi Castellanos | G3 | Senior Credit Analyst | CBK | Chicago | `EMP-300301` |

#### A.4 Control Functions — Compliance, Risk, Internal Audit

| Employee ID | Name | Grade | Role | Dept | Location | Reports To |
|---|---|---|---|---|---|---|
| `EMP-400101` | Adeline Mercier | G9 | Head of Financial Crime | CMP | New York | `EMP-100005` |
| `EMP-400102` | Robert Kinsella | G8 | BSA Officer | CMP | New York | `EMP-400101` |
| `EMP-400103` | Priyanka Iyer | G6 | Compliance Officer — Retail Banking | CMP | Charlotte | `EMP-400101` |
| `EMP-400104` | Oluwaseun Bakare | G5 | Compliance Officer — Branch Network Monitoring | CMP | Charlotte | `EMP-400103` |
| `EMP-400201` | Lars Henriksson | G9 | Head of Credit Risk | RSK | New York | `EMP-100004` |
| `EMP-400202` | Deepa Ramanathan | G8 | Head of Operational Risk | RSK | New York | `EMP-100004` |
| `EMP-400203` | Julien Faucher | G6 | Risk Manager — Operational Risk, Retail & Operations | RSK | Charlotte | `EMP-400202` |
| `EMP-400301` | Imani Cole | G8 | Head of Audit — Retail & Operations | IAD | Charlotte | `EMP-100009` |
| `EMP-400302` | Sean Fitzpatrick | G6 | Audit Manager | IAD | New York | `EMP-400301` |

#### A.5 Technology and Information Security

| Employee ID | Name | Grade | Role | Dept | Location | Reports To |
|---|---|---|---|---|---|---|
| `EMP-500101` | Ravi Subramanian | G11 | Head of IT Operations | ITO | Charlotte | `EMP-100007` |
| `EMP-500102` | Yuki Nakagawa | G9 | Head of Platform Engineering | ITO | San Francisco | `EMP-500101` |
| `EMP-500103` | Andrés Villalobos | G8 | Head of Service Management | ITO | Hyderabad | `EMP-500101` |
| `EMP-500201` | Marta Bauer | G8 | Head of Cyber Defence | ISC | San Francisco | `EMP-100010` |
| `EMP-500202` | Tobias Lindgren | G8 | Head of Identity & Access | ISC | San Francisco | `EMP-100010` |
| `EMP-500203` | Aisha Rahman | G6 | Information Security Officer — Business Engagement (Retail & HR) | ISC | Charlotte | `EMP-500201` |

#### A.6 Corporate Centre — Finance, Treasury, Legal, Administration, Procurement

| Employee ID | Name | Grade | Role | Dept | Location | Reports To |
|---|---|---|---|---|---|---|
| `EMP-600101` | Gemma Ashworth | G9 | Group Financial Controller | FIN | New York | `EMP-100002` |
| `EMP-600102` | Marcel Delacroix | G8 | Head of Financial Operations | FIN | Charlotte | `EMP-600101` |
| `EMP-600103` | Sandeep Bhatt | G6 | Finance Manager — Corporate Centre Cost Control | FIN | New York | `EMP-600101` |
| `EMP-600104` | Rosa Delgado | G6 | Corporate Travel & Expense Manager | FIN | Charlotte | `EMP-600102` |
| `EMP-600105` | Anneke Visser | G9 | Head of Financial Planning & Analysis | FIN | New York | `EMP-100002` |
| `EMP-600106` | Farhan Siddiqui | G9 | Head of Regulatory Reporting | FIN | New York | `EMP-100002` |
| `EMP-600107` | Miriam Rosenthal | G8 | Head of Tax | FIN | New York | `EMP-100002` |
| `EMP-600108` | Pieter Janssen | G8 | Head of Product Control & Valuation | FIN | London | `EMP-600101` |
| `EMP-600109` | Rosalind Mbeki | G8 | Head of Accounting Policy & Technical Accounting | FIN | New York | `EMP-600101` |
| `EMP-600110` | Teresa Villanueva | G8 | Head of Internal Controls & SOX | FIN | Charlotte | `EMP-600101` |
| `EMP-600111` | Arun Balakrishnan | G8 | Head of Capital Planning & Stress Testing | FIN | New York | `EMP-100002` |
| `EMP-600112` | Colin Devereaux | G7 | Head of Accounts Payable | FIN | Charlotte | `EMP-600102` |
| `EMP-600113` | Noriko Hayashi | G7 | Head of Accounts Receivable & Billing | FIN | Charlotte | `EMP-600102` |
| `EMP-600114` | Rahul Bhattacharya | G7 | Head of Finance Systems & Data | FIN | Hyderabad | `EMP-600101` |
| `EMP-600115` | Bethany Clarke | G6 | Payroll Accounting Manager | FIN | Charlotte | `EMP-600102` |
| `EMP-600116` | Olumide Fashola | G6 | Finance Manager — Consumer & Retail Banking | FIN | Charlotte | `EMP-600105` |
| `EMP-600117` | Wei-Ling Tan | G6 | Finance Manager — Technology & Operations | FIN | San Francisco | `EMP-600105` |
| `EMP-600118` | Elias Nyberg | G3 | Senior Financial Analyst — Corporate Centre | FIN | New York | `EMP-600103` |
| `EMP-600119` | Divya Nair | G2 | Accounts Payable Analyst | FIN | Hyderabad | `EMP-600112` |
| `EMP-600120` | Joaquín Herrera | G4 | Expense Audit Officer | FIN | Hyderabad | `EMP-600104` |
| `EMP-600201` | Aurélie Dubois | G7 | Head of Physical Security | ADM | New York | `EMP-100019` |
| `EMP-600202` | Nadine Okafor | G6 | Vice President, Enterprise Knowledge Management (EKMO) | ADM | Charlotte | `EMP-100019` |
| `EMP-600301` | Beatriz Cardoso | G8 | Head of Employment Legal | LEG | New York | `EMP-100006` |
| `EMP-600401` | Ethan Brookfield | G8 | Head of Category Management | PRC | Charlotte | `EMP-100013` |
| `EMP-600402` | Angela Duarte | G8 | Head of Procurement Operations | PRC | Charlotte | `EMP-100013` |
| `EMP-600501` | Nikolai Petrov | G8 | Head of Treasury Operations | TRY | New York | `EMP-100018` |
| `EMP-600502` | Sarah Bergström | G8 | Head of Balance Sheet Management | TRY | New York | `EMP-100018` |
| `EMP-600503` | Anand Krishnamurthy | G8 | Head of Liquidity Management | TRY | London | `EMP-100018` |

**Register governance.** New employees are added by HR Operations (`EMP-200102` Owen Bradshaw) with the identifier allocated from ApexPeople. Role, grade, department, and reporting line changes are effected in ApexPeople and reflected here at the next Minor version. Departed employees remain in the register marked `Former` for the duration of the retention period so that historical records remain resolvable.

### Appendix B — HR Record Identifiers and Naming

Extends the record type register in `ANB-ADM-STD-0007` §8.4. Filenames follow `<Prefix>_<EntityID>_<Descriptor>_<YYYYMMDD>.<ext>`.

| Identifier | Format | Record Type Prefix | System | Retention |
|---|---|---|---|---|
| Employee | `EMP-######` | `HRRE` | ApexPeople | `RET-HRM-7Y` |
| Requisition | `REQ-######` | `HRRQ` | ApexPeople | `RET-REC-2Y` |
| Candidate | `CND-########` | `HRCV` | ApexPeople | `RET-REC-2Y` (unsuccessful) / `RET-HRM-7Y` (hired) |
| Background verification | `CND-########` | `HRBG` | ApexPeople, ApexServe | `RET-HRM-7Y` |
| Offer | `REQ-######` | `HROF` | ApexPeople, ApexDocs | `RET-HRM-7Y` |
| Performance review | `PRF-########` | `HRPR` | ApexPeople | `RET-HRM-7Y` |
| Leave request | `LVE-##########` | `HRLV` | ApexPeople | `RET-HRM-7Y` |
| Training / certification record | `TRN-########` | `HRTR` | ApexLearn | `RET-TRN-5Y` |
| Conduct / grievance case | `CAS-########` | `HRCD` | ApexServe, ApexDocs | `RET-HRM-7Y` |
| Exit clearance | `EMP-######` | `HREX` | ApexPeople | `RET-HRM-7Y` |
| Travel request | `TRV-########` | `TRVL` | ApexServe | `RET-FIN-10Y` |
| Expense claim | `EXP-##########` | `EXPN` | ApexLedger | `RET-FIN-10Y` |

**Examples.**

```
HRRE_EMP-300103_EmploymentContract_20240115.pdf
HRRQ_REQ-114820_BranchManager-CharlotteUptown_20260304.pdf
HRBG_CND-20260419_BackgroundVerificationReport_20260428_C2.pdf
HROF_REQ-114820_OfferLetter-Signed_20260506.pdf
HRPR_PRF-20260112_AnnualReview-FY26_20270131_C2.pdf
HRLV_LVE-4471209833_ParentalLeave-Primary_20260601.pdf
HRTR_TRN-88104220_AML-Annual-FY26-Certificate_20260930.pdf
HRCD_CAS-00714290_InvestigationReport_20261118_C3.pdf
HREX_EMP-300105_ExitClearanceRecord_20270228.pdf
TRVL_TRV-00218844_Singapore-ClientVisit-Approval_20260812.pdf
EXPN_EXP-9928014471_TravelSettlement-Singapore_20260901.pdf
```

### Appendix C — "Where Do I Find It?" Index

| Question | Document | Section |
|---|---|---|
| How many holidays do I get? | `ANB-HRM-POL-0002` | §8.1 |
| How do I book leave? | `ANB-HRM-POL-0002` | §11.1 |
| Can I carry leave into next year? | `ANB-HRM-POL-0002` | §10.1 |
| Do I have to take two consecutive weeks? | `ANB-HRM-POL-0002` | §9 |
| What class can I fly? | `ANB-FIN-POL-0002` | §8.2 |
| What's my meal allowance in London? | `ANB-FIN-POL-0002` | §9.2 |
| How long do I have to claim expenses? | `ANB-FIN-POL-0002` | §11.3 |
| Can I travel to a high-risk country? | `ANB-FIN-POL-0002` | §12 |
| How many days must I be in the office? | `ANB-HRM-POL-0003` | §7 |
| Can I work from another country? | `ANB-HRM-POL-0003` | §9 |
| What equipment will I get at home? | `ANB-HRM-POL-0003` | §10 |
| Can I trade shares? | `ANB-HRM-POL-0004` | §10 |
| Can I take a second job? | `ANB-HRM-POL-0004` | §11 |
| Can I accept a gift from a client? | `ANB-HRM-POL-0004` | §9 |
| How do I report misconduct anonymously? | `ANB-HRM-POL-0004` | §12 |
| When are objectives due? | `ANB-HRM-POL-0006` | §7 |
| How do ratings work? | `ANB-HRM-POL-0006` | §9 |
| How do I get promoted? | `ANB-HRM-POL-0006` | §12 |
| What is a PIP? | `ANB-HRM-POL-0006` | §13 |
| How do I raise a job requisition? | `ANB-HRM-SOP-0007` | §8 |
| What does background verification cover? | `ANB-HRM-SOP-0007` | §10 |
| Who approves an offer? | `ANB-HRM-SOP-0007` | §11 |
| Which training is mandatory for me? | `ANB-HRM-POL-0008` | §8 |
| What happens if I miss a training deadline? | `ANB-HRM-POL-0008` | §11 |
| How long is my certification valid? | `ANB-HRM-POL-0008` | §10 |
| How much notice must I give? | This Handbook | §14.3 |
| What happens on my last day? | This Handbook | §15 |

### Appendix D — Key Contacts

| Need | Contact | Route |
|---|---|---|
| Anything HR, first line | Your HR Business Partner (Appendix A.2) | ApexServe HR case |
| Leave, payroll, benefits administration | HR Operations | ApexServe HR case |
| Recruitment and internal moves | Talent Acquisition | ApexServe HR case |
| Training and certification | Learning & Development | ApexLearn or ApexServe |
| Conduct, grievance, harassment | Employee Relations (`EMP-200105` Grace Mwangi) | ApexServe, marked Confidential |
| Confidential ethics concern | Ethics Line — independent third party | 24×7, anonymous where permitted by local law |
| Conflicts, personal dealing, gifts | Compliance (`EMP-400103` Priyanka Iyer or business-aligned officer) | ApexServe |
| Security incident or suspected data loss | Information Security (`EMP-500201` Marta Bauer) | ApexServe — Severity 1 route; report immediately |
| System access | Your line manager, then ApexID request | ApexServe |
| Travel booking and duty of care | Corporate Travel & Expense (`EMP-600104` Rosa Delgado); Physical Security (`EMP-600201` Aurélie Dubois) for risk-rated destinations | ApexServe |
| Building access, badge, facilities | Administration | ApexServe |
| Where a policy lives | Enterprise Knowledge Management Office (`EMP-600202` Nadine Okafor) | ApexDocs search |

---

**End of Document**

`ANB-HRM-HBK-0001` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) · Approver: Yvonne Carter, Chief Human Resources Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
