# Apex National Bank — Leave Policy

**Human Resources Policy | Absence Entitlement, Approval, and Administration**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-POL-0002` |
| **Document Title** | Apex National Bank — Leave Policy |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) — HR Operations |
| **Custodian** | Owen Bradshaw, Head of HR Operations (G8) — `EMP-200102` |
| **Approver** | Yvonne Carter, Chief Human Resources Officer (G11) — `EMP-100008` |
| **Secondary Approvers** | Margaret Sullivan, General Counsel; Priya Raghunathan, Chief Financial Officer (accrual provisioning) |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-04 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24) |
| **Supersedes** | None — initial published policy |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.2` Reward → Benefits → `POL` |
| **Business Process** | `BP-HR-LEAVE` Leave & Mandatory Absence Administration |
| **Governing Body** | Executive Committee; Board Compensation & Human Capital Committee (noting) |
| **System of Record** | ApexPeople (entitlement, balance, requests) · ApexDocs (this policy) |
| **Keywords** | leave, annual leave, sick leave, parental leave, bereavement, mandatory absence, carry forward, accrual, absence |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0004` · `ANB-HRM-POL-0006` · `ANB-HRM-SOP-0007` · `ANB-ADM-MTX-0001` · `ANB-ADM-POL-0001` |

> **Authority.** This Policy implements the leave framework described in `ANB-ADM-REF-0001` §6 and is summarised in `ANB-HRM-HBK-0001` §13.1. Where the Handbook summary and this Policy differ, this Policy prevails. Where local statute provides a more favourable entitlement, local statute prevails.

---

## 2. Purpose

Leave is not an administrative courtesy. In a regulated bank it serves three distinct purposes at once: it protects employee wellbeing and sustained performance; it satisfies statutory entitlement across nineteen jurisdictions; and — through mandatory consecutive absence — it operates as a **fraud and operational control**, because sustained concealment of irregular activity requires uninterrupted access.

This Policy therefore:

1. Sets entitlement for every leave type across all grades and legal entities.
2. Defines a single approval workflow with clear escalation.
3. Governs accrual, balance, carry-forward, encashment, and settlement.
4. Enforces the mandatory two-week consecutive absence control for designated sensitive roles.
5. Defines the records produced and their retention.

---

## 3. Scope

### 3.1 Applies To

| Population | Coverage |
|---|---|
| Permanent employees G1–G12 | Full entitlement |
| Fixed-term employees | Pro-rated by contract duration |
| Part-time employees | Pro-rated by contracted hours |
| Interns and apprentices | Statutory minimum plus sick leave |
| Employees on international assignment | Home-entity entitlement or host-country statutory minimum, whichever is greater (`ANB-HRM-POL-0003` §9) |
| All legal entities | Apex National Bank, N.A.; Apex National Bank (UK) plc; Apex Bank Europe SE; Apex Securities LLC; Apex Asset Management, Inc.; Apex Trust Company, N.A.; Apex Global Services |

### 3.2 Does Not Apply To

Contractors, agency workers, and vendor personnel, whose absence arrangements sit with their employer under `ANB-PRC-POL-0002`. Bank managers must not approve, record, or refuse leave for non-employees.

### 3.3 Jurisdictional Floor

The entitlements in Section 8 are the **Apex standard**. In every jurisdiction, the employee receives the greater of the Apex standard and the local statutory minimum. Local schedules are maintained by the regional HR Business Partner, approved by the HR Director, and published as child documents of this Policy in ApexDocs.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Statutory compliance in every jurisdiction | Zero statutory entitlement breaches |
| O-2 | Mandatory absence control operates | 100% of designated sensitive-role holders complete two consecutive weeks annually |
| O-3 | Leave is taken, not banked | ≥ 90% of annual entitlement used within the leave year |
| O-4 | Accrual liability is accurate | Monthly ApexPeople-to-ApexLedger accrual reconciliation variance < 0.5% |
| O-5 | Requests are decided promptly | ≥ 95% of requests decided within 5 business days |
| O-6 | Absence records are complete | ≥ 99% of absence recorded in ApexPeople within 24 hours |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Leave Year** | 1 January to 31 December, aligned to the performance year in `ANB-HRM-POL-0006`. |
| **Entitlement** | The total leave allocated for a leave year, before accrual timing. |
| **Accrual** | The portion of entitlement earned to date, accruing monthly in arrears at 1/12 of annual entitlement. |
| **Balance** | Accrued entitlement less leave taken and approved future bookings. |
| **Carry-Forward** | Unused annual leave permitted to move into the following leave year. |
| **Encashment** | Payment in lieu of untaken leave. |
| **Mandatory Consecutive Absence** | Two uninterrupted weeks of leave with all system access suspended, required of designated sensitive roles as a control. |
| **Sensitive Role** | A role designated in ApexPeople as subject to mandatory consecutive absence (§9.2). |
| **Unauthorised Absence** | Absence not approved and not covered by an accepted notification. |
| **Leave Request** | A record in ApexPeople identified `LVE-##########`. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Employee** | Request leave in advance through ApexPeople; notify unplanned absence before the start of the working day; provide certification where required; return on the agreed date. |
| **Line Manager** | Decide requests within 5 business days; balance operational cover; ensure team members take their entitlement; ensure sensitive-role holders complete mandatory absence; never approve their own leave. |
| **Department Head (G9–G11)** | Approve exceptional leave, sabbaticals, unpaid leave beyond 10 days, and mandatory-absence exemption requests before onward escalation. |
| **HR Business Partner (G6)** | Advise on complex absence, parental leave, long-term sickness, disability accommodation, and disputes. Named HRBPs are listed in `ANB-HRM-HBK-0001` Appendix A.2. |
| **HR Operations (`EMP-200102` Owen Bradshaw, G8)** | Own entitlement configuration, accrual calculation, balance integrity, carry-forward processing, and the leave calendar. |
| **HR Operations Analyst — Leave & Absence (`EMP-200501` Sarah Whitmore, G3)** | Day-to-day administration, certification tracking, and exception reporting. |
| **Head of Reward (`EMP-200104` Stefan Feldman, G8)** | Owns entitlement design and its cost; approves schedule changes with the CHRO. |
| **Finance (`EMP-600101` Gemma Ashworth, G9)** | Monthly accrual provisioning and reconciliation between ApexPeople and ApexLedger. |
| **Compliance (`EMP-400101` Adeline Mercier, G9)** | Co-owns the sensitive-role designation list; reviews mandatory-absence exceptions. |
| **Information Security (`EMP-500202` Tobias Lindgren, G8)** | Executes access suspension and restoration for mandatory consecutive absence. |
| **Internal Audit (IAD)** | Tests mandatory-absence compliance as a fraud control within scheduled audits. |
| **Employment Legal (`EMP-600301` Beatriz Cardoso, G8)** | Confirms statutory floors and advises on disability, medical, and discrimination-sensitive absence. |

---

## 7. Policy Statements

**L-1.** Leave is an entitlement, not a discretionary reward. Managers may schedule leave for operational reasons but may not refuse an employee reasonable access to their full entitlement across the leave year.

**L-2.** All leave — planned, unplanned, paid, and unpaid — must be recorded in ApexPeople. Absence agreed informally and never recorded is unauthorised absence and a records defect.

**L-3.** Managers may not approve their own leave. The approver is always the next level up in the ApexPeople reporting line.

**L-4.** An employee on approved leave is not expected to work, monitor email, or be available, except where they hold a documented on-call or crisis-response duty.

**L-5.** Mandatory consecutive absence is a **control**, not an entitlement. It cannot be waived by the line manager, cannot be split, and cannot be substituted by remote working.

**L-6.** Leave may not be used to avoid, delay, or frustrate a disciplinary process, an investigation, or an audit request. Sick leave during an open investigation is managed by the HRBP with occupational health input.

**L-7.** Entitlement is pro-rated for joiners, leavers, part-time employees, and unpaid absence exceeding one month.

**L-8.** Falsifying a leave request, a sickness reason, or supporting certification is misconduct under `ANB-HRM-POL-0004` §14 and may constitute fraud against the Bank.

**L-9.** Leave records contain health and family data. They are classified **Confidential (C2)**, carry `contains_pii = true`, and are accessible only to the employee, their line manager (dates only, not medical detail), HR, and Occupational Health.

**L-10.** No manager may see the medical detail supporting a sickness or accommodation request. Managers see dates and fitness-to-work status only.

---

## 8. Standards — Leave Types and Entitlement

### 8.1 Annual Leave

| Grade Band | Annual Entitlement (US standard) | Accrual |
|---|---|---|
| G1–G3 | 20 working days | 1.667 days/month |
| G4–G6 | 25 working days | 2.083 days/month |
| G7–G9 | 28 working days | 2.333 days/month |
| G10–G12 | 30 working days | 2.500 days/month |

**Service uplift.** One additional day at 5 years' continuous service and one further day at 10 years, to a maximum of 32 days.

**Regional floors.** United Kingdom: minimum 25 days plus 8 bank holidays. European Union entities: minimum 25 days plus public holidays, or the local statutory minimum if higher. India: minimum 24 days combined earned/casual leave plus public holidays. UAE: minimum 30 calendar days. Singapore and Hong Kong: Apex standard applies, which exceeds statutory minima. Where a jurisdiction mandates more, the mandate applies.

**Minimum booking.** Half-day increments. Single-day bookings are permitted; a minimum of one continuous week must be taken at least once per leave year by all employees, to support wellbeing and cover-testing.

### 8.2 Public Holidays

Employees observe the public holidays of their country and, in the United States, of their state of employment, up to the entity holiday calendar published annually in ApexPeople by HR Operations before 1 November for the following year. Employees required to work a public holiday receive a substitute day within 60 days or premium payment per local practice. Branch and contact-centre rosters for public holidays are published four weeks in advance.

### 8.3 Sick Leave

| Stage | Provision | Evidence Required |
|---|---|---|
| Days 1–2 | Self-certified; notify line manager before the start of the working day and record in ApexPeople within 24 hours | Self-certification in ApexPeople |
| Days 3–7 | Paid; HRBP notified | Medical certificate submitted to HR (not to the manager) |
| Days 8–10 | Paid; return-to-work discussion required on return | Medical certificate |
| Beyond 10 days (cumulative annual paid sick leave exhausted) | Short-Term Disability: 100% of base pay for 13 weeks, then 60% to week 26 | Occupational Health assessment |
| Beyond 26 weeks | Long-Term Disability at 60% of base pay | Occupational Health and insurer assessment |

**Return-to-work discussion.** Mandatory after any absence of three or more consecutive days, and after any third separate absence in a rolling twelve months. Conducted by the line manager, recorded in ApexPeople, and focused on support and fitness to work — not on questioning the illness.

**Long-term absence.** Cases exceeding 20 continuous working days are transferred to the HRBP with Occupational Health involvement, a documented support plan, and phased-return options. Disability-related absence is managed with reasonable adjustments as of right, coordinated by the HRBP with Employment Legal.

**Sickness during annual leave.** Where an employee falls ill during booked annual leave and provides a medical certificate, the affected days are reclassified as sick leave and the annual leave is restored.

### 8.4 Emergency and Personal Leave

**Entitlement:** 3 paid days per leave year, non-accruing and non-carry-forward.

Available for: sudden dependant care breakdown, urgent home emergency (fire, flood, burglary), urgent immigration or legal appointments that cannot be scheduled outside working hours, and comparable unforeseeable events. Notified to the line manager as early as possible and recorded within 24 hours. Where the need exceeds 3 days, the employee may use annual leave, request unpaid leave, or — for dependant illness — access statutory dependant leave where the jurisdiction provides it.

### 8.5 Bereavement Leave

| Relationship | Paid Entitlement |
|---|---|
| Spouse, domestic partner, child, stillbirth, or pregnancy loss | 10 working days |
| Parent, sibling, grandparent, grandchild, parent-in-law, or a person for whom the employee is primary carer | 10 working days |
| Extended family (aunt, uncle, cousin, niece, nephew) | 3 working days |
| Close friend or colleague — attendance at funeral | 1 working day |

**Additional provisions.** Travel time for international bereavement is granted additionally, up to 3 further days for travel beyond the employee's country of residence. Entitlement may be taken non-consecutively within 12 months of the bereavement. No documentary evidence is required. Extension by agreement with the HRBP, using annual, unpaid, or compassionate leave. Pregnancy loss at any gestation qualifies for the 10-day provision for both parents.

### 8.6 Parental Leave — Primary Caregiver

**Entitlement:** 16 weeks at full pay, available to the primary caregiver regardless of gender, and applying equally to birth, adoption, and surrogacy.

| Element | Provision |
|---|---|
| Eligibility | From day one of employment |
| Notification | At least 8 weeks before the intended start date, where reasonably practicable |
| Timing | May begin up to 4 weeks before the expected date and must be used within 12 months of birth or placement |
| Structure | Continuous, or in up to three blocks with the HRBP's agreement |
| Statutory interaction | Runs concurrently with statutory maternity/adoption entitlement; the employee receives the greater of the two |
| Antenatal appointments | Paid time off for all appointments, not deducted from any entitlement |
| Benefits continuity | All benefits continue; annual leave accrues throughout |
| Return | Same role, or one of equivalent grade and terms, guaranteed |
| Phased return | Up to 4 weeks at 80% hours on full pay |
| Performance year | Objectives and rating are pro-rated; leave must not disadvantage the rating (`ANB-HRM-POL-0006` §9.5) |

### 8.7 Parental Leave — Secondary Caregiver

**Entitlement:** 8 weeks at full pay, available regardless of gender, applying to birth, adoption, and surrogacy.

Available from day one of employment, usable within 12 months of birth or placement, in up to three blocks. Runs concurrently with statutory paternity or partner entitlement, with the employee receiving the greater. Where both parents are Apex employees, each takes their own entitlement; the primary caregiver designation is declared by the employees.

### 8.8 Marriage Leave

**Entitlement:** 5 working days paid, once per employment.

Provided in jurisdictions where it is customary or statutory — India, United Arab Emirates, Singapore, Hong Kong SAR, and Brazil. Elsewhere, employees use annual leave. Requires 4 weeks' notice and evidence of the marriage date. Extends to civil partnerships and legally recognised equivalents.

### 8.9 Compensatory Leave

**Eligibility:** G1–G4 only. Grades G5 and above are salaried and do not accrue compensatory leave.

| Rule | Detail |
|---|---|
| Trigger | Approved work outside scheduled hours on documented business need — month-end close, release weekends, incident response, regulatory deadlines, branch stocktake |
| Pre-approval | Mandatory by the line manager before the additional hours are worked |
| Accrual | Hour for hour on weekdays; 1.5× on rostered rest days and public holidays |
| Cap | 10 days accrued at any time |
| Expiry | Must be taken within 90 calendar days of accrual; otherwise lapses without payment, except where local statute requires payment |
| Encashment | Not permitted in service |
| Interaction with overtime | Where local law requires overtime payment for the same hours, payment applies and compensatory leave does not |

### 8.10 Sabbatical

**Eligibility:** 10 years' continuous service; not previously taken within the preceding 5 years; performance rating of 3 (Effective) or above in the most recent completed cycle; no live disciplinary warning.

**Provision:** up to 12 weeks unpaid, or up to 4 weeks at 50% pay. Benefits continue; annual leave does not accrue during unpaid sabbatical. Requires 6 months' notice, Department Head recommendation, and CHRO approval. A written return commitment applies: an employee resigning within 12 months of return repays any paid element.

### 8.11 Statutory and Civic Leave

| Type | Provision |
|---|---|
| Jury service | Paid leave for the duration; the employee remits any court allowance |
| Court witness summons | Paid leave for the duration |
| Military reserve service | Per local statute; the Bank makes up the difference to base pay for up to 4 weeks per year |
| Voting | Paid time off where statute provides |
| Volunteering | 2 paid days per leave year with an approved partner organisation |
| Study and examination | Paid time off for examinations relating to Bank-sponsored qualifications under `ANB-HRM-POL-0008` §12 |
| Public duty (school governor, magistrate, local office) | Up to 5 unpaid days, with Department Head agreement, subject to `ANB-HRM-POL-0004` §11 outside-activity declaration |

### 8.12 Unpaid Leave

Unpaid leave of up to 10 working days may be approved by the line manager where entitlement is exhausted. Beyond 10 days requires Department Head approval; beyond 20 days requires the HRBP and CHRO. Unpaid leave exceeding one month suspends annual leave accrual and may affect benefit eligibility and service-related entitlements — the HRBP confirms the impact in writing before approval.

---

## 9. Standards — Mandatory Consecutive Absence

### 9.1 The Control

Employees in designated sensitive roles must take **two consecutive calendar weeks** of leave in each calendar year, during which **all system access is suspended**. This exists so that irregular activity requiring continuous concealment is exposed. It is mandated by `ANB-ADM-REF-0001` §6 and tested by Internal Audit as a fraud control.

### 9.2 Designated Sensitive Roles

| Role Family | Examples from the Canonical Register |
|---|---|
| Traders and dealers | Treasury & Markets front office (`TRY`) |
| Treasury operations and settlement | Treasury back office; nostro management |
| Payment release and wire operations | Payment Operations (`ITO`), under `BP-PAY-DOM` and `BP-PAY-XB` |
| Cash and vault custodians | Branch Managers and vault custodians — e.g. `EMP-300103` Amara Okoye, `EMP-300104` Brendan Kelly |
| Privileged IT administrators | Platform Engineering privileged accounts (`EMP-500102` Yuki Nakagawa's team) |
| Credit approvers holding delegated authority | Senior Credit Officers and above (`EMP-400201` Lars Henriksson's team) |
| Financial crime investigators with case-closure authority | `EMP-400102` Robert Kinsella's team |
| Ledger and reconciliation controllers | Financial Operations (`EMP-600102` Marcel Delacroix's team) |

The designation list is maintained jointly by HR Operations, Compliance, and Operational Risk, reviewed annually, and recorded against the **position** — not the person — in ApexPeople.

### 9.3 Operating Rules

| Rule | Detail |
|---|---|
| Duration | Two consecutive calendar weeks, including at least 10 consecutive working days |
| Splitting | Not permitted |
| Substitution | Remote working, training attendance, and business travel do not count |
| Access | All system access suspended by Information Security at the start and restored on return; the employee retains ApexPeople self-service only |
| Devices | Bank laptop and phone surrendered or locked; no VPN access |
| Contact | The employee must not be contacted for operational matters; delegation is arranged before departure |
| Handover | Documented handover to a named colleague filed in ApexDocs before departure |
| Scheduling | Booked in ApexPeople by 31 March each year; unbooked at 30 June triggers escalation to the Department Head |
| Non-completion | Reported to the Operational Risk Committee as a control failure |

### 9.4 Exemptions

An exemption may be granted only where the role is genuinely unique and cover cannot be arranged, and only with a documented compensating control (for example, enhanced transaction review during a shorter absence). Exemption requires the approval of the **CHRO and the Chief Compliance Officer** jointly (`ANB-ADM-MTX-0001` §13), is limited to one leave year, and is reported to Internal Audit and to the Operational Risk Committee.

---

## 10. Standards — Balance, Carry-Forward, and Settlement

### 10.1 Carry-Forward

| Rule | Detail |
|---|---|
| Maximum carried | 5 working days |
| Deadline for use | 31 March of the following leave year |
| Beyond deadline | Forfeited without payment, except where local statute prohibits forfeiture |
| Exceptional carry-forward beyond 5 days | Department Head approval **and** HRBP endorsement; permitted only where leave was refused for documented operational reasons, or where long-term sickness or parental leave prevented use |
| Statutory protection | In jurisdictions where statute requires carry-forward of untaken statutory leave (for example, leave untaken due to sickness), the statutory rule overrides this section |
| Carry-forward reporting | HR Operations reports balances above 10 days to Department Heads monthly from October |

### 10.2 Encashment

Encashment of annual leave **in service is prohibited**, except where local statute requires it. Leave exists to be taken. On separation, accrued and untaken annual leave is paid in the final payroll; leave taken in excess of accrual is recovered from final pay where local law permits.

### 10.3 Excessive Balance Management

| Balance at Month End | Action |
|---|---|
| Above 60% of annual entitlement at 30 June | Line manager agrees a booking plan with the employee |
| Above 40% of annual entitlement at 30 September | Department Head notified; plan filed in ApexPeople |
| Above 25% of annual entitlement at 30 November | HRBP intervention; leave may be directed by the Bank with 4 weeks' notice |

The Bank reserves the right to direct leave with reasonable notice where balances put statutory compliance, the accrual provision, or employee wellbeing at risk.

### 10.4 Accrual and Financial Control

HR Operations produces a monthly leave liability extract from ApexPeople. Finance posts the accrual to ApexLedger and reconciles under `BP-RECN-DAILY`; variances above 0.5% are investigated and reported to the Group Financial Controller. The leave provision is a SOX-relevant estimate and is subject to control testing under `BP-AUD-SOX`.

---

## 11. Process Flow

### 11.1 Planned Leave Request

```
EMPLOYEE                LINE MANAGER            HR OPERATIONS          SYSTEM
   │                          │                       │                   │
   ├─ Raise LVE- request ────►│                       │            ApexPeople
   │   in ApexPeople          │                       │                   │
   │                          ├─ Check balance,       │                   │
   │                          │  cover, blackout,     │                   │
   │                          │  mandatory-absence    │                   │
   │                          │  status               │                   │
   │                          │                       │                   │
   │                    ┌─────┴─────┐                 │                   │
   │                 APPROVE     DECLINE              │                   │
   │                    │           │                 │                   │
   │◄── Confirmation ───┤           ├─ Written reason │                   │
   │                    │           │  within 5 days  │                   │
   │                    ├──────────────────────────►  │ Balance updated   │
   │                    │                             │ Calendar updated  │
   │                    │                             │ Payroll notified  │
   │                    │                             │                   │
   └─ If sensitive role: ISC suspends access at start, restores on return │
```

**Service levels.** Requests of 5 days or fewer: decision within 5 business days. Requests exceeding 5 days: decision within 10 business days. Requests submitted with less than the required notice may be declined on that basis alone.

**Notice periods.** 1–2 days: 5 business days' notice. 3–5 days: 10 business days. 6–15 days: 20 business days. Over 15 days: 40 business days. Emergency, bereavement, and sick leave are exempt from notice requirements.

### 11.2 Unplanned Absence

```
Employee unable to attend
        │
        ├─ Notify line manager by phone before start of working day
        │   (branch/contact centre: at least 2 hours before shift start)
        │
        ├─ Line manager arranges cover; records absence in ApexPeople within 24h
        │
        ├─ Day 3 ──► Medical certificate to HR (not to manager)
        │
        ├─ Day 8 ──► HRBP notified; Occupational Health referral considered
        │
        ├─ Day 20 ──► Case transferred to HRBP; support plan documented
        │
        └─ Return ──► Return-to-work discussion recorded in ApexPeople
```

### 11.3 Refusal and Escalation

A manager may decline leave only for documented operational reasons: insufficient cover, a declared blackout period, an unresolved handover, or inadequate notice. The reason must be given in writing within 5 business days, and the manager must offer alternative dates. An employee who believes leave has been unreasonably refused escalates to the Department Head; if unresolved, to the HRBP; if still unresolved, through the grievance route in `ANB-HRM-HBK-0001` §14.2.

### 11.4 Blackout Periods

| Period | Affected Population | Rationale |
|---|---|---|
| Financial year-end close (last 3 and first 5 business days of January) | Finance, Treasury operations, Regulatory Reporting | `BP-FIN-CLOSE`, `BP-REG-FILE` |
| Quarter-end close (last 2 and first 3 business days) | Finance, Product Control | `BP-FIN-CLOSE` |
| Technology change freeze windows | Platform Engineering on-call rosters | `ANB-ITO-SOP-0003` |
| Peak retail periods (last 3 business days of each month; 20 Dec – 2 Jan) | Branch network, Contact Centre | Customer demand |
| Annual regulatory submission windows | Regulatory Reporting, Compliance | `BP-REG-FILE` |
| Audit fieldwork on the audited unit | Named audit interviewees only | `BP-AUD-ENG` |

Blackout periods restrict **discretionary** annual leave only. They never restrict sick, bereavement, emergency, parental, or statutory leave, and never override mandatory consecutive absence — which is scheduled around them.

---

## 12. Decision Tables

### 12.1 Which Leave Type Applies?

| Situation | Leave Type | Paid | Evidence |
|---|---|---|---|
| Planned holiday | Annual leave | Yes | None |
| Woke up unwell | Sick leave | Yes (to limit) | Self-cert to day 2; certificate from day 3 |
| Child's school closed unexpectedly | Emergency leave | Yes (3 days/yr) | None |
| Child's planned surgery | Annual leave or dependant leave where statutory | Per type | Appointment evidence for statutory |
| Parent died | Bereavement — 10 days | Yes | None |
| Cousin died | Bereavement — 3 days | Yes | None |
| Partner giving birth, employee is secondary caregiver | Parental — secondary, 8 weeks | Yes | Birth documentation |
| Adopting a child as primary caregiver | Parental — primary, 16 weeks | Yes | Placement documentation |
| Getting married (Mumbai-based employee) | Marriage leave — 5 days | Yes | Marriage date evidence |
| Getting married (New York-based employee) | Annual leave | Yes | None |
| Worked the full release weekend, G3 | Compensatory leave | Yes (time off) | Pre-approval record |
| Worked the full release weekend, G7 | None — salaried | — | — |
| Summoned for jury duty | Jury service | Yes | Court summons |
| Studying for a Bank-sponsored CAMS examination | Study leave | Yes | Exam confirmation |
| Fell ill on day 2 of a two-week holiday | Sick leave from day 2; annual leave restored | Yes | Medical certificate |
| Wants 3 months to travel after 11 years' service | Sabbatical | Unpaid or 4 weeks at 50% | Department Head recommendation |
| Trader who has not booked mandatory absence by 30 June | Directed leave | Yes | Escalation record |

### 12.2 Approval Authority

| Request | Approver | Second Approver | Reference |
|---|---|---|---|
| Annual leave up to 10 days | Line manager | — | — |
| Annual leave 11–20 days | Line manager | Department Head (G9) | — |
| Annual leave over 20 days | Line manager | Department Head **and** HRBP | — |
| Sick leave (any duration) | Line manager (recording) | HRBP beyond 20 days | §8.3 |
| Emergency leave | Line manager | — | §8.4 |
| Bereavement | Line manager | — | §8.5 |
| Bereavement extension | Line manager | HRBP | §8.5 |
| Parental leave | HRBP | Head of HR Operations (G8) | §8.6, §8.7 |
| Marriage leave | Line manager | — | §8.8 |
| Compensatory leave accrual | Line manager (pre-approval) | — | §8.9 |
| Unpaid leave up to 10 days | Line manager | — | §8.12 |
| Unpaid leave 11–20 days | Department Head (G9) | HRBP | §8.12 |
| Unpaid leave over 20 days | Department Head | CHRO (G11) | §8.12 |
| Sabbatical | Department Head (G9) | CHRO (G11) | §8.10 |
| Carry-forward above 5 days | Department Head (G9) | HRBP | §10.1 |
| Mandatory absence exemption | CHRO (G11) | Chief Compliance Officer (G11) | §9.4 |
| Leave for an ExCo member (G11) | Group CEO | — | `ANB-ADM-MTX-0001` §13 |
| Leave for the Group CEO | Independent Chair of the Board | — | `ANB-LEG-REF-0003` §7.4 |

---

## 13. Examples

### 13.1 Branch Manager — Mandatory Consecutive Absence

`EMP-300103` Amara Okoye (G5, Branch Manager, Charlotte Uptown `SIT-0412`) is a vault custodian and therefore a designated sensitive-role holder.

| Date | Action | Actor |
|---|---|---|
| 2026-02-20 | Books 2026-07-06 to 2026-07-17 as mandatory consecutive absence in ApexPeople (`LVE-4471209833`) | `EMP-300103` |
| 2026-02-24 | Approved; deputy branch manager designated as vault custodian for the period | `EMP-300102` Victor Salazar |
| 2026-06-29 | Handover document filed in ApexDocs; vault dual-control keys reassigned | `EMP-300103` |
| 2026-07-04 (17:00) | ApexID suspends all system access; badge restricted to no branch entry | `EMP-500202` Tobias Lindgren |
| 2026-07-06 to 07-17 | Absent; no contact; branch operates under deputy | — |
| 2026-07-20 (08:00) | Access restored; vault custody re-transferred with dual-control count | `EMP-500202`, `EMP-300102` |
| 2026-07-20 | Completion recorded; evidence available for `BP-AUD-ENG` testing | `EMP-200501` Sarah Whitmore |

Had Ms Okoye not booked by 31 March, escalation would have gone to `EMP-100014` Gregory Lin as Department Head, and non-completion by year end would have been reported to the Operational Risk Committee.

### 13.2 Parental Leave — Primary Caregiver with Phased Return

`EMP-300202` Michael Thornton (G6, Customer Service Manager) is the primary caregiver for a child due in November 2026.

| Date | Action |
|---|---|
| 2026-08-10 | Notifies line manager `EMP-300201` Katarina Novak and HRBP `EMP-200201` Fiona Gallagher; request raised in ApexPeople |
| 2026-08-14 | HRBP confirms 16 weeks at full pay from 2026-11-16, running concurrently with statutory entitlement; annual leave continues to accrue |
| 2026-09 to 11 | Cover arranged; objectives for FY26 pro-rated in ApexPeople per `ANB-HRM-POL-0006` §9.5 |
| 2026-11-16 | Leave begins; access retained for ApexPeople self-service only; no operational contact |
| 2027-03-08 | Returns to the same role; phased return at 80% hours on full pay for 4 weeks |
| 2027-03-08 | Mandatory training refreshed within 10 business days per `ANB-HRM-POL-0008` §11.4 |
| 2027-04-05 | Full hours resume; FY27 objectives set |

### 13.3 Long-Term Sickness

`EMP-300302` Naomi Castellanos (G3, Senior Credit Analyst) is absent from 2026-09-07.

| Day | Action | Owner |
|---|---|---|
| 1 | Telephones `EMP-300301` Henry Bakshi before start of day; absence recorded in ApexPeople | Employee, Manager |
| 3 | Medical certificate submitted to HR Operations — not to the manager | Employee |
| 8 | HRBP `EMP-200204` Tomás Rivera notified; Occupational Health referral raised | HR Operations |
| 20 | Case transferred to HRBP; documented support plan; manager receives fitness-to-work status only | HRBP |
| 51 (10 paid days exhausted earlier) | Short-Term Disability at 100% of base pay commences | Reward, Payroll |
| 90 | Occupational Health review; phased-return options assessed with reasonable adjustments | HRBP, Employment Legal |
| Return | Return-to-work discussion; adjustments implemented; annual leave accrued during absence is available and, where untaken, carried forward under the statutory protection in §10.1 | Manager, HRBP |

At no point does the line manager receive medical detail.

### 13.4 Refused Leave and Escalation

`EMP-300106` Jamal Robertson (G1, Teller) requests 2026-12-22 to 2026-12-31 with 15 business days' notice. The branch is in the retail peak blackout (20 Dec – 2 Jan) and two colleagues are already approved.

The manager declines in writing on 2026-12-01, citing the blackout and cover, and offers 2027-01-12 to 2027-01-21. Mr Robertson accepts. Had he escalated, `EMP-300102` Victor Salazar would have reviewed the cover position; the blackout itself is not appealable, but its application to an individual is.

---

## 14. Approval Matrix — Policy Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| Policy Major version | Head of HR Operations (G8) | Employment Legal, Compliance, Finance, Employee Relations, works councils where applicable | CHRO (G11) | ExCo; Board Compensation & Human Capital Committee |
| Policy Minor version | Head of HR Operations (G8) | Employment Legal | HR Director (G9) | All staff via enterprise notice |
| Entitlement schedule change | Head of Reward (G8) | Finance (cost), Employment Legal | CHRO **and** CFO | Board Compensation & Human Capital Committee |
| Local jurisdictional schedule | Regional HRBP (G6) | Local employment counsel | HR Director (G9) | Local employees |
| Blackout period addition or removal | Department Head (G9) | Head of HR Operations | HR Director (G9) | Affected department |
| Sensitive-role designation list change | Head of Operational Risk (G8) | Compliance, HR Operations | CHRO **and** CCO | Operational Risk Committee; Internal Audit |

---

## 15. Records and Retention

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Leave request and decision | `LVE-##########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Medical certificate | Attached to `LVE-` | ApexPeople (restricted) | C3 | `RET-HRM-7Y` |
| Occupational Health report | `CAS-########` | ApexServe (restricted) | C3 | `RET-HRM-7Y` |
| Return-to-work discussion record | `EMP-######` | ApexPeople | C2 | `RET-HRM-7Y` |
| Mandatory absence completion evidence | `EMP-######` | ApexPeople | C2 | `RET-HRM-7Y` |
| Mandatory absence exemption approval | `CAS-########` | ApexServe, ApexDocs | C2 | `RET-HRM-7Y` |
| Leave liability extract and reconciliation | Monthly | ApexPeople → ApexLedger | C2 | `RET-FIN-10Y` |
| Entity holiday calendar | Annual | ApexPeople, ApexDocs | C1 | `RET-POL-10Y` |

Naming follows `ANB-ADM-STD-0007` §8.3 and `ANB-HRM-HBK-0001` Appendix B — for example `HRLV_LVE-4471209833_MandatoryAbsence-FY26_20260706.pdf`.

---

## 16. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Source of grades and leave policy scope |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Summarises this Policy; canonical employee register |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Leave taken adjacent to business travel |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | Remote work is not a substitute for leave |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Falsified leave requests; conduct during absence |
| `ANB-HRM-POL-0006` | Performance Management Policy | `02_human_resources/006_PERFORMANCE_MANAGEMENT_POLICY.md` | Pro-rating for extended leave; sabbatical eligibility |
| `ANB-HRM-SOP-0007` | Recruitment SOP | `02_human_resources/007_RECRUITMENT_STANDARD_OPERATING_PROCEDURE.md` | Entitlement from day one of employment |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | Study leave; training refresh after long absence |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | People decision authorities |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | `RET-HRM-7Y` |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.2` classification; Employee entity |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | `HRLV` record naming |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-LEAVE` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | ORC reporting of control failures |
| `ANB-HRM-POL-0005` | Compensation & Incentive Governance Policy | *(planned)* | Pay during absence; accrual cost |

---

## 17. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review and re-approval | Head of HR Operations | Annually by 31 July |
| Statutory entitlement change | Update the affected jurisdictional schedule | Regional HRBP with Employment Legal | 30 days |
| New country of operation | Publish local schedule before first hire | Head of Global Mobility | Before first hire |
| Sensitive-role list annual review | Reconfirm designations against positions | Operational Risk with HR Operations and Compliance | Annually by 31 March |
| Mandatory-absence control failure | Root cause and remediation to ORC | Head of HR Operations | 30 days |
| Audit finding | Remediation plan | Head of HR Operations | 30 days |

Next scheduled review: **2027-07-24**.

---

## 18. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-04 | HR Operations | Initial draft from `ANB-ADM-REF-0001` §6 leave scope | — |
| 0.4 | 2026-06-20 | HR Operations | Full entitlement schedule and jurisdictional floors added | — |
| 0.6 | 2026-07-03 | HR Operations | Mandatory consecutive absence section rewritten as a control following Operational Risk and Internal Audit input | — |
| 0.8 | 2026-07-15 | HR Operations | Carry-forward, encashment, and accrual reconciliation added after Finance review | — |
| 0.9 | 2026-07-21 | HR Operations | Employment Legal amendments: statutory carry-forward protection; medical data segregation | — |
| 1.0 | 2026-07-24 | HR Operations | First published version | Y. Carter |

---

## 19. Appendices

### Appendix A — Entitlement Summary Card

| Leave Type | Entitlement | Paid | Carry Forward | Approver |
|---|---|---|---|---|
| Annual leave | 20–30 days by grade, +2 for service | Yes | 5 days to 31 March | Line manager |
| Public holidays | Per entity calendar | Yes | Substitute day if worked | Automatic |
| Sick leave | 10 days, then STD/LTD | Yes | No | Line manager records |
| Emergency / personal | 3 days | Yes | No | Line manager |
| Bereavement — immediate | 10 days | Yes | Usable within 12 months | Line manager |
| Bereavement — extended | 3 days | Yes | No | Line manager |
| Parental — primary | 16 weeks | Yes | Within 12 months of birth/placement | HRBP |
| Parental — secondary | 8 weeks | Yes | Within 12 months of birth/placement | HRBP |
| Marriage | 5 days (eligible jurisdictions) | Yes | No | Line manager |
| Compensatory (G1–G4) | Accrued, max 10 days | Time off | 90 days then lapses | Line manager |
| Sabbatical | Up to 12 weeks | Unpaid or 4 weeks at 50% | No | CHRO |
| Jury / witness | Duration | Yes | No | Line manager |
| Military reserve | Per statute | Top-up to 4 weeks | No | Line manager |
| Volunteering | 2 days | Yes | No | Line manager |
| Study / examination | Per programme | Yes | No | Line manager |
| Unpaid | By approval | No | No | Escalating by duration |
| Mandatory consecutive absence | 2 weeks (control) | Uses annual leave | Not applicable | Cannot be waived |

### Appendix B — Notice and Service Levels

| Request Length | Employee Notice | Manager Decision SLA |
|---|---|---|
| Half day – 2 days | 5 business days | 5 business days |
| 3–5 days | 10 business days | 5 business days |
| 6–15 days | 20 business days | 10 business days |
| Over 15 days | 40 business days | 10 business days |
| Parental leave | 8 weeks | 10 business days |
| Sabbatical | 6 months | 20 business days |
| Emergency, bereavement, sick | None required | Recorded within 24 hours |

### Appendix C — Manager Checklist

Before approving:

1. Is the balance sufficient, including bookings already approved?
2. Is cover arranged, and is the cover person competent and entitled to the required system access?
3. Does the period fall in a declared blackout for this role?
4. Is this employee a sensitive-role holder with mandatory absence still unbooked?
5. Has notice been given per Appendix B?
6. For over 10 days: is a written handover required, and who receives it?
7. For a sensitive-role holder: has Information Security been notified for access suspension?
8. Is my decision recorded in ApexPeople — not agreed verbally or in chat?

Before the employee departs for more than 10 days:

9. Delegated authorities reassigned in ApexServe with an end date (`ANB-ADM-MTX-0001` §15.2).
10. Open approvals, audit actions, and committee obligations reassigned.
11. Out-of-office set with a named alternative contact.

### Appendix D — Jurisdictional Variations at a Glance

| Jurisdiction | Notable Variation from the Apex Standard |
|---|---|
| United States | Apex standard applies; state-specific sick leave accrual laws are honoured where more generous; FMLA runs concurrently with parental leave |
| United Kingdom | 25 days minimum plus 8 bank holidays; statutory sick pay interacts with Bank sick pay; shared parental leave available |
| European Union (Germany, France, Netherlands, Ireland, Spain, Italy, Poland) | Local statutory minimum applies where higher; works council consultation required for any reduction; statutory carry-forward of untaken leave during sickness protected |
| Canada | Provincial minimums; statutory bereavement and family responsibility leave honoured |
| India | 24 days combined earned and casual leave plus public holidays; marriage leave provided; maternity per Maternity Benefit Act where more generous |
| United Arab Emirates | 30 calendar days annual leave; marriage leave provided; end-of-service gratuity unaffected by leave balance |
| Singapore | Apex standard exceeds statutory minima; childcare leave per statute in addition |
| Hong Kong SAR | Apex standard exceeds statutory minima; marriage leave provided |
| Japan | Statutory annual paid leave with mandatory minimum usage; the Bank directs leave where necessary to meet the statutory usage requirement |
| Australia | 20 days annual leave minimum plus personal/carer's leave and long service leave per state |
| Brazil | 30 calendar days annual leave; marriage leave provided; leave must be taken within the statutory concession period |
| Mexico | Statutory vacation entitlement with vacation premium |

Local schedules with full detail are maintained in ApexDocs as child documents of this Policy and are the operative reference for employees of that entity.

---

**End of Document**

`ANB-HRM-POL-0002` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) · Approver: Yvonne Carter, Chief Human Resources Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
