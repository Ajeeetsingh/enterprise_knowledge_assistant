# Apex National Bank — Performance Management Policy

**Human Resources Policy | Objectives, Assessment, Calibration, Promotion, and Talent**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-POL-0006` |
| **Document Title** | Apex National Bank — Performance Management Policy |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) — Talent & Performance |
| **Custodian** | Camille Duforest, Head of Talent & Performance (G8) — `EMP-200107` |
| **Approver** | Yvonne Carter, Chief Human Resources Officer (G11) — `EMP-100008` |
| **Secondary Approvers** | Helena Brandt, Chief Risk Officer (risk-adjustment provisions); Samuel A. Okonkwo, Chief Compliance Officer (conduct provisions) |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-12 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24) |
| **Supersedes** | None — initial published policy |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.2` Reward → Performance & Talent Management → `POL` |
| **Business Process** | `BP-HR-PERF` Performance, Talent & Promotion Management |
| **Governing Body** | Executive Committee; Board Compensation & Human Capital Committee |
| **System of Record** | ApexPeople (objectives, reviews, ratings, talent data) · ApexDocs (this policy) |
| **Keywords** | performance, objectives, ratings, calibration, promotion, PIP, succession, talent review, reward |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0004` · `ANB-HRM-SOP-0007` · `ANB-HRM-POL-0008` · `ANB-ADM-MTX-0001` |

> **Authority.** This Policy governs how performance is set, assessed, calibrated, and consequenced. Reward outcomes derived from ratings are governed by `ANB-HRM-POL-0005`, approved by the Board Compensation & Human Capital Committee. Conduct outcomes that constrain ratings are governed by `ANB-HRM-POL-0004`.

---

## 2. Purpose

Performance management in a bank does two things that a performance system in most industries does not have to do. It must produce a defensible, evidenced assessment of every individual — because pay, promotion, and dismissal decisions are challenged, audited, and in regulated roles reported to supervisors. And it must **risk-adjust**: a result achieved by taking risk outside appetite, breaching a control, or treating a customer unfairly is not a result the Bank will pay for.

This Policy therefore:

1. Sets a single performance year, cycle, and set of milestones for the whole Group.
2. Requires objectives that are specific, measurable, and — for every employee — inclusive of risk, control, and conduct.
3. Assesses **what** was delivered and **how** it was delivered, with the "how" capable of capping the overall outcome.
4. Establishes calibration so that a rating means the same thing in Charlotte as in Singapore.
5. Governs promotion, performance improvement, succession, and talent review with named accountabilities.

---

## 3. Scope

### 3.1 Applies To

All employees of all Apex legal entities at grades G1–G12 who have completed at least three months of service by 31 December of the performance year. Employees with less than three months' service receive a documented check-in and enter the full cycle the following year.

### 3.2 Applies With Modification To

| Population | Modification |
|---|---|
| Employees in probation | Assessed under `ANB-HRM-SOP-0007` §14 until confirmation, then joining the annual cycle |
| Fixed-term employees | Full cycle where the contract spans the year; end-of-contract assessment otherwise |
| Employees on extended leave | Objectives and ratings pro-rated (§9.5) |
| Control function employees (RSK, CMP, IAD, ISC) | Ratings determined independently of the business areas overseen (§6, §10.5) |
| Material Risk Takers | Additional risk adjustment, deferral, malus, and clawback under `ANB-HRM-POL-0005` |
| Registered and certified roles | Rating outcomes feed regulatory fitness and propriety assessments |

### 3.3 Does Not Apply To

Contractors and agency workers, whose performance is managed through the engagement under `ANB-PRC-POL-0002`. Bank managers must not record performance ratings for non-employees in ApexPeople.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Every employee has documented objectives | 100% of eligible employees with objectives in ApexPeople by 31 January |
| O-2 | Every objective set includes risk, control, and conduct | 100% of objective sets containing the mandatory risk and conduct objective |
| O-3 | Assessment is evidenced | 100% of ratings supported by written manager assessment and at least two recorded check-ins |
| O-4 | Ratings are consistent across the Group | Post-calibration distribution within guide bands for each department; cross-department variance reviewed by ExCo |
| O-5 | Underperformance is addressed, not deferred | Zero rating of 1 or 2 issued without a prior documented conversation during the year |
| O-6 | Outcomes are equitable | Annual equity analysis by gender, ethnicity, age, disability, working pattern, and location shows no unexplained differential |
| O-7 | Succession is real | 100% of G9+ positions with at least two identified successors; 90% with a ready-now or ready-in-one-year candidate |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Performance Year** | 1 January to 31 December, aligned to the leave year in `ANB-HRM-POL-0002`. |
| **Objective** | A documented, measurable commitment for the year, recorded in ApexPeople. |
| **Check-In** | A recorded performance conversation held at least quarterly. |
| **Overall Rating** | The single 1–5 rating combining delivery and behaviour. |
| **Delivery Assessment** | Assessment of *what* was achieved against objectives. |
| **Behaviour Assessment** | Assessment of *how* it was achieved, against the Core Values and the Code of Conduct. |
| **Calibration** | The moderated group discussion in which draft ratings are compared and adjusted for consistency. |
| **Risk Adjustment** | Reduction of a rating or reward outcome for risk, control, or conduct failures. |
| **PIP** | Performance Improvement Plan — a formal, time-bound plan to address sustained underperformance. |
| **Talent Review** | The annual assessment of potential, readiness, and succession. |
| **9-Box** | The performance-by-potential grid used in talent review. |
| **Ready Now** | Assessed as capable of taking a named role immediately. |

---

## 6. Roles and Responsibilities

| Role | Responsibility |
|---|---|
| **Employee** | Propose and agree objectives; maintain evidence; participate in check-ins; complete self-assessment; own development; raise concerns about fairness through the defined route. |
| **Line Manager** | Set objectives within 14 days of the cycle opening or of a new joiner starting; hold at least quarterly check-ins; give timely, specific feedback; write an evidenced assessment; attend calibration prepared; deliver ratings personally; address underperformance early. |
| **Department Head (G9–G11)** | Chair departmental calibration; own the departmental distribution; approve promotions within delegated authority; own succession for the department. |
| **Head of Talent & Performance (`EMP-200107` Camille Duforest, G8)** | Own the cycle, the rating framework, calibration standards, talent review, and equity analysis. |
| **HR Business Partner (G6)** | Facilitate calibration; challenge unevidenced ratings; advise on PIPs and disputes; run the equity review for their department. |
| **Head of Reward (`EMP-200104` Stefan Feldman, G8)** | Translate ratings into reward outcomes under `ANB-HRM-POL-0005`. |
| **Head of Learning & Development (`EMP-200106` Hiroshi Tanabe, G8)** | Convert development needs into curriculum and programmes under `ANB-HRM-POL-0008`. |
| **Chief Risk Officer (`EMP-100004` Helena Brandt, G11)** | Provide the risk input to executive and Material Risk Taker assessments; own risk-adjustment criteria. |
| **Chief Compliance Officer (`EMP-100005` Samuel A. Okonkwo, G11)** | Provide conduct input; confirm conduct constraints on ratings. |
| **Head of Employee Relations (`EMP-200105` Grace Mwangi, G8)** | Own the PIP framework and its interface with the disciplinary framework. |
| **Executive Committee** | Review Group-level distribution, executive ratings, and succession. |
| **Board Compensation & Human Capital Committee** | Approve executive performance outcomes, the talent and succession framework, and Material Risk Taker adjustments. |

**Control function independence.** Ratings and reward for employees in Risk, Compliance, Internal Audit, and Information Security are determined within the control function's own reporting line. Business management may contribute observations but has **no vote** on a control function employee's rating (`ANB-ADM-MTX-0001` R-5).

---

## 7. The Performance Cycle

### 7.1 Calendar

| Milestone | Timing | Owner |
|---|---|---|
| Cycle opens; enterprise priorities cascaded | 2 January | Head of Talent & Performance |
| Objectives set and agreed | By 31 January (within 14 days for new joiners) | Employee and Line Manager |
| Q1 check-in | March | Line Manager |
| Mid-year review | June–July | Line Manager |
| Q3 check-in | September | Line Manager |
| Talent review and succession | September–October | Department Head with HRBP |
| Cycle closes | 31 December | — |
| Employee self-assessment | By 15 January following | Employee |
| Manager assessment drafted | By 31 January following | Line Manager |
| Calibration | February | Department Head with HRBP |
| Ratings approved | Late February | Department Head |
| Reward decisions | March | Head of Reward |
| Ratings and reward communicated | March | Line Manager |
| Reward effective | 1 April | Payroll |
| Equity analysis published | April | Head of Talent & Performance |

### 7.2 Continuous Performance

The annual cycle is the record, not the mechanism. Feedback is expected continuously. A minimum of four recorded conversations per year is required; a rating of 2 or below may not be issued at year end unless the concern was raised and recorded during the year (O-5). "It was in the annual review" is not an acceptable answer to "when did you first tell them?".

---

## 8. Standards — Objective Setting

### 8.1 Structure

Every employee has between **four and seven objectives**. Fewer than four is usually too coarse to assess; more than seven is usually a task list. Objectives cascade from the enterprise priorities set by ExCo, through department and team objectives, to the individual.

### 8.2 Mandatory Objectives

| # | Objective | Applies To | Content |
|---|---|---|---|
| M-1 | **Risk and Control** | Every employee | Operating within delegated authority; timely completion of control activities; quality of risk identification and escalation; audit and issue closure; RCSA participation where applicable |
| M-2 | **Conduct and Values** | Every employee | Behaviour against the seven Core Values; Code of Conduct compliance; declaration timeliness; customer fairness where applicable |
| M-3 | **Learning and Certification** | Every employee | On-time completion of the mandatory curriculum and maintenance of role-required certification (`ANB-HRM-POL-0008`) |
| M-4 | **People and Leadership** | Every manager | Team objective completion; check-in cadence; training compliance of the team; team engagement; talent development; diversity and inclusion outcomes |
| M-5 | **Control Function Independence** | Control function employees | Quality and independence of challenge; timeliness of assurance; no dilution of findings under pressure |

M-1, M-2, and M-3 are populated automatically in ApexPeople and cannot be removed.

### 8.3 Objective Quality

Each objective states: what will be achieved; how it will be measured, with a named data source; the deadline; and what "meeting" versus "exceeding" looks like. Objectives that cannot be evidenced from a system, a document, or a named observer are not acceptable.

| Weak | Strong |
|---|---|
| "Improve customer service" | "Reduce branch complaint volume at `SIT-0412` from 34 to below 20 per quarter by Q4, measured in Apex360, without reducing complaints recorded" |
| "Support the AML programme" | "Clear the alert backlog in ApexGuard to under 5 business days average age by 30 June and hold it through Q4, with quality-review pass rate above 95%" |
| "Be a better manager" | "Hold four recorded check-ins with each of my seven reports; achieve 100% team mandatory training completion by due date; close all three open audit actions by 30 September" |
| "Deliver the migration" | "Migrate 14 remaining ApexCore batch interfaces to the new scheduler by 31 October with zero Severity 1 incidents attributable to the migration and CAB approval for every change" |

### 8.4 Changing Objectives

Objectives may be amended mid-year where the business context changes materially — reorganisation, project cancellation, regulatory intervention, extended absence, or role change. Amendments are agreed with the manager, recorded in ApexPeople with a reason and a date, and visible at calibration. Objectives may not be amended retrospectively after the year end.

---

## 9. Standards — Assessment and Ratings

### 9.1 Two Dimensions

Every employee receives a **Delivery** assessment and a **Behaviour** assessment. They combine into a single **Overall Rating**. The Behaviour assessment can cap, but never inflate, the Overall Rating.

### 9.2 Rating Scale

| Rating | Label | Definition | Distribution Guide |
|---|---|---|---|
| **5** | Exceptional | Delivered materially beyond objectives; role-model behaviour; impact visible beyond the immediate team; would be a significant loss to the Bank | 5–10% |
| **4** | Strong | Exceeded on several objectives and met the rest; consistently strong behaviour; a clear contributor above expectation | 20–30% |
| **3** | Effective | Met objectives; behaviour consistent with the values; the standard the Bank hires for and expects. **This is a good rating.** | 50–60% |
| **2** | Developing | Met some objectives but fell short on others, or delivered with behavioural concerns; requires a documented improvement plan | 5–15% |
| **1** | Unsatisfactory | Did not meet objectives, or a serious behavioural or conduct failure; formal action required | 0–5% |

**The distribution is a guide for calibration discussion, not a quota.** A department whose distribution sits materially outside these bands explains why at calibration; a department is never required to place an individual in a band to satisfy a number. Forced ranking is not used.

### 9.3 Behaviour Assessment

Assessed against the seven Core Values from `ANB-ADM-REF-0001` §1.6, each rated Exceeds / Meets / Below with a written example.

| Value | Evidence Looked For |
|---|---|
| Integrity First | Escalated a concern against interest; refused to proceed without documentation; raised bad news early |
| Client Stewardship | Recommended the suitable rather than profitable option; identified and protected a vulnerable customer |
| Disciplined Risk | Documented exceptions properly; identified an emerging risk; owned a limit |
| Operational Excellence | Root-caused rather than patched; met SLA; improved a process measurably |
| Respect and Inclusion | Invited challenge; built an inclusive team; addressed poor behaviour in others |
| Accountability | Owned a decision and its outcome; produced an auditable record; did not deflect |
| Enduring Value | Made a decision that cost short-term but protected the franchise |

### 9.4 Conduct and Risk Constraints

These constraints are mandatory and are applied at calibration, not at the manager's discretion.

| Circumstance | Maximum Overall Rating |
|---|---|
| Live first written warning at 31 December | 3 |
| Live final written warning at 31 December | 2 |
| Substantiated gross misconduct finding during the year | 1 |
| Mandatory training more than 30 days overdue at year end | 3 |
| Mandatory training incomplete at year end | 2 |
| Required certification lapsed and not remediated | 2 |
| Code of Conduct attestation not completed | 2 |
| Sensitive-role mandatory absence not taken without approved exemption | 3 |
| Material risk or control failure attributable to the employee | 2 |
| Substantiated retaliation against a whistleblower | 1, with dismissal considered |
| Objectives achieved through a breach of risk appetite | 2, with reward adjustment |
| Overdue audit action owned by the employee at year end, without agreed extension | 3 |

Where a manager believes a constraint produces an unjust outcome on the facts, they may make the case at calibration; overriding a constraint requires the Department Head and the HRBP jointly, with the reason recorded.

### 9.5 Pro-Rating for Absence

Employees absent for a substantial part of the year on parental leave, long-term sickness, sabbatical, military service, or jury service are assessed on the period worked, against pro-rated objectives. Extended absence must not depress a rating. The HRBP reviews every rating of an employee who was absent for more than 8 weeks, specifically for this risk. A returning employee's rating is compared with their pre-absence trajectory.

### 9.6 Employees Who Change Role Mid-Year

Where an employee changes role or manager during the year, the outgoing manager records a written handover assessment in ApexPeople at the point of change. The year-end rating is owned by the manager holding the relationship at 31 December, using both inputs. An employee who has changed role within the last 8 weeks of the year is rated primarily on the prior role.

---

## 10. Standards — Calibration

### 10.1 Purpose

Calibration exists so that a "4" in Retail Banking means what a "4" means in Risk. It is a moderated discussion in which managers present draft ratings with evidence and peers challenge them.

### 10.2 Structure

| Level | Participants | Chair | Scope |
|---|---|---|---|
| Team calibration | Line managers within a function | Function head (G7–G8) | Their direct reports |
| Departmental calibration | Function heads | Department Head (G9–G11) | The department |
| Business unit calibration | Department Heads | Business Unit Head (G10) | The business unit |
| Group calibration | ExCo members | Group CEO (G12), with CHRO | G9 and above; Group distribution |
| Executive calibration | Board Compensation & Human Capital Committee | Committee Chair | ExCo members and the Group CEO |

The HRBP attends every calibration session and has an explicit mandate to challenge an unevidenced rating, an inconsistent standard, or a pattern that suggests bias.

### 10.3 Rules of Calibration

1. Every rating is presented with evidence. "I just know they're a 4" is not evidence.
2. Ratings move in both directions. A calibration in which no rating moves has not happened.
3. Managers advocate for their people and challenge each other's.
4. The conduct and risk constraints in §9.4 are applied before discussion of distribution.
5. No individual is moved to fit a percentage.
6. Every change is recorded with the reason in ApexPeople.
7. Recency bias, halo effects, proximity bias against remote workers, and similarity bias are named openly and tested for.
8. Employees who were absent for more than 8 weeks are reviewed specifically per §9.5.
9. Discussion is confidential; the outcome is communicated by the line manager, who owns it regardless of whether they argued for it.

### 10.4 Equity Analysis

Before ratings are released, the Head of Talent & Performance runs a distribution analysis by gender, ethnicity, age band, disability status, working pattern (on-site, hybrid, remote), part-time status, location, and grade. Unexplained differentials are investigated with the relevant Department Head and HRBP before release, not afterwards. The analysis is reported to ExCo and to the Board Compensation & Human Capital Committee annually.

### 10.5 Control Function Calibration

Risk, Compliance, Internal Audit, and Information Security employees are calibrated within their own function, chaired by the function's Department Head. Business heads may provide written observations; they do not attend and do not vote. Internal Audit ratings are calibrated by the Chief Audit Executive and reported to the Board Audit Committee.

---

## 11. Standards — Feedback and Communication

### 11.1 Delivering a Rating

Ratings are delivered in person or by video, never by email or system notification alone. The conversation covers: the rating, the evidence, the specific strengths, the specific development areas, and what would change the rating next year. The employee's reaction is recorded factually. The written assessment is available in ApexPeople before the conversation.

### 11.2 Multi-Source Feedback

Employees at G7 and above, and all people managers, receive structured feedback from at least three colleagues outside their reporting line, collected in ApexPeople. Feedback is attributed to the manager but summarised to the employee where anonymity is needed for candour. Multi-source feedback informs the behaviour assessment; it does not determine the rating.

### 11.3 Disagreement

An employee who disagrees with their rating raises it first with the line manager. If unresolved, they may request a review by the Department Head within 10 business days, with the HRBP present. The review examines whether the process was followed, the evidence supports the rating, and the standard was applied consistently — it is not a re-rating. If the employee believes the rating reflects discrimination or retaliation, the matter goes to Employee Relations under `ANB-HRM-POL-0004` §12 and is handled as a protected concern, not a performance dispute.

---

## 12. Standards — Promotion

### 12.1 Principle

Promotion recognises **sustained performance at the next grade**, not tenure, not a retention response, and not a reward for a single good year. The question is not "has this person done well?" but "are they already operating at the next level?".

### 12.2 Eligibility

| Criterion | Requirement |
|---|---|
| Time in grade | Minimum 18 months, except where a role change justifies otherwise |
| Performance | Rating of 4 or 5 in the most recent year and no less than 3 in the year before |
| Conduct | No live warning; no unresolved conduct matter |
| Training | Mandatory curriculum complete; role certifications current |
| Evidence | Demonstrated performance at the next grade for at least two quarters |
| Role | A role exists at the target grade, or the scope of the current role has grown to the next grade level (evidenced by job evaluation) |
| Budget | Funded within the department's approved headcount and reward budget |

### 12.3 Promotion Panels

Promotions to **G7 and above** require a Promotion Panel.

| Element | Standard |
|---|---|
| Composition | Chair at least two grades above the target grade; the Department Head; one independent panel member from another department at the same or higher grade; the HRBP |
| Independence | The proposing manager presents but does not vote |
| Evidence pack | Two years of ratings; the case for promotion against the next-grade competencies; multi-source feedback; conduct and training status; the role and budget confirmation |
| Decision | Recorded with reasons in ApexPeople, whether approved or not |
| Feedback | Unsuccessful candidates receive specific, written development feedback within 5 business days |
| Frequency | Panels convene twice yearly, in March and September, aligned to the reward cycle |
| Equity | Panel outcomes are analysed for demographic differentials by the Head of Talent & Performance |

Promotions to G4–G6 are approved by the Department Head with HRBP endorsement, without a panel. Promotions to G10 and above require Group CEO approval; promotions into the Executive Committee require Board Compensation & Human Capital Committee approval (`ANB-ADM-MTX-0001` §13).

### 12.4 Regulated and Control Roles

Promotion into a registered, certified, or approved role requires: Compliance confirmation of fitness and propriety; completion of role certification before or within a defined period of taking the role; re-screening under `ANB-HRM-SOP-0007` §10.5; and regulatory notification or approval where required. The promotion does not take effect until these are complete.

### 12.5 Lateral Moves and Internal Mobility

Employees are encouraged to move between departments. An employee with 18 months in role and a rating of 3 or above may apply for any internal vacancy without their manager's consent, and managers must not obstruct internal moves — obstruction is a leadership failure assessed under M-4. The releasing manager is entitled to a reasonable transition period, normally 8 weeks. Internal candidates are considered before external candidates under `ANB-HRM-SOP-0007` §9.1.

---

## 13. Standards — Performance Improvement Plans

### 13.1 When a PIP Is Used

A PIP is used where performance is sustained below the standard of the grade and informal feedback has not resolved it. It is a genuine attempt to restore performance, not a procedural step towards dismissal. Where the issue is conduct rather than capability, the disciplinary framework in `ANB-HRM-POL-0004` §14 applies instead — the two must not be confused or combined.

### 13.2 Preconditions

A PIP may not be started unless: the specific shortfall has been raised and recorded at least twice previously; the employee has had a genuine opportunity to improve; capability rather than conduct, health, disability, or workload is the cause; and the HRBP has reviewed and endorsed the case. Where health, disability, or a caring responsibility may be contributing, Occupational Health assessment and reasonable adjustments come first.

### 13.3 Content

| Element | Requirement |
|---|---|
| Duration | Normally 60 days at G1–G6; 90 days at G7 and above |
| Objectives | Three to five specific, measurable, achievable improvements with dated milestones |
| Standard | What "met" looks like, stated unambiguously |
| Support | Named coach or mentor; specific training assigned in ApexLearn; workload adjustment where relevant; increased manager time |
| Reviews | Fortnightly, recorded in ApexPeople |
| Consequences | Stated at the outset in writing: successful completion, extension, redeployment, or termination of employment |
| Representation | The employee may be accompanied at PIP review meetings |
| Remote working | Remote eligibility suspended for the PIP duration (`ANB-HRM-POL-0003` §7.5) |

### 13.4 Outcomes

| Outcome | Consequence |
|---|---|
| Improvement achieved and sustained | PIP closed; employee returns to normal management; a 6-month sustained-performance watch applies; remote eligibility restored |
| Partial improvement | One extension of up to 30 days, approved by the Department Head and HRBP; no second extension |
| No improvement | Redeployment considered where a suitable role exists; otherwise termination for capability, approved per §13.5 |
| Improvement achieved then lost within 12 months | Return directly to the final stage; no repeat of the full PIP |

### 13.5 Termination for Capability

Requires: a completed PIP with documented reviews; HRBP and Employment Legal review; consideration of redeployment; Department Head (G9–G11) approval, with the CHRO informed; and, where local law provides, statutory process, notice, and appeal rights. Termination for capability is distinct from termination for conduct and produces a different regulatory reference.

---

## 14. Standards — Talent Review and Succession

### 14.1 Annual Talent Review

Held September–October, chaired by the Department Head with the HRBP, covering every employee at G6 and above and all identified high-potential employees below G6.

### 14.2 The 9-Box

Performance (last two years) is plotted against potential (assessed capacity to operate two grades higher within five years).

| | **Low Potential** | **Medium Potential** | **High Potential** |
|---|---|---|---|
| **High Performance** | Trusted Professional — retain, reward, deepen expertise | Growth Talent — stretch assignment, broaden scope | Future Leader — accelerate, protect, plan succession |
| **Medium Performance** | Solid Contributor — sustain, targeted development | Core Talent — develop, expand responsibility | Emerging Talent — invest, test with a stretch role |
| **Low Performance** | Action Required — PIP or redeployment | Development Case — diagnose cause, coach, re-test | Misplaced Talent — likely wrong role; redeploy before concluding |

Potential is assessed on learning agility, capacity for complexity, breadth of judgment, and behavioural range — not on ambition, visibility, or similarity to the assessor.

### 14.3 Succession Planning

| Requirement | Standard |
|---|---|
| Coverage | Every G9 and above position, every ExCo position, and every position designated business-critical |
| Depth | At least two identified successors per position; at least one ready now or ready within one year |
| Categories | Ready now · Ready 1–2 years · Ready 3–5 years |
| Emergency cover | A named interim for every ExCo and business-critical position, tested annually |
| Review | Departmental plans reviewed by ExCo annually; ExCo and Group CEO succession reviewed by the Board Compensation & Human Capital Committee annually |
| Diversity | Succession slates must be diverse; a slate without diversity is returned for widening, not approved with a note |
| Regulated roles | Successors for approved and controlled functions confirmed as fit and proper by Compliance in advance |
| Key-person risk | Positions with no viable successor are recorded as an operational risk and reported to the Operational Risk Committee |

### 14.4 High-Potential Programmes

Identified talent enters development programmes owned by Learning & Development under `ANB-HRM-POL-0008` §12: the Emerging Leaders Programme (G5–G6), the Leadership Development Programme (G7–G8), and the Executive Development Programme (G9–G10), supplemented by cross-departmental rotations, board and committee exposure, and external coaching. Identification is reviewed annually and is not permanent; being identified creates no entitlement, and not being identified is not a ceiling.

---

## 15. Standards — Reward Linkage

Reward outcomes are governed by `ANB-HRM-POL-0005`. This Policy establishes the inputs.

| Rating | Typical Reward Consequence |
|---|---|
| 5 — Exceptional | Top-quartile variable pay; salary review priority; promotion and talent consideration |
| 4 — Strong | Above-median variable pay; salary review consideration |
| 3 — Effective | Median variable pay; salary review per market and position in range |
| 2 — Developing | Materially reduced or nil variable pay; no salary increase; PIP or improvement plan |
| 1 — Unsatisfactory | Nil variable pay; formal action |

Additional rules: variable pay is funded from an enterprise pool approved by ExCo and ratified by the Board Compensation & Human Capital Committee, and is risk-adjusted before distribution; control function reward is determined independently of business outcomes; Material Risk Taker awards are subject to deferral, malus, and clawback; and a conduct finding after award but relating to the performance period triggers malus or clawback assessment by the Board Compensation & Human Capital Committee.

---

## 16. Process Flow

### 16.1 Annual Cycle

```
JAN                     JUN–JUL            SEP–OCT           JAN(+1)        FEB           MAR
 │                          │                  │                 │            │             │
 ├─ Enterprise priorities   │                  │                 │            │             │
 ├─ Objectives set ────────►│                  │                 │            │             │
 │  (incl. M-1 risk,        ├─ Mid-year review │                 │            │             │
 │   M-2 conduct,           │  Objectives      │                 │            │             │
 │   M-3 learning,          │  reconfirmed     │                 │            │             │
 │   M-4 people)            │                  ├─ Talent review  │            │             │
 │                          │                  │  9-box,         │            │             │
 ├─ Q1 check-in             │                  │  succession     │            │             │
 │                          │                  ├─ Q3 check-in    │            │             │
 │                          │                  │                 ├─ Self-     │             │
 │                          │                  │                 │  assessment│             │
 │                          │                  │                 ├─ Manager   │             │
 │                          │                  │                 │  assessment│             │
 │                          │                  │                 │            ├─ Conduct &  │
 │                          │                  │                 │            │  risk caps  │
 │                          │                  │                 │            ├─ CALIBRATION│
 │                          │                  │                 │            ├─ Equity     │
 │                          │                  │                 │            │  analysis   │
 │                          │                  │                 │            │             ├─ Reward
 │                          │                  │                 │            │             ├─ Communicate
 └──────────────────────────────────────────────────────────────────────────────────────────┴─ 1 Apr effective
```

### 16.2 Promotion Panel

```
Manager proposes ──► HRBP eligibility check (§12.2) ──► Evidence pack assembled
                              │
                        Not eligible ──► Written feedback; development plan
                              │
                          Eligible
                              │
                     G4–G6: Dept Head + HRBP approve
                     G7+:   PROMOTION PANEL
                              │
                     ┌────────┴────────┐
                  APPROVE           DECLINE
                     │                 │
              Regulated role?     Written development
                     │             feedback in 5 days
              Compliance F&P,          │
              certification,      Re-application eligible
              re-screening        after 12 months or on
                     │            evidenced change
              Effective date;
              recorded in ApexPeople
```

### 16.3 PIP

```
Sustained underperformance
        │
        ├─ Documented informal feedback × 2 (recorded in ApexPeople)
        ├─ HRBP review: capability, not conduct/health/workload?
        │      └─ Health or disability indicated ──► Occupational Health, adjustments first
        │      └─ Conduct indicated ─────────────► ANB-HRM-POL-0004 §14 instead
        │
        ├─ PIP issued in writing: objectives, standard, support, duration, consequences
        ├─ Remote eligibility suspended
        ├─ Fortnightly reviews recorded
        │
        └─ Outcome ──► Met: close, 6-month watch, restore eligibility
                   ──► Partial: one extension ≤30 days (Dept Head + HRBP)
                   ──► Not met: redeployment considered ──► termination for capability
                                (Dept Head approval; CHRO informed; Legal review)
```

---

## 17. Decision Tables

### 17.1 Approval Authority

| Decision | Approver | Second | Reference |
|---|---|---|---|
| Objective set for an individual | Line manager | — | §8 |
| Mid-year objective amendment | Line manager | HRBP if material | §8.4 |
| Draft rating | Line manager | — | §9 |
| Final rating G1–G8 | Department Head at calibration | HRBP endorsement | §10.2 |
| Final rating G9+ | Group calibration; Group CEO | CHRO | §10.2 |
| ExCo ratings | Board Compensation & Human Capital Committee | — | `ANB-ADM-MTX-0001` §13 |
| Override of a §9.4 conduct constraint | Department Head (G9) | HRBP (G6) | §9.4 |
| Promotion G2–G6 | Department Head (G9) | HRBP | §12.3 |
| Promotion G7–G9 | Promotion Panel | Department Head | §12.3 |
| Promotion G10+ | Group CEO (G12) | CHRO | `ANB-ADM-MTX-0001` §13 |
| Promotion into ExCo | Board Compensation & Human Capital Committee | Board | `ANB-ADM-MTX-0001` §13 |
| PIP issue | Line manager | HRBP (G6) endorsement mandatory | §13.2 |
| PIP extension | Department Head (G9) | HRBP | §13.4 |
| Termination for capability | Department Head (G9–G11) | Employment Legal; CHRO informed | §13.5 |
| Succession plan for a department | Department Head (G9) | CHRO | §14.3 |
| ExCo and CEO succession | Board Compensation & Human Capital Committee | Board | §14.3 |
| High-potential identification | Department Head at talent review | Head of Talent & Performance | §14.4 |
| Rating review request outcome | Department Head (G9) | HRBP present | §11.3 |

### 17.2 Scenario Table

| Scenario | Outcome |
|---|---|
| Employee exceeded every objective but has a live final written warning | Overall rating capped at 2 (§9.4). Delivery is recorded as strong; the cap is explained in the conversation. |
| Employee delivered a record year in Corporate Banking but breached credit approval authority twice | Rating capped at 2 for a material control failure; reward adjusted; authority reviewed. |
| Employee was on parental leave from March to September | Objectives pro-rated to the period worked; HRBP reviews the rating specifically for absence bias (§9.5). |
| Manager wants to rate a report 2 without having raised it during the year | Not permitted (O-5). Rating stands at 3; the manager's own M-4 objective is affected. |
| Department presents 40% at rating 4 | Explained at calibration with evidence. Not automatically reduced, but tested rigorously against peer departments. |
| Employee moved from Compliance to Retail Banking in October | Rated primarily on the Compliance role using the outgoing manager's handover assessment (§9.6). |
| Business head wants a Risk Manager's rating reduced for "being difficult" about a limit | Rejected. Business heads have no vote on control function ratings (§10.5); the approach is itself escalated as a potential independence concern. |
| High performer with a rating of 5 has 14 months in grade | Not eligible for promotion (§12.2). Alternative recognition through reward and a stretch assignment. |
| Promotion panel slate for a G8 role contains no women | Slate returned for widening before the panel convenes (§14.3). |
| Employee on a PIP asks to keep two remote days | Remote eligibility is suspended for the PIP duration (`ANB-HRM-POL-0003` §7.5). |
| Employee alleges their rating dropped after they reported a colleague to Compliance | Handled by Employee Relations as a protected concern under `ANB-HRM-POL-0004` §12, not as a rating dispute. |
| Employee's certification lapsed in November, remediated in December | Cap of 2 applies unless remediated before year end; here it was, so the constraint does not bite, but it is noted at calibration. |

---

## 18. Approval Matrix — Policy Governance

| Action | Author | Reviewers | Approver | Notification |
|---|---|---|---|---|
| Policy Major version | Head of Talent & Performance (G8) | CRO, CCO, CAE, Employee Relations, Employment Legal, works councils where applicable | CHRO (G11) | ExCo; Board Compensation & Human Capital Committee |
| Policy Minor version | Head of Talent & Performance | Employment Legal | HR Director (G9) | All managers |
| Rating scale or distribution guide change | Head of Talent & Performance | Reward, Risk, Compliance | CHRO | Board Compensation & Human Capital Committee |
| Conduct and risk constraint change (§9.4) | Head of Employee Relations (G8) | Risk, Compliance | CHRO **and** CCO | ExCo |
| Reward linkage change | Head of Reward (G8) | Finance, Risk | CHRO **and** CFO | Board Compensation & Human Capital Committee |
| Promotion panel composition change | Head of Talent & Performance | HRBPs | HR Director (G9) | Department Heads |
| Succession framework change | Head of Talent & Performance | ExCo | CHRO | Board Compensation & Human Capital Committee |
| PIP framework change | Head of Employee Relations | Employment Legal | HR Director (G9) | All managers |

---

## 19. Records and Retention

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Objectives and amendments | `PRF-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Check-in records | `PRF-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Self-assessment and manager assessment | `PRF-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Multi-source feedback | `PRF-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Calibration record and rating changes | `PRF-########` | ApexPeople | C2 | `RET-HRM-7Y` |
| Equity analysis | Annual | ApexInsight, ApexDocs | C2 | `RET-HRM-7Y` |
| Promotion panel pack and decision | `CAS-########` | ApexPeople, ApexDocs | C2 | `RET-HRM-7Y` |
| PIP and review records | `CAS-########` | ApexPeople | C3 | `RET-HRM-7Y` |
| Termination for capability file | `CAS-########` | ApexPeople, ApexDocs | C3 | `RET-HRM-7Y` |
| Talent review and 9-box placement | `EMP-######` | ApexPeople | C3 | `RET-HRM-7Y` |
| Succession plan | Departmental | ApexPeople, ApexDocs | C3 | `RET-HRM-7Y` |
| Rating review request and outcome | `CAS-########` | ApexPeople | C2 | `RET-HRM-7Y` |

Naming follows `ANB-HRM-HBK-0001` Appendix B — for example `HRPR_PRF-20260112_AnnualReview-FY26_20270131_C2.pdf`.

---

## 20. Examples

### 20.1 Objective Set — Branch Manager

`EMP-300103` Amara Okoye (G5, Branch Manager, `SIT-0412`), FY2026.

| # | Objective | Measure | Source |
|---|---|---|---|
| 1 | Grow primary banking relationships at the branch | Net new primary relationships ≥ 340 for the year | Apex360 |
| 2 | Improve complaint outcomes without suppressing recording | Complaints resolved at first contact ≥ 72%; recorded volume within ±10% of prior year | Apex360, ApexServe |
| 3 | Zero cash differences above tolerance | No unexplained difference above $200; all differences reported same day | ApexTeller, ApexCore |
| M-1 | Risk and control | Vault dual control 100%; branch RCSA completed by 30 September; all three open branch audit actions closed by 31 October; mandatory consecutive absence taken | ApexRisk, ApexAudit, ApexPeople |
| M-2 | Conduct and values | Code attestation complete; conflicts declared; no substantiated sales-practice concern; evidence of vulnerable-customer protection | ApexLearn, ApexServe |
| M-3 | Learning and certification | Personal mandatory curriculum complete by due date | ApexLearn |
| M-4 | People and leadership | Four recorded check-ins per report; team mandatory training 100% on time; engagement score improvement of 5 points | ApexPeople, ApexLearn |

**Outcome.** Objectives 1 and 3 exceeded; objective 2 met; M-1 met except one audit action closed 12 days late with an agreed extension; M-4 met with team training at 100%. Draft rating 4. At calibration, the branch's complaint recording is checked against the pattern in `ANB-HRM-POL-0004` §20.2 and found genuine. Rating confirmed at 4.

### 20.2 Calibration Adjustment

At Retail Banking departmental calibration chaired by `EMP-100014` Gregory Lin with HRBP `EMP-200201` Fiona Gallagher:

| Employee | Draft | Final | Reason Recorded |
|---|---|---|---|
| Branch Manager A | 5 | 4 | Strong results but scope smaller than peer 5s; evidence did not support enterprise-level impact |
| `EMP-300105` Lucia Marchetti | 3 | 4 | Manager under-rated; evidence of sustained referral quality and two vulnerable-customer escalations handled exceptionally |
| Branch Manager B | 4 | 3 | Mandatory training completed 41 days late — §9.4 cap applies |
| Operations Lead C | 3 | 2 | Material control failure attributable to the individual — §9.4 cap applies |
| `EMP-300106` Jamal Robertson | 3 | 3 | Confirmed; strong first full year |

Group distribution after adjustment sits within the guide bands. Two managers were challenged on evidence quality; the Head of Talent & Performance records this for the manager-capability programme.

### 20.3 PIP That Worked

`EMP-300202` Michael Thornton's team includes a dispute analyst whose case closure quality has been below standard for two quarters, raised in the Q2 and Q3 check-ins.

| Stage | Detail |
|---|---|
| Pre-check | HRBP confirms capability, not conduct; no health issue; workload within team norm |
| Day 0 | 60-day PIP issued: three objectives with weekly quality thresholds; a named mentor; two ApexLearn modules assigned; remote eligibility suspended |
| Day 14, 28, 42 | Reviews recorded; quality improving from 71% to 88% against a 92% threshold |
| Day 60 | Threshold met for the final three weeks; PIP closed successfully |
| Day 60 + 6 months | Sustained-performance watch completed; remote eligibility restored at day 60 |
| Year end | Rating 3; the PIP is recorded but does not itself cap the rating, because performance was restored |

### 20.4 Succession Gap

Talent review for Compliance identifies that the Head of Financial Crime position (`EMP-400101` Adeline Mercier, G9) has one successor ready in 1–2 years and none ready now. Emergency cover would fall to `EMP-400102` Robert Kinsella, who is not yet assessed as ready.

Actions: the position is recorded as a key-person risk and reported to the Operational Risk Committee; Mr Kinsella enters the Leadership Development Programme with a defined readiness plan; an external market map is commissioned by Talent Acquisition without opening a vacancy; and the succession slate is widened at the next review. The gap is closed, not noted.

---

## 21. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Core Values; grade structure; committees |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Performance summary; canonical employee register |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Pro-rating for extended leave; sabbatical eligibility |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Expense conduct feeding behaviour assessment |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | PIP suspends remote eligibility; proximity bias; output-based supervision |
| `ANB-HRM-POL-0004` | Code of Conduct | `02_human_resources/005_CODE_OF_CONDUCT.md` | Conduct constraints on ratings; disciplinary boundary with PIP |
| `ANB-HRM-SOP-0007` | Recruitment SOP | `02_human_resources/007_RECRUITMENT_STANDARD_OPERATING_PROCEDURE.md` | Probation assessment; internal mobility; re-screening on promotion |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | M-3 objective; leadership programmes; certification caps |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Promotion and termination authorities; control function independence |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | `RET-HRM-7Y` |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.2` classification |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | `HRPR` record naming |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-PERF` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Board Compensation & Human Capital Committee; ORC |
| `ANB-HRM-POL-0005` | Compensation & Incentive Governance Policy | *(planned)* | Reward, deferral, malus, clawback |

---

## 22. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review and re-approval | Head of Talent & Performance | Annually by 31 July |
| Post-cycle review | Cycle effectiveness, calibration quality, manager capability gaps | Head of Talent & Performance | Annually in May |
| Equity differential identified | Investigation and remediation before ratings release | HRBP with Department Head | Within the cycle |
| Regulatory change on remuneration or accountability | Targeted amendment | Head of Reward with Compliance | 30 days |
| Material rise in rating disputes or grievances | Root cause review | Head of Employee Relations | 60 days |
| Succession coverage below target | Departmental remediation plan | Department Head with CHRO | Next talent review |

Next scheduled review: **2027-07-24**.

---

## 23. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-12 | Talent & Performance | Initial draft; cycle and rating scale defined | — |
| 0.3 | 2026-06-28 | Talent & Performance | Mandatory risk, conduct, and learning objectives added following Risk and Compliance review | — |
| 0.5 | 2026-07-07 | Talent & Performance | Conduct and risk constraint table added; control function independence made explicit | — |
| 0.7 | 2026-07-15 | Talent & Performance | Calibration rules, equity analysis, and bias controls added | — |
| 0.9 | 2026-07-21 | Talent & Performance | PIP framework separated clearly from the disciplinary framework after Employment Legal review | — |
| 1.0 | 2026-07-24 | Talent & Performance | First published version | Y. Carter |

---

## 24. Appendices

### Appendix A — Manager Calendar

| Month | Action |
|---|---|
| January | Set objectives with every report by 31 January; include M-1 to M-4 |
| March | Q1 check-in, recorded |
| June–July | Mid-year review; reconfirm or amend objectives |
| September | Q3 check-in; prepare talent review inputs |
| October | Attend talent review; contribute to succession slates |
| December | Gather evidence; flag any likely rating of 2 or below to the HRBP **before** year end |
| January (+1) | Read self-assessments; write evidenced assessments by 31 January |
| February | Attend calibration prepared with evidence for every rating |
| March | Deliver every rating in person; deliver reward; agree next-year objectives |

### Appendix B — Employee Guide

| Question | Answer |
|---|---|
| How many objectives should I have? | Four to seven, including the mandatory risk, conduct, and learning objectives. |
| Is a 3 a bad rating? | No. A 3 means you did the job you were hired to do, well. Most people are a 3. |
| Can my rating change after my manager tells me their view? | Yes — calibration can move it in either direction. Your manager owns the final outcome and will explain it. |
| Can my behaviour cap my rating even if I hit every number? | Yes. See §9.4. |
| I was on parental leave for six months — will that hurt me? | It must not. Objectives are pro-rated and the HRBP reviews your rating specifically for this. |
| I disagree with my rating. What can I do? | Raise it with your manager, then request a Department Head review within 10 business days (§11.3). |
| I think my rating is retaliation for a report I made. | That is a protected concern. Go to Employee Relations or the Ethics Line, not the rating dispute route. |
| When can I be promoted? | 18 months in grade, a 4 or 5 last year, and evidence you are already operating at the next level (§12.2). |
| What is a PIP really for? | Restoring performance. It is not a formality before dismissal, and it is not used for conduct issues. |
| Does remote working affect my rating? | It must not. The data is analysed for exactly that (§10.4). |

### Appendix C — Calibration Pack Contents

For each employee: current grade and time in grade; objectives and outcomes with evidence source; delivery assessment; behaviour assessment with an example against each value; multi-source feedback summary where applicable; mandatory training and certification status; conduct and warning status; audit action status; mandatory absence status; absence during the year exceeding 8 weeks; prior two years' ratings; draft rating with a one-paragraph rationale.

For the group: draft distribution against guide bands; distribution by gender, ethnicity, age band, disability status, working pattern, part-time status, and location; prior-year distribution for comparison; list of employees where a §9.4 constraint applies.

### Appendix D — Rating Definitions in Full

**5 — Exceptional.** Delivered materially beyond every objective, or transformed an outcome that was not expected to be achievable. Behaviour is a reference point for others. Impact is visible beyond the immediate team and recognised by peers outside it. The Bank would take a real capability loss if this person left.

**4 — Strong.** Exceeded several objectives and met the remainder. Handled complexity or ambiguity that the role did not strictly require. Behaviour consistently strong, with at least one clear example of values-led judgment under pressure. Recognised by peers as a strong performer.

**3 — Effective.** Met objectives. Behaviour consistent with the values. Reliable, competent, trusted. **This is the rating the Bank hires for and the rating most people should receive.** It is not a warning, a plateau, or a disappointment.

**2 — Developing.** Fell short on material objectives, or delivered results with behavioural concerns, or is new to a materially expanded role and not yet at the standard. Requires a documented improvement plan. Not a dismissal signal by itself, but not sustainable across two years.

**1 — Unsatisfactory.** Did not meet objectives despite support, or a serious behavioural or conduct failure occurred. Formal action follows: PIP for capability, the disciplinary framework for conduct.

---

**End of Document**

`ANB-HRM-POL-0006` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) · Approver: Yvonne Carter, Chief Human Resources Officer · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
