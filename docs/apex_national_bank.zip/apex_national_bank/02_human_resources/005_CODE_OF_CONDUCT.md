# Apex National Bank — Code of Conduct

**Enterprise Policy | Ethical Standards, Conflicts, Market Conduct, and the Disciplinary Framework**

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-HRM-POL-0004` |
| **Document Title** | Apex National Bank — Code of Conduct |
| **Version** | 1.0 |
| **Owner** | Human Resources Department (HRM) with Legal (LEG) |
| **Joint Owner** | Compliance (CMP) for regulated conduct provisions |
| **Custodian** | Grace Mwangi, Head of Employee Relations (G8) — `EMP-200105` |
| **Approver** | Marcus D. Whitfield, Group Chief Executive Officer (G12) — `EMP-100001` |
| **Secondary Approvers** | Yvonne Carter, CHRO; Margaret Sullivan, General Counsel; Samuel A. Okonkwo, Chief Compliance Officer |
| **Ratified By** | Board of Directors, on the recommendation of the Public Responsibility & Compliance Committee |
| **Status** | Approved — Published |
| **Classification** | Internal (C1) |
| **Created Date** | 2026-06-10 |
| **Effective Date** | 2026-08-01 |
| **Last Updated** | 2026-07-24 |
| **Review Cycle** | Annual (next review 2027-07-24) |
| **Supersedes** | None — initial published Code |
| **Retention** | `RET-POL-10Y` — Policies and Standards |
| **Record Class** | Policies and Standards |
| **Taxonomy** | `T7` People & Workplace → `T7.4` Conduct → Code of Conduct → `POL` |
| **Business Process** | `BP-HR-COND` Conduct, Grievance & Disciplinary Management |
| **Governing Body** | Board of Directors; Public Responsibility & Compliance Committee; Executive Committee |
| **System of Record** | ApexDocs (this Code) · ApexLearn (attestation) · ApexServe (declarations and cases) |
| **Keywords** | code of conduct, ethics, integrity, conflicts of interest, insider trading, personal account dealing, anti-bribery, whistleblower, social media, outside employment, discipline |
| **Related Documents** | `ANB-ADM-REF-0001` · `ANB-HRM-HBK-0001` · `ANB-HRM-POL-0002` · `ANB-FIN-POL-0002` · `ANB-HRM-POL-0003` · `ANB-HRM-POL-0006` · `ANB-HRM-SOP-0007` · `ANB-HRM-POL-0008` · `ANB-ADM-MTX-0001` · `ANB-ADM-POL-0001` |

> **Standing.** This Code is the Bank's most senior conduct instrument. It applies to every person who acts for Apex National Bank. Where any other Bank document conflicts with this Code on a matter of ethics or conduct, **this Code prevails**. It is approved by the Group CEO and ratified by the Board.

---

## 2. Purpose

A bank holds other people's money and other people's confidences. Nothing in a control framework survives the absence of individual integrity — controls are designed by people, operated by people, and, when they fail, defeated by people.

This Code states, in one place, the standard of behaviour expected of every person acting for Apex National Bank. It exists to:

1. Make the ethical standard **explicit** rather than assumed.
2. Establish the **declarations and pre-clearances** that convert an unmanaged conflict into a managed one.
3. Set the **market conduct rules** — insider information, personal dealing, information barriers — that carry criminal as well as employment consequences.
4. Guarantee **protection for those who speak up**, without which no code operates.
5. Define the **disciplinary framework** so that consequence is proportionate, consistent, and evidenced.

---

## 3. Scope

### 3.1 Applies To

| Population | Coverage |
|---|---|
| All employees, all grades G1–G12, all Apex legal entities | Full, with annual attestation |
| Members of the Board of Directors | Full, with a supplementary Directors' Code administered by the Corporate Secretary |
| Contractors, agency workers, and vendor personnel with Bank access | Sections 6–13 in full, contracted through `ANB-PRC-POL-0002` |
| Secondees, interns, and apprentices | Full |
| Third parties acting on the Bank's behalf — introducers, agents, outsourced providers | Sections 6, 7, 9, and 12 through contractual flow-down |

### 3.2 Territorial Reach

This Code applies to conduct wherever it occurs — on Bank premises, at home under `ANB-HRM-POL-0003`, while travelling under `ANB-FIN-POL-0002`, at Bank and industry events, and on any channel. Where local law is stricter than this Code, local law applies. Where local practice is more permissive, **this Code applies**. That the conduct is customary in a market is never a defence.

### 3.3 Personal Life

The Bank does not regulate private life. It does regulate conduct in private life that creates a conflict, damages the Bank's standing, or bears on fitness to perform a regulated role — including criminal charges, financial difficulty in roles with financial authority, undeclared outside activity, and public conduct that would reasonably be understood as reflecting on the Bank.

---

## 4. Objectives

| # | Objective | Measure |
|---|---|---|
| O-1 | Every individual knows the standard | 100% annual attestation; no exceptions permitted |
| O-2 | Conflicts are declared, not discovered | Conflict declaration completion ≥ 99%; conflicts identified by audit rather than declaration < 5 per year |
| O-3 | Market conduct rules are followed | Zero unpre-cleared personal trades by covered persons; zero information-barrier breaches |
| O-4 | Speaking up is safe | Zero substantiated retaliation cases; Ethics Line volume monitored as a health indicator, not suppressed |
| O-5 | Discipline is consistent | Outcome consistency reviewed quarterly by Employee Relations; appeal overturn rate < 15% |
| O-6 | Bribery risk is eliminated | Zero facilitation payments; 100% pre-clearance of public-official interactions |

---

## 5. Definitions

| Term | Definition |
|---|---|
| **Covered Person** | An employee designated as subject to enhanced personal account dealing rules — front office, Research, Corporate Finance, Treasury & Markets, Compliance, Internal Audit, Risk, Finance with earnings access, and all G9 and above. |
| **MNPI** | Material Non-Public Information — information a reasonable investor would consider important to an investment decision, not generally available. |
| **Restricted List** | Securities on which the Bank possesses MNPI or has a conflicting engagement; personal and proprietary dealing prohibited. |
| **Watch List** | Confidential list of engagements monitored by Compliance; not disclosed to staff. |
| **Information Barrier** | Organisational and physical separation preventing MNPI passing from a private side to a public side. |
| **Wall Crossing** | The controlled, Compliance-approved process of bringing a public-side individual over an information barrier. |
| **Public Official** | Any officer or employee of a government, government agency, state-owned enterprise, public international organisation, or political party, and any candidate for public office. |
| **Facilitation Payment** | A small payment to a public official to secure or expedite a routine action to which the payer is already entitled. |
| **Outside Business Activity (OBA)** | Any employment, directorship, consultancy, trusteeship, or business interest outside the Bank. |
| **Protected Disclosure** | A report of suspected wrongdoing that attracts whistleblower protection under this Code and applicable law. |
| **Gross Misconduct** | Conduct so serious that it destroys the employment relationship, justifying dismissal without notice. |

---

## 6. Confidentiality and Information

### 6.1 The Obligation

Every employee owes a duty of confidence to the Bank, to its customers, and to its employees. Information is disclosed only to those with a legitimate need to know and a right to receive it. The duty **survives the end of employment indefinitely**.

### 6.2 Specific Rules

| Rule | Detail |
|---|---|
| Need to know | Access to customer or employee data is permitted only for a task the employee is performing. Curiosity is not a business purpose. Looking up a celebrity, a neighbour, a colleague, a family member, or one's own account outside a work task is a serious breach. |
| Classification | All information is handled per its classification C0–C3 (`ANB-ADM-STD-0006`, `ANB-ISC-STD-0004`). |
| Systems of record | Bank information resides in approved systems. Personal cloud storage, personal email, personal messaging, and unapproved AI tools are prohibited for any Bank information (`ANB-ADM-POL-0001` §10.3). |
| Removal on departure | Taking customer lists, pricing, models, pipeline data, code, or documents on leaving is theft of Bank property and is pursued civilly and, where appropriate, criminally. |
| Discussion in public | No discussion of customers, transactions, or Bank matters in lifts, trains, restaurants, aircraft, or online. |
| Media and analysts | Only authorised spokespersons speak for the Bank. All media enquiries go to Marketing; all analyst and investor enquiries go to Investor Relations; all regulatory enquiries go to Compliance or Legal. |
| Regulatory and legal requests | Never respond directly. Route immediately to Legal and Compliance. Never destroy, alter, or conceal a document that may be relevant, whether or not a legal hold has been issued (`ANB-ADM-POL-0001` §12). |
| Data privacy | Personal data is processed lawfully, minimally, and only for the stated purpose, under GDPR, GLBA, and equivalent regimes. |
| Colleagues' data | Pay, performance, health, and personal circumstances of colleagues obtained through a Bank system may never be disclosed. |

### 6.3 Artificial Intelligence and Generative Tools

Bank information may be entered only into AI tools approved by the Chief Data Officer and Information Security and listed in the approved tooling register. Entering customer data, employee data, or Confidential Bank information into a public AI service is a data breach and is treated as such. AI-generated output used in Bank work must be reviewed by the employee, who remains accountable for its accuracy.

---

## 7. Integrity, Fair Treatment, and Respect

### 7.1 Honesty

Employees deal honestly with customers, colleagues, counterparties, auditors, and regulators. Specifically: no false or misleading statement in any Bank record, report, or communication; no backdating; no creation of a document to give a false impression of when a decision was taken; no concealment of an error, loss, or breach; and no misrepresentation of qualifications, experience, or performance.

### 7.2 Fair Treatment of Customers

| Principle | Application |
|---|---|
| Suitability before sale | Recommend the suitable product, not the profitable one. Where a customer is better served by a cheaper or competitor product, say so. |
| Clarity | Fees, rates, risks, and material terms are explained in plain language before commitment. |
| No pressure | No selling technique that exploits urgency, confusion, or fear. |
| Vulnerability | Where a customer appears vulnerable through age, health, bereavement, language, or financial distress, additional care applies and the interaction is escalated where necessary. |
| No unauthorised accounts | No account, product, or service may be opened, modified, or closed without the customer's informed consent. This is absolute and is gross misconduct. |
| Complaints | Complaints are recorded, never discouraged, and never resolved by informal payment outside the process. |
| Fair lending | Credit decisions are made on the merits. Discrimination on any protected characteristic is unlawful and is gross misconduct. |

### 7.3 Respect at Work

Harassment, bullying, discrimination, victimisation, and retaliation are prohibited without qualification. This includes conduct based on race, colour, ethnicity, national origin, religion or belief, sex, gender identity or expression, sexual orientation, age, disability, pregnancy, maternity, marital or civil partnership status, veteran status, genetic information, or any other characteristic protected by applicable law.

It also includes: sexual harassment in any form; persistent criticism or humiliation, including in front of others; exclusion or isolation used as a management technique; abuse of authority, including pressure to breach policy; unwanted physical contact; and offensive material shared in any channel, including private group chats on Bank systems.

**Managers carry additional accountability.** A manager who witnesses or is told of such conduct and does not act has themselves breached this Code.

### 7.4 Substance Use and Fitness for Duty

Employees must be fit to perform their duties. Being under the influence of alcohol or drugs at work, or impaired by them, is misconduct. In cash-handling, trading, driving, and safety-sensitive roles, it is gross misconduct. Alcohol at Bank events is permitted in moderation; the conduct standard applies at Bank events exactly as it does in the office. Employees taking prescribed medication that may impair performance should tell Occupational Health, not their manager, so an adjustment can be made. An employee who comes forward with a dependency issue before it causes harm is supported through the Employee Assistance Programme; the support route is not available once misconduct has occurred.

---

## 8. Conflicts of Interest

### 8.1 Principle

A conflict of interest is not misconduct. **Failing to declare one is.** The Bank's expectation is disclosure, so that a conflict can be managed, restricted, or avoided.

### 8.2 What Must Be Declared

| Category | Examples |
|---|---|
| Personal relationships at work | A reporting line, hiring decision, performance rating, or pay decision involving a family member, partner, or close personal relationship |
| Relationships with counterparties | A family member or partner employed by a customer, competitor, supplier, regulator, or audit firm |
| Financial interests | An ownership interest in a customer, supplier, competitor, or a company the Bank is evaluating |
| Outside business activities | Any directorship, employment, consultancy, or business — see §11 |
| Board and trustee positions | Including charities, schools, industry bodies, and homeowners' associations |
| Political activity and public office | Candidacy, appointment, or significant political fundraising |
| Personal borrowing or investment | Borrowing from or lending to a customer, supplier, or subordinate |
| Business opportunities | Any opportunity discovered through Bank work that the employee might pursue personally |
| Procurement involvement | Any relationship with a bidder in a sourcing process the employee influences |
| Cohabitation | Sharing a home office or residence with someone employed by a competitor, regulator, customer, or supplier (`ANB-HRM-POL-0003` §11.2) |

### 8.3 Declaration Requirements

Declared in ApexServe at onboarding, annually at the Code attestation, and **within 5 business days** of any new or changed circumstance. The declaration is assessed by the HRBP with Compliance, and the outcome — permit, permit with conditions, restrict, or prohibit — is recorded with the reason.

### 8.4 Standing Rules

- No employee may participate in a hiring, performance, pay, promotion, or disciplinary decision affecting a family member, partner, or close personal relationship.
- No employee may have a family member or partner in their direct or indirect reporting line. Where this arises, the reporting line is changed, not the declaration deferred.
- No employee may approve, underwrite, price, or influence a credit, account, or fee decision affecting themselves, a family member, or a person reporting to them.
- No employee may take a business opportunity discovered through Bank work for personal benefit.
- No employee may participate in a procurement decision involving a supplier in which they, or a family member, hold an interest.

---

## 9. Anti-Bribery, Corruption, Gifts, and Entertainment

### 9.1 Zero Tolerance

The Bank prohibits bribery and corruption absolutely, in every jurisdiction, in every form, whether given or received, whether direct or through an intermediary. This reflects the US Foreign Corrupt Practices Act, the UK Bribery Act, and equivalent legislation, all of which have extraterritorial reach.

**Facilitation payments are prohibited without exception**, including where they are lawful or customary locally. An employee facing a demand for one refuses, pays nothing, protects their personal safety first, and reports to Compliance immediately. Where personal safety requires a payment, the employee pays, leaves, and reports it at the first safe opportunity — such a payment is a safety response, not a policy breach, provided it is reported.

### 9.2 Gifts and Entertainment Thresholds

| Situation | Requirement |
|---|---|
| Gift received, under $100 | Permitted; record in the Gifts & Entertainment Register in ApexServe |
| Gift received, $100–$250 | Line manager approval **and** register entry |
| Gift received, above $250 | Refuse, return, or — where refusal would cause offence — surrender to the Bank for charitable donation; Compliance approval and register entry |
| Cash or cash equivalents (including gift cards) | **Never permitted**, in any amount, given or received |
| Entertainment received, under $250 per head | Permitted; register entry; the host must be present |
| Entertainment received, $250–$500 per head | Line manager approval and register entry |
| Entertainment received, above $500 per head | G9 approval and Compliance pre-clearance |
| Entertainment offered | As above, plus expense approval under `ANB-FIN-POL-0002` §15.2 and `ANB-ADM-MTX-0001` §7.2 |
| Anything to or from a **public official**, any value | General Counsel **and** Chief Compliance Officer pre-approval, without exception |
| Travel or accommodation paid by a third party | Prohibited unless pre-approved by Compliance; the Bank normally pays its own way |
| Anything during a live tender, credit decision, or regulatory matter | Prohibited |
| Charitable donation at a customer's request | Treated as entertainment; Compliance pre-clearance |
| Political contribution using Bank funds or in the Bank's name | Prohibited without General Counsel approval |

**The test.** Would a reasonable outsider — a journalist, a regulator, a customer who was not offered the same — consider this capable of influencing a business decision? If yes, refuse it. Frequency matters as much as value: repeated small hospitality from the same source is a pattern and must be declared.

### 9.3 Third Parties

Introducers, agents, consultants, and outsourced providers acting for the Bank are subject to anti-bribery due diligence at onboarding under `ANB-PRC-POL-0002` and to contractual flow-down of this section. An employee who suspects an intermediary is making improper payments must report it to Compliance immediately. The Bank is liable for the acts of those acting on its behalf.

---

## 10. Market Conduct, Insider Information, and Personal Dealing

### 10.1 Insider Information

An employee in possession of MNPI must not: trade in the affected securities; recommend or induce another to trade; or disclose the information to anyone without a legitimate business need — including a spouse, family member, or friend. This applies to information about Apex National Bank itself, about customers, and about counterparties.

Insider dealing and unlawful disclosure are **criminal offences**. Employment consequences are additional to, not instead of, criminal liability.

### 10.2 Information Barriers

The Bank maintains information barriers between private-side activity (Corporate & Investment Banking, Corporate Finance, Research where applicable) and public-side activity (Treasury & Markets, sales, and trading). Employees must not: seek information from the other side; discuss deal information outside the deal team; leave deal material visible or unattended; use deal code names inconsistently; or attempt to infer deal activity from observed behaviour. Crossing the barrier requires a documented **wall crossing** approved and recorded by Compliance. Physical and system access follow the barrier.

### 10.3 Personal Account Dealing

| Rule | Application |
|---|---|
| Registration | Covered Persons register all personal accounts — including accounts of a spouse, partner, dependants, and any account over which they have influence — with Compliance in ApexServe within 10 business days of joining or of opening the account |
| Pre-clearance | Covered Persons obtain pre-clearance for every transaction in a single-name security, valid for the trading day of approval only |
| Restricted List | No dealing in any security on the Restricted List, personally or for the Bank's account |
| Apex securities | Employees may deal in Apex National Bank securities only in open windows announced by the Corporate Secretary after results, and never while holding MNPI |
| Minimum holding period | 30 calendar days for single-name securities; short-term speculation is not consistent with employment at the Bank |
| Prohibited instruments | Short selling; derivatives on Apex securities; spread betting on financial instruments; hedging of unvested Apex awards |
| Duplicate confirmations | Covered Persons arrange for duplicate contract notes and statements to be provided to Compliance |
| Exempt instruments | Diversified collective investment schemes over which the employee has no investment discretion, government securities, and cash deposits are exempt from pre-clearance |
| Surveillance | Personal dealing is monitored by Compliance in ApexWatch against the Restricted and Watch Lists |

### 10.4 Market Abuse

Prohibited absolutely: market manipulation of any kind, including layering, spoofing, wash trades, and marking the close; benchmark manipulation; front-running customer orders; misuse of customer order information; false or misleading market communications; and improper coordination with competitors on pricing, terms, or market allocation.

### 10.5 Communications

Regulated communications occur only on recorded, approved channels. Using personal phones, personal messaging applications, or auto-deleting messaging for Bank business is a serious breach — enforcement action against peer institutions in this area has been substantial and the Bank's position is absolute. Employees must not disable recording, use unapproved channels because a system is inconvenient, or take a conversation "offline" to avoid a record.

---

## 11. Outside Employment and Activities

### 11.1 Pre-Approval Required

Any outside business activity requires **written pre-approval** through ApexServe, assessed by the HRBP and Compliance. Approval is recorded with any conditions and reviewed annually at attestation.

### 11.2 Assessment Criteria

Whether the activity conflicts with the Bank's interests; whether it involves a customer, competitor, supplier, or regulator; whether it uses Bank time, information, systems, or resources; whether the time commitment affects performance or creates fatigue risk; whether it creates a regulatory or reputational exposure; and whether it would create an appearance of endorsement by the Bank.

### 11.3 Never Permitted

Employment or engagement by a competing financial institution; any role that would use Bank confidential information; any activity involving a customer where the employee has a decision-making role over that customer; providing personal financial, tax, or legal advice for a fee where it could be confused with Bank advice; acting as an executor, trustee, or attorney for a customer other than a family member; accepting a bequest from a customer other than a family member; and any second role that materially impairs the employee's capacity to perform their Apex role.

### 11.4 Generally Permitted with Declaration

Non-executive directorships of non-competing, non-customer entities; charity trusteeships and school governorships; teaching and academic appointments; writing, speaking, and publishing on non-Bank subjects; family businesses in unrelated sectors; and passive investment.

### 11.5 Political Activity

Personal political participation is a private matter. Employees must not use Bank resources, time, or name for political activity; must make clear that personal political views are personal; and must declare candidacy for or appointment to public office, which is assessed for conflict. Political contributions by the Bank, or in its name, require General Counsel approval and are subject to pay-to-play restrictions where the Bank provides services to a public entity.

---

## 12. Speaking Up and Whistleblower Protection

### 12.1 The Obligation to Report

Every employee has a **duty** to report suspected breaches of law, regulation, this Code, or Bank policy. Silence in the face of known wrongdoing is itself a breach. This includes suspected fraud, financial crime, market abuse, mis-selling, accounting irregularity, bribery, discrimination, harassment, data breach, safety risk, and any attempt to conceal any of these.

### 12.2 Channels

| Channel | Use |
|---|---|
| Line manager | The normal first route for most concerns |
| Skip-level manager or Department Head | Where the concern involves the line manager |
| HR Business Partner | Employment and behavioural concerns |
| Head of Employee Relations (`EMP-200105` Grace Mwangi) | Serious behavioural and conduct concerns |
| Compliance (`EMP-100005` Samuel A. Okonkwo, or the business-aligned officer) | Regulatory, financial crime, and market conduct concerns |
| Risk, Legal, or Internal Audit | Any concern within their remit |
| **Ethics Line** | Confidential, 24×7, independent third-party operated, available in all operating languages, anonymous where local law permits |
| Direct to the Board | Serious concerns about senior management may be raised with the Chair of the Board Audit Committee or the Public Responsibility & Compliance Committee |
| Regulator | Nothing in this Code, in any employment contract, or in any settlement agreement prevents an employee from reporting to a regulator or law enforcement, or from receiving a statutory whistleblower award |

Employees at any grade may escalate directly to Compliance, Risk, or Internal Audit **without line-manager consent** (`ANB-ADM-REF-0001` §1.7).

### 12.3 Protection

**Retaliation against anyone who raises a concern in good faith is gross misconduct and is a terminable offence.** Retaliation includes dismissal, demotion, exclusion, rating reduction, reassignment, denial of opportunity, ostracism, and informal pressure.

Protection applies where the concern is raised in good faith, whether or not it is ultimately substantiated. It does not protect a knowingly false report made maliciously, which is itself misconduct. Protection extends to those who assist an investigation and to those who refuse to participate in wrongdoing.

### 12.4 How Reports Are Handled

Acknowledged within 2 business days. Triaged by Employee Relations, Compliance, or Internal Audit according to subject matter. Assigned to an investigator with no involvement in or reporting relationship to the matter. Confidentiality maintained to the fullest extent consistent with a fair investigation. The reporter is told the outcome to the extent lawful. Anonymous reports are investigated on their merits. Substantiated matters are reported to the Public Responsibility & Compliance Committee; whistleblowing volume, themes, and outcomes are reported to the Board Audit Committee quarterly and are treated as a culture indicator — a fall in reports is examined, not celebrated.

---

## 13. Social Media and Public Communication

| Rule | Detail |
|---|---|
| Speaking for the Bank | Only authorised spokespersons. Employees must not state or imply that a personal view is the Bank's. |
| Identification | Employees who identify their employer on a public profile must include a clear personal-views disclaimer and must meet the professional standard in everything they post. |
| Confidentiality | No customer information, transaction information, non-public financial information, internal document, screenshot, or photograph of a workspace. |
| Live matters | No commentary on live litigation, regulatory matters, incidents, or investigations involving the Bank. |
| Customer contact | Never conduct Bank business, respond to a complaint, or discuss an account on social media. Route to the official channel. |
| Colleagues and customers | No content that would breach §7.3 if said in the office. A private group chat on a Bank system is not private. |
| Competitors | No disparagement of competitors, their products, or their staff. |
| Endorsements | No endorsement of a product, supplier, or investment in a way that implies Bank backing. |
| Recruitment | Only Talent Acquisition posts vacancies officially; employee sharing of official posts is encouraged. |
| Market-sensitive periods | No posting about Apex financial performance outside official disclosure; closed-period rules apply. |
| Personal accounts | The Bank does not monitor personal accounts, but publicly available conduct that breaches this Code is actionable. |

---

## 14. Disciplinary Framework

### 14.1 Principles

Discipline is corrective before it is punitive; proportionate to the conduct, the role, and the impact; consistent across comparable cases, tested quarterly by Employee Relations; evidenced, with reasons recorded; and fair, with the employee heard before a decision.

### 14.2 Categories

**Misconduct** — conduct falling short of the standard but not destroying the employment relationship. Examples: failure to complete mandatory training after reminders; repeated lateness or unnotified absence; failure to declare a conflict promptly; minor expense policy breaches; unprofessional communication; failure to follow a documented procedure without loss; unauthorised remote working days.

**Serious Misconduct** — conduct causing material risk, loss, or breach. Examples: unauthorised access to customer or employee data; breach of personal account dealing pre-clearance; using an unapproved communication channel for regulated business; unapproved cross-border working creating tax or regulatory exposure; failure to escalate a known error or breach; approving beyond delegated authority; bullying or discriminatory conduct.

**Gross Misconduct** — conduct destroying the employment relationship, justifying dismissal without notice. Examples: theft, fraud, or falsification of records, including expense fraud; insider dealing or unlawful disclosure of MNPI; bribery or acceptance of a bribe; opening or altering a customer account without consent; deliberate concealment of a loss, error, or breach; **retaliation against a whistleblower**; sexual harassment or violence; deliberate destruction of records subject to legal hold; deliberate circumvention of a control or of an information barrier; serious breach of customer confidentiality; being unfit for duty in a safety-sensitive role; false attestation to this Code; and misleading an auditor, investigator, or regulator.

### 14.3 Sanctions

| Sanction | Application | Live Period | Additional Consequence |
|---|---|---|---|
| Informal counselling and file note | Minor, first instance | 12 months | None |
| First written warning | Misconduct | 12 months | Performance rating impact; may affect variable pay |
| Final written warning | Serious misconduct, or repetition during a live warning | 24 months | Variable pay impact; promotion ineligibility; remote eligibility review |
| Demotion or role change | Where capability or authority is the issue | Permanent | Grade and pay adjusted |
| Withdrawal of authority | Where delegated authority was misused | As specified | Recorded in ApexServe |
| Variable pay adjustment, malus, or clawback | Where conduct affected results or risk | Per award terms | Applies to Material Risk Takers under `ANB-HRM-POL-0005` |
| Dismissal with notice | Serious misconduct not warranting summary dismissal | — | Regulatory reference reflects the facts |
| Summary dismissal | Gross misconduct | — | No notice; regulatory notification where required; referral to law enforcement where appropriate |

Sanctions may combine. A conduct outcome caps the year-end performance rating per `ANB-HRM-POL-0006` §9.4.

### 14.4 Procedural Safeguards

The employee is told the allegations in writing, with the evidence relied on, before any hearing, with reasonable time to prepare. The employee may be accompanied by a colleague or, where local law provides, a trade union or legal representative. Suspension is a neutral act on full pay, used only where continued attendance would prejudice an investigation or pose a risk, reviewed every 10 business days. The decision-maker is not the investigator. The outcome is given in writing with reasons. The employee may appeal within 10 business days to a manager senior to and not previously involved in the decision; the appeal outcome is final internally. Where the employee is a member of a works council jurisdiction or covered by a collective agreement, the applicable procedure applies in addition.

### 14.5 Regulatory Consequences

Conduct outcomes for individuals in registered, certified, or approved roles are notified to the relevant regulator where required, are reflected in regulatory references given to future employers, and may affect fitness and propriety assessments. Employees must not agree with the Bank to conceal a conduct outcome from a regulator; any such agreement is void.

---

## 15. Investigation Protocol

| Stage | Standard |
|---|---|
| Receipt | Logged in ApexServe as a `CAS-########` case, classified Confidential (C2) or Restricted (C3) |
| Triage | Within 2 business days by Employee Relations, with Compliance for regulated conduct and Internal Audit for fraud |
| Preservation | Legal hold applied immediately where litigation or regulatory action is foreseeable (`ANB-ADM-POL-0001` §12); no deletion of any potentially relevant record |
| Independence | Investigator has no involvement in the matter and no reporting relationship to any party |
| Scope | Written terms of reference agreed at the outset |
| Interviews | Recorded in writing; the subject is interviewed before any conclusion; notes shared with the interviewee for comment |
| Evidence | System evidence obtained through Information Security and Compliance under a documented request; no informal access to another employee's mailbox or files |
| Standard of proof | Balance of probabilities |
| Duration | Target 30 business days; extension approved and communicated |
| Report | Findings, evidence, and recommendation to the decision-maker; the investigator does not decide the sanction |
| Records | Retained under `RET-HRM-7Y`; investigation reports classified C3 |
| Reporting | Substantiated serious matters to the Public Responsibility & Compliance Committee; fraud to the Financial Crime Committee; control failures to the Operational Risk Committee |

Managers must never investigate a conduct allegation themselves. They escalate to Employee Relations.

---

## 16. Attestation

| Requirement | Detail |
|---|---|
| On joining | Attestation within 14 days, before or during the first week of duties |
| Annually | During the annual Code attestation window, delivered in ApexLearn |
| On material amendment | Re-attestation where a Major version changes obligations |
| Content | Confirmation that the individual has read and understood the Code, has declared all conflicts and outside activities, has complied during the period, and knows how to report a concern |
| Non-completion | Escalation to the Department Head at 10 business days overdue; system access restriction at 20 business days; treated as misconduct at 30 business days |
| Evidence | Attestation records held in ApexLearn, retained under `RET-TRN-5Y`, and produced to regulators and auditors on request |
| Coverage | 100% is the only acceptable outcome. No exceptions are granted; long-term absentees attest on return. |

---

## 17. Decision Tables

### 17.1 Gift and Entertainment Decisions

| Situation | Decision |
|---|---|
| Customer sends a $60 hamper at year end | Accept; record in the register |
| Customer offers a $180 dinner, host present | Accept; line manager approval; record |
| Supplier offers tickets worth $600 to a sporting event, no host present | Refuse — this is a gift, not entertainment, and exceeds the limit |
| Supplier offers the same tickets during a live tender | Refuse absolutely; report to Procurement and Compliance |
| A public official's office offers a $40 desk ornament | Requires General Counsel and CCO approval regardless of value |
| Customer offers a $50 gift card | Refuse — cash equivalents are never permitted |
| Customer invites the relationship manager and spouse to a weekend abroad | Refuse; report to Compliance |
| Customer offers a charitable donation in the employee's name | Treated as entertainment; Compliance pre-clearance |
| The same customer buys lunch weekly | Declare the pattern even though each instance is below threshold |

### 17.2 Conflict Decisions

| Situation | Outcome |
|---|---|
| Employee's sibling joins a supplier the employee manages | Declare within 5 days; supplier relationship reassigned |
| Employee begins a relationship with a direct report | Declare immediately; reporting line changed |
| Employee's partner works for the Bank's external auditor | Declare; Compliance assesses independence; likely restriction on audit-related work |
| Employee wants to sit on the board of a local charity that banks with Apex | Declare; usually approved with a condition that the employee takes no part in the charity's banking relationship |
| Employee is offered a paid consultancy by a customer | Refuse; §11.3 |
| Employee inherits shares in a competitor | Declare; usually permitted as passive, with a dealing restriction |
| Employee is named executor by a long-standing customer | Refuse unless a family member; §11.3 |
| Employee applies for an Apex mortgage | Permitted; no involvement in own underwriting; file marked for enhanced review (`ANB-HRM-HBK-0001` §10.2) |

### 17.3 Sanction Guidance

| Conduct | Typical First Outcome |
|---|---|
| Mandatory training 45 days overdue after reminders | First written warning |
| Expense claim for a personal dinner, self-corrected before review | Informal counselling and repayment |
| Expense claim for a fabricated dinner | Summary dismissal — fraud |
| Looking up a colleague's account out of curiosity | Final written warning; dismissal where data was shared |
| Trading a Restricted List security without pre-clearance | Final written warning at minimum; dismissal and regulatory notification where MNPI was held |
| Discussing a live deal outside the deal team | Serious misconduct; final written warning; wall-crossing review |
| Working four days from another country without clearance, self-reported | Informal counselling and remediation; no sanction where prompt and genuine |
| The same, concealed and discovered by Tax | Final written warning or dismissal depending on exposure created |
| Manager reduces a whistleblower's rating after a report | Summary dismissal |
| Failing to declare a partner working for a competitor, discovered by audit | Final written warning; access restriction |
| Shouting at a colleague in an open-plan area, first instance | First written warning; behavioural coaching |
| Repeated belittling of a team member over months | Serious misconduct; final written warning or dismissal for a manager |

Guidance only. Every case is assessed on its facts, the employee's record, the role held, and the impact.

---

## 18. Approval Matrix

| Action | Author | Reviewers | Approver | Ratification |
|---|---|---|---|---|
| Code Major version | Head of Employee Relations (G8) | CHRO, General Counsel, CCO, CRO, works councils where applicable | Group CEO (G12) | Board of Directors |
| Code Minor version | Head of Employee Relations | General Counsel, CCO | CHRO (G11) | Public Responsibility & Compliance Committee (noting) |
| Gift and entertainment threshold change | Chief Compliance Officer (G11) | Finance, Legal | CCO **and** CHRO | ExCo |
| Personal dealing rule change | Chief Compliance Officer | Legal, Internal Audit | CCO | Public Responsibility & Compliance Committee |
| Covered Person designation change | Head of Markets Compliance (G8) | HR Operations | CCO | — |
| Public official interaction | Requester | Compliance | General Counsel **and** CCO | `ANB-ADM-MTX-0001` §7.2 |
| Outside business activity approval | Employee | HRBP, Compliance | Department Head (G9) | — |
| Conflict outcome — restrict or prohibit | HRBP (G6) | Compliance | Department Head (G9) | — |
| First / final written warning | Line manager with HRBP | Employee Relations | Department Head (G9) | — |
| Dismissal for conduct | HRBP (G6) | Legal, Compliance | Department Head (G9–G11) | CHRO informed (`ANB-ADM-MTX-0001` §13) |
| Dismissal of a G9+ employee | Head of Employee Relations | Legal, Compliance | CHRO (G11) **and** Group CEO | Board Compensation & Human Capital Committee |
| Malus or clawback application | Head of Reward (G8) | Risk, Compliance, Legal | Board Compensation & Human Capital Committee | Board |
| Whistleblower case outcome | Investigator | Employee Relations, Legal | CCO for regulatory matters; CHRO for employment matters | Public Responsibility & Compliance Committee |

---

## 19. Records and Retention

| Record | Identifier | System | Classification | Retention |
|---|---|---|---|---|
| Code attestation | `EMP-######` | ApexLearn | C1 | `RET-TRN-5Y` |
| Conflict of interest declaration and outcome | `CAS-########` | ApexServe | C2 | `RET-HRM-7Y` |
| Outside business activity approval | `CAS-########` | ApexServe | C2 | `RET-HRM-7Y` |
| Gifts & Entertainment Register entry | `CAS-########` | ApexServe | C2 | `RET-HRM-7Y` |
| Public official pre-approval | `CAS-########` | ApexServe, ApexDocs | C2 | `RET-AML-5Y` |
| Personal account dealing pre-clearance | `EMP-######` | ApexServe, ApexWatch | C2 | `RET-HRM-7Y` |
| Wall crossing record | `CAS-########` | ApexWatch | C3 | `RET-HRM-7Y` |
| Conduct investigation file | `CAS-########` | ApexServe, ApexDocs | C3 | `RET-HRM-7Y` |
| Disciplinary outcome and appeal | `CAS-########` | ApexPeople, ApexDocs | C3 | `RET-HRM-7Y` |
| Whistleblower report and outcome | `CAS-########` | Ethics Line platform, ApexDocs | C3 | `RET-HRM-7Y` |
| Regulatory reference given | `EMP-######` | ApexDocs | C2 | `RET-HRM-7Y` |

Naming follows `ANB-HRM-HBK-0001` Appendix B — for example `HRCD_CAS-00714290_InvestigationReport_20261118_C3.pdf`.

---

## 20. Examples

### 20.1 Undeclared Conflict Discovered by Audit

`EMP-600401` Ethan Brookfield (G8, Head of Category Management) has run a sourcing process for a technology supplier. Internal Audit's routine testing identifies that his spouse became a senior employee of the winning bidder four months before award; no declaration exists.

| Step | Action |
|---|---|
| Detection | `EMP-400302` Sean Fitzpatrick raises the finding through `BP-AUD-ENG` |
| Case opened | `CAS-` raised by Employee Relations; classified C3 |
| Preservation | Sourcing file, evaluation scores, and correspondence preserved in ApexDocs; legal hold applied |
| Investigation | Independent investigator appointed with no PRC reporting line; scoring reviewed for influence |
| Findings | No evidence the outcome was influenced; the failure to declare was a material omission over four months |
| Outcome | Final written warning for serious misconduct; removal from the supplier relationship; award re-validated by an independent panel; annual variable pay reduced |
| Reporting | Reported to the Operational Risk Committee as a control failure; sourcing controls amended to require a declaration refresh at shortlist stage |

Had the evidence shown influence on the award, the outcome would have been dismissal.

### 20.2 Whistleblower Report and Retaliation

An analyst reports through the Ethics Line that a manager is instructing the team to hold complaints out of the complaints register until month end to improve reported metrics.

| Step | Action |
|---|---|
| Day 0 | Report received anonymously; acknowledged through the platform within 2 business days |
| Day 2 | Triaged jointly by Employee Relations and Compliance; Internal Audit engaged for data testing |
| Day 5 | Complaint register data tested; the pattern is confirmed |
| Day 12 | Manager interviewed; admits the practice, describes it as "managing the queue" |
| Day 18 | Findings: deliberate misstatement of a regulatory metric — gross misconduct |
| Day 22 | Manager summarily dismissed; regulatory notification made; complaint data restated |
| Day 30 | Reported to the Public Responsibility & Compliance Committee and the Board Audit Committee |
| Day 45 | Two team members who assisted the investigation are moved off a project by an acting manager. Employee Relations investigates this separately as suspected retaliation; the acting manager receives a final written warning and the assignments are restored |

The second investigation is the point: retaliation is pursued as its own offence, whether or not the original report was substantiated.

### 20.3 Personal Dealing Breach

A Covered Person in Corporate Banking buys shares in a listed company without pre-clearance. The company is on the Restricted List because Apex is advising on a transaction, although the employee was not on the deal team and held no MNPI.

Compliance surveillance in ApexWatch identifies the trade from duplicate confirmations within 3 business days. The employee is required to unwind the position, surrender any profit to charity, and bear any loss personally. Because no MNPI was held, the outcome is a final written warning rather than dismissal, with pre-clearance training reassigned and a 12-month enhanced monitoring period. Had the employee held MNPI, the matter would have been referred to the regulator and to law enforcement.

---

## 21. Related Documents

| Document ID | Title | File | Relationship |
|---|---|---|---|
| `ANB-ADM-REF-0001` | Master Company Profile | `00_foundation/COMPANY_PROFILE.md` | Values, culture, speak-up, Three Lines of Defence |
| `ANB-HRM-HBK-0001` | Employee Handbook | `02_human_resources/001_EMPLOYEE_HANDBOOK.md` | Conduct summary; disciplinary summary; employee register |
| `ANB-HRM-POL-0002` | Leave Policy | `02_human_resources/002_LEAVE_POLICY.md` | Falsified leave; absence during investigation |
| `ANB-FIN-POL-0002` | Travel Policy | `02_human_resources/003_TRAVEL_POLICY.md` | Entertainment, facilitation payments, loyalty points, expense fraud |
| `ANB-HRM-POL-0003` | Remote Work Policy | `02_human_resources/004_REMOTE_WORK_POLICY.md` | Confidentiality at home; recorded channels; cohabitation conflicts |
| `ANB-HRM-POL-0006` | Performance Management Policy | `02_human_resources/006_PERFORMANCE_MANAGEMENT_POLICY.md` | Conduct caps ratings; behaviour assessment |
| `ANB-HRM-SOP-0007` | Recruitment SOP | `02_human_resources/007_RECRUITMENT_STANDARD_OPERATING_PROCEDURE.md` | Screening, references, conflicts at hire |
| `ANB-HRM-POL-0008` | Training & Certification Policy | `02_human_resources/008_TRAINING_AND_CERTIFICATION_POLICY.md` | Code attestation delivery; AML and anti-bribery curriculum |
| `ANB-ADM-MTX-0001` | Approval Authority Matrix | `01_enterprise_governance/006_APPROVAL_AUTHORITY_MATRIX.md` | Public official approvals; termination authorities |
| `ANB-ADM-POL-0001` | Records Retention Policy | `01_enterprise_governance/005_RECORDS_RETENTION_POLICY.md` | Legal hold; prohibition on destruction; `RET-HRM-7Y` |
| `ANB-ADM-STD-0006` | Enterprise Knowledge Taxonomy | `01_enterprise_governance/003_KNOWLEDGE_TAXONOMY.md` | `T7.4` Conduct; classification C0–C3 |
| `ANB-ADM-STD-0007` | Document Naming and Versioning Standard | `01_enterprise_governance/004_DOCUMENT_NAMING_AND_VERSIONING_STANDARD.md` | `HRCD` case naming |
| `ANB-ADM-GDL-0001` | Business Process Classification Guide | `01_enterprise_governance/008_BUSINESS_PROCESS_CLASSIFICATION_GUIDE.md` | `BP-HR-COND` |
| `ANB-LEG-REF-0003` | Enterprise Committee Charter | `01_enterprise_governance/007_ENTERPRISE_COMMITTEE_CHARTER.md` | Public Responsibility & Compliance Committee; Financial Crime Committee |
| `ANB-HRM-POL-0005` | Compensation & Incentive Governance Policy | *(planned)* | Malus and clawback |
| `ANB-CMP-POL-0005` | Sanctions & OFAC Screening Policy | *(planned)* | Sanctioned-jurisdiction restrictions |
| `ANB-CMP-SOP-0007` | Personal Account Dealing Procedure | *(planned)* | Operational pre-clearance detail |
| `ANB-CMP-POL-0008` | Communications Surveillance Policy | *(planned)* | Monitoring of regulated communications |
| `ANB-CMP-POL-0009` | Whistleblowing Policy | *(planned)* | Ethics Line operating detail |
| `ANB-CMP-POL-0010` | Anti-Bribery & Corruption Policy | *(planned)* | Detailed ABC controls |
| `ANB-PRC-POL-0002` | Third-Party Risk Management Policy | *(planned)* | Contractual flow-down to third parties |

---

## 22. Review Cycle

| Trigger | Action | Owner | Timeframe |
|---|---|---|---|
| Annual review | Full review, Board ratification, re-attestation | Head of Employee Relations | Annually by 31 July |
| Regulatory enforcement action against a peer institution in a covered area | Gap assessment against the Code | Compliance with Employee Relations | 60 days |
| Change in bribery, market abuse, or whistleblowing legislation | Targeted amendment | General Counsel | 30 days |
| Substantiated retaliation case | Root cause review and reporting to the Board | Head of Employee Relations | 30 days |
| Quarterly consistency review of disciplinary outcomes | Analysis by conduct type, grade, department, and protected characteristic | Head of Employee Relations | Quarterly |
| Culture survey or exit interview themes indicating suppressed reporting | Investigate and report to ExCo | CHRO | Next cycle |

Next scheduled review: **2027-07-24**.

---

## 23. Revision History

| Version | Date | Author | Summary | Approver |
|---|---|---|---|---|
| 0.1 | 2026-06-10 | Employee Relations | Initial draft from `ANB-ADM-REF-0001` §1.6–§1.7 and §6 Code of Conduct scope | — |
| 0.3 | 2026-06-26 | Employee Relations | Market conduct, information barriers, and personal dealing sections added by Compliance | — |
| 0.5 | 2026-07-06 | Employee Relations | Anti-bribery thresholds and public official rules added; FCPA and UK Bribery Act alignment confirmed by Legal | — |
| 0.7 | 2026-07-14 | Employee Relations | Whistleblower protection strengthened; direct-to-Board and direct-to-regulator routes made explicit | — |
| 0.9 | 2026-07-21 | Employee Relations | Disciplinary framework and investigation protocol finalised after works council and union consultation | — |
| 1.0 | 2026-07-24 | Employee Relations | First published version; ratified by the Board | M. D. Whitfield |

---

## 24. Appendices

### Appendix A — The Ten Standing Rules

1. **Say it, or it did not happen.** Every material decision is written down, with a named owner and a reason.
2. **Declare, do not decide.** A conflict you disclose is managed. A conflict you assess yourself is a breach.
3. **Need to know means need.** Curiosity is not a business purpose.
4. **Nothing in cash.** No cash, no cash equivalents, no gift cards — given or received, any amount.
5. **Public officials are different.** Anything of value, any value, needs the General Counsel and the CCO.
6. **Never on an unrecorded channel.** If it is Bank business, it happens where the Bank can see it.
7. **Do not trade on what you know.** If you would not want the regulator to see the timing, do not place the order.
8. **Escalate early.** The error is recoverable. The concealment is not.
9. **Retaliation ends a career.** Not the reporter's — yours.
10. **Local practice is not a defence.** This Code travels with you.

### Appendix B — Annual Attestation Content

The attestation in ApexLearn requires confirmation that the individual:

1. Has read and understood the Code of Conduct in its current version.
2. Has complied with the Code throughout the attestation period.
3. Has declared all conflicts of interest, including personal relationships, financial interests, and cohabitation arrangements within scope of §8.2.
4. Has declared all outside business activities, directorships, trusteeships, and public offices, and holds current approval for each.
5. Has recorded all gifts and entertainment given or received above the register threshold.
6. Has, where a Covered Person, registered all personal accounts and obtained pre-clearance for every transaction requiring it.
7. Has not used any unapproved communication channel for Bank business.
8. Is not aware of any breach of the Code by any person that they have not reported.
9. Understands the reporting channels available, including the Ethics Line and the direct route to the Board.
10. Understands that a false attestation is gross misconduct.

### Appendix C — Reporting Routes at a Glance

| Concern | Route |
|---|---|
| Something feels wrong but you are not sure | Line manager, or the Ethics Line if you prefer |
| Your manager is the problem | Skip-level manager, HRBP, or Ethics Line |
| Suspected fraud or financial crime | Compliance immediately; do not investigate yourself |
| Market abuse or insider dealing | Compliance immediately; do not alert the subject |
| Mis-selling or unfair customer outcome | Compliance and your Department Head |
| Harassment, bullying, or discrimination | HRBP or Employee Relations |
| Data breach or lost device | ApexServe Severity 1 within one hour |
| Accounting irregularity | Internal Audit or the Chair of the Board Audit Committee |
| Retaliation for a previous report | Employee Relations and the Ethics Line |
| Senior management misconduct | Chair of the Board Audit Committee, or the Ethics Line |
| Anything, anonymously | Ethics Line, 24×7, independent third party |

You may always go to a regulator. Nothing the Bank asks you to sign can prevent that.

### Appendix D — Covered Person Designations

| Population | Basis |
|---|---|
| All employees of Corporate & Investment Banking, Corporate Finance, and Capital Markets | Regular MNPI access |
| All employees of Treasury & Markets front office | Market activity |
| Research analysts and supervisors | Publication-sensitive information |
| All employees of Compliance, Risk, and Internal Audit | Access to Restricted and Watch Lists and investigative information |
| Finance employees with pre-release earnings access | Apex MNPI |
| Legal employees with transaction or disclosure access | MNPI |
| Executive support to G10 and above | Incidental MNPI access |
| All employees at G9 and above | Seniority and information access |
| Any employee wall-crossed onto a specific transaction | For the duration plus 30 days |

The designation list is maintained by Markets Compliance, reviewed quarterly, and recorded against the position in ApexPeople.

---

**End of Document**

`ANB-HRM-POL-0004` · Version 1.0 · Classification: Internal (C1) · Owner: Human Resources (HRM) with Legal (LEG) and Compliance (CMP) · Approver: Marcus D. Whitfield, Group Chief Executive Officer · Ratified by the Board of Directors · Effective 2026-08-01 · Next Review 2027-07-24

*This document is controlled. Printed copies are uncontrolled. The authoritative version resides in ApexDocs.*
