# SAR Draft (FinCEN) — Pre-Filing

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `SAR-202608-0881` |
| **Document Title** | SAR Draft (FinCEN) — Pre-Filing |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | BSA Officer path / Investigations |
| **Classification** | Highly Restricted (C3+/C4 handling) |
| **Effective / As-Of** | 2026-08-15 |
| **Business Process** | `BP-AML-SAR`, `ANB-CMP-SOP-0004` |
| **System of Record** | ApexGuard · ApexRegRep |
| **Related Documents** | `CASE-AML-202608-0881` — **CONFIDENTIAL SAR** |


## 2. Filing Intent

Suspicious Activity Report draft regarding Horizon Craft Supply LLC and Luis M. Alvarez for potential structuring of cash deposits and rapid dissipation of commercial loan proceeds without adequate business documentation for a subset of counterparties totaling approximately **USD 141,200**.

Amount involved (aggregate suspicious): ~USD 168,800 (wires unsupported + near-CTR cash pattern).

## 3. Subjects

Horizon Craft Supply LLC; Luis Miguel Alvarez. Sofia Alvarez listed as related household with **no** suspicious activity identified on personal mortgage.

## 4. Confidentiality

Per AML-7 — do not disclose SAR existence to subjects or RM beyond need-to-know.

## 5. Related

Investigation report · Compliance decision · `ANB-CMP-SOP-0004`

---

**End** — `SAR-202608-0881` (DRAFT WORKPAPER)
