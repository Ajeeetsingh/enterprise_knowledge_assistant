# AML Investigation Report

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `INV-AML-202608-0881` |
| **Document Title** | AML Investigation Report |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | AML Investigator / `EMP-400109` review |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-18 |
| **Business Process** | `BP-AML-INV`, `ANB-CMP-POL-0001` |
| **System of Record** | ApexGuard |
| **Related Documents** | `CASE-AML-202608-0881`, `SAR-202608-0881`, Case 2, Case 5 Meridian confirm |


## 2. Executive Conclusion

**Suspicious activity substantiated in part.** Legitimate Meridian-related flows ~USD 96k documented. Unsupported outbound wires USD 141,200 and sequential cash deposits appear designed to avoid CTR and are inconsistent with stated use of `LOAN-SME-88214401` proceeds. Recommend SAR file; risk rate **CR-H**; enhanced monitoring; Credit informed for covenant/default review **without SAR tipping**.

## 3. Evidence Table

| Evidence | Ref |
|---|---|
| TM alert | `AML-202608-04412` |
| Loan docs | Case 2 |
| Meridian confirm | Case 5 / email |
| Interview notes | Case notes |
| Screens | `SCR-202608-8821`, `PEP-202608-8821` |

## 4. Related

Compliance decision · Closure memo · Credit Special Assets awareness (no SAR copy)

---

**End** — `INV-AML-202608-0881`
