# Sanctions Re-Screen — Case 3

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `SCR-202608-8821` |
| **Document Title** | Sanctions Re-Screen — Case 3 |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | Screening Ops |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-03 |
| **Business Process** | `ANB-CMP-SOP-0005` |
| **System of Record** | ApexKYC |
| **Related Documents** | `SCR-202606-8821`, wire beneficiaries |


## 2. Results

Entity/BO clear. Two beneficiaries name-cleared as false positives (common Hispanic surnames). No OFAC true hit.

## 3. Related

Investigation — typology more structuring / misuse of loan proceeds than sanctions.

---

**End** — `SCR-202608-8821`
