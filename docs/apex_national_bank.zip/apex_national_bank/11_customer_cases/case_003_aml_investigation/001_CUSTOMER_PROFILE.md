# AML Case Customer Profile Pack

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-AML-PRF-88214401` |
| **Document Title** | AML Case Customer Profile Pack |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | AML Investigations `EMP-400109` Trevor Walsh desk |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-02 |
| **Business Process** | `BP-AML-INV`, `BP-AML-TM` |
| **System of Record** | ApexGuard · ApexKYC · ApexCore |
| **Related Documents** | Case 2 full · Case 1 · `ANB-CMP-POL-0001` |


## 2. Subjects

| Subject | ID | Role |
|---|---|---|
| Horizon Craft Supply LLC | `CUS-SME-88214401` | Primary |
| Luis M. Alvarez | `CUS-03115591` | BO / guarantor |
| Sofia R. Alvarez | `CUS-03115590` | Related household — **not** subject at open; funds-flow check only |
| Operating acct | `ACC-8821440101` | Monitored |

## 3. Products

SME loan `LOAN-SME-88214401` / `FAC-SME-88214401` · Operating deposits · Wires

## 4. Related

Case 2 onboarding · Case 5 Meridian as legitimate counterparty

---

**End** — `ANB-AML-PRF-88214401`
