# AML Case Notes — CASE-AML-202608-0881

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-AML-NOT-0881` |
| **Document Title** | AML Case Notes — CASE-AML-202608-0881 |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | Investigator assigned under `EMP-400109` |
| **Classification** | Restricted (C3) — SAR-sensitive |
| **Effective / As-Of** | 2026-08-01 → 2026-08-20 |
| **Business Process** | `BP-AML-INV` |
| **System of Record** | ApexGuard |
| **Related Documents** | `AML-202608-04412`, Case 2 RM notes, Case 1 mortgage (negative funds-flow) |


## 2. Chronological Notes

| Date | Note |
|---|---|
| 08-01 | Alert promoted to case `CASE-AML-202608-0881`. |
| 08-02 | Pulled loan file Case 2; purpose inventory/AR. |
| 08-05 | Luis interview via secure call — claims suppliers require "relationship deposits"; invoices incomplete for 4 wires. |
| 08-07 | Meridian AP (`CORP-10000001`) confirms legitimate invoices USD 96k received — supports portion of activity. |
| 08-09 | Cash deposits: customer states trade-show booth cash sales — weak contemporaneous records. |
| 08-11 | Sofia mortgage account reviewed — **no** layering from SME loan into `HLN-202605-0099` escrow. |
| 08-12 | RM Bakshi reminded of no-tipping-off. |
| 08-15 | Draft SAR recommendation for structuring + possible loan proceeds diversion on unsupported wires USD 141,200. |
| 08-18 | BSA Officer review. |

## 3. Related

SAR draft · Investigation report · `ANB-CMP-SOP-0004`

---

**End** — `ANB-AML-NOT-0881`
