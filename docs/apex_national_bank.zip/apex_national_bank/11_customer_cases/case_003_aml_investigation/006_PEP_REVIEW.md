# PEP Review

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `PEP-202608-8821` |
| **Document Title** | PEP Review |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | EDD / FCC |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-04 |
| **Business Process** | `ANB-CMP-POL-0001`, `ANB-CMP-SOP-0006` |
| **System of Record** | ApexKYC |
| **Related Documents** | `EDD-202608-8821` |


## 2. Result

Luis M. Alvarez / Sofia R. Alvarez / Horizon — **not PEP**. Adverse media: none material. Distant name match to municipal employee in another state — ruled out by DOB/address.

## 3. Related

EDD · Compliance decision

---

**End** — `PEP-202608-8821`
