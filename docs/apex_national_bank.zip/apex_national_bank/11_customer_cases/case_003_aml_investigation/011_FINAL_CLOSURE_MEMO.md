# Final Closure Memo — CASE-AML-202608-0881

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-AML-CLS-0881` |
| **Document Title** | Final Closure Memo — CASE-AML-202608-0881 |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | `EMP-400109` Trevor Walsh |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-21 |
| **Business Process** | `BP-AML-INV` |
| **System of Record** | ApexGuard |
| **Related Documents** | Full Case 3 set · retention `RET-AML-5Y` |


## 2. Closure

Case closed **SAR Filed — Enhanced Monitoring**. Monitoring rules tuned on `ACC-8821440101`. Reopen triggers: further near-CTR cash, unsupported international wires, or credit default.

## 3. Cross-Domain Hand-offs

| Team | Hand-off |
|---|---|
| Credit / RM | Watchlist relationship |
| Retail mortgage servicing | No action on `HLN-202605-0099` |
| Audit | Available for `BP-AUD-ENG` sample |
| Ops | No link to SEV-1 payments incident root cause |

## 4. Related

`SAR-202608-0881` · `ANB-IAD-CHT-0001` sampling possible

---

**End** — `ANB-AML-CLS-0881`
