# KYC Refresh — High Activity Trigger

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `KYC-202608-8821` |
| **Document Title** | KYC Refresh — High Activity Trigger |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | KYC / EDD team |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-05 |
| **Business Process** | `BP-ONB-KYC`, `BP-AML-RISK`, `ANB-CMP-SOP-0006` |
| **System of Record** | ApexKYC |
| **Related Documents** | `KYC-202606-8821`, `EDD-202608-8821` |


## 2. Refresh Drivers

Post-funding velocity > expected; TM alert `AML-202608-04412`; risk rating proposed **CR-H** pending EDD.

## 3. Updates

Source of funds narrative refreshed: loan proceeds + Meridian receipts. Supplier list requested.

## 4. Related

EDD · Case notes

---

**End** — `KYC-202608-8821`
