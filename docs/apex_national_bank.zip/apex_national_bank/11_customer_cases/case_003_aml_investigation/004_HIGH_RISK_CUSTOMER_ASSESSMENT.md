# High Risk Customer Assessment

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `EDD-202608-8821` |
| **Document Title** | High Risk Customer Assessment |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | EDD Analyst / FCC |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-08 |
| **Business Process** | `BP-AML-RISK`, `ANB-CMP-SOP-0006` |
| **System of Record** | ApexGuard · ApexKYC |
| **Related Documents** | `KYC-202608-8821`, `ANB-CMP-POL-0001` |


## 2. Assessment

| Factor | Score drive |
|---|---|
| Tenure | New entity < 12 months |
| Product | Credit + wires |
| Behaviour | Velocity vs KYC expected |
| Geography | Domestic only — lower |
| PEP | Clear |
| **Proposed rating** | **CR-H** |

## 3. Decision Path

EDD mandatory; senior approval for continuance per AML-4/AML-1 RBA.

## 4. Related

PEP review · Sanctions · Compliance decision

---

**End** — `EDD-202608-8821`
