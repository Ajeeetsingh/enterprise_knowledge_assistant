# Compliance Decision — AML Case

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CMP-DEC-0881` |
| **Document Title** | Compliance Decision — AML Case |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | BSA Officer / Head of Financial Crime `EMP-400101` Adeline Mercier path |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-19 |
| **Business Process** | `BP-AML-SAR`, `ANB-CMP-POL-0001` |
| **System of Record** | ApexGuard |
| **Related Documents** | `INV-AML-202608-0881`, `SAR-202608-0881` |


## 2. Decision

| Decision | Detail |
|---|---|
| SAR | **File** `SAR-202608-0881` with FinCEN |
| Rating | Maintain/upgrade **CR-H** |
| Relationship | Continue with EDD & monthly FCC review — decline not mandated yet |
| Credit notice | Material adverse information notice to Credit (no SAR) |
| Law enforcement | Respond if requested per `ANB-LEG-SOP-0007` |

## 3. Approval

BSA Officer approved filing 2026-08-19.

## 4. Related

Final closure memo · Case 2 RM notes · Case 6 unrelated

---

**End** — `ANB-CMP-DEC-0881`
