# Transaction Monitoring Alert

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `AML-202608-04412` |
| **Document Title** | Transaction Monitoring Alert |
| **Version** | 1.0 |
| **Case / Folder** | `case_003_aml_investigation` |
| **Customer / Entity** | `CUS-SME-88214401` Horizon Craft; BO Luis Alvarez `CUS-03115591`; related household `CUS-03115590` |
| **Owner** | TM L1 Analyst → Investigations |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-08-01 |
| **Business Process** | `BP-AML-TM`, `ANB-CMP-POL-0001` |
| **System of Record** | ApexGuard |
| **Related Documents** | `CASE-AML-202608-0881`, `ACC-8821440101` |


## 2. Alert Detail

| Field | Value |
|---|---|
| Alert ID | `AML-202608-04412` |
| Rule | Rapid movement of loan proceeds + structured cash deposits below CTR |
| Scenario | Funding 2026-07-03 USD 350,000 → 9 outbound wires 7 days totaling USD 276,400 to new counterparties; cash deposits USD 8,900 / 9,200 / 9,500 on consecutive days |
| Score | 92 / 100 |
| Case | `CASE-AML-202608-0881` |

## 3. Narrative (system)

```
LOAN_CREDIT 350000 2026-07-03 PAY-SME-88214401
WIRE_OUT patterns to LLC counterparties formed <90 days
CASH_IN near 10k threshold x3 — CTR not triggered individually
```

## 4. Related

Investigation report · SAR draft · Ops note: not related to `INC-20260714-0001` except same-week customer service noise

---

**End** — `AML-202608-04412`
