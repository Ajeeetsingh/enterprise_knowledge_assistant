# Customer Complaint — Mortgage Payment Posting

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `CMP-202607-0311` |
| **Document Title** | Customer Complaint — Mortgage Payment Posting |
| **Version** | 1.0 |
| **Case / Folder** | `case_006_customer_complaint` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez — mortgage payment complaint / regulatory escalation |
| **Owner** | CST / Mortgage Servicing |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-15 |
| **Business Process** | `BP-CST-CMP`, `BP-RTL-MTG` |
| **System of Record** | Apex360 · ApexServe |
| **Related Documents** | Case 1 `HLN-202605-0099`, `ANB-OPS-INC-0001`, `INST-MTG-03115590` |


## 2. Complaint

Sofia R. Alvarez alleges first mortgage payment due 2026-07-01 was "taken twice then reversed then late-fee threatened" after online banking outage week of 14 July. Seeks: confirmation payment applied once, fee waiver, written explanation, and escalation if not resolved.

| Field | Value |
|---|---|
| Complaint ID | `CMP-202607-0311` |
| Channel | ApexOnline secure message + branch `BRN-0412` visit 2026-07-15 |
| Loan | `HLN-202605-0099` / `MTG-202605-2210` |
| Amount in dispute | USD 3,184.00 PITIA + threatened USD 45 late fee |

## 3. Related Prior Cases

Customer Case 1 mortgage. Spouse entity in Case 3 — **do not discuss AML**. Distinct from fraud complaint `CMP-202607-0492` (Jamal K. Robertson).

## 4. Related

Call transcript · Ops investigation · `ANB-RTL-MAN-0004`

---

**End** — `CMP-202607-0311`
