# Operations Investigation — Payment Posting

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-OPS-INV-03115590` |
| **Document Title** | Operations Investigation — Payment Posting |
| **Version** | 1.0 |
| **Case / Folder** | `case_006_customer_complaint` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez — mortgage payment complaint / regulatory escalation |
| **Owner** | Payments / Mortgage Servicing Ops |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-18 |
| **Business Process** | `BP-OPS-INC`, `BP-RTL-MTG` |
| **System of Record** | ApexCore · ApexPay · ApexServe |
| **Related Documents** | `ANB-OPS-INC-0001`, `INC-20260714-0001`, `ANB-OPS-RCA-0001` |


## 2. Root Technical Link

During SEV-1 `INC-20260714-0001`, ApexPay latency caused **duplicate submit UI** on ApexMobile; second submit created pending debit that auto-voided. Customer-facing "failed" banner incorrect. Actual ACH/debit to `ACC-1029384701` for mortgage posted once effective 2026-07-01.

No customer funds double-taken overnight. Late fee engine raised then cleared warning — **USD 0 charged**.

## 3. CAPA Link

Aligns with `CAPA-20260714-*` UX/monitoring fixes; servicing comms template updated.

## 4. Related

`ANB-OPS-RCA-0001` · Compliance review · Root cause doc

---

**End** — `ANB-OPS-INV-03115590`
