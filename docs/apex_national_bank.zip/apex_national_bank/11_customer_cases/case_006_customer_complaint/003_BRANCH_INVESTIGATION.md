# Branch Investigation Note — BRN-0412

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-BRN-03115590` |
| **Document Title** | Branch Investigation Note — BRN-0412 |
| **Version** | 1.0 |
| **Case / Folder** | `case_006_customer_complaint` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez — mortgage payment complaint / regulatory escalation |
| **Owner** | Branch Manager `EMP-300103` Amara Okoye / `EMP-300107` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-17 |
| **Business Process** | `BP-RTL-BRN`, `ANB-RTL-MAN-0003` |
| **System of Record** | ApexServe · ApexTeller |
| **Related Documents** | `CMP-202607-0311`, `BRN-0412` |


## 2. Findings

Customer visited `BRN-0412` 2026-07-15. PB `EMP-300105` pulled servicing screen: single applied instalment #1; memo of threatened fee was **system warning during reverse/repair**, not assessed. Printed payoff/history given. Customer still requested formal letter and regulatory path.

Teller `EMP-300106` Jamal Robertson assisted printouts — **not** the fraud customer Jamal K. Robertson.

## 3. Related

Ops investigation · Complaint

---

**End** — `ANB-RTL-BRN-03115590`
