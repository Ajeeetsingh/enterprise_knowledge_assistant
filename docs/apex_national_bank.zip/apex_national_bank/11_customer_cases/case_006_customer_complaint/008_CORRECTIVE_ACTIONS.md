# Corrective Actions — Complaint & Servicing UX

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `CAPA-CMP-202607-0311` |
| **Document Title** | Corrective Actions — Complaint & Servicing UX |
| **Version** | 1.0 |
| **Case / Folder** | `case_006_customer_complaint` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez — mortgage payment complaint / regulatory escalation |
| **Owner** | Mortgage Servicing + Digital + OPS |
| **Classification** | Internal (C1) |
| **Effective / As-Of** | 2026-07-28 |
| **Business Process** | `BP-OPS-CAPA`, `BP-CST-CMP` |
| **System of Record** | ApexServe |
| **Related Documents** | `CMP-202607-0311`, `CAPA-20260714-0001` family |


## 2. Actions

| ID | Action | Owner | Due |
|---|---|---|---|
| `ACT-CMP-0311-01` | Suppress late-fee warnings on voided duplicate submits | Servicing IT | 2026-08-30 |
| `ACT-CMP-0311-02` | Mobile banner copy for "pending reverse" states | Digital | 2026-08-15 |
| `ACT-CMP-0311-03` | Goodwill USD 150 + fee assurance letter | CST | 2026-07-30 |
| `ACT-CMP-0311-04` | Link complaint MI to major INC automatically | Ops MI | 2026-09-15 |

## 3. Related

Final resolution · Audit may sample under `ANB-IAD-CHK-0001` complaint linkage (OBS-07 theme)

---

**End** — `CAPA-CMP-202607-0311`
