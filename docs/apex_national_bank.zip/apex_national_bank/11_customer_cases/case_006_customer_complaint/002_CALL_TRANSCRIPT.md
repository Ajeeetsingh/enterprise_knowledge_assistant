# Call Transcript — Complaint Follow-up

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CST-TRN-03115590` |
| **Document Title** | Call Transcript — Complaint Follow-up |
| **Version** | 1.0 |
| **Case / Folder** | `case_006_customer_complaint` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez — mortgage payment complaint / regulatory escalation |
| **Owner** | CST Mortgage Specialty |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-16 |
| **Business Process** | `BP-CST-CMP` |
| **System of Record** | ApexVoice |
| **Related Documents** | `CMP-202607-0311` |


## 2. Transcript Excerpt

**Agent:** I see payment effective dated 07/01 for 3184.00.  
**Sofia:** But ApexMobile showed failed on the 14th and I panicked — I pushed another payment.  
**Agent:** Second attempt auto-reversed same day; no late fee assessed. Outage ticket `INC-20260714-0001` affected payments display.  
**Sofia:** I want this in writing. If not fixed I'm calling the regulator.  
**Agent:** Opening written response path; escalating to Ops + Compliance review.

## 3. Related

Branch investigation · Ops investigation

---

**End** — `ANB-CST-TRN-03115590`
