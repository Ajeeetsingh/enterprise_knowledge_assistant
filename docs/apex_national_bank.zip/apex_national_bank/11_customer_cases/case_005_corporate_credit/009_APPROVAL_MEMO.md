# Approval Memo — Meridian FAC Upsize

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-APR-10028441` |
| **Document Title** | Approval Memo — Meridian FAC Upsize |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Credit Admin / CRO path |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-06 |
| **Business Process** | `ANB-CBK-SOP-0001` |
| **System of Record** | ApexCredit |
| **Related Documents** | `ANB-CBK-MIN-202608-014`, `FAC-10028441` |


## 2. Approval

GrCC approved increase of `FAC-10028441` to USD 100,000,000 effective upon CP satisfaction. Booking limit `LMT-10028441` updated.

## 3. Related

Loan agreement execution · Annual review cadence

---

**End** — `ANB-CBK-APR-10028441`
