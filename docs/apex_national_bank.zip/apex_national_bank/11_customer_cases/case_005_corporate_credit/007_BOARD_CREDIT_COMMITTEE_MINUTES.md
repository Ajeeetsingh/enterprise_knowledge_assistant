# Group Credit Committee Minutes — Extract (Meridian)

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-MIN-202608-014` |
| **Document Title** | Group Credit Committee Minutes — Extract (Meridian) |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Credit Committee Secretariat |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-06 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-SOP-0001`, `ANB-LEG-REF-0003` |
| **System of Record** | ApexDocs · Directors' Desk extract |
| **Related Documents** | `ANB-CBK-MEM-10028441`, CRO `EMP-100004` |


## 2. Minutes Extract

**Meeting:** Group Credit Committee · 2026-08-06  
**Chair:** Helena Brandt, CRO (`EMP-100004`)  
**Item 4 — Meridian Advanced Materials Inc. RCF upsize to USD 100M**

Discussion: leverage trajectory favourable; supplier financing of Horizon disclosed — Compliance confirmed Meridian not AML subject; Horizon under separate FCC monitoring (committee informed *that monitoring exists*, not SAR detail).

**Resolution:** Approved as proposed. Risk affirmative vote recorded.

## 3. Related

Approval memo · `ANB-ADM-MTX-0001`

---

**End** — `ANB-CBK-MIN-202608-014`
