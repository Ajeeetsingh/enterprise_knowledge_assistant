# Relationship History — Meridian

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-HIS-10028441` |
| **Document Title** | Relationship History — Meridian |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | `EMP-300301` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-01 |
| **Business Process** | `BP-CBK-REL` |
| **System of Record** | Apex360 |
| **Related Documents** | Case 5 pack · Case 2 notes |


## 2. Timeline

| Year | Event |
|---|---|
| 2018 | Onboarded; initial RCF USD 40M |
| 2021 | Upsize to USD 75M `FAC-10028441` |
| 2024 | Temporary utilisation peak 82% during expansion |
| 2026-02 | Employee Luis Alvarez exits; starts Horizon (Case 2) — Meridian signs supply agreement |
| 2026-06 | Horizon financed by Bank (same RM) — conflict/connected check: **arm's length supplier**, disclosed |
| 2026-07 | Request RCF upsize to USD 100M |
| 2026-08 | AML team queries AP history for Horizon — Finance responds |

## 3. Related

Credit memo · Board Credit Committee minutes

---

**End** — `ANB-CBK-HIS-10028441`
