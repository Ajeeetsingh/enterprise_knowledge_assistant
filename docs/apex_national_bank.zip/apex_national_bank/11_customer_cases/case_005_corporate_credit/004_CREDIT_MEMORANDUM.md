# Credit Memorandum — Meridian RCF Upsize

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-MEM-10028441` |
| **Document Title** | Credit Memorandum — Meridian RCF Upsize |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | `EMP-300302` Naomi Castellanos / RM Bakshi |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-28 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-TPL-0003`, `ANB-CBK-SOP-0001` |
| **System of Record** | ApexOrigin · ApexCredit |
| **Related Documents** | `FAC-10028441`, `ANB-CBK-POL-0001`, Case 2 disclosure |


## 2. Request

Upsize RCF from USD 75M to **USD 100M**, same pricing grid +15 bps, tenor extend 1 year. Purpose: capacity expansion CapEx bridge + working capital.

## 3. Analysis Snapshot

Leverage declining; interest coverage strong; collateral package existing first-lien all-assets. Connected party: supplier Horizon Bank exposure `FAC-SME-88214401` USD 0.35M — **immaterial**; aggregate single-name still within `ANB-CBK-GDL-0003`.

## 4. Recommendation

Approve with GrCC (amount over Regional).

## 5. Related

Facility proposal · BCC minutes · `ANB-CBK-TPL-0003`

---

**End** — `ANB-CBK-MEM-10028441`
