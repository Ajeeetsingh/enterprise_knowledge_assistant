# Collateral Package — Meridian

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `COLL-10028441` |
| **Document Title** | Collateral Package — Meridian |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Credit Admin `EMP-300307` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-30 |
| **Business Process** | `ANB-CBK-POL-0002` |
| **System of Record** | ApexDocs · UCC |
| **Related Documents** | `FAC-10028441` |


## 2. Package

| Collateral | Perfection |
|---|---|
| All-assets UCC (IL/NC/etc.) | Continuations current |
| Pledge of material subsidiaries stock | Delivered |
| Mortgage on Plant 3 (Chicago) | Recorded — valuation USD 48M |
| Insurance assignments | Current |

No collateral sharing with Horizon SME facility.

## 3. Related

Legal review · Loan agreement amendment

---

**End** — `COLL-10028441`
