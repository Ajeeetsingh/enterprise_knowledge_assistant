# Corporate Customer Profile — Meridian Advanced Materials Inc.

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-PRF-10028441` |
| **Document Title** | Corporate Customer Profile — Meridian Advanced Materials Inc. |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | RM `EMP-300301` Henry Bakshi |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-01 |
| **Business Process** | `BP-CBK-REL`, `ANB-CBK-POL-0001` |
| **System of Record** | Apex360 · ApexCore · ApexCredit |
| **Related Documents** | Existing register in `ANB-CBK-POL-0001` · Case 2 supplier Horizon · Case 3 Meridian AP confirm |


## 2. Entity

| Field | Value |
|---|---|
| Legal name | Meridian Advanced Materials Inc. |
| CORP ID | `CORP-10000001` |
| CIF | `CUS-10028441` |
| HQ | Chicago, IL |
| Sector | Manufacturing — advanced materials |
| RM | `EMP-300301` Henry Bakshi |
| Risk rating | `CRR-0003` |
| Existing facility | `FAC-10028441` USD 75M RCF |

## 3. Ecosystem Links

- Supplier: Horizon Craft Supply LLC (Case 2) — materials packaging consumables.
- Former employee: Luis M. Alvarez (now Horizon BO) — amicable departure 2026-02.
- AML Case 3: Meridian provided AP confirmations as third party (not a subject).

## 4. Related

Financial statements · Credit memo · Annual review

---

**End** — `ANB-CBK-PRF-10028441`
