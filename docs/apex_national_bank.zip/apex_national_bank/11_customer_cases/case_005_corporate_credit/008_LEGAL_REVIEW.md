# Legal Review — Facility Amendment

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-REV-10028441` |
| **Document Title** | Legal Review — Facility Amendment |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Legal Credit Documentation |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-08 |
| **Business Process** | `BP-LEG-CTR`, `ANB-CBK-CTR-0002` |
| **System of Record** | ApexLegal |
| **Related Documents** | `FAC-10028441`, Master Loan Agreement template lineage `ANB-LEG` / `ANB-CBK-CTR-0002` |


## 2. Review Outcome

Amendment and Restatement of RCF documentation enforceable; conditions precedent checklist standard. No cross-default to Horizon SME facility required or recommended.

## 3. Related

Approval memo · Loan agreement

---

**End** — `ANB-LEG-REV-10028441`
