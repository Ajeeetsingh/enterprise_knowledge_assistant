# Amended & Restated Loan Agreement — Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-LON-10028441` |
| **Document Title** | Amended & Restated Loan Agreement — Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Legal / Credit Admin |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-15 |
| **Business Process** | `BP-LEG-CTR` |
| **System of Record** | ApexDocs |
| **Related Documents** | `FAC-10028441`, `ANB-CBK-CTR-0002`, `ANB-LEG` corporate loan forms |


## 2. Execution

Amended & Restated Revolving Credit Agreement dated 2026-08-15 among Meridian Advanced Materials Inc., Apex National Bank as Administrative Agent and Lender, commitment USD 100M. Facility ID unchanged `FAC-10028441`.

## 3. Related

Annual review · Collateral · Case 2 arm's-length confirmation clause in representations (no Horizon default contagion)

---

**End** — `ANB-LEG-LON-10028441`
