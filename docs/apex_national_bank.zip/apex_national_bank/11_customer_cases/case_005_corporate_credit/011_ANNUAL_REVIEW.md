# Annual Credit Review — Meridian (Interim Upsize Year)

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-ARV-10028441` |
| **Document Title** | Annual Credit Review — Meridian (Interim Upsize Year) |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Portfolio Management `EMP-300309` / RM |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-08-20 |
| **Business Process** | `BP-CBK-REV` |
| **System of Record** | ApexCredit · ApexRisk |
| **Related Documents** | `FAC-10028441`, `CRR-0003` |


## 2. Review Conclusion

Maintain **CRR-0003**. Utilisation post-upsize 41%. Watch item: monitor Horizon payable concentration (Meridian AP) given Case 3 FCC monitoring on supplier — **credit neutral to Meridian** if supplier disruption; dual-source plan requested by next quarter.

## 3. Related

Credit memo · RM notes Case 2 · AML closure Case 3 (limited info)

---

**End** — `ANB-CBK-ARV-10028441`
