# Facility Proposal Term Sheet

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-TSP-10028441` |
| **Document Title** | Facility Proposal Term Sheet |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | RM / Credit |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-28 |
| **Business Process** | `BP-CBK-CRD` |
| **System of Record** | ApexDocs |
| **Related Documents** | `FAC-10028441` (amended), `ANB-CBK-MEM-10028441` |


## 2. Terms

| Term | Proposed |
|---|---|
| Facility | Revolving Credit Facility |
| Commitment | USD 100,000,000 |
| Facility ID (amended) | `FAC-10028441` |
| Maturity | 2030-09-30 |
| Pricing | SOFR + 185–250 bps grid |
| Undrawn fee | 35 bps |
| Financial covenants | Max net leverage 2.50x; min interest coverage 3.00x |

## 3. Related

Collateral package · Legal review · Approval memo

---

**End** — `ANB-CBK-TSP-10028441`
