# Financial Statements Summary — Meridian FY25 / LTM

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-FIN-10028441` |
| **Document Title** | Financial Statements Summary — Meridian FY25 / LTM |
| **Version** | 1.0 |
| **Case / Folder** | `case_005_corporate_credit` |
| **Customer / Entity** | `CORP-10000001` / `CUS-10028441` Meridian Advanced Materials Inc. |
| **Owner** | Credit Analyst `EMP-300302` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-15 |
| **Business Process** | `BP-CBK-CRD` |
| **System of Record** | ApexCredit · client 10-type package |
| **Related Documents** | `FAC-10028441`, `ANB-CBK-GDL-0001` |


## 2. Key Figures (USD millions)

| Metric | FY24 | FY25 | LTM Jun26 |
|---|---|---|---|
| Revenue | 820 | 905 | 940 |
| EBITDA | 118 | 132 | 138 |
| Total debt | 210 | 195 | 188 |
| Cash | 42 | 55 | 61 |
| Net leverage | 1.42x | 1.06x | 0.92x |

## 3. Related

Credit memorandum · Facility proposal (upsizing)

---

**End** — `DOC-FIN-10028441`
