# Fraud Case Closure

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FRD-CLS-1902` |
| **Document Title** | Fraud Case Closure |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud Ops |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-28 |
| **Business Process** | `BP-FRD-INV` |
| **System of Record** | ApexGuard Fraud · Apex360 |
| **Related Documents** | `CASE-FRD-202607-1902`, `CMP-202607-0492` |


## 2. Closure Code

**Fraud — Account Takeover — Customer Authenticated Victim — Credited.**

| Metric | Value |
|---|---|
| Gross fraud | 4,872.16 |
| Customer loss | 0.00 |
| Est. Bank net loss | 1,100.00 |
| Cards reissued | 1 |
| Devices blacklisted | `DEV-CUS-0492-99` |

## 3. Cross References

No link to Case 3 AML subjects. Customer also has historic `CMP-202608-0088` OD fee complaint (service, not fraud). Name collision with `EMP-300106` documented in HR-safe note for investigators only.

## 4. Related

`ANB-ISC-SOP-0003` phishing playbook lessons · Retail CSAT follow-up

---

**End** — `ANB-FRD-CLS-1902`
