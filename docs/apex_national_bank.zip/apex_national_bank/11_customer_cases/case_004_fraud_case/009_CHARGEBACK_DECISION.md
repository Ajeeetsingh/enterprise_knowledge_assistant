# Chargeback Decision

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-FRD-CBD-1902` |
| **Document Title** | Chargeback Decision |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud Ops Manager |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-25 |
| **Business Process** | `BP-FRD-INV` |
| **System of Record** | Card processor · ApexCore |
| **Related Documents** | `INV-FRD-202607-1902` |


## 2. Decisions by Item

| Bucket | Amount | Action |
|---|---|---|
| CNP gaming/electronics | 4,030.16 | Chargeback filed — customer provisional finalised |
| Miami ATM + transit | 842.00 | Network claim — provisional remains; good-faith final credit if acquirer denies |

Customer final liability: **USD 0** (Reg E + Bank policy goodwill on ATM).

## 3. Related

Case closure

---

**End** — `ANB-FRD-CBD-1902`
