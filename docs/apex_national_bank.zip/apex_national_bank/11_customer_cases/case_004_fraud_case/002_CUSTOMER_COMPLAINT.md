# Customer Complaint — Unauthorised Card Transactions

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `CMP-202607-0492` |
| **Document Title** | Customer Complaint — Unauthorised Card Transactions |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | CST / Fraud intake |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-19 |
| **Business Process** | `BP-CST-CMP`, `ANB-RTL-MAN-0004` |
| **System of Record** | Apex360 · ApexServe |
| **Related Documents** | `FRD-202607-1902`, prior OD complaint `CMP-202608-0088` (separate), `CUS-04928311` |


## 2. Complaint Narrative

Customer called ApexVoice 2026-07-19 08:42 ET: "I didn't buy anything in Miami or online gaming sites. My card is still in my wallet in Charlotte." Claims SMS OTP received overnight not actioned by him.

Product: Essential Checking `CHK-202402-1102`. Also holds savings `SAV-202401-8841` (recently reactivated per retail guide example).

## 3. Requested Outcome

Full provisional credit; new card; investigation.

## 4. Related

Reg E claim clock started · Fraud investigation · Note: distinct from Sofia Alvarez mortgage complaint Case 6 `CMP-202607-0311`

---

**End** — `CMP-202607-0492`
