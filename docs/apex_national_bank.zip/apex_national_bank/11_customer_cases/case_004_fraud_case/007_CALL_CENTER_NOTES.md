# Call Center Notes

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CST-CLN-04928311` |
| **Document Title** | Call Center Notes |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | CST Agent / Fraud hotline |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-19 |
| **Business Process** | `BP-CST-CMP` |
| **System of Record** | ApexVoice · Apex360 |
| **Related Documents** | `CMP-202607-0492` |


## 2. Transcript Excerpt (redacted)

**Agent:** Thank you for calling Apex National Bank Fraud line.  
**Customer:** Someone drained my account — Miami ATM? I've never been to Miami!  
**Agent:** I'm locking the card now... authentication via out-of-band...  
**Customer:** I got texts last night asking me to "confirm transfer" — I clicked one.  
**Agent:** Please do not click those links. Opening claim `CMP-202607-0492` / fraud case...

Auth: KBA + last deposit `CUS-04928311`. Mentions teller friend "Jamal at uptown" — agent noted **possible confusion with employee name**; verified last four SSN unique.

## 3. Related

Complaint · Investigation

---

**End** — `ANB-CST-CLN-04928311`
