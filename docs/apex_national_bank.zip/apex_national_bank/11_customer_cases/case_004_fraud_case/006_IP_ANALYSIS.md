# IP Analysis

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-IP-04928311` |
| **Document Title** | IP Analysis |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud / Digital Risk |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-07-20 |
| **Business Process** | `BP-FRD-INV` |
| **System of Record** | ApexShield / Splunk |
| **Related Documents** | `DOC-DEV-04928311` |


## 2. IPs

| IP | Geo | ASN | Notes |
|---|---|---|---|
| 70.xx.xx.12 | Charlotte, NC | Residential ISP | Customer historic |
| 185.xx.xx.44 | Miami, FL (hosting) | Bulletproof-ish VPS | Hostile — matches ATM geo spoof + CNP |
| 102.xx.xx.9 | Lagos proxy | VPN | Brief reconnaissance |

## 3. Related

Merchant investigation · ISC threat intel `IOC-` optional share

---

**End** — `DOC-IP-04928311`
