# Card Transaction History — Dispute Window

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-TXN-04928311` |
| **Document Title** | Card Transaction History — Dispute Window |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud Ops |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-07-19 |
| **Business Process** | `BP-FRD-INV` |
| **System of Record** | ApexCore · Card processor |
| **Related Documents** | `FRD-202607-1902`, `DBC-202402-1102` |


## 2. Disputed Transactions (USD)

| Time (ET) | Merchant | Amount | Auth | City |
|---|---|---|---|---|
| 07-18 23:11 | GAME-VAULT ONLINE | 499.00 | Y | Digital |
| 07-18 23:14 | GAME-VAULT ONLINE | 499.00 | Y | Digital |
| 07-18 23:20 | ELEC-MARKET*US | 1,280.50 | Y | Digital |
| 07-19 01:05 | MIAMI TRANSIT KIOSK | 42.00 | Y | Miami FL |
| 07-19 01:22 | ATM WITHDRAW | 800.00 | Y | Miami FL |
| 07-19 02:10 | ELEC-MARKET*US | 1,751.66 | Y | Digital |
| ... | (5 more micro + one 500) | 1,000.00 | Y | Mixed |
| **Total** | | **4,872.16** | | |

Legitimate pre-dispute: grocery Charlotte 07-18 18:40 USD 86.12 — customer affirms.

## 3. Related

Device analysis · Chargeback decision

---

**End** — `DOC-TXN-04928311`
