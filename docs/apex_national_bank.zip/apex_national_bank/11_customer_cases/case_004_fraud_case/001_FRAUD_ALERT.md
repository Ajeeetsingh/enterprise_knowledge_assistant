# Fraud Alert — Card / Digital Takeover Indicators

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `FRD-202607-1902` |
| **Document Title** | Fraud Alert — Card / Digital Takeover Indicators |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud Ops `EMP-400106` path |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-07-19 |
| **Business Process** | `BP-FRD-INV`, `BP-SEC-IR` |
| **System of Record** | ApexGuard Fraud · ApexCore · ApexShield |
| **Related Documents** | `CASE-FRD-202607-1902`, `DBC`/`CRD` cards, `ANB-CMP` fraud models, Case 6 unrelated complainant |


## 2. Alert

| Field | Value |
|---|---|
| Alert ID | `FRD-202607-1902` |
| Case | `CASE-FRD-202607-1902` |
| Channel | Debit card `DBC-202402-1102` on `CHK-202402-1102` / `ACC-8871200456` |
| Trigger | Geo-velocity + merchant category spike + new device |
| Loss exposure (auth) | USD 4,872.16 across 11 txns |
| Priority | High |

## 3. Ambiguity Warning (internal)

Customer name **Jamal K. Robertson** vs employee teller **Jamal Robertson** `EMP-300106` at `BRN-0412` — **different persons** (DOB/SSN diverge). Do not merge profiles.

## 4. Related

Customer complaint · Card history · Device/IP analysis · `ANB-ISC-SOP-0003` if credential stuffing confirmed

---

**End** — `FRD-202607-1902`
