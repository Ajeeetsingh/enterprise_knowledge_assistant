# Device Analysis

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-DEV-04928311` |
| **Document Title** | Device Analysis |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud / Digital Risk |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-07-20 |
| **Business Process** | `BP-FRD-INV`, `BP-DIG-AUTH` |
| **System of Record** | ApexOnline telemetry · CrowdStrike customer endpoint N/A |
| **Related Documents** | `FRD-202607-1902` |


## 2. Devices

| Device ID | First seen | Risk |
|---|---|---|
| iPhone-iOS known (`DEV-CUS-0492-01`) | 2024 | Trusted |
| Android-unknown (`DEV-CUS-0492-99`) | 2026-07-18 22:58 | **Hostile session** — rooted signals, emulator traits |

Hostile device performed card-not-present adds and OTP acceptance.

## 3. Related

IP analysis · Call center notes

---

**End** — `DOC-DEV-04928311`
