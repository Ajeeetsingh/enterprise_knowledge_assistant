# Merchant Investigation Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-MER-04928311` |
| **Document Title** | Merchant Investigation Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud Ops / Card network liaison |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-21 |
| **Business Process** | `BP-FRD-INV` |
| **System of Record** | Network cases |
| **Related Documents** | `DOC-TXN-04928311` |


## 2. Merchants

| Merchant | Outcome |
|---|---|
| GAME-VAULT ONLINE | High fraud merchant MCC; chargeback rights strong |
| ELEC-MARKET*US | Partial representment likely |
| Miami ATM | Acquirer claim — skim/cashout ring pattern known |

## 3. Related

Chargeback decision

---

**End** — `DOC-MER-04928311`
