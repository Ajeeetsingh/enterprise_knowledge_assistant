# Fraud Investigation Report

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `INV-FRD-202607-1902` |
| **Document Title** | Fraud Investigation Report |
| **Version** | 1.0 |
| **Case / Folder** | `case_004_fraud_case` |
| **Customer / Entity** | `CUS-04928311` Jamal K. Robertson (customer — distinct from teller `EMP-300106` Jamal Robertson) |
| **Owner** | Fraud Investigator |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-07-22 |
| **Business Process** | `BP-FRD-INV` |
| **System of Record** | ApexGuard Fraud |
| **Related Documents** | `CASE-FRD-202607-1902`, device/IP, call notes, merchant |


## 2. Findings

**Account takeover via phishing SMS + malware session** on customer mobile. OTP relay suspected. Not branch-insider (teller collision name eliminated). Not related to AML Case 3 subjects.

Provisional credit issued USD 4,872.16 on 2026-07-20 per Reg E timeline. Card blocked; `DBC` reissue.

## 3. Loss

Gross fraud USD 4,872.16 · Recoveries pending chargeback · Net expected Bank loss ≈ USD 1,100 after representment estimate.

## 4. Cyber Coordination

Credential stuffing indicators shared with SOC as `ALERT` intel — no SEV cyber incident; playbook `PB-SEC-PHISH` reference `ANB-ISC-SOP-0003`.

## 5. Related

Chargeback · Closure · Retail card SOP

---

**End** — `INV-FRD-202607-1902`
