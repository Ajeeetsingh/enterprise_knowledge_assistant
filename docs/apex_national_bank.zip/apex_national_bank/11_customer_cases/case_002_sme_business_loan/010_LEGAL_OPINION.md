# Legal Opinion — SME Facility Enforceability

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-OPN-88214401` |
| **Document Title** | Legal Opinion — SME Facility Enforceability |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Legal — Credit Documentation `EMP-600305` path |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-25 |
| **Business Process** | `BP-LEG-CTR`, `ANB-CBK-POL-0001` |
| **System of Record** | ApexLegal · ApexDocs |
| **Related Documents** | `ANB-LEG-AGR-0002` style facility docs · `FAC-SME-88214401` |


## 2. Opinion Summary

Subject to standard assumptions, the Loan Agreement and Guaranty will constitute valid and binding obligations of Borrower and Guarantor under NC law when duly executed. UCC-1 in NC SOS perfects security interest in personal property collateral described.

## 3. Issues Noted

No cross-default to residential mortgage `HLN-202605-0099` (Case 1) — intentional.

## 4. Related

Loan agreement · Facility letter · `ANB-LEG-AGR-0002` MSA not applicable (credit facility)

---

**End** — `ANB-LEG-OPN-88214401`
