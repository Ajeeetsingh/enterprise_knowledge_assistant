# Tax / Sales Tax Summary (US analogue)

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-TAX-88214401` |
| **Document Title** | Tax / Sales Tax Summary (US analogue) |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Credit Analyst `EMP-300302` Naomi Castellanos |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-18 |
| **Business Process** | `BP-CBK-CRD` |
| **System of Record** | ApexDocs · client upload |
| **Related Documents** | Financial statements · Credit analysis |


## 2. Tax Posture

US LLC taxed as sole proprietorship / disregarded for 2026 stub year. NC sales tax permit active. No GST (non-India); sales tax collected on taxable wholesale where applicable.

| Item | Amount (USD) |
|---|---|
| 2026 YTD gross receipts (through May) | 412,000 |
| Estimated taxable sales | 288,000 |
| Sales tax remitted | Current — no delinquency |

## 3. Artefact

Client spreadsheet tab "GST" mislabeled by bookkeeper (ex-India ERP habit) — values are NC sales tax.

## 4. Related

Financial statements · Cash flow

---

**End** — `DOC-TAX-88214401`
