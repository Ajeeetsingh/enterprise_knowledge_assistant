# SME Loan Approval

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-APR-88214401` |
| **Document Title** | SME Loan Approval |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Regional Credit Committee path / `EMP-400201` oversight |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-28 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-SOP-0001` |
| **System of Record** | ApexOrigin · ApexCredit |
| **Related Documents** | `FAC-SME-88214401`, `ANB-CBK-CRA-88214401`, `ANB-ADM-MTX-0001` |


## 2. Approval

| Field | Value |
|---|---|
| Facility ID | `FAC-SME-88214401` |
| Amount | USD 350,000 term |
| Tenor | 60 months |
| Rate | 9.25% fixed |
| Approver | Regional CC (delegated) with Credit Risk concur `EMP-400201` desk |
| Date | 2026-06-28 |
| Loan ID | `LOAN-SME-88214401` |

## 3. Conditions

UCC filed · insurance · landlord waiver · first Meridian invoice assignment notice.

## 4. Related

Facility letter · Agreement · RM notes

---

**End** — `ANB-CBK-APR-88214401`
