# Cash Flow Analysis

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-CF-88214401` |
| **Document Title** | Cash Flow Analysis |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | `EMP-300302` Naomi Castellanos |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-20 |
| **Business Process** | `BP-CBK-CRD` |
| **System of Record** | ApexOrigin |
| **Related Documents** | `DOC-FIN-88214401`, `FAC-SME-88214401` |


## 2. DSCR Projection

| Item | Monthly USD |
|---|---|
| EBITDA / 12 (annualised) | 12,000 |
| Proposed debt service | 7,312 |
| **DSCR** | **1.64x** |

## 3. Working Capital

Facility purpose: inventory build + AR lag (Net 45 to Meridian). Cash conversion ~52 days.

## 4. Stress

-15% revenue → DSCR ~1.25x still > 1.20x covenant proposal.

## 5. Related

Credit analysis · Case 5 Meridian payment behaviour

---

**End** — `DOC-CF-88214401`
