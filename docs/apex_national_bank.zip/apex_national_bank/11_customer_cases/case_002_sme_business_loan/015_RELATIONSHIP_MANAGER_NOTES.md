# Relationship Manager Notes — Horizon Craft

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-RMN-88214401` |
| **Document Title** | Relationship Manager Notes — Horizon Craft |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | `EMP-300301` Henry Bakshi |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-15 (rolling) |
| **Business Process** | `BP-CBK-REL` |
| **System of Record** | Apex360 |
| **Related Documents** | Case 2 · Case 3 · Case 5 Meridian · Case 1 household |


## 2. Call / Note Log

| Date | Note |
|---|---|
| 2026-06-05 | Intro via Meridian procurement; Luis leaving Meridian employment amicably to supply them. |
| 2026-06-20 | Site visit Suite 120 — inventory neat; books QuickBooks. |
| 2026-07-03 | Facility funded `PAY-SME-88214401`. |
| 2026-07-22 | Customer asked about wire batching to "supplier consolidator" — advised documented invoices only. |
| 2026-08-04 | **Compliance hold advisory** — AML Case 3 opened; RM must not tip off (`ANB-CMP-POL-0001` AML-7). Relationship service continues with FCC guidance. |
| 2026-08-12 | Meridian RM `EMP-300301` (same) confirms Meridian AP payments on time — Case 5 annual review context. |

## 3. Related

Case 3 investigation · `FAC-SME-88214401`

---

**End** — `ANB-CBK-RMN-88214401`
