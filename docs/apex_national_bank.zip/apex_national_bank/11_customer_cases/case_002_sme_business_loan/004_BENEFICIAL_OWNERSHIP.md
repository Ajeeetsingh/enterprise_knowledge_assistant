# Beneficial Ownership Certification

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-BO-88214401` |
| **Document Title** | Beneficial Ownership Certification |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | KYC Ops |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-06-12 |
| **Business Process** | `BP-ONB-KYC`, `ANB-CMP-POL-0002` |
| **System of Record** | ApexKYC |
| **Related Documents** | `KYC-202606-8821`, Case 1 mortgage joint applicant |


## 2. Beneficial Owners (≥25%)

| Name | CIF | Ownership | Control | DOB |
|---|---|---|---|---|
| Luis Miguel Alvarez | `CUS-03115591` | 100% | Managing Member | 1985-11-02 |

No other BO. Sofia R. Alvarez is spouse — **not** a BO of the LLC (no ownership interest).

## 3. Ambiguity Note

Apex360 initially suggested household "related party ownership" flag on Sofia — cleared 2026-06-13 after Operating Agreement review.

## 4. Related

Case 1 · Case 3 EDD

---

**End** — `DOC-BO-88214401`
