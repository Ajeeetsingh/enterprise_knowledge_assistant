# Collateral Valuation — SME

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `COLL-SME-88214401` |
| **Document Title** | Collateral Valuation — SME |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Credit Admin / Appraiser panel |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-21 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-POL-0002` |
| **System of Record** | ApexDocs |
| **Related Documents** | `FAC-SME-88214401`, UCC-1 filing ref |


## 2. Collateral Package

| Asset | Advance | NOLV / Value |
|---|---|---|
| Inventory | 50% | USD 95,000 → lendable 47,500 |
| AR (eligible) | 70% | USD 90,000 eligible → 63,000 |
| Equipment | 40% | USD 28,000 → 11,200 |
| **Total lendable support** | | **≈ 121,700** |
| Guaranty | Unsecured support | Luis Alvarez personal |

Facility USD 350k primarily cash-flow based with blanket UCC `COLL-SME-88214401`; collateral coverage partial — structured as secured term with guaranty per policy exception approved at Regional Credit.

## 3. Related

Legal opinion · Facility docs

---

**End** — `COLL-SME-88214401`
