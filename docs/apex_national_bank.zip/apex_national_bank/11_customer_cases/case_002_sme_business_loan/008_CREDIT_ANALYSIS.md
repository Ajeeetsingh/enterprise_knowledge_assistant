# SME Credit Analysis

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-CRA-88214401` |
| **Document Title** | SME Credit Analysis |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | `EMP-300302` / RM `EMP-300301` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-22 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-POL-0001`, `ANB-CBK-GDL-0001` |
| **System of Record** | ApexOrigin · ApexCredit |
| **Related Documents** | `FAC-SME-88214401`, Case 5 concentration, Case 1 household |


## 2. Recommendation

Approve USD 350,000 term loan, 60 months, interest **9.25%**, monthly principal & interest **USD 7,312.04**, secured by UCC all-assets + personal guaranty of Luis M. Alvarez. Risk rating **CRR-0004** (Watchful Average) due to start-up tenure mitigated by Meridian contract and guarantor FICO 711 / home equity via Case 1 (informational — **no mortgage cross-collateral**).

## 3. Key Risks / Mitigants

| Risk | Mitigant |
|---|---|
| Customer concentration Meridian | Contract through 2027; diversification plan |
| Short operating history | Guaranty + inventory audit rights |
| Household leverage (mortgage) | DTI personal already underwritten separately |

## 4. Related

Collateral · Legal opinion · Approval · `ANB-CBK-TPL-0003` structure

---

**End** — `ANB-CBK-CRA-88214401`
