# Sanctions Screening — Entity & BO

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `SCR-202606-8821` |
| **Document Title** | Sanctions Screening — Entity & BO |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Financial Crime Screening |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-06-12 |
| **Business Process** | `BP-AML-SCR`, `ANB-CMP-SOP-0005` |
| **System of Record** | ApexKYC / World-Check |
| **Related Documents** | `KYC-202606-8821`, Case 3 re-screen |


## 2. Results

| Subject | List hit | Disposition |
|---|---|---|
| Horizon Craft Supply LLC | None | Clear |
| Luis Miguel Alvarez | Name proximity noise | False positive — DOB/address diverge |
| Meridian (as related) | N/A — existing customer clear | — |

## 3. Related

Case 3 enhanced re-screen `SCR-202608-8821`

---

**End** — `SCR-202606-8821`
