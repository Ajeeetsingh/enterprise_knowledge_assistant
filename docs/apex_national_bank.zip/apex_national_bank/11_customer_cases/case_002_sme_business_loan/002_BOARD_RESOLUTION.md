# Board / Member Resolution — Borrowing Authority

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-BR-88214401` |
| **Document Title** | Board / Member Resolution — Borrowing Authority |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Legal / Credit Admin |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-15 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-POL-0001` |
| **System of Record** | ApexDocs |
| **Related Documents** | `FAC-SME-88214401`, `ANB-LEG-AGR` facility docs |


## 2. Resolution Extract

RESOLVED, that Luis Miguel Alvarez, Managing Member, is authorised to negotiate, execute, and deliver loan documents with Apex National Bank for a term facility up to **USD 350,000**, and to pledge collateral as required.

Adopted 2026-06-15. Single-member LLC consent in lieu of meeting.

## 3. Related

Facility letter · Loan agreement · Personal guaranty of Luis M. Alvarez

---

**End** — `DOC-BR-88214401`
