# Company Registration Package — Horizon Craft Supply LLC

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-REG-88214401` |
| **Document Title** | Company Registration Package — Horizon Craft Supply LLC |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Commercial Onboarding / RM `EMP-300301` Henry Bakshi (coverage assist) |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-10 |
| **Business Process** | `BP-CBK-ONB`, `ANB-CBK-SOP-0002` |
| **System of Record** | ApexKYC · ApexDocs · NC SOS |
| **Related Documents** | Case 2 set · Case 1 spouse · Case 5 Meridian supplier link · `ANB-CBK-GDL-0002` |


## 2. Entity

| Field | Value |
|---|---|
| Legal name | Horizon Craft Supply LLC |
| Trade name | Horizon Craft |
| Formation | North Carolina LLC — 2026-02-14 |
| SOS ID | NC-LLC-2026-441289 |
| EIN (masked) | **-***8821 |
| Bank CIF | `CUS-SME-88214401` |
| Registered office | 410 Westinghouse Blvd, Suite 120, Charlotte, NC 28273 |
| Industry | Wholesale — craft & industrial consumables (NAICS 424990) |
| RM | `EMP-300301` Henry Bakshi (intro via Meridian supply relationship) |

## 3. Timeline

Formed 2026-02-14 · Banking relationship opened 2026-06-12 · Facility `FAC-SME-88214401` approved 2026-06-28.

## 4. Cross Links

- Sole managing member Luis M. Alvarez — spouse of mortgage customer Sofia (`CUS-03115590`, Case 1).
- Primary receivable concentration: Meridian Advanced Materials Inc. `CORP-10000001` (Case 5).

## 5. Related

Board resolution · KYB · `ANB-CMP-POL-0002`

---

**End** — `DOC-REG-88214401`
