# SME Loan Agreement — Execution Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-LON-88214401` |
| **Document Title** | SME Loan Agreement — Execution Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Credit Documentation / Legal |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-07-02 |
| **Business Process** | `BP-CBK-CRD`, `BP-LEG-CTR` |
| **System of Record** | ApexDocs |
| **Related Documents** | `FAC-SME-88214401`, `LOAN-SME-88214401`, `ANB-CBK-CTR-0002` template lineage |


## 2. Key Terms

Borrower: Horizon Craft Supply LLC · Guarantor: Luis M. Alvarez · Principal USD 350,000 · Interest 9.25% · P&I monthly USD 7,312.04 · Maturity 2031-07-01 · Security: UCC blanket + guaranty.

## 3. Covenants

Min DSCR 1.20x tested annually · no additional liens without consent · information rights.

## 4. Related

Facility letter · Case 3 monitoring of payments · Case 5 Meridian

---

**End** — `ANB-LEG-LON-88214401`
