# Facility Letter — Horizon Craft Supply LLC

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CBK-FAC-88214401` |
| **Document Title** | Facility Letter — Horizon Craft Supply LLC |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | RM `EMP-300301` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-29 |
| **Business Process** | `BP-CBK-CRD` |
| **System of Record** | ApexDocs · Apex360 |
| **Related Documents** | `FAC-SME-88214401`, `ANB-CBK-APR-88214401` |


## 2. Offer Extract

Apex National Bank is pleased to offer a senior secured term loan facility of USD 350,000 on terms in the Approval of 2026-06-28. Acceptance via execution of loan documents by 2026-07-15.

Disbursement target: 2026-07-03 `PAY-SME-88214401` to operating account `ACC-8821440101`.

## 3. Related

Loan agreement · RM notes · Case 3 (post-disbursement alerts)

---

**End** — `ANB-CBK-FAC-88214401`
