# Financial Statements — Horizon Craft Supply LLC (Stub)

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-FIN-88214401` |
| **Document Title** | Financial Statements — Horizon Craft Supply LLC (Stub) |
| **Version** | 1.0 |
| **Case / Folder** | `case_002_sme_business_loan` |
| **Customer / Entity** | `CUS-SME-88214401` / Horizon Craft Supply LLC; BO `CUS-03115591` Luis M. Alvarez (household with `CUS-03115590`) |
| **Owner** | Credit Analyst `EMP-300302` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-06-18 |
| **Business Process** | `BP-CBK-CRD`, `ANB-CBK-GDL-0001` |
| **System of Record** | ApexOrigin · client Excel |
| **Related Documents** | `FAC-SME-88214401` |


## 2. Management Accounts (USD) — Feb–May 2026 annualised view

| Line | Stub 4 mo | Annualised |
|---|---|---|
| Revenue | 412,000 | 1,236,000 |
| COGS | 268,000 | 804,000 |
| Gross profit | 144,000 | 432,000 |
| Operating expenses | 96,000 | 288,000 |
| EBITDA (approx) | 48,000 | 144,000 |
| Cash | 62,400 | — |
| AR | 118,200 | — |
| Inventory | 95,000 | — |
| AP | 54,000 | — |

## 3. Quality Notes

Compiled, not audited. Spreadsheet columns shifted on "Balanee Sheet" tab (typo retained).

## 4. Related

Cash flow · Credit analysis · Meridian AR concentration ~41% of AR

---

**End** — `DOC-FIN-88214401`
