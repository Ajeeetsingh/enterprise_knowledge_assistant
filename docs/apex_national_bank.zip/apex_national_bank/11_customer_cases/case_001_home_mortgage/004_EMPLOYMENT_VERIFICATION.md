# Employment Verification — Sofia R. Alvarez

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-EMP-03115590` |
| **Document Title** | Employment Verification — Sofia R. Alvarez |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Operations / Underwriting |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-06 |
| **Business Process** | `BP-RTL-MTG`, `ANB-RTL-SOP-0005` |
| **System of Record** | ApexOrigin · ApexDocs |
| **Related Documents** | `APP-MTG-202605-2210`, salary slips, `ANB-RTL-POL-0003` |


## 2. Employer Confirmation

| Field | Value |
|---|---|
| Employer | Apex Digital Marketing LLC (unrelated to Bank brand) |
| Position | Marketing Manager |
| Start date | 2019-09-16 |
| Status | Full-time permanent |
| Annual base salary | USD 118,500 |
| Bonus (2025 actual) | USD 12,000 |
| VOE method | The Work Number + HR email 2026-05-05 |
| Verified by | `EMP-300205` (Mortgage Processor) |

## 3. Spouse Employment (joint)

Luis M. Alvarez — transitioning from W-2 at Meridian Advanced Materials (`CORP-10000001`) to owner-operator Horizon Craft Supply LLC (Case 2). Underwriting used: last 2 yrs W-2 + YTD K-1 estimate per `ANB-RTL-POL-0003` self-employed rules with PB exception note.

## 4. Timeline

VOE ordered 2026-05-03 · returned 2026-05-06 · filed under `APP-MTG-202605-2210`.

## 5. Related

Salary slips · Bank statement analysis · Credit assessment

---

**End** — `DOC-EMP-03115590`
