# Credit Risk Assessment — Mortgage

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-CRA-03115590` |
| **Document Title** | Credit Risk Assessment — Mortgage |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Credit / Mortgage UW |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-16 |
| **Business Process** | `BP-RTL-MTG`, `BP-RSK-CRED` |
| **System of Record** | ApexOrigin · ApexRisk |
| **Related Documents** | `APP-MTG-202605-2210`, `DOC-CBR-03115590`, `ANB-RTL-POL-0003`, `ANB-RSK-POL-0001` |


## 2. Risk Summary

| Factor | Assessment |
|---|---|
| FICO primary | 742 — Acceptable |
| LTV | 80% — Policy compliant |
| DTI | 36.2% final — within max |
| Reserves | 2.4 months PITIA |
| Collateral | Condo; appraisal supports |
| Layered risk | Spouse self-employment transition — mitigated with W-2 history + reserves |
| Model | Retail mortgage scorecard `MDL-` retail overlay |

**Risk rating recommendation:** Approve — Average risk.

## 3. Conditions Precedent

- Gift letter final  
- HOA cert  
- Clear title  
- Insurance binder  

## 4. Cross-references

Future AML Case 3 on spouse entity does **not** retroactively impair this closed-end mortgage underwriting decision; servicing overlay watch posted 2026-08-02.

---

**End** — `ANB-RTL-CRA-03115590`
