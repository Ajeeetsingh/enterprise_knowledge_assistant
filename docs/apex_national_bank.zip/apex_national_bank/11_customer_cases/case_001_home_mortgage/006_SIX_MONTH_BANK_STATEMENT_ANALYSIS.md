# Six-Month Bank Statement Analysis

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-BSA-03115590` |
| **Document Title** | Six-Month Bank Statement Analysis |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Underwriting |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-05-08 |
| **Business Process** | `BP-RTL-MTG` |
| **System of Record** | ApexOrigin · customer-provided PDF |
| **Related Documents** | `APP-MTG-202605-2210`, `CHK` statements Nov 2025–Apr 2026 |


## 2. Purpose

Validate income deposits, reserves, and NSF history for `MTG-202605-2210`.

## 3. Summary Metrics (joint deposit accounts reviewed)

| Metric | Value (USD) |
|---|---|
| Average balance (6 mo) | 18,640 |
| Lowest balance | 6,112 (2026-01-03 rent+holiday) |
| Payroll credits (Sofia) | 7,200 ± consistent |
| Large deposits >10k | 1 — 2026-03-18 USD 42,000 (gift from Elena Alvarez — gift letter on file `DOC-GIFT-03115590`) |
| NSF / OD | 0 in window |
| Gambling / crypto | None observed |

## 4. Reserves at Application

Checking + savings + gift remaining ≈ USD 51,400 after estimated closing → meets 2 mo PITIA reserves policy (`ANB-RTL-POL-0003`).

## 5. Cross-Case Flag (post-boarding annotation 2026-08)

AML Case 3 later reviewed outbound transfers from Luis business account — **not** present on Sofia personal statements in this window. Annotation added for investigator awareness; no change to mortgage underwriting conclusion.

## 6. Related

`DOC-GIFT-03115590` (gift letter excerpt in credit file) · Credit assessment · Case 3

---

**End** — `DOC-BSA-03115590`
