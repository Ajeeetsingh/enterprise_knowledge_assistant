# Identity Documents Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-ID-03115590` |
| **Document Title** | Identity Documents Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | KYC Operations |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-05-02 |
| **Business Process** | `BP-ONB-KYC` |
| **System of Record** | ApexKYC · ApexDocs |
| **Related Documents** | `KYC-202605-0311` |


## 2. Documents Reviewed

| Doc | Issuer | Number (masked) | Expiry | Result |
|---|---|---|---|---|
| NC Driver License | NCDMV | ****4412 | 2029-03-14 | Pass — photo match |
| US Passport | US DOS | ***** Mid pages on file | 2031-11-02 | Pass |
| Social Security card | SSA | ***-**-4412 | N/A | Visual; eCBSV |

## 3. Joint Applicant Luis M. Alvarez

| Doc | Result |
|---|---|
| NC DL ****8821 | Pass |
| Passport | Pass |

## 4. Notes

Secondary utility bill address matched prior East Blvd — annotated "prior address OK".

## 5. Related

`KYC-202605-0311` · `ANB-CST-PRF-03115590`

---

**End** — `DOC-ID-03115590`
