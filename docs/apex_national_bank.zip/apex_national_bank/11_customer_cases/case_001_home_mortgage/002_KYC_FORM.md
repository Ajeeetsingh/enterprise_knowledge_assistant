# KYC / CIP Form — Sofia R. Alvarez

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `KYC-202605-0311` |
| **Document Title** | KYC / CIP Form — Sofia R. Alvarez |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | KYC Operations / `EMP-300105` |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-05-02 |
| **Business Process** | `BP-ONB-KYC` |
| **System of Record** | ApexKYC |
| **Related Documents** | `ANB-CST-PRF-03115590`, `DOC-ID-03115590`, `ANB-CMP-GDL-0007`, `ANB-CMP-POL-0002` |


## 2. Purpose

Capture Customer Identification Programme (CIP) and CDD elements for mortgage underwriting and account maintenance.

## 3. CIP Elements

| Field | Response | Verification |
|---|---|---|
| Legal name | Sofia Rosa Alvarez | DL NC + Passport |
| DOB | 14 Mar 1987 | DL |
| Address | 1842 Belmont Avenue Apt 4B, Charlotte NC 28203 | Utility + DL |
| Identification | NC DL `DOC-ID-03115590` exp 2029-03-14 | Visual + barcode |
| SSN | Provided / TIN check pass | eCBSV pass 2026-05-02 |
| Expected activity | Payroll DD USD 7.2–7.8k/mo; mortgage debit; retail spend | Declared |

## 4. CDD Risk Factors

| Factor | Result |
|---|---|
| Product | Mortgage + deposit | Standard |
| Geography | US domestic | Low |
| PEP | Negative `PEP-202605-0311` | Clear |
| Sanctions | `SCR-202605-0311` clear | Clear |
| Overall | `CR-L` | Approved |

## 5. Joint Applicant

Luis Miguel Alvarez — separate CIP package attached; linked application `APP-MTG-202605-2210`.

## 6. Timeline

2026-05-01 intake → 2026-05-02 verification complete → linked to `MTG-202605-2210`.

## 7. Imperfections (record artefacts)

- Form field "Occupation" OCR read as "Marketlng Manager".
- Date stamped both `05/02/2026` and `2026-05-02` on scanned PDF pages.

## 8. Related Documents

`DOC-ID-03115590` · Employment verification · `ANB-CMP-GDL-0007` · Case 2 BO KYC for spouse entity

---

**End** — `KYC-202605-0311`
