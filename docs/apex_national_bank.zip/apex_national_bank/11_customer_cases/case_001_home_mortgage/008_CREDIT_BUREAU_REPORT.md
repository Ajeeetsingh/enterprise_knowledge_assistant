# Credit Bureau Report Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-CBR-03115590` |
| **Document Title** | Credit Bureau Report Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Underwriting |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-05-03 |
| **Business Process** | `BP-RTL-MTG` |
| **System of Record** | ApexOrigin (bureau gateway) |
| **Related Documents** | `APP-MTG-202605-2210` |


## 2. Scores (Tri-merge representative)

| Applicant | FICO (Classic) | Vantage | Derogs |
|---|---|---|---|
| Sofia R. Alvarez | **742** | 738 | None material |
| Luis M. Alvarez | **711** | 705 | One medical collection USD 220 paid 2025 |

## 3. Liabilities (monthly)

| Obligation | Monthly | Balance |
|---|---|---|
| Auto loan Sofia | 412 | 9,800 |
| Card Sofia | 85 (pmt) | 2,100 |
| Card Luis | 120 | 3,400 |
| Student loan Sofia | 210 | 14,200 |
| Proposed mortgage PITIA | 3,184 | — |

## 4. DTI

Qualifying income (Sofia W-2 + allowable Luis): USD 10,450 / mo.  
Total obligations incl. proposed PITIA: USD 4,011 → **DTI 38.4%** stated in policy example as ~36% with DU variance; final UW used **36.2%** after excluding paid collection and using documented overtime average — see credit assessment reconciliation note.

> Underwriter note (hand transcription): "DTI bridge 36.2% after OT avg — OK per ANB-RTL-POL-0003 §."

## 5. Related

Credit risk assessment · `ANB-RTL-POL-0003`

---

**End** — `DOC-CBR-03115590`
