# Mortgage Disbursement Record

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `PAY-MTG-202605-0099` |
| **Document Title** | Mortgage Disbursement Record |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Closing / Funding Ops |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-28 |
| **Business Process** | `BP-RTL-MTG`, `BP-PAY-DOM` |
| **System of Record** | ApexCore · ApexPay |
| **Related Documents** | `HLN-202605-0099`, `MTG-202605-2210` |


## 2. Funding

| Field | Value |
|---|---|
| Loan boarding ID | `HLN-202605-0099` |
| Fund date | 2026-05-28 |
| Wire to settlement | USD 416,000.00 principal (+ credits per CD) |
| Payment ID | `PAY-MTG-202605-0099` |
| Disbursement status | Completed |
| Boarded payment method | Auto-debit `ACC-1029384701` |

## 3. Timeline

CTC 2026-05-18 → Closing 2026-05-27 → Fund/board 2026-05-28.

## 4. Related

Repayment schedule · Case 6 (July debit posting issue)

---

**End** — `PAY-MTG-202605-0099`
