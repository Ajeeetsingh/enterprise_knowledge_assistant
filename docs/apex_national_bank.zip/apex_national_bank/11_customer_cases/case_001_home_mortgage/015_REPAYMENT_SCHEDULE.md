# Repayment Schedule — HLN-202605-0099

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `INST-MTG-03115590` |
| **Document Title** | Repayment Schedule — HLN-202605-0099 |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Loan Servicing |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-28 |
| **Business Process** | `BP-RTL-MTG` |
| **System of Record** | ApexCore |
| **Related Documents** | `HLN-202605-0099`, `ANB-LEG-MTG-03115590` |


## 2. Loan Terms Recap

Principal USD 416,000 · 6.625% · 360 months · P&I **USD 2,664.48** · Taxes/ins escrow estimate USD 519.52 · **Total PITIA USD 3,184.00**

## 3. First 12 Instalments

| Inst # | Due Date | P&I | Escrow | Total | Principal rem. (approx) |
|---|---|---|---|---|---|
| 1 | 2026-07-01 | 2,664.48 | 519.52 | 3,184.00 | 415,632.69 |
| 2 | 2026-08-01 | 2,664.48 | 519.52 | 3,184.00 | 415,263.35 |
| 3 | 2026-09-01 | 2,664.48 | 519.52 | 3,184.00 | 414,891.97 |
| 4 | 2026-10-01 | 2,664.48 | 519.52 | 3,184.00 | 414,518.54 |
| 5 | 2026-11-01 | 2,664.48 | 519.52 | 3,184.00 | 414,143.04 |
| 6 | 2026-12-01 | 2,664.48 | 519.52 | 3,184.00 | 413,765.46 |
| 7 | 2027-01-01 | 2,664.48 | 519.52 | 3,184.00 | 413,385.78 |
| 8 | 2027-02-01 | 2,664.48 | 519.52 | 3,184.00 | 413,003.99 |
| 9 | 2027-03-01 | 2,664.48 | 519.52 | 3,184.00 | 412,620.07 |
| 10 | 2027-04-01 | 2,664.48 | 519.52 | 3,184.00 | 412,234.01 |
| 11 | 2027-05-01 | 2,664.48 | 519.52 | 3,184.00 | 411,845.79 |
| 12 | 2027-06-01 | 2,664.48 | 519.52 | 3,184.00 | 411,455.40 |

## 4. Servicing Event

Instalment #1 debit 2026-07-01 initially showed as "pending/failed" during `INC-20260714-0001` payments latency — customer complaint Case 6; ultimately posted effective 2026-07-01 with no late fee (`CMP-202607-0311`).

## 5. Related

`ANB-OPS-INC-0001` · Case 6 · `PAY-MTG-202605-0099`

---

**End** — `INST-MTG-03115590`
