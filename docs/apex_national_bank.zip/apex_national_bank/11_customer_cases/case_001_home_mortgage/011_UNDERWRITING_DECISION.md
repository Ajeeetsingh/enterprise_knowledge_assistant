# Underwriting Decision

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-UWD-03115590` |
| **Document Title** | Underwriting Decision |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Underwriter (delegated authority) |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-18 |
| **Business Process** | `BP-RTL-MTG`, `ANB-RTL-SOP-0005` |
| **System of Record** | ApexOrigin |
| **Related Documents** | `ANB-RTL-CRA-03115590`, `MTG-202605-2210` |


## 2. Decision

| Field | Value |
|---|---|
| Decision | **Clear to Close (CTC)** |
| Decision ID | `ANB-RTL-UWD-03115590` |
| Authority | Per `ANB-ADM-MTX-0001` / mortgage delegation |
| Date | 2026-05-18 |
| Loan | USD 416,000 @ 6.625% / 360 months |

## 3. Approval Comments (system)

```
DU Approve/Eligible. Manual confirm condo warranty.
OT income averaged 24 months — OK.
Joint self-emp transitional — reserves strong.
```

## 4. Related

Loan approval memo · Agreement · `ANB-RTL-POL-0003`

---

**End** — `ANB-RTL-UWD-03115590`
