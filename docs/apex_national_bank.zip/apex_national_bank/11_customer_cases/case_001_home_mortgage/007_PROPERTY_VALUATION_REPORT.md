# Property Valuation Report

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `VAL-202605-4410` |
| **Document Title** | Property Valuation Report |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Appraisal Management / Underwriting |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-12 |
| **Business Process** | `BP-RTL-MTG`, `ANB-RTL-SOP-0005` |
| **System of Record** | ApexOrigin · Appraisal portal |
| **Related Documents** | `APP-MTG-202605-2210`, `MTG-202605-2210`, `COLL-MTG-03115590` |


## 2. Subject Property

| Field | Value |
|---|---|
| Address | 1842 Belmont Avenue, Apt 4B, Charlotte, NC 28203 |
| Type | Condo / attached |
| Purchase price | USD 520,000 |
| Appraised value | USD 522,000 |
| Appraisal ID | `VAL-202605-4410` |
| Appraiser | Piedmont Valuation Group (approved panel) |
| Inspection date | 2026-05-10 |
| Report date | 2026-05-12 |

## 3. LTV Calculation

Loan amount USD 416,000 / lesser of purchase or appraised (520,000) = **80.00% LTV**. Collateral ID `COLL-MTG-03115590`.

## 4. Conditions

Minor patio crack noted — not value-impairing. Condo questionnaire complete; HOA dues USD 310/mo included in DTI.

## 5. Related

Underwriting decision · Mortgage agreement · `ANB-RTL-POL-0003`

---

**End** — `VAL-202605-4410`
