# Salary Slips Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `DOC-PAY-03115590` |
| **Document Title** | Salary Slips Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Underwriting |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-05-06 |
| **Business Process** | `BP-RTL-MTG` |
| **System of Record** | ApexOrigin |
| **Related Documents** | `DOC-EMP-03115590` |


## 2. Pay Evidence (Sofia)

| Period | Gross | Net | Employer |
|---|---|---|---|
| 2026-02 | 9,875.00 | 7,210.44 | Apex Digital Marketing LLC |
| 2026-03 | 9,875.00 | 7,198.12 | same |
| 2026-04 | 9,875.00 | 7,205.90 | same |

YTD gross through Apr 2026: USD 39,500. Consistent with USD 118,500 annualized.

## 3. Artefacts

Payslip PDF page 2 skewed scan; net pay OCR initially `7205.9O` corrected manually by processor.

## 4. Related

Employment verification · Bank statement DD matches `ACC-1029384701`.

---

**End** — `DOC-PAY-03115590`
