# Customer Profile — Sofia R. Alvarez

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-CST-PRF-03115590` |
| **Document Title** | Customer Profile — Sofia R. Alvarez |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Retail Banking — Personal Banker `EMP-300105` Lucia Marchetti |
| **Classification** | Confidential (C2) / Restricted elements C3 |
| **Effective / As-Of** | 2026-05-02 |
| **Business Process** | `BP-ONB-KYC`, `BP-RTL-MTG`, `BP-CST-SERV` |
| **System of Record** | ApexCore · Apex360 · ApexKYC |
| **Related Documents** | `KYC-202605-0311`, `MTG-202605-2210`, `HLN-202605-0099`, `CHK-202608-0156`, `SAV-202608-0156`, Case 2 BO link, Case 6 `CMP-202607-0311` |


## 2. Purpose

Authoritative retail customer profile snapshot supporting mortgage origination `MTG-202605-2210` and ongoing servicing of `HLN-202605-0099`.

## 3. Scope

Individual retail relationship and joint mortgage applicants. Business ownership of spouse documented under Case 2 (`CUS-SME-88214401` / Horizon Craft Supply LLC).

## 4. Customer Identifiers

| Attribute | Value |
|---|---|
| CIF | `CUS-03115590` |
| Legacy CIF (merged 2022) | `CUS-02998801` (superseded — see §9) |
| Name (legal) | Sofia Rosa Alvarez |
| Name variants on file | Sofia R. Alvarez; S. Alvarez; Sofia Alvarez-Morales (maiden fragment on old utility bill) |
| DOB | 1987-03-14 |
| SSN (masked) | ***-**-4412 |
| Citizenship | United States |
| Primary phone (current) | +1-704-555-0188 (updated 2026-04-11) |
| Prior phone | +1-704-555-0091 (closed) |
| Email | sofia.alvarez.home@email.example |
| Branch of domicile | `BRN-0412` Charlotte Uptown / `SIT-0412` |
| RM / PB | `EMP-300105` Lucia Marchetti |
| Risk rating (CDD) | `CR-L` (personal); monitor spouse SME `CR-M` |

## 5. Addresses

| Type | Address | Status |
|---|---|---|
| Current residential | 1842 Belmont Avenue, Apt 4B, Charlotte, NC 28203 | Primary (since 2024-11) |
| Prior residential | 902 East Blvd, Charlotte, NC 28203 | Prior (2019–2024) |
| Mailing | Same as current | — |
| Employer | Apex Digital Marketing LLC, 200 S Tryon St, Charlotte, NC 28202 | Employment |

## 6. Product Holdings (as of 2026-05-02 / updated 2026-08)

| Product | ID | Status | Balance / Limit |
|---|---|---|---|
| Checking Essential | `CHK-202608-0156` / `ACC-1029384701` | Open | USD 6,842.17 |
| Savings | `SAV-202608-0156` / `ACC-1029384756` | Open | USD 4,200.00 avg |
| Mortgage (boarding) | `HLN-202605-0099` / `MTG-202605-2210` | Current | See repayment schedule |
| Debit card | `DBC-202608-0156` | Active | — |
| Closed legacy checking | `CHK-201903-2201` | Closed 2022-06 (merge) | 0.00 |

## 7. Household / Related Parties

| Party | Relationship | Notes |
|---|---|---|
| Luis Miguel Alvarez | Spouse / joint mortgage applicant | BO of Horizon Craft Supply LLC — Case 2; AML Case 3 subject |
| Elena Alvarez | Mother (emergency contact) | Not a Bank customer |
| Meridian Advanced Materials Inc. | Employer of Luis (W-2 historically); now customer of Horizon | Case 5 counterparty ecosystem |

## 8. Timeline

| Date | Event |
|---|---|
| 2019-08-12 | Original CIF `CUS-02998801` opened at `BRN-0412` |
| 2022-06-30 | Profile merge → surviving `CUS-03115590` |
| 2026-04-11 | Phone update; KYC refresh kickoff |
| 2026-05-02 | Mortgage application `APP-MTG-202605-2210` |
| 2026-05-28 | Loan boarded `HLN-202605-0099` |
| 2026-07-14 | Payment posting dispute window (Ops `INC-20260714-0001`) → Case 6 |
| 2026-07–08 | Spouse SME facility activity under AML review Case 3 |

## 9. Ambiguity / Data Quality Notes

- Merged CIF retained old address on one Apex360 fragment until 2026-05-03 patch (OCR import from scanned DL showed "Belrnont").
- Surname collision risk: teller `EMP-300106` Jamal **Robertson** ≠ customer Case 4 Jamal **K. Robertson** (`CUS-04928311`).
- Sanctions screening historically flagged "Ali" token false positive on joint wire memo (see `ANB-CMP-SOP-0005` example pattern) — disposition false positive `SCR-202608-0156` family.

## 10. Related Documents

Case 1 full set · Case 2 BO docs · Case 3 AML · Case 6 complaint · `ANB-RTL-POL-0003` · `ANB-RTL-SOP-0005` · `ANB-CMP-GDL-0007` · `ANB-ISC-STD-0004`

## 11. Classification Handling

PII and SSN elements: **Restricted (C3)** per `ANB-ISC-STD-0004` / `ANB-LEG-POL-0004`.

---

**End of Document** — `ANB-CST-PRF-03115590`
