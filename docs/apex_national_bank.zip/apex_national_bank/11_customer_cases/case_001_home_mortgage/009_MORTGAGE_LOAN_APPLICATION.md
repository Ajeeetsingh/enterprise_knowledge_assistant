# Mortgage Loan Application (URLA Summary)

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `APP-MTG-202605-2210` |
| **Document Title** | Mortgage Loan Application (URLA Summary) |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Origination `EMP-300205` |
| **Classification** | Restricted (C3) |
| **Effective / As-Of** | 2026-05-02 |
| **Business Process** | `BP-RTL-MTG`, `ANB-RTL-SOP-0005` |
| **System of Record** | ApexOrigin |
| **Related Documents** | `MTG-202605-2210`, `KYC-202605-0311`, `ANB-RTL-POL-0003` |


## 2. Loan Request

| Field | Value |
|---|---|
| Application ID | `APP-MTG-202605-2210` |
| Mortgage ID | `MTG-202605-2210` |
| Purpose | Purchase |
| Property | 1842 Belmont Ave Apt 4B, Charlotte NC |
| Purchase price | USD 520,000 |
| Base loan | USD 416,000 |
| Product | 30-year fixed conventional |
| Note rate | 6.625% |
| Lock | 2026-05-04 / 45 days |
| Applicants | Sofia R. Alvarez; Luis M. Alvarez (joint) |

## 3. Declarations

Bankruptcy/foreclosure: No. Occupancy: Primary. Citizenship: US both.

## 4. Timeline

| Date | Milestone |
|---|---|
| 2026-05-02 | Application taken — branch assist `BRN-0412` / PB `EMP-300105` |
| 2026-05-04 | Rate lock |
| 2026-05-12 | Appraisal in |
| 2026-05-18 | CTC |
| 2026-05-28 | Disbursement / boarding `HLN-202605-0099` |

## 5. Related

Full Case 1 package · `ANB-RTL-SOP-0005`

---

**End** — `APP-MTG-202605-2210`
