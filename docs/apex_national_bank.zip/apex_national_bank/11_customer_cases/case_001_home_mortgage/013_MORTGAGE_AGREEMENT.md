# Mortgage / Deed of Trust & Note — Execution Summary

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-LEG-MTG-03115590` |
| **Document Title** | Mortgage / Deed of Trust & Note — Execution Summary |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Closing Attorney / Credit Admin |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-27 |
| **Business Process** | `BP-RTL-MTG`, `BP-LEG-CTR` |
| **System of Record** | ApexDocs · County recordation |
| **Related Documents** | `HLN-202605-0099`, `MTG-202605-2210`, `ANB-LEG` mortgage templates, `COLL-MTG-03115590` |


## 2. Instrument Summary

| Field | Value |
|---|---|
| Note date | 2026-05-27 |
| Principal | USD 416,000.00 |
| Interest rate | 6.625% per annum |
| Maturity | 2056-06-01 |
| First payment due | 2026-07-01 |
| Property | 1842 Belmont Ave Apt 4B, Charlotte NC 28203 |
| Lien | First mortgage / DOT |
| Collateral ID | `COLL-MTG-03115590` |
| Borrowers | Sofia Rosa Alvarez; Luis Miguel Alvarez |

## 3. Covenants (extract)

Occupancy as primary residence; maintain insurance; no senior liens; due-on-sale standard.

## 4. Related Legal

Execution package retained ApexDocs; aligns consumer mortgage disclosure set (LE/CD) under retail compliance.

## 5. Cross Case

Borrower Luis also guarantor on SME facility Case 2 — **separate** obligation; no cross-default in this note to SME loan (confirmed by Legal 2026-05-26 email excerpt in file).

---

**End** — `ANB-LEG-MTG-03115590`
