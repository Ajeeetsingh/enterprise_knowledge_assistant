# Loan Approval Memo — Home Mortgage

---

## 1. Document Metadata

| Field | Value |
|---|---|
| **Document ID** | `ANB-RTL-MEM-03115590` |
| **Document Title** | Loan Approval Memo — Home Mortgage |
| **Version** | 1.0 |
| **Case / Folder** | `case_001_home_mortgage` |
| **Customer / Entity** | `CUS-03115590` Sofia R. Alvarez (joint: Luis M. Alvarez) |
| **Owner** | Mortgage Credit / `EMP-300205` |
| **Classification** | Confidential (C2) |
| **Effective / As-Of** | 2026-05-18 |
| **Business Process** | `BP-RTL-MTG` |
| **System of Record** | ApexDocs · ApexOrigin |
| **Related Documents** | `MTG-202605-2210`, `HLN-202605-0099`, `ANB-RTL-UWD-03115590` |


## 2. Memo Body

Recommend approval of conventional purchase mortgage for Sofia R. & Luis M. Alvarez, loan USD 416,000, 80% LTV, note rate 6.625%, property appraised USD 522,000 against purchase USD 520,000. Aligns with `ANB-RTL-POL-0003` and SOP `ANB-RTL-SOP-0005`.

Secondary market intent: FNMA eligible. MI: not required at 80% LTV.

## 3. Sign-offs

| Role | Name / ID | Date |
|---|---|---|
| Underwriter | System + named UW | 2026-05-18 |
| PB acknowledgement | `EMP-300105` | 2026-05-18 |

## 4. Related

Mortgage Agreement `ANB-LEG` retail mortgage form instance · Disbursement

---

**End** — `ANB-RTL-MEM-03115590`
